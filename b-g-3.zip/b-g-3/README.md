# Burger Cartel — Web Platform & Multi-Branch CMS

Welcome to the official web platform and Content Management System for **Burger Cartel**, an artisan burger restaurant brand across North Bengal (Darjeeling, Kurseong, Siliguri).

This repository contains the full production source code for both the customer-facing website and the administrative back-office portal.

---

## Features

- **Interactive Digital Menu:** Full categorization (Burgers, Pizzas, Croissants, Hot Dogs, Pasta, Mains, Breakfast, Beverages, Sides) with instant dietary filtering (Veg / Non-Veg / Favourites), branch-specific availability, and a master price display switch (ON/OFF).
- **Multi-Branch Operations:** Real-time operating hours, status (Open/Closed), temporary closure notices, and direct Google Maps navigation across all 5 branches.
- **Custom Dynamic Pages:** Back-office ability to publish custom marketing, catering, and event pages at `/p/[slug]` with zero developer deployment required.
- **Device Image Uploads:** Direct upload of food photography and banners from phone or desktop (`Select from device`) with instant thumbnail preview.
- **Live Reactive Synchronisation:** Built-in client event bus ensures that content edited in the admin panel updates customer sessions immediately without full page reloads.
- **Enterprise Security:** Scrypt password hashing, timing-safe equality, HTTP-only SameSite session cookies, IP + User-Agent integrity guards, atomic rate limiting, and hash-chained audit trails.
- **Performance & SEO:** Responsive WebP imagery, modern typography, JSON-LD structured restaurant schemas, dynamic XML sitemaps, and strict Content Security Policies.

---

## Tech Stack

- **Framework:** Next.js 16 (App Router with Turbopack)
- **UI Library:** React 19, Tailwind CSS v4, Lucide Icons, GSAP & Lenis Smooth Scroll
- **Database:** Neon PostgreSQL Serverless (`@neondatabase/serverless`)
- **Language:** TypeScript 5 (Strict Mode)

---

## Quickstart

### 1. Prerequisites
- Node.js 20.x or later
- npm or pnpm

### 2. Installation
```bash
npm install
```

### 3. Environment Configuration
Copy `.env.example` to `.env.local`:
```bash
cp .env.example .env.local
```

Ensure your `.env.local` contains your Neon PostgreSQL connection string:
```ini
DATABASE_URL=postgresql://neondb_owner:password@host/neondb?sslmode=require
SESSION_SECRET=your-random-64-char-hex-secret
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

### 4. Running the Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

### 5. Building for Production
```bash
npm run build
npm run start
```

---

## Admin Portal Access

The Content Management System is hosted at:
- **URL:** [http://localhost:3000/admin-panel](http://localhost:3000/admin-panel)
- **Initial Setup:** If accessing for the first time on a fresh database, visit the setup page to initialize your administrator credentials.

---

## Project Documentation

For in-depth architectural diagrams, database schema designs, security models, and developer guidelines, read [ARCHITECTURE.md](./ARCHITECTURE.md).

---

## License & Copyright

© 2026 Burger Cartel Private Limited. All rights reserved.
