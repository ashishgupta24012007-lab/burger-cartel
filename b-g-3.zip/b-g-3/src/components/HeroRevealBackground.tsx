"use client";

import React, { useEffect, useRef, useState } from "react";

interface HeroRevealBackgroundProps {
  heroRef: React.RefObject<HTMLElement | null>;
}

export default function HeroRevealBackground({
  heroRef,
}: HeroRevealBackgroundProps) {
  const [isInside, setIsInside] = useState(true);
  const revealLayerRef = useRef<HTMLDivElement>(null);

  // Position references for smooth cursor lerping, mobile touch & idle floating drift
  const stateRef = useRef({
    currentX: -500,
    currentY: -500,
    targetX: -500,
    targetY: -500,
    isUserActive: false,
    lastUserActivity: 0,
    hasInitialized: false,
    isTouchDevice: false,
    tiltX: 0,
    tiltY: 0,
    hasGyro: false,
  });

  useEffect(() => {
    const heroEl = heroRef.current;
    if (!heroEl) return;

    let rafId: number = 0;
    let isVisibleOnScreen = true;

    // Detect if device requests reduced motion
    const prefersReducedMotion =
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    // Detect if device supports touch
    if (typeof window !== "undefined") {
      stateRef.current.isTouchDevice =
        "ontouchstart" in window ||
        navigator.maxTouchPoints > 0 ||
        window.matchMedia("(pointer: coarse)").matches;
    }

    const updateTarget = (clientX: number, clientY: number) => {
      const rect = heroEl.getBoundingClientRect();
      const x = clientX - rect.left;
      const y = clientY - rect.top;

      stateRef.current.targetX = x;
      stateRef.current.targetY = y;
      stateRef.current.isUserActive = true;
      stateRef.current.lastUserActivity = performance.now();

      if (!stateRef.current.hasInitialized) {
        stateRef.current.currentX = x;
        stateRef.current.currentY = y;
        stateRef.current.hasInitialized = true;
      }

      setIsInside(true);
    };

    // Desktop Mouse Events
    const handleMouseMove = (e: MouseEvent) => {
      updateTarget(e.clientX, e.clientY);
    };

    const handleMouseEnter = (e: MouseEvent) => {
      updateTarget(e.clientX, e.clientY);
    };

    const handleMouseLeave = () => {
      stateRef.current.isUserActive = false;
      if (!stateRef.current.isTouchDevice) {
        setIsInside(false);
      }
    };

    // Mobile & Touchscreen Events: Seamless finger tracking across the hero
    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        const touch = e.touches[0];
        const rect = heroEl.getBoundingClientRect();
        if (
          touch.clientY >= rect.top &&
          touch.clientY <= rect.bottom &&
          touch.clientX >= rect.left &&
          touch.clientX <= rect.right
        ) {
          updateTarget(touch.clientX, touch.clientY);
        }
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        const touch = e.touches[0];
        const rect = heroEl.getBoundingClientRect();
        if (
          touch.clientY >= rect.top &&
          touch.clientY <= rect.bottom &&
          touch.clientX >= rect.left &&
          touch.clientX <= rect.right
        ) {
          updateTarget(touch.clientX, touch.clientY);
        }
      }
    };

    const handleTouchEnd = () => {
      stateRef.current.isUserActive = false;
      stateRef.current.lastUserActivity = performance.now();
    };

    // DeviceOrientation (Gyroscope Tilt on Mobile)
    const handleOrientation = (e: DeviceOrientationEvent) => {
      if (e.gamma !== null && e.beta !== null) {
        // Clamp gamma (roll left-right: -30 to 30) and beta (pitch: 20 to 70 for typical viewing angle)
        const g = Math.max(-30, Math.min(30, e.gamma));
        const b = Math.max(-25, Math.min(25, e.beta - 45));
        stateRef.current.tiltX = g / 30; // normalized -1 to 1
        stateRef.current.tiltY = b / 25; // normalized -1 to 1
        stateRef.current.hasGyro = true;
      }
    };

    // Attach listeners
    heroEl.addEventListener("mousemove", handleMouseMove, { passive: true });
    heroEl.addEventListener("mouseenter", handleMouseEnter);
    heroEl.addEventListener("mouseleave", handleMouseLeave);

    // Global touch tracking so drags over buttons and texts still smoothly move the spotlight
    window.addEventListener("touchstart", handleTouchStart, { passive: true });
    window.addEventListener("touchmove", handleTouchMove, { passive: true });
    window.addEventListener("touchend", handleTouchEnd, { passive: true });
    window.addEventListener("touchcancel", handleTouchEnd, { passive: true });

    if (typeof window !== "undefined" && "DeviceOrientationEvent" in window) {
      window.addEventListener("deviceorientation", handleOrientation, {
        passive: true,
      });
    }

    // Smooth render loop with easing / lerp & gentle idle floating drift
    const animate = (time: number) => {
      if (!isVisibleOnScreen) {
        rafId = 0;
        return;
      }

      const s = stateRef.current;
      const rect = heroEl.getBoundingClientRect();
      const width = rect.width || window.innerWidth;
      const height = rect.height || window.innerHeight;
      const isMobile = width < 768;

      // Initial center placement if not yet moved
      if (!s.hasInitialized) {
        s.currentX = width * 0.5;
        s.currentY = isMobile ? height * 0.42 : height * 0.45;
        s.targetX = s.currentX;
        s.targetY = s.currentY;
        s.hasInitialized = true;
      }

      // If user requested reduced motion, stop loop after initial placement
      if (prefersReducedMotion) {
        if (revealLayerRef.current) {
          const radius = isMobile ? 130 : 260;
          const mask = `radial-gradient(circle ${radius}px at ${s.currentX}px ${s.currentY}px, black 0%, black 65%, rgba(0, 0, 0, 0.4) 86%, transparent 100%)`;
          revealLayerRef.current.style.webkitMaskImage = mask;
          revealLayerRef.current.style.maskImage = mask;
        }
        rafId = 0;
        return;
      }

      // If user is idle (especially on mobile before first touch or between touches), gently drift
      const timeSinceUser = performance.now() - s.lastUserActivity;
      if (!s.isUserActive && (timeSinceUser > 1200 || s.lastUserActivity === 0)) {
        const t = time * 0.0009;
        const driftAmplitudeX = isMobile ? width * 0.32 : width * 0.22;
        const driftAmplitudeY = isMobile ? height * 0.2 : height * 0.16;

        let calculatedTargetX =
          width * 0.5 + Math.cos(t * 1.1) * driftAmplitudeX;
        let calculatedTargetY =
          height * (isMobile ? 0.46 : 0.48) +
          Math.sin(t * 1.7) * driftAmplitudeY;

        // Apply gyro tilt influence if available on mobile
        if (s.hasGyro) {
          calculatedTargetX += s.tiltX * (width * 0.25);
          calculatedTargetY += s.tiltY * (height * 0.2);
        }

        s.targetX = calculatedTargetX;
        s.targetY = calculatedTargetY;
      }

      // Smooth lerp easing (factor 0.1)
      s.currentX += (s.targetX - s.currentX) * 0.1;
      s.currentY += (s.targetY - s.currentY) * 0.1;

      if (revealLayerRef.current) {
        // Spotlight radius: properly scaled for mobile viewports (no blowout) vs desktop
        const radius = isMobile
          ? Math.max(120, Math.min(width * 0.36, 145))
          : 260;

        const mask = `radial-gradient(circle ${radius.toFixed(1)}px at ${s.currentX.toFixed(1)}px ${s.currentY.toFixed(1)}px, black 0%, black 65%, rgba(0, 0, 0, 0.4) 86%, transparent 100%)`;

        revealLayerRef.current.style.webkitMaskImage = mask;
        revealLayerRef.current.style.maskImage = mask;
      }

      rafId = requestAnimationFrame(animate);
    };

    // IntersectionObserver pauses the RAF loop when user scrolls past hero section, saving CPU/battery on mobile
    const observer = new IntersectionObserver(
      ([entry]) => {
        isVisibleOnScreen = entry.isIntersecting;
        if (isVisibleOnScreen && !rafId && !prefersReducedMotion) {
          rafId = requestAnimationFrame(animate);
        } else if (!isVisibleOnScreen && rafId) {
          cancelAnimationFrame(rafId);
          rafId = 0;
        }
      },
      { threshold: 0.05 }
    );
    observer.observe(heroEl);

    if (!prefersReducedMotion) {
      rafId = requestAnimationFrame(animate);
    } else {
      animate(0);
    }

    return () => {
      observer.disconnect();
      heroEl.removeEventListener("mousemove", handleMouseMove);
      heroEl.removeEventListener("mouseenter", handleMouseEnter);
      heroEl.removeEventListener("mouseleave", handleMouseLeave);
      window.removeEventListener("touchstart", handleTouchStart);
      window.removeEventListener("touchmove", handleTouchMove);
      window.removeEventListener("touchend", handleTouchEnd);
      window.removeEventListener("touchcancel", handleTouchEnd);
      if (typeof window !== "undefined" && "DeviceOrientationEvent" in window) {
        window.removeEventListener("deviceorientation", handleOrientation);
      }
      if (rafId) {
        cancelAnimationFrame(rafId);
      }
    };
  }, [heroRef]);

  return (
    <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none select-none bg-black">
      {/* ================= 1. BASE LAYER (BG_IMAGE_1 - Pure Dark Night Atmosphere) ================= */}
      <div className="absolute inset-0 w-full h-full overflow-hidden">
        <picture className="w-full h-full block">
          {/* Mobile & Portrait WebP */}
          <source
            type="image/webp"
            media="(orientation: portrait), (max-width: 768px)"
            srcSet="/images/hero-base-mobile.webp"
          />
          {/* Desktop WebP */}
          <source
            type="image/webp"
            srcSet="/images/hero-base.webp"
          />
          <img
            src="/images/hero-base.webp"
            alt="BURGER CARTEL Atmosphere"
            fetchPriority="high"
            decoding="async"
            className="w-full h-full object-cover object-bottom sm:object-center"
            loading="eager"
          />
        </picture>
        {/* Subtle, smooth ambient darkening for rich atmosphere */}
        <div className="absolute inset-0 bg-black/35" />
      </div>

      {/* ================= 2. REVEAL LAYER (BG_IMAGE_2 - Pure Daylight Atmosphere) ================= */}
      <div
        ref={revealLayerRef}
        className="absolute inset-0 w-full h-full transition-opacity duration-300 ease-out"
        style={{
          opacity: isInside ? 1 : 0,
          pointerEvents: "none",
          WebkitMaskRepeat: "no-repeat",
          maskRepeat: "no-repeat",
        }}
      >
        <picture className="w-full h-full block">
          {/* Mobile & Portrait WebP */}
          <source
            type="image/webp"
            media="(orientation: portrait), (max-width: 768px)"
            srcSet="/images/hero-reveal-mobile.webp"
          />
          {/* Desktop WebP */}
          <source
            type="image/webp"
            srcSet="/images/hero-reveal.webp"
          />
          <img
            src="/images/hero-reveal.webp"
            alt="BURGER CARTEL Daylight Atmosphere"
            decoding="async"
            className="w-full h-full object-cover object-bottom sm:object-center"
            loading="eager"
          />
        </picture>
        {/* Atmosphere & contrast shield: subtle warm vignette ensuring text remains 100% crisp and readable while keeping food vivid */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/55 via-black/35 to-black/15 pointer-events-none" />
      </div>
    </div>
  );
}
