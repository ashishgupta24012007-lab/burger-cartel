"use client";

import React, { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { Clock, Flame, ArrowUpRight } from "lucide-react";
import {
  BRANCH_ACTIVITIES,
  BranchActivity,
} from "@/data/branchActivityData";

interface BranchActivitySectionProps {
  onOpenLocation?: () => void;
}

// -------------------------------------------------------------------
// CUTE, AESTHETIC COMPACT BRANCH RHYTHM CARD
// -------------------------------------------------------------------
function CuteBranchCard({
  branch,
  branchIndex,
  isVisible,
}: {
  branch: BranchActivity;
  branchIndex: number;
  isVisible: boolean;
}) {
  const defaultDay = branch.verifiedDay;
  const dayData = branch.days[defaultDay];
  const [hoveredHour, setHoveredHour] = useState<number | null>(null);

  // Peak hour calculation
  const peakHourItem = dayData.hours.reduce((max, h) =>
    h.activity > max.activity ? h : max
  );

  const activeHourItem =
    hoveredHour !== null
      ? dayData.hours.find((h) => h.hour === hoveredHour)
      : null;

  return (
    <div className="neu-cream-card rounded-2xl p-4 sm:p-5 flex flex-col justify-between hover:-translate-y-1 transition-all duration-300 border border-white/80 group">
      <div>
        {/* Top Header: Cute Index, Branch Name, and Peak Badge */}
        <div className="flex items-start justify-between gap-2 mb-3">
          <div>
            <div className="flex items-center gap-1.5 text-[9px] font-bold tracking-[0.18em] uppercase text-[#B18B5B]">
              <span>0{branchIndex}</span>
              <span>·</span>
              <span className="text-[#736F67]">{branch.neighborhood}</span>
            </div>
            <Link
              href={`/locations/${branch.id}`}
              className="text-base sm:text-lg font-black uppercase text-[#1F2B20] tracking-tight hover:text-[#B18B5B] transition-colors inline-flex items-center gap-1 group/title"
            >
              <span>{branch.shortName}</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-[#B18B5B] opacity-0 group-hover/title:opacity-100 transition-opacity" />
            </Link>
          </div>

          {/* Cute Live/Peak Pill */}
          <div className="shrink-0 flex items-center gap-1 px-2.5 py-0.8 rounded-full bg-[#FAF7F0] border border-[#B18B5B]/30 text-[10px] font-bold text-[#1F2B20] shadow-2xs">
            <Flame className="w-3 h-3 text-[#E05D5D] fill-[#E05D5D]" />
            <span>Peak {peakHourItem.displayHour}</span>
          </div>
        </div>

        {/* Cute Minimal Bar Chart (No Scientific Gridlines!) */}
        <div className="relative pt-2 pb-1">
          {/* Chart well */}
          <div className="h-18 sm:h-20 w-full rounded-xl p-2.5 flex items-end justify-between gap-1 neu-cream-inset bg-[#ECE5D8]/80 relative overflow-hidden">
            {dayData.hours.map((h, idx) => {
              const isPeak = h.hour === peakHourItem.hour;
              const isHovered = hoveredHour === h.hour;
              const targetHeight = isVisible ? Math.max(12, h.activity) : 0;
              const delay = `${idx * 40}ms`;

              // Cute gradient: warm honey for peak, cozy slate for regular
              let barColor = "bg-[#5A6474]/80 hover:bg-[#1F2B20]";
              if (isPeak) {
                barColor = "bg-gradient-to-t from-[#D9822B] to-[#F2A65A] shadow-[0_0_8px_rgba(242,166,90,0.6)]";
              } else if (isHovered) {
                barColor = "bg-gradient-to-t from-[#2563EB] to-[#60A5FA]";
              }

              return (
                <div
                  key={h.hour}
                  className="relative flex-1 h-full flex flex-col justify-end items-center cursor-pointer group/bar"
                  onMouseEnter={() => setHoveredHour(h.hour)}
                  onMouseLeave={() => setHoveredHour(null)}
                >
                  <div
                    style={{
                      height: `${targetHeight}%`,
                      transition: `height 1100ms cubic-bezier(0.16, 1, 0.3, 1) ${delay}`,
                    }}
                    className={`w-full max-w-[10px] sm:max-w-[12px] rounded-full transition-transform duration-150 ${barColor} ${
                      isHovered ? "scale-115" : "group-hover/bar:scale-105"
                    }`}
                  />
                </div>
              );
            })}
          </div>

          {/* Cute Time Axis */}
          <div className="flex items-center justify-between text-[9px] font-mono text-[#736F67] px-1 mt-1.5">
            <span>9a</span>
            <span>12p</span>
            <span>3p</span>
            <span>6p</span>
            <span>9p</span>
          </div>
        </div>

        {/* Cute Status & Operating Hours Row */}
        <div className="pt-2 mt-1 border-t border-[#E8DED0]/60 flex items-center justify-between text-[10px] text-[#4A4843]">
          <div className="flex items-center gap-1.5 font-bold text-[#1F2B20]">
            <Clock className="w-3 h-3 text-[#B18B5B]" />
            <span>{activeHourItem ? `${activeHourItem.displayHour}: ${activeHourItem.status}` : branch.operatingHours}</span>
            {!activeHourItem && (
              <span className="text-[#8B8880] font-normal text-[9px] hidden sm:inline">Daily</span>
            )}
          </div>
          <span className="text-[9px] font-semibold text-[#736F67] shrink-0">
            {activeHourItem ? `${activeHourItem.activity}% flow` : branch.typicalDwellTime.replace("People typically spend ", "").replace(" here", "")}
          </span>
        </div>
      </div>
    </div>
  );
}

// -------------------------------------------------------------------
// MAIN SECTION: CUTE & COMPACT BRANCH ACTIVITY
// -------------------------------------------------------------------
export default function BranchActivitySection({}: BranchActivitySectionProps) {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsVisible(true);
          }
        });
      },
      { threshold: 0.1 }
    );

    const el = sectionRef.current;
    if (el) observer.observe(el);

    return () => {
      if (el) observer.unobserve(el);
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      id="branch-activity"
      className="relative z-10 py-12 sm:py-16 px-4 sm:px-6 md:px-10 bg-[#F5F0E7] text-[#292925] border-t border-[#E8DED0] overflow-hidden"
    >
      <div className="max-w-6xl mx-auto">
        {/* =========================================================
            COMPACT SECTION HEADER
            ========================================================= */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-5 border-b border-[#E8DED0] gap-3 mb-6">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full neu-cream-pill text-[10px] font-bold tracking-[0.2em] text-[#B18B5B] uppercase mb-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#B18B5B] animate-pulse" />
              <span>POPULAR TIMES &amp; HOURLY RHYTHM</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black uppercase tracking-tight text-[#1F2B20]">
              Every Branch Has Its Rush.
            </h2>
          </div>

          <p className="text-xs text-[#736F67] max-w-sm sm:text-right">
            Hourly dining flow inspired by Google Maps Popular Times data across all five locations.
          </p>
        </div>

        {/* =========================================================
            5 CUTE COMPACT CARDS IN A BALANCED GRID (3 + 2)
            ========================================================= */}
        {/* Row 1: Panchanai, Pradhan Nagar, Darjeeling */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 mb-4 sm:mb-5">
          <CuteBranchCard
            branch={BRANCH_ACTIVITIES[0]}
            branchIndex={1}
            isVisible={isVisible}
          />
          <CuteBranchCard
            branch={BRANCH_ACTIVITIES[1]}
            branchIndex={2}
            isVisible={isVisible}
          />
          <CuteBranchCard
            branch={BRANCH_ACTIVITIES[2]}
            branchIndex={3}
            isVisible={isVisible}
          />
        </div>

        {/* Row 2: Kurseong, Shivmandir (Centered 2-card layout) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5 max-w-4xl mx-auto">
          <CuteBranchCard
            branch={BRANCH_ACTIVITIES[3]}
            branchIndex={4}
            isVisible={isVisible}
          />
          <CuteBranchCard
            branch={BRANCH_ACTIVITIES[4]}
            branchIndex={5}
            isVisible={isVisible}
          />
        </div>

        {/* Bottom Minimal Legend */}
        <div className="mt-6 pt-4 border-t border-[#E8DED0] flex flex-col sm:flex-row items-center justify-between gap-2 text-[10px] text-[#736F67]">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-[#F2A65A]" />
              <span>Peak Hours</span>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-[#5A6474]" />
              <span>Normal Flow</span>
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-[#2563EB]" />
              <span>Hover to Inspect</span>
            </span>
          </div>

          <div className="flex items-center gap-3">
            <Link
              href="/locations"
              className="text-[#1F2B20] hover:text-[#B18B5B] font-bold uppercase tracking-wider transition-colors inline-flex items-center gap-1"
            >
              <span>Explore All 5 Outlets &amp; Maps</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-[#B18B5B]" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
