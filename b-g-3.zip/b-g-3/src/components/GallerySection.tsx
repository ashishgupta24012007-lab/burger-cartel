"use client";

import React, { useState, useEffect, useCallback } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  Maximize2,
  X,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  Sparkles,
} from "lucide-react";
import { GALLERY_ITEMS, GalleryItem } from "@/data/galleryData";
import { fetchCmsContentOnce } from "@/lib/client/cmsClient";

type CategoryFilter = "all" | "burgers" | "food" | "interiors" | "outlets";

const CATEGORIES: { id: CategoryFilter; label: string }[] = [
  { id: "all", label: "ALL" },
  { id: "burgers", label: "BURGERS" },
  { id: "food", label: "FOOD & DRINKS" },
  { id: "interiors", label: "INTERIORS" },
  { id: "outlets", label: "OUTLETS" },
];

export default function GallerySection() {
  const [activeCategory, setActiveCategory] = useState<CategoryFilter>("all");
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>(GALLERY_ITEMS);

  useEffect(() => {
    let mounted = true;
    async function loadCmsGallery() {
      const data = await fetchCmsContentOnce();
      if (!mounted) return;
      if (Array.isArray(data?.gallery)) {
        setGalleryItems(
          data.gallery.map((item, idx) => {
            const fallback =
              GALLERY_ITEMS.find((g) => g.id === item.id) ||
              GALLERY_ITEMS[idx % GALLERY_ITEMS.length];
            return {
              id: item.id,
              title: item.title,
              category: item.category,
              categoryLabel: item.categoryLabel || fallback?.categoryLabel || "Burgers",
              src: item.src,
              alt: item.alt || fallback?.alt || item.title,
              description: item.description || fallback?.description || "",
              aspect: fallback?.aspect || "standard",
              width: fallback?.width || 800,
              height: fallback?.height || 600,
              featured: Boolean(item.featured),
            };
          })
        );
      }
    }
    loadCmsGallery();

    const handleCmsUpdate = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail && Array.isArray(customEvent.detail.gallery)) {
        setGalleryItems(
          customEvent.detail.gallery.map((item: GalleryItem, idx: number) => {
            const fallback =
              GALLERY_ITEMS.find((g) => g.id === item.id) ||
              GALLERY_ITEMS[idx % GALLERY_ITEMS.length];
            return {
              id: item.id,
              title: item.title,
              category: item.category,
              categoryLabel: item.categoryLabel || fallback?.categoryLabel || "Burgers",
              src: item.src,
              alt: item.alt || fallback?.alt || item.title,
              description: item.description || fallback?.description || "",
              aspect: fallback?.aspect || "standard",
              width: fallback?.width || 800,
              height: fallback?.height || 600,
              featured: Boolean(item.featured),
            };
          })
        );
      }
    };

    window.addEventListener("cms:updated", handleCmsUpdate);
    return () => {
      mounted = false;
      window.removeEventListener("cms:updated", handleCmsUpdate);
    };
  }, []);

  // Filter items
  const filteredItems =
    activeCategory === "all"
      ? galleryItems
      : galleryItems.filter((item) => item.category === activeCategory);

  // Lightbox keyboard navigation (Escape to close, Arrows to cycle)
  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (lightboxIndex === null) return;

      if (e.key === "Escape") {
        setLightboxIndex(null);
      } else if (e.key === "ArrowRight") {
        setLightboxIndex((prev) =>
          prev !== null ? (prev + 1) % filteredItems.length : 0
        );
      } else if (e.key === "ArrowLeft") {
        setLightboxIndex((prev) =>
          prev !== null
            ? (prev - 1 + filteredItems.length) % filteredItems.length
            : 0
        );
      }
    },
    [lightboxIndex, filteredItems.length]
  );

  useEffect(() => {
    if (lightboxIndex !== null) {
      document.body.style.overflow = "hidden";
      window.addEventListener("keydown", handleKeyDown);
    } else {
      document.body.style.overflow = "";
    }

    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [lightboxIndex, handleKeyDown]);

  const activeLightboxItem: GalleryItem | null =
    lightboxIndex !== null ? filteredItems[lightboxIndex] : null;

  return (
    <section
      id="gallery"
      className="relative z-10 pt-10 sm:pt-14 md:pt-16 pb-16 sm:pb-20 md:pb-24 px-4 sm:px-6 md:px-10 lg:px-14 bg-[#F5F0E7] text-[#292925] border-t border-[#E8DED0] overflow-hidden"
    >
      <div className="max-w-6xl mx-auto">
        {/* =========================================================
            1. EDITORIAL HEADER & CAPTION
            ========================================================= */}
        <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-[#E8DED0] pb-5 sm:pb-6 mb-8 sm:mb-10 gap-5">
          <div>
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full neu-cream-pill text-[10px] sm:text-[11px] font-bold tracking-[0.22em] text-[#B18B5B] uppercase mb-2.5">
              <Sparkles className="w-3 h-3 text-[#B18B5B]" />
              <span>INSIDE BURGER CARTEL · VISUAL GALLERY</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black uppercase tracking-tight text-[#1F2B20] leading-tight">
              A TASTE OF THE CARTEL
            </h2>
            <p className="text-xs sm:text-sm text-[#B18B5B] font-bold tracking-[0.16em] uppercase mt-1">
              Big flavours. Bold cravings. Good times.
            </p>
          </div>

          <p className="text-xs sm:text-[13px] text-[#4A4843] max-w-md leading-relaxed font-normal">
            A visual journey through our handcrafted smashed burgers, artisan
            wood-fired pizzas, specialty Himalayan brews, and cozy dining spaces
            across North Bengal.
          </p>
        </div>

        {/* =========================================================
            2. CATEGORY FILTER BAR
            ========================================================= */}
        <div className="flex items-center justify-between gap-2 mb-8 overflow-x-auto pb-2 scrollbar-none">
          <div
            role="tablist"
            aria-label="Gallery filters"
            className="flex items-center gap-1.5 sm:gap-2"
          >
            {CATEGORIES.map((cat) => {
              const isSelected = activeCategory === cat.id;
              const count =
                cat.id === "all"
                  ? GALLERY_ITEMS.length
                  : GALLERY_ITEMS.filter((i) => i.category === cat.id).length;

              return (
                <button
                  key={cat.id}
                  role="tab"
                  aria-selected={isSelected}
                  onClick={() => {
                    setActiveCategory(cat.id);
                    setLightboxIndex(null);
                  }}
                  className={`px-3.5 sm:px-4 py-1.5 sm:py-2 rounded-full text-[10px] sm:text-xs font-bold tracking-[0.16em] uppercase transition-all duration-200 cursor-pointer select-none ${
                    isSelected
                      ? "neu-cream-inset text-[#1F2B20] border border-[#B18B5B]/50 font-black"
                      : "neu-cream-pill text-[#736F67] hover:text-[#1F2B20] hover:bg-white"
                  }`}
                >
                  <span>{cat.label}</span>
                  <span className="ml-1.5 opacity-60 text-[9px]">({count})</span>
                </button>
              );
            })}
          </div>

          <span className="hidden sm:inline-block text-[11px] font-mono text-[#736F67]">
            {filteredItems.length} PHOTOGRAPHS
          </span>
        </div>

        {/* =========================================================
            3. ASYMMETRICAL EDITORIAL GALLERY GRID
            ========================================================= */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
          {filteredItems.map((item, idx) => {
            // Asymmetrical span logic: feature cards get larger prominence
            const isFirst = idx === 0 && activeCategory === "all";
            const isWide = item.aspect === "wide";

            return (
              <div
                key={item.id}
                onClick={() => setLightboxIndex(idx)}
                className={`group relative neu-cream-card rounded-2xl overflow-hidden cursor-pointer transition-all duration-300 hover:-translate-y-1 hover:shadow-xl ${
                  isFirst
                    ? "sm:col-span-2 lg:col-span-2 lg:row-span-2 min-h-[380px] sm:min-h-[460px]"
                    : isWide
                    ? "sm:col-span-2 lg:col-span-1 min-h-[260px] sm:min-h-[290px]"
                    : "min-h-[280px] sm:min-h-[320px]"
                } flex flex-col justify-end`}
              >
                {/* Image Container with Smooth Zoom on Hover */}
                <div className="absolute inset-0 w-full h-full bg-[#E8DED0]">
                  <Image
                    src={item.src}
                    alt={item.alt}
                    fill
                    sizes={
                      isFirst
                        ? "(max-width: 768px) 100vw, 66vw"
                        : "(max-width: 768px) 100vw, 33vw"
                    }
                    className="object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                    loading="lazy"
                  />
                </div>

                {/* Subtle Protective Gradient Vignette */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity duration-300 pointer-events-none" />

                {/* Top Right Zoom Icon Tag */}
                <div className="absolute top-3.5 right-3.5 w-8 h-8 rounded-full bg-black/40 backdrop-blur-md border border-white/20 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-all duration-300 scale-90 group-hover:scale-100">
                  <Maximize2 className="w-3.5 h-3.5" />
                </div>

                {/* Card Content Overlay */}
                <div className="relative z-10 p-4 sm:p-5 text-white">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="inline-block px-2.5 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider bg-black/50 backdrop-blur-md border border-white/20 text-[#F2A65A]">
                      {item.categoryLabel}
                    </span>
                    {item.featured && (
                      <span className="inline-block px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider bg-[#B18B5B] text-white">
                        SIGNATURE
                      </span>
                    )}
                  </div>

                  <h3
                    className={`${
                      isFirst
                        ? "text-xl sm:text-2xl md:text-3xl"
                        : "text-base sm:text-lg"
                    } font-black uppercase tracking-tight text-white leading-snug drop-shadow-md`}
                  >
                    {item.title}
                  </h3>

                  <p
                    className={`text-[11px] sm:text-xs text-zinc-300 mt-1 line-clamp-2 leading-relaxed ${
                      isFirst ? "max-w-xl" : ""
                    }`}
                  >
                    {item.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* =========================================================
            4. BOTTOM FOOTER & EXPLORE MENU CTA
            ========================================================= */}
        <div className="mt-12 sm:mt-14 pt-8 border-t border-[#E8DED0] flex flex-col sm:flex-row items-center justify-between gap-5">
          <div>
            <h4 className="text-base sm:text-lg font-black uppercase text-[#1F2B20]">
              Craving Something Real?
            </h4>
            <p className="text-xs text-[#736F67] mt-0.5">
              Explore our full catalogue of handcrafted smash burgers, pizzas, and drinks.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <Link
              href="/menu"
              className="px-7 py-3 rounded-full bg-[#1F2B20] hover:bg-[#283829] text-white text-xs font-bold uppercase tracking-[0.18em] flex items-center gap-2 shadow-md hover:shadow-lg transition-all cursor-pointer"
            >
              <span>EXPLORE THE MENU</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </div>

      {/* =========================================================
          5. ACCESSIBLE FULLSCREEN LIGHTBOX MODAL
          ========================================================= */}
      {activeLightboxItem && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={activeLightboxItem.title}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/92 backdrop-blur-md p-4 sm:p-6 animate-in fade-in duration-200"
          onClick={() => setLightboxIndex(null)}
        >
          {/* Close Button */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setLightboxIndex(null);
            }}
            className="absolute top-4 right-4 sm:top-6 sm:right-6 w-11 h-11 rounded-full bg-white/10 hover:bg-white/20 border border-white/20 flex items-center justify-center text-white transition-colors cursor-pointer z-50"
            aria-label="Close image viewer"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Left Navigation Arrow */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setLightboxIndex((prev) =>
                prev !== null
                  ? (prev - 1 + filteredItems.length) % filteredItems.length
                  : 0
              );
            }}
            className="absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-white/10 hover:bg-white/20 border border-white/20 flex items-center justify-center text-white transition-colors cursor-pointer z-50"
            aria-label="Previous image"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* Right Navigation Arrow */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setLightboxIndex((prev) =>
                prev !== null ? (prev + 1) % filteredItems.length : 0
              );
            }}
            className="absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-white/10 hover:bg-white/20 border border-white/20 flex items-center justify-center text-white transition-colors cursor-pointer z-50"
            aria-label="Next image"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Center Lightbox Card */}
          <div
            className="relative max-w-4xl max-h-[85vh] w-full flex flex-col items-center select-none"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative w-full h-[55vh] sm:h-[65vh] rounded-2xl overflow-hidden shadow-2xl bg-black">
              <Image
                src={activeLightboxItem.src}
                alt={activeLightboxItem.alt}
                fill
                className="object-contain"
                priority
              />
            </div>

            {/* Lightbox Caption Row */}
            <div className="w-full mt-4 flex items-center justify-between text-white px-2">
              <div>
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#F2A65A]">
                    {activeLightboxItem.categoryLabel}
                  </span>
                  <span className="text-zinc-500">·</span>
                  <span className="text-xs text-zinc-400 font-mono">
                    {lightboxIndex !== null ? lightboxIndex + 1 : 1} OF{" "}
                    {filteredItems.length}
                  </span>
                </div>
                <h3 className="text-lg sm:text-xl font-bold uppercase tracking-wide text-white">
                  {activeLightboxItem.title}
                </h3>
                <p className="text-xs text-zinc-300 max-w-xl leading-relaxed mt-1">
                  {activeLightboxItem.description}
                </p>
              </div>

              <Link
                href="/menu"
                onClick={() => setLightboxIndex(null)}
                className="hidden sm:inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-white text-[#1F2B20] text-xs font-bold uppercase tracking-wider hover:bg-zinc-200 transition-colors shrink-0"
              >
                <span>VIEW MENU</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
