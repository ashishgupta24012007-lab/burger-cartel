"use client";

import React, { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { fetchCmsContentOnce } from "@/lib/client/cmsClient";

interface FooterProps {
  onOpenLocation?: () => void;
}

interface OutletLink {
  slug: string;
  name: string;
}

export default function Footer({}: FooterProps) {
  const [footerData, setFooterData] = useState({
    tagline: "cafe & restaurant",
    description: "",
    copyrightText: "BURGER CARTEL. ALL RIGHTS RESERVED.",
    showOutlets: true,
  });

  const [contactData, setContactData] = useState({
    supportEmail: "info@burgercartel.com",
    primaryPhone: "+91 99073 11111",
    instagram: "https://www.instagram.com/burgercartel.in?mdxt=ZDVpbDN6Z3pwZWMx",
  });

  const [outlets, setOutlets] = useState<OutletLink[]>([
    { slug: "darjeeling", name: "Darjeeling (Chauk Bazaar)" },
    { slug: "kurseong", name: "Kurseong" },
    { slug: "pradhan-nagar", name: "Pradhan Nagar" },
    { slug: "panchanai", name: "Parijat Road (Panchanai)" },
    { slug: "shivmandir", name: "Shivmandir" },
  ]);

  useEffect(() => {
    let mounted = true;
    async function loadFooter() {
      const data = await fetchCmsContentOnce();
      if (!mounted || !data) return;

      if (data.siteContent?.footer) {
        setFooterData((prev) => ({ ...prev, ...data.siteContent.footer }));
      }
      if (data.siteContent?.contact) {
        setContactData((prev) => ({ ...prev, ...data.siteContent.contact }));
      }
      if (Array.isArray(data.outlets) && data.outlets.length > 0) {
        setOutlets(
          data.outlets.map((o) => ({
            slug: o.slug,
            name: o.shortName || o.name,
          }))
        );
      }
    }
    loadFooter();

    const handleCmsUpdate = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail) {
        if (customEvent.detail.siteContent?.footer) {
          setFooterData((prev) => ({ ...prev, ...customEvent.detail.siteContent.footer }));
        }
        if (customEvent.detail.siteContent?.contact) {
          setContactData((prev) => ({ ...prev, ...customEvent.detail.siteContent.contact }));
        }
        if (Array.isArray(customEvent.detail.outlets) && customEvent.detail.outlets.length > 0) {
          setOutlets(
            customEvent.detail.outlets.map((o: { slug: string; shortName?: string; name: string }) => ({
              slug: o.slug,
              name: o.shortName || o.name,
            }))
          );
        }
      }
    };

    window.addEventListener("cms:updated", handleCmsUpdate);
    return () => {
      mounted = false;
      window.removeEventListener("cms:updated", handleCmsUpdate);
    };
  }, []);

  return (
    <footer className="relative z-10 border-t border-[#E8DED0] bg-[#FAF7F0] py-14 sm:py-16 px-5 sm:px-8 md:px-12 text-[#4A4843] text-xs">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-8 mb-12">
        {/* Left: Brand Identity, Script Subtitle, and Outlets */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <Link href="/" className="relative w-12 h-12 rounded-full overflow-hidden shrink-0 border border-[#E8DED0] bg-white shadow-md p-1 group">
            <Image
              src="/images/logo.webp"
              alt="BURGER CARTEL Logo"
              width={48}
              height={48}
              loading="lazy"
              className="w-full h-full object-contain transition-transform group-hover:scale-105"
            />
          </Link>
          <div>
            <h3 className="text-lg sm:text-xl font-black text-[#1F2B20] uppercase tracking-tight mb-0.5">
              BURGER CARTEL
            </h3>
            <p className="text-[11px] font-script text-[#B18B5B] text-base leading-none">
              {footerData.tagline || "cafe & restaurant"}
            </p>
            {footerData.description && (
              <p className="text-[#4A4843] text-[11px] mt-0.5 max-w-md">
                {footerData.description}
              </p>
            )}
            {footerData.showOutlets !== false && outlets.length > 0 && (
              <p className="text-[#4A4843] text-[11px] mt-1">
                Outlets:{" "}
                {outlets.map((outlet, idx) => (
                  <React.Fragment key={outlet.slug}>
                    {idx > 0 && " · "}
                    <Link
                      href={`/locations/${outlet.slug}`}
                      className="hover:underline hover:text-[#1F2B20]"
                    >
                      {outlet.name}
                    </Link>
                  </React.Fragment>
                ))}
              </p>
            )}
          </div>
        </div>

        {/* Right: Unified Navigation Links */}
        <div className="flex flex-wrap items-center gap-6 text-[11px] uppercase tracking-widest text-[#736F67] font-bold">
          <Link href="/about" className="hover:text-[#1F2B20] transition-colors">
            ABOUT
          </Link>
          <Link href="/order-online" className="hover:text-[#1F2B20] transition-colors">
            ORDER ONLINE
          </Link>
          <Link href="/menu" className="hover:text-[#1F2B20] transition-colors">
            MENU
          </Link>
          <Link href="/#reviews" className="hover:text-[#1F2B20] transition-colors">
            REVIEWS
          </Link>
          <Link href="/#gallery" className="hover:text-[#1F2B20] transition-colors">
            GALLERY
          </Link>
          <Link href="/locations" className="hover:text-[#1F2B20] transition-colors">
            LOCATIONS
          </Link>
          {contactData.instagram && (
            <a
              href={contactData.instagram}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full border border-[#E8DED0] bg-white text-[#1F2B20] hover:text-[#B18B5B] hover:border-[#B18B5B] transition-all shadow-2xs hover:shadow-xs"
              aria-label="Burger Cartel on Instagram"
            >
              <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect width="20" height="20" x="2" y="2" rx="5" ry="5"/>
                <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
                <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>
              </svg>
              <span>INSTAGRAM</span>
            </a>
          )}
        </div>
      </div>

      {/* Bottom Row: Minimal Legal Disclaimers & Copyright */}
      <div className="max-w-6xl mx-auto pt-8 border-t border-[#E8DED0] flex flex-col sm:flex-row items-center justify-between gap-4 text-[10px] text-[#736F67] tracking-wider uppercase font-medium">
        <span>{footerData.copyrightText || "BURGER CARTEL. ALL RIGHTS RESERVED."}</span>
        <div className="flex items-center gap-4">
          {contactData.supportEmail && (
            <>
              <a href={`mailto:${contactData.supportEmail}`} className="hover:text-[#1F2B20] hover:underline transition-colors lowercase">
                {contactData.supportEmail}
              </a>
              <span>·</span>
            </>
          )}
          <Link href="/terms" className="hover:text-[#1F2B20] hover:underline transition-colors lowercase first-letter:uppercase">
            Terms of Use
          </Link>
          <span>·</span>
          <Link href="/privacy-policy" className="hover:text-[#1F2B20] hover:underline transition-colors lowercase first-letter:uppercase">
            Privacy Policy
          </Link>
        </div>
        <span>5 LOCATIONS: DARJEELING · KURSEONG · SILIGURI · OPEN DAILY</span>
      </div>
    </footer>
  );
}
