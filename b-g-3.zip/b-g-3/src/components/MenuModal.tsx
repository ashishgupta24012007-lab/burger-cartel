"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { X, Flame, Coffee, Sparkles } from "lucide-react";

interface MenuItem {
  name: string;
  price: string;
  desc: string;
  tag?: string;
}

interface MenuModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function MenuModal({
  isOpen,
  onClose,
}: MenuModalProps) {
  const [activeCategory, setActiveCategory] = useState<"burgers" | "coffee" | "sides">("burgers");

  if (!isOpen) return null;

  const categories = [
    { id: "burgers", label: "CRAFT BURGERS", icon: Flame },
    { id: "coffee", label: "SINGLE ORIGIN COFFEE", icon: Coffee },
    { id: "sides", label: "ARTISAN SIDES", icon: Sparkles },
  ] as const;

  const menuItems: Record<"burgers" | "coffee" | "sides", MenuItem[]> = {
    burgers: [
      {
        name: "CARTEL'S PRIME ANGUS SMASH",
        price: "₹590",
        desc: "200g prime gourmet patty, 24-month aged cheddar, house brioche, caramelized Vidalia onions, Cartel sauce.",
        tag: "SIGNATURE",
      },
      {
        name: "DOUBLE TRUFFLE & RACLETTE",
        price: "₹640",
        desc: "Two crispy-edged smash patties, melted alpine raclette cheese, black truffle aioli, pickled dill chips.",
        tag: "CHEF PICK",
      },
      {
        name: "APPLEWOOD SMOKEHOUSE BACON",
        price: "₹580",
        desc: "Thick-cut smoked bacon, charred sweet onion BBQ glaze, crispy onion strings, Monterey Jack.",
      },
      {
        name: "NASHVILLE BUTTERMILK CRISPY CHICKEN",
        price: "₹520",
        desc: "Buttermilk-brined chicken breast tossed in cayenne hot honey, vinegar cabbage slaw, bread & butter pickles.",
      },
    ],
    coffee: [
      {
        name: "SILIGURI ESTATE 18-HR NITRO COLD BREW",
        price: "₹260",
        desc: "18-hour cold steeped single-origin Arabica from local foothills, pulled through nitrogen taps.",
        tag: "HOUSE BREW",
      },
      {
        name: "HIMALAYAN POUR OVER (SINGLE ORIGIN)",
        price: "₹240",
        desc: "Light roast with delicate floral notes, peach nectar, and candied citrus finish.",
      },
      {
        name: "DOUBLE ESPRESSO AMERICANO",
        price: "₹210",
        desc: "Extracted over hot filtered water. Deep notes of dark cocoa and roasted almond.",
      },
    ],
    sides: [
      {
        name: "WHITE TRUFFLE & PARMESAN FRIES",
        price: "₹290",
        desc: "Hand-cut Russet potato fries tossed in aromatic white truffle oil, freshly grated 24-month Reggiano.",
      },
      {
        name: "CRISPY BEER-BATTERED ONION RINGS",
        price: "₹260",
        desc: "Colossal sweet onions dipped in craft IPA batter, served with smoked paprika dip.",
      },
    ],
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-[#F5F0E7] text-[#292925] border border-[#E8DED0] neu-cream-card rounded-3xl p-6 sm:p-8 max-h-[88vh] overflow-y-auto">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-[#4A4843] hover:text-[#1F2B20] neu-cream-disc rounded-full transition-colors cursor-pointer"
          aria-label="Close menu"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="mb-6 border-b border-[#E8DED0] pb-4 flex items-center gap-3.5">
          <div className="relative w-11 h-11 rounded-full overflow-hidden shrink-0 border border-[#E8DED0] bg-white p-1 shadow-xs">
            <Image
              src="/images/logo.png"
              alt="BURGER CARTEL Logo"
              width={44}
              height={44}
              className="w-full h-full object-contain"
            />
          </div>
          <div>
            <span className="text-[10px] font-bold tracking-[0.25em] text-[#B18B5B] uppercase block mb-0.5">
              BURGER CARTEL · SERVED AT ALL 5 BRANCHES
            </span>
            <h2 className="text-xl sm:text-2xl font-black uppercase tracking-tight text-[#1F2B20] leading-tight">
              FOOD &amp; BEVERAGE
            </h2>
          </div>
        </div>

        {/* Categories */}
        <div className="flex border-b border-[#E8DED0] mb-6 gap-6">
          {categories.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setActiveCategory(c.id)}
              className={`pb-3 text-xs font-bold tracking-[0.2em] uppercase transition-colors relative cursor-pointer ${
                activeCategory === c.id
                  ? "text-[#1F2B20]"
                  : "text-[#736F67] hover:text-[#1F2B20]"
              }`}
            >
              {c.label}
              {activeCategory === c.id && (
                <span className="absolute bottom-0 left-0 w-full h-[2px] bg-[#B18B5B] rounded-full" />
              )}
            </button>
          ))}
        </div>

        {/* Items */}
        <div className="space-y-3.5 mb-6">
          {menuItems[activeCategory].map((item, idx) => (
            <div
              key={idx}
              className="p-4 sm:p-5 neu-cream-card rounded-2xl flex flex-col sm:flex-row sm:items-start justify-between gap-3"
            >
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-[#1F2B20]">
                    {item.name}
                  </h3>
                  {item.tag && (
                    <span className="text-[9px] font-bold uppercase tracking-wider neu-cream-disc text-[#B18B5B] px-2 py-0.5 rounded-full">
                      {item.tag}
                    </span>
                  )}
                </div>
                <p className="text-xs text-[#4A4843] mt-1 leading-relaxed">
                  {item.desc}
                </p>
              </div>
              <span className="text-sm font-black text-[#1F2B20] shrink-0 font-mono">
                {item.price}
              </span>
            </div>
          ))}
        </div>

        <div className="pt-4 border-t border-[#E8DED0] flex items-center justify-between">
          <span className="text-[11px] text-[#736F67] uppercase tracking-wider">
            All burgers cooked to order on volcanic cast iron
          </span>
          <Link
            href="/order-online"
            onClick={onClose}
            className="px-6 py-2.5 bg-[#1F2B20] hover:bg-[#283829] text-white text-xs font-bold uppercase tracking-wider rounded-full shadow-md transition-all cursor-pointer"
          >
            ORDER ONLINE →
          </Link>
        </div>
      </div>
    </div>
  );
}
