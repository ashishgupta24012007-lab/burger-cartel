"use client";

import React, { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { X, MapPin, Phone, ExternalLink, Clock } from "lucide-react";
import { fetchCmsContentOnce } from "@/lib/client/cmsClient";

interface Branch {
  id: string;
  name: string;
  region: "Darjeeling & Kurseong" | "Siliguri";
  address: string;
  hours: string;
  phone?: string;
  phoneRaw?: string;
  mapsUrl: string;
  swiggyUrl?: string;
  zomatoUrl?: string;
}

const STATIC_BRANCHES: Branch[] = [
  {
    id: "darjeeling",
    name: "Darjeeling (Chauk Bazaar)",
    region: "Darjeeling & Kurseong",
    address:
      "Hotel Seven Seas Building, 17 N, B Singh Road, Chauk Bazaar, Darjeeling, West Bengal 734101",
    hours: "9:00 AM – 9:00 PM (Monday to Sunday)",
    phone: "+91 99073 32580",
    phoneRaw: "+919907332580",
    mapsUrl: "https://maps.app.goo.gl/FYzxL6N2TYf7a59k8",
  },
  {
    id: "kurseong",
    name: "Kurseong",
    region: "Darjeeling & Kurseong",
    address:
      "Top floor, Clock tower, near Station, Kurseong, West Bengal 734203",
    hours: "9:00 AM – 9:00 PM (Monday to Sunday)",
    mapsUrl: "https://maps.app.goo.gl/Y9XQPy68UKiyvaee6",
  },
  {
    id: "pradhan-nagar",
    name: "Pradhan Nagar",
    region: "Siliguri",
    address:
      "Nivedita Rd, Ward 2, Pradhan Nagar, Siliguri, West Bengal 734003",
    hours: "8:00 AM – 10:00 PM (Monday to Sunday)",
    phone: "+91 92390 17877",
    phoneRaw: "+919239017877",
    mapsUrl: "https://maps.app.goo.gl/LDovHJgBRH5W5cJg7",
  },
  {
    id: "parijat-road",
    name: "Parijat Road (Salbari / Panchanai)",
    region: "Siliguri",
    address:
      "Parijat Rd, Siliguri, Panchanai, West Bengal 734002",
    hours: "9:00 AM – 9:30 PM (Monday to Sunday)",
    phone: "+91 78118 43316",
    phoneRaw: "+917811843316",
    mapsUrl: "https://maps.app.goo.gl/1oKwaBin9L4rW91q7",
  },
  {
    id: "shivmandir",
    name: "Shivmandir",
    region: "Siliguri",
    address:
      "Shiv Mandir, Siliguri, Bara Mohansingh, West Bengal 734011",
    hours: "9:00 AM – 10:00 PM (Monday to Sunday)",
    mapsUrl: "https://maps.app.goo.gl/u4ATKF6SmuqRTW7FA",
  },
];

interface LocationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function LocationModal({ isOpen, onClose }: LocationModalProps) {
  const [selectedBranchId, setSelectedBranchId] = useState<string>("darjeeling");
  const [branchList, setBranchList] = useState<Branch[]>(STATIC_BRANCHES);

  useEffect(() => {
    let mounted = true;
    async function loadOutlets() {
      const data = await fetchCmsContentOnce();
      if (!mounted || !data) return;
      if (Array.isArray(data.outlets) && data.outlets.length > 0) {
        setBranchList(
          data.outlets.map((o) => ({
            id: o.slug,
            name: o.name,
            region: o.slug === "darjeeling" || o.slug === "kurseong" ? "Darjeeling & Kurseong" : "Siliguri",
            address: o.address,
            hours: o.hoursDisplay,
            phone: o.phone,
            phoneRaw: o.phone?.replace(/[^0-9+]/g, ""),
            mapsUrl: o.googleMapsUrl || "https://maps.google.com",
            swiggyUrl: o.swiggyUrl,
            zomatoUrl: o.zomatoUrl,
          }))
        );
      }
    }
    loadOutlets();

    const handleCmsUpdate = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (Array.isArray(customEvent.detail?.outlets) && customEvent.detail.outlets.length > 0) {
        setBranchList(
          customEvent.detail.outlets.map((o: { slug: string; name: string; address: string; hoursDisplay: string; phone?: string; googleMapsUrl?: string; swiggyUrl?: string; zomatoUrl?: string }) => ({
            id: o.slug,
            name: o.name,
            region: o.slug === "darjeeling" || o.slug === "kurseong" ? "Darjeeling & Kurseong" : "Siliguri",
            address: o.address,
            hours: o.hoursDisplay,
            phone: o.phone,
            phoneRaw: o.phone?.replace(/[^0-9+]/g, ""),
            mapsUrl: o.googleMapsUrl || "https://maps.google.com",
            swiggyUrl: o.swiggyUrl,
            zomatoUrl: o.zomatoUrl,
          }))
        );
      }
    };

    window.addEventListener("cms:updated", handleCmsUpdate);
    return () => {
      mounted = false;
      window.removeEventListener("cms:updated", handleCmsUpdate);
    };
  }, []);

  // Prevent background scroll when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const activeBranch =
    branchList.find((b) => b.id === selectedBranchId) || branchList[0];

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-md p-3 sm:p-6 flex justify-center items-start sm:items-center min-h-screen py-8 sm:py-14 animate-in fade-in duration-200"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-2xl bg-[#F5F0E7] text-[#292925] border border-[#E8DED0] neu-cream-card p-5 sm:p-8 rounded-3xl shadow-2xl my-auto"
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-[#4A4843] hover:text-[#1F2B20] neu-cream-disc rounded-full transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="mb-5 border-b border-[#E8DED0] pb-4 flex items-center gap-3.5">
          <div className="relative w-13 h-13 sm:w-14 sm:h-14 rounded-full overflow-hidden shrink-0 border border-[#E8DED0] bg-white p-1 shadow-xs">
            <Image
              src="/images/logo.png"
              alt="BURGER CARTEL Logo"
              width={56}
              height={56}
              className="w-full h-full object-contain"
            />
          </div>
          <div>
            <span className="text-[10px] font-bold tracking-[0.25em] text-[#B18B5B] uppercase block mb-0.5">
              OUTLETS &amp; CONTACT DETAILS
            </span>
            <h2 className="text-xl sm:text-2xl font-black uppercase tracking-tight text-[#1F2B20] leading-tight">
              BURGER CARTEL LOCATIONS
            </h2>
          </div>
        </div>

        {/* Branch Selection Tabs */}
        <div className="mb-5">
          <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-[#736F67] mb-2">
            CHOOSE AN OUTLET
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {branchList.map((branch) => {
              const isSelected = branch.id === selectedBranchId;
              return (
                <button
                  key={branch.id}
                  type="button"
                  onClick={() => setSelectedBranchId(branch.id)}
                  className={`px-3.5 py-2.5 rounded-xl text-left transition-all cursor-pointer ${
                    isSelected
                      ? "neu-cream-pill border border-[#B18B5B]/50 text-[#1F2B20] font-bold shadow-sm"
                      : "neu-cream-inset border border-transparent text-[#736F67] hover:text-[#1F2B20]"
                  }`}
                >
                  <span className="block text-xs font-bold tracking-wide truncate">
                    {branch.name}
                  </span>
                  <span className="block text-[9px] uppercase tracking-wider text-[#B18B5B] mt-0.5">
                    {branch.region}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Active Branch Showcase Card */}
        <div className="space-y-3.5 neu-cream-inset p-4 sm:p-5 rounded-2xl border border-[#E8DED0] bg-[#FAF7F0]">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-[#E8DED0]">
            <div>
              <span className="text-[10px] font-bold tracking-[0.2em] text-[#B18B5B] uppercase block">
                BURGER CARTEL
              </span>
              <h3 className="text-lg sm:text-xl font-black uppercase tracking-tight text-[#1F2B20]">
                {activeBranch.name}
              </h3>
            </div>
            <span className="px-3 py-1 rounded-full text-[10px] font-bold tracking-wider neu-cream-pill text-[#B18B5B] uppercase">
              {activeBranch.region}
            </span>
          </div>

          {/* Operating Hours */}
          <div className="p-3.5 bg-white/80 border border-[#E8DED0] rounded-xl flex items-center gap-3">
            <Clock className="w-4 h-4 text-[#B18B5B] shrink-0" />
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#736F67] block">
                HOURS
              </span>
              <p className="text-xs text-[#1F2B20] font-bold mt-0.5">
                {activeBranch.hours}
              </p>
            </div>
          </div>

          {/* Address */}
          <div className="p-3.5 bg-white/80 border border-[#E8DED0] rounded-xl flex items-start gap-3">
            <MapPin className="w-4 h-4 text-[#B18B5B] shrink-0 mt-0.5" />
            <div>
              <h4 className="text-[10px] font-bold uppercase tracking-wider text-[#736F67]">
                ADDRESS
              </h4>
              <p className="text-xs text-[#1F2B20] font-medium mt-0.5 leading-relaxed">
                {activeBranch.address}
              </p>
            </div>
          </div>

          {/* Phone (Only if present) */}
          {activeBranch.phone && (
            <div className="p-3.5 bg-white/80 border border-[#E8DED0] rounded-xl flex items-center gap-3">
              <Phone className="w-4 h-4 text-[#1F2B20] shrink-0" />
              <div>
                <span className="text-[10px] uppercase font-bold text-[#736F67] block">
                  PHONE
                </span>
                <a
                  href={`tel:${activeBranch.phoneRaw}`}
                  className="text-xs font-bold text-[#1F2B20] hover:text-[#B18B5B] underline"
                >
                  {activeBranch.phone}
                </a>
              </div>
            </div>
          )}
        </div>

        {/* Direct Action Buttons */}
        <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-3">
          <a
            href={activeBranch.mapsUrl}
            target="_blank"
            rel="noreferrer"
            className="py-3 px-4 rounded-xl text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 bg-[#1F2B20] hover:bg-[#283829] text-white shadow-md transition-all cursor-pointer"
          >
            <span>LOCATION LINK (GOOGLE MAPS)</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>

          <Link
            href={`/locations/${activeBranch.id === "parijat-road" ? "panchanai" : activeBranch.id}`}
            onClick={onClose}
            className="neu-cream-pill py-3 px-4 rounded-xl text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 text-[#1F2B20] hover:bg-white transition-all cursor-pointer"
          >
            <span>VIEW OUTLET DETAILS ↗</span>
          </Link>
        </div>

        {/* All Outlets Quick List with Direct Map Links */}
        <div className="mt-6 pt-5 border-t border-[#E8DED0]">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-[11px] font-bold uppercase tracking-[0.2em] text-[#736F67]">
              ALL OUTLETS &amp; MAP LINKS
            </h4>
            <Link
              href="/locations"
              onClick={onClose}
              className="text-[11px] font-bold uppercase tracking-wider text-[#B18B5B] hover:text-[#1F2B20] transition-colors"
            >
              Directory Page ↗
            </Link>
          </div>
          <div className="space-y-2.5">
            {branchList.map((b) => (
              <div
                key={b.id}
                className="p-3.5 rounded-xl neu-cream-card flex flex-col sm:flex-row sm:items-center justify-between gap-2.5"
              >
                <div>
                  <span className="text-xs font-bold text-[#1F2B20] block">
                    {b.name}
                  </span>
                  <span className="text-[10px] font-semibold text-[#B18B5B] block mt-0.5">
                    {b.hours}
                  </span>
                  <p className="text-[11px] text-[#4A4843] leading-snug mt-0.5">
                    {b.address}
                  </p>
                  {b.phone && (
                    <span className="text-[10px] text-[#736F67] font-semibold block mt-0.5">
                      Phone: {b.phone}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-3 shrink-0 self-start sm:self-center">
                  <Link
                    href={`/locations/${b.id === "parijat-road" ? "panchanai" : b.id}`}
                    onClick={onClose}
                    className="inline-flex items-center gap-1 text-[11px] font-bold text-[#1F2B20] hover:text-[#B18B5B]"
                  >
                    <span>DETAILS</span>
                  </Link>
                  <a
                    href={b.mapsUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 text-[11px] font-bold text-[#B18B5B] hover:text-[#1F2B20]"
                  >
                    <span>MAP</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
