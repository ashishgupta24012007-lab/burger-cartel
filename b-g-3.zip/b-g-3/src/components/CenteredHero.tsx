"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { sanitizeUrl } from "@/lib/utils/urlSanitizer";
import { fetchCmsContentOnce } from "@/lib/client/cmsClient";

interface CenteredHeroProps {
  onOpenLocation?: () => void;
}

export default function CenteredHero({
  onOpenLocation,
}: CenteredHeroProps) {
  const [hero, setHero] = useState({
    badge: "5 BRANCHES / DARJEELING · KURSEONG · SILIGURI",
    headline: "",
    titleLine1: "BURGER",
    titleLine2: "CARTEL",
    subtitle: "cafe & restaurant",
    locationTagline: "AMERICAN RESTAURANT · 5 LOCATIONS ACROSS NORTH BENGAL",
    description: "HANDCRAFTED BURGERS, GREAT COFFEE, AND GOOD VIBES ACROSS NORTH BENGAL.",
    ctaPrimaryText: "VIEW MENU",
    ctaPrimaryLink: "/menu",
    ctaSecondaryText: "FIND US",
  });

  useEffect(() => {
    let mounted = true;
    async function loadHero() {
      const data = await fetchCmsContentOnce();
      if (!mounted) return;
      if (data?.siteContent?.hero) {
        setHero((prev) => ({ ...prev, ...data.siteContent.hero }));
      }
    }
    loadHero();

    const handleCmsUpdate = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail?.siteContent?.hero) {
        setHero((prev) => ({ ...prev, ...customEvent.detail.siteContent.hero }));
      }
    };

    window.addEventListener("cms:updated", handleCmsUpdate);
    return () => {
      mounted = false;
      window.removeEventListener("cms:updated", handleCmsUpdate);
    };
  }, []);

  return (
    <div className="relative w-full max-w-4xl mx-auto px-4 sm:px-6 py-4 sm:py-6 md:py-8 flex flex-col items-center justify-center text-center z-20">
      {/* 0. Top Editorial Badge */}
      <div className="mb-4 sm:mb-6 inline-flex items-center gap-2.5 px-4 sm:px-5 py-1.5 sm:py-2 rounded-full border border-white/15 bg-black/30 backdrop-blur-sm text-[10px] sm:text-xs font-bold tracking-[0.22em] uppercase text-zinc-300 select-none">
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
        <span>{hero.badge}</span>
      </div>

      {/* 1. Main Hero Headline */}
      <div className="relative">
        <h1 className="font-sans font-black text-6xl sm:text-7xl md:text-8xl lg:text-[7.8rem] xl:text-[9.2rem] 2xl:text-[10.2rem] tracking-[-0.03em] leading-[0.85] uppercase select-none hero-headline-text">
          {hero.titleLine1 || hero.titleLine2 ? (
            <>
              {hero.titleLine1 && <span className="block">{hero.titleLine1}</span>}
              {hero.titleLine2 && <span className="block">{hero.titleLine2}</span>}
            </>
          ) : hero.headline ? (
            <span className="block">{hero.headline}</span>
          ) : (
            <>
              <span className="block">BURGER</span>
              <span className="block">CARTEL</span>
            </>
          )}
        </h1>
      </div>

      {/* 2. Script Sub-Headline */}
      <div className="my-2 sm:my-3 md:my-4 w-full relative">
        <span className="font-script text-4xl sm:text-5xl md:text-6xl lg:text-7xl block leading-tight font-normal select-none hero-script-text">
          {hero.subtitle}
        </span>
      </div>

      {/* 3. Supporting Location Tagline */}
      <div className="mb-2 sm:mb-3 max-w-2xl mx-auto px-4">
        <p className="font-sans text-[11px] sm:text-xs md:text-[13px] font-bold tracking-[0.24em] text-[#E5BA7D] uppercase leading-relaxed [text-shadow:_0_1px_3px_rgba(0,0,0,0.9),_0_2px_6px_rgba(0,0,0,0.65)] select-none">
          {hero.locationTagline}
        </p>
      </div>

      {/* 4. Description Tagline */}
      <div className="mb-7 sm:mb-9 max-w-2xl mx-auto px-4">
        <p className="font-sans text-xs sm:text-sm md:text-base font-bold uppercase text-white tracking-[0.16em] sm:tracking-[0.2em] leading-relaxed [text-shadow:_0_1px_3px_rgba(0,0,0,0.95),_0_2px_8px_rgba(0,0,0,0.75)] select-none">
          {hero.description}
        </p>
      </div>

      {/* 5. Hero CTAs */}
      <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-5 w-full">
        <Link
          href={sanitizeUrl(hero.ctaPrimaryLink || "/menu", "/menu")}
          className="group px-7 sm:px-9 py-3.5 sm:py-4 rounded-full bg-white hover:bg-zinc-100 text-[#1F2B20] text-xs sm:text-sm font-bold uppercase tracking-[0.2em] flex items-center justify-center gap-2.5 shadow-lg hover:shadow-xl transition-all cursor-pointer select-none"
        >
          <span>{hero.ctaPrimaryText || "VIEW MENU"}</span>
          <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
        </Link>

        {onOpenLocation && (
          <button
            type="button"
            onClick={onOpenLocation}
            className="group px-7 sm:px-8 py-3.5 sm:py-4 rounded-full bg-white/10 hover:bg-white/20 border border-white/25 hover:border-white/45 text-white text-xs sm:text-sm font-bold uppercase tracking-[0.2em] flex items-center justify-center gap-2 transition-all cursor-pointer select-none backdrop-blur-sm"
          >
            <span>{hero.ctaSecondaryText || "FIND US"}</span>
            <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
          </button>
        )}
      </div>
    </div>
  );
}
