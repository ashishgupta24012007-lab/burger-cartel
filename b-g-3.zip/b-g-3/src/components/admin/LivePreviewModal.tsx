"use client";

import React, { useState } from "react";
import { X, Smartphone, Monitor, Tablet, RotateCw, ExternalLink } from "lucide-react";

interface LivePreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialPath?: string;
}

export default function LivePreviewModal({
  isOpen,
  onClose,
  initialPath = "/",
}: LivePreviewModalProps) {
  const [viewport, setViewport] = useState<"desktop" | "tablet" | "mobile">("desktop");
  const [currentPath, setCurrentPath] = useState(initialPath);
  const [iframeKey, setIframeKey] = useState(0);

  if (!isOpen) return null;

  const reloadIframe = () => setIframeKey((k) => k + 1);

  const pages = [
    { label: "Homepage", path: "/" },
    { label: "Menu", path: "/menu" },
    { label: "Locations Hub", path: "/locations" },
    { label: "Panchanai Outlet", path: "/locations/panchanai" },
    { label: "Darjeeling Outlet", path: "/locations/darjeeling" },
    { label: "About Us", path: "/about" },
    { label: "Order Online", path: "/order-online" },
  ];

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black/85 backdrop-blur-md animate-fadeIn">
      {/* Top Controls Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-3.5 bg-zinc-950 border-b border-zinc-800 text-white shrink-0">
        <div className="flex items-center gap-3">
          <span className="text-xs font-bold tracking-[0.2em] text-[#B18B5B] uppercase">
            LIVE PREVIEW
          </span>
          <div className="h-4 w-px bg-zinc-800" />
          {/* Page Selector */}
          <select
            value={currentPath}
            onChange={(e) => setCurrentPath(e.target.value)}
            className="bg-zinc-900 border border-zinc-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#B18B5B]"
          >
            {pages.map((p) => (
              <option key={p.path} value={p.path}>
                {p.label} ({p.path})
              </option>
            ))}
          </select>
        </div>

        {/* Viewport Toggles */}
        <div className="flex items-center gap-1 bg-zinc-900 p-1 rounded-xl border border-zinc-800">
          <button
            type="button"
            onClick={() => setViewport("desktop")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              viewport === "desktop"
                ? "bg-[#B18B5B] text-white shadow-sm"
                : "text-zinc-400 hover:text-white"
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>Desktop</span>
          </button>
          <button
            type="button"
            onClick={() => setViewport("tablet")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              viewport === "tablet"
                ? "bg-[#B18B5B] text-white shadow-sm"
                : "text-zinc-400 hover:text-white"
            }`}
          >
            <Tablet className="w-3.5 h-3.5" />
            <span>Tablet</span>
          </button>
          <button
            type="button"
            onClick={() => setViewport("mobile")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              viewport === "mobile"
                ? "bg-[#B18B5B] text-white shadow-sm"
                : "text-zinc-400 hover:text-white"
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Mobile (375px)</span>
          </button>
        </div>

        {/* Actions: Reload, Open in Tab, Close */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={reloadIframe}
            className="p-2 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white transition-colors"
            title="Reload Preview Frame"
          >
            <RotateCw className="w-4 h-4" />
          </button>
          <a
            href={currentPath}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white text-xs font-medium transition-colors"
            title="Open page in a new browser tab"
          >
            <span>Open Tab</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg bg-red-950/60 hover:bg-red-900 text-red-200 transition-colors ml-2"
            title="Close Preview"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Frame Canvas Wrapper */}
      <div className="flex-1 overflow-auto flex items-center justify-center p-4 sm:p-6 bg-zinc-900/50">
        <div
          className="transition-all duration-300 bg-white shadow-2xl rounded-2xl overflow-hidden border border-zinc-700 flex flex-col"
          style={{
            width: viewport === "desktop" ? "100%" : viewport === "tablet" ? "768px" : "375px",
            height: viewport === "desktop" ? "100%" : "812px",
            maxWidth: "100%",
            maxHeight: "100%",
          }}
        >
          {/* Simulated Browser Header Bar for Mobile/Tablet */}
          {viewport !== "desktop" && (
            <div className="bg-zinc-950 px-4 py-2 border-b border-zinc-800 flex items-center justify-between text-[11px] text-zinc-400 select-none">
              <span className="font-mono truncate">{currentPath}</span>
              <span className="text-[10px] uppercase font-bold text-[#B18B5B]">
                {viewport === "mobile" ? "iPhone SE / Pixel" : "iPad / Tablet"}
              </span>
            </div>
          )}

          <iframe
            key={iframeKey}
            src={currentPath}
            title="Burger Cartel Public Preview"
            className="w-full flex-1 border-0"
          />
        </div>
      </div>
    </div>
  );
}
