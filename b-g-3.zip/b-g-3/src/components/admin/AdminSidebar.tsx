"use client";

import React, { useState } from "react";
import Image from "next/image";
import {
  LayoutDashboard,
  Home,
  UtensilsCrossed,
  Building2,
  Star,
  Image as ImageIcon,
  BookOpen,
  FileText,
  PhoneCall,
  Compass,
  Megaphone,
  Search,
  ShieldCheck,
  History,
  Archive,
  ChevronRight,
  X,
} from "lucide-react";

export type AdminTab =
  | "overview"
  | "homepage"
  | "menu"
  | "outlets"
  | "reviews"
  | "gallery"
  | "about"
  | "customPages"
  | "contact"
  | "navigation"
  | "announcement"
  | "seo"
  | "backup"
  | "security"
  | "logs";

interface AdminSidebarProps {
  activeTab: AdminTab;
  onSelectTab: (tab: AdminTab) => void;
  counts?: {
    menuItems: number;
    reviews: number;
    outlets: number;
    pages: number;
    gallery: number;
  };
  isMobileOpen: boolean;
  onCloseMobile: () => void;
}

interface NavItem {
  id: AdminTab;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number;
  badgeColor?: string;
}

interface NavGroup {
  title: string;
  items: NavItem[];
}

export default function AdminSidebar({
  activeTab,
  onSelectTab,
  counts,
  isMobileOpen,
  onCloseMobile,
}: AdminSidebarProps) {
  const [filterQuery, setFilterQuery] = useState("");

  const groups: NavGroup[] = [
    {
      title: "Core Operations",
      items: [
        { id: "overview", label: "Dashboard Overview", icon: LayoutDashboard },
        { id: "homepage", label: "Homepage Editor", icon: Home },
        {
          id: "menu",
          label: "Menu Management",
          icon: UtensilsCrossed,
          badge: counts?.menuItems,
          badgeColor: "bg-[#B18B5B]/20 text-[#B18B5B]",
        },
        {
          id: "outlets",
          label: "Branch Outlets",
          icon: Building2,
          badge: counts?.outlets,
          badgeColor: "bg-emerald-500/20 text-emerald-400",
        },
        {
          id: "reviews",
          label: "Customer Reviews",
          icon: Star,
          badge: counts?.reviews,
          badgeColor: "bg-amber-500/20 text-amber-400",
        },
        {
          id: "gallery",
          label: "Media & Gallery",
          icon: ImageIcon,
          badge: counts?.gallery,
        },
      ],
    },
    {
      title: "Pages & Editorial",
      items: [
        { id: "about", label: "About Our Story", icon: BookOpen },
        {
          id: "customPages",
          label: "Custom Pages Builder",
          icon: FileText,
          badge: counts?.pages,
        },
        { id: "announcement", label: "Announcement Banner", icon: Megaphone },
        { id: "contact", label: "Contact & Socials", icon: PhoneCall },
        { id: "navigation", label: "Navigation & Footer", icon: Compass },
      ],
    },
    {
      title: "System & Growth",
      items: [
        { id: "seo", label: "SEO & Metadata", icon: Search },
        { id: "backup", label: "Backup & Restore", icon: Archive },
        { id: "security", label: "Security & Passwords", icon: ShieldCheck },
        { id: "logs", label: "Audit Logs", icon: History },
      ],
    },
  ];

  const handleTabClick = (tabId: AdminTab) => {
    onSelectTab(tabId);
    onCloseMobile();
  };

  const filteredGroups = groups
    .map((g) => ({
      ...g,
      items: g.items.filter((item) =>
        item.label.toLowerCase().includes(filterQuery.toLowerCase())
      ),
    }))
    .filter((g) => g.items.length > 0);

  return (
    <>
      {/* Mobile Backdrop */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/70 backdrop-blur-sm lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      {/* Sidebar Panel */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 w-72 bg-zinc-950 border-r border-zinc-800/80 flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isMobileOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* Brand Header */}
        <div className="p-5 border-b border-zinc-800/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative w-10 h-10 rounded-full bg-white p-1 overflow-hidden shrink-0 shadow-md">
              <Image
                src="/images/logo.webp"
                alt="Burger Cartel Logo"
                width={40}
                height={40}
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <h1 className="font-sans font-black text-sm tracking-tight uppercase text-white leading-none">
                BURGER CARTEL
              </h1>
              <span className="text-[10px] font-bold tracking-[0.2em] text-[#B18B5B] uppercase block mt-1">
                LIVE CMS V3
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onCloseMobile}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white lg:hidden"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Filter Search */}
        <div className="px-4 py-3 border-b border-zinc-900">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
            <input
              type="text"
              placeholder="Search CMS sections..."
              aria-label="Filter CMS navigation sections"
              value={filterQuery}
              onChange={(e) => setFilterQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-zinc-900 border border-zinc-800 rounded-lg text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-[#B18B5B]/60"
            />
          </div>
        </div>

        {/* Navigation Groups List */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6 custom-scrollbar">
          {filteredGroups.map((group) => (
            <div key={group.title} className="space-y-1">
              <span className="px-3 text-[10px] font-bold uppercase tracking-[0.18em] text-zinc-500 block mb-2">
                {group.title}
              </span>

              {group.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;

                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleTabClick(item.id)}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all group cursor-pointer ${
                      isActive
                        ? "bg-[#B18B5B] text-white font-bold shadow-md shadow-[#B18B5B]/20"
                        : "text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900/80"
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <Icon
                        className={`w-4 h-4 shrink-0 transition-transform ${
                          isActive ? "text-white" : "text-zinc-400 group-hover:scale-110"
                        }`}
                      />
                      <span className="truncate">{item.label}</span>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      {item.badge !== undefined && item.badge > 0 && (
                        <span
                          className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md ${
                            isActive
                              ? "bg-white/20 text-white"
                              : item.badgeColor || "bg-zinc-800 text-zinc-400"
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                      {!isActive && (
                        <ChevronRight className="w-3.5 h-3.5 text-zinc-600 opacity-0 group-hover:opacity-100 transition-opacity" />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          ))}
        </div>

        {/* Footer Status Pill */}
        <div className="p-3.5 border-t border-zinc-900 bg-zinc-950/80">
          <div className="flex items-center justify-between text-[11px] text-zinc-400 px-2">
            <span className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Production Store Active</span>
            </span>
            <span className="text-[10px] text-zinc-500 font-mono">Encrypted GCM</span>
          </div>
        </div>
      </aside>
    </>
  );
}
