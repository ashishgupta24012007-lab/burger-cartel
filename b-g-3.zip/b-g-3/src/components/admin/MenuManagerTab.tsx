"use client";

import React, { useState, useMemo, useRef } from "react";
import Image from "next/image";
import {
  UtensilsCrossed,
  Search,
  Plus,
  Edit2,
  Trash2,
  Check,
  X,
  AlertCircle,
  Eye,
  EyeOff,
  Star,
  Leaf,
  Layers,
  Building2,
  Image as ImageIcon,
  Upload,
} from "lucide-react";
import { CmsMenuItem, CmsMenuCategory, CmsGalleryItem, CmsOutlet } from "@/lib/cms/store";

interface MenuManagerTabProps {
  menuItems: CmsMenuItem[];
  menuCategories: CmsMenuCategory[];
  galleryItems: CmsGalleryItem[];
  outlets?: CmsOutlet[];
  outletMenuAvailability?: Record<string, Record<string, boolean>>;
  menuSettings?: { showPrices: boolean };
  onSaveItem: (item: Partial<CmsMenuItem>) => Promise<boolean>;
  onDeleteItem: (id: string) => Promise<boolean>;
  onSaveCategory: (category: Partial<CmsMenuCategory>) => Promise<boolean>;
  onDeleteCategory: (id: string) => Promise<boolean>;
  onToggleOutletAvailability?: (outletId: string, menuItemId: string, isAvailable: boolean) => Promise<boolean>;
  onUpdateMenuSettings?: (settings: { showPrices: boolean }) => Promise<boolean>;
  showToast: (msg: string, type?: "success" | "error") => void;
}

export default function MenuManagerTab({
  menuItems,
  menuCategories,
  galleryItems,
  outlets = [],
  outletMenuAvailability = {},
  menuSettings,
  onSaveItem,
  onDeleteItem,
  onSaveCategory,
  onDeleteCategory,
  onToggleOutletAvailability,
  onUpdateMenuSettings,
  showToast,
}: MenuManagerTabProps) {
  const [subTab, setSubTab] = useState<"items" | "categories">("items");

  // Filters state
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedOutletId, setSelectedOutletId] = useState<string>("all");
  const [dietaryFilter, setDietaryFilter] = useState<"all" | "veg" | "non-veg" | "faves" | "sold-out">("all");

  // Modals state
  const [itemModalOpen, setItemModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<CmsMenuItem | null>(null);
  const [itemSaving, setItemSaving] = useState(false);

  const [categoryModalOpen, setCategoryModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<CmsMenuCategory | null>(null);
  const [categorySaving, setCategorySaving] = useState(false);

  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [deleteType, setDeleteType] = useState<"item" | "category" | null>(null);
  const [deleting, setDeleting] = useState(false);

  // Form state for Item
  const [itemName, setItemName] = useState("");
  const [itemCategory, setItemCategory] = useState("");
  const [itemSubcategory, setItemSubcategory] = useState("");
  const [itemDescription, setItemDescription] = useState("");
  const [itemPrice, setItemPrice] = useState("₹180");
  const [itemImage, setItemImage] = useState("/images/menu/burgers/the-classic-fresh.webp");
  const [itemIsVeg, setItemIsVeg] = useState(false);
  const [itemIsFave, setItemIsFave] = useState(false);
  const [itemIsAvailable, setItemIsAvailable] = useState(true);
  const [itemIsVisible, setItemIsVisible] = useState(true);
  const [itemTags, setItemTags] = useState("");
  const [itemVariants, setItemVariants] = useState("");

  // Menu Price Switch State
  const [showPricesOverride, setShowPricesOverride] = useState<boolean | null>(null);
  const showPrices = showPricesOverride !== null ? showPricesOverride : (menuSettings?.showPrices !== false);
  const [priceToggleLoading, setPriceToggleLoading] = useState(false);

  const handleTogglePrices = async () => {
    const nextVal = !showPrices;
    setPriceToggleLoading(true);
    try {
      if (onUpdateMenuSettings) {
        const ok = await onUpdateMenuSettings({ showPrices: nextVal });
        if (ok) {
          setShowPricesOverride(nextVal);
          showToast(nextVal ? "Menu prices turned ON across website." : "Menu prices turned OFF across website.", "success");
        }
      } else {
        const res = await fetch("/api/admin/cms", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "UPDATE_MENU_SETTINGS",
            payload: { showPrices: nextVal },
          }),
        });
        const json = await res.json();
        if (res.ok && json.success) {
          setShowPricesOverride(nextVal);
          showToast(nextVal ? "Menu prices turned ON across website." : "Menu prices turned OFF across website.", "success");
        } else {
          showToast(json.error || "Failed to update menu settings.", "error");
        }
      }
    } catch {
      showToast("Network error updating price setting.", "error");
    } finally {
      setPriceToggleLoading(false);
    }
  };

  // Device File Upload for Dish Image
  const dishFileInputRef = useRef<HTMLInputElement>(null);
  const [isUploadingDishImage, setIsUploadingDishImage] = useState(false);

  const handleDishImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      showToast("Selected image exceeds 5MB limit.", "error");
      return;
    }

    setIsUploadingDishImage(true);
    try {
      const formData = new FormData();
      formData.append("file", file);

      const res = await fetch("/api/admin/media/upload", {
        method: "POST",
        body: formData,
      });
      const json = await res.json();
      if (res.ok && json.success && json.url) {
        setItemImage(json.url);
        showToast("Dish image uploaded from device!", "success");
      } else {
        showToast(json.error || "Failed to upload image.", "error");
      }
    } catch (err) {
      console.error("Upload error:", err);
      showToast("Network error uploading image.", "error");
    } finally {
      setIsUploadingDishImage(false);
      if (dishFileInputRef.current) dishFileInputRef.current.value = "";
    }
  };

  // Form state for Category
  const [catId, setCatId] = useState("");
  const [catName, setCatName] = useState("");
  const [catShortName, setCatShortName] = useState("");
  const [catSubtitle, setCatSubtitle] = useState("");
  const [catDescription, setCatDescription] = useState("");
  const [catIsVisible, setCatIsVisible] = useState(true);
  const [catSortOrder, setCatSortOrder] = useState(1);

  // Filtered menu items
  const filteredItems = useMemo(() => {
    return menuItems.filter((item) => {
      // Category filter
      if (selectedCategory !== "all" && item.category !== selectedCategory) {
        return false;
      }
      // Dietary filter
      if (dietaryFilter === "veg" && !item.isVegetarian) return false;
      if (dietaryFilter === "non-veg" && item.isVegetarian) return false;
      if (dietaryFilter === "faves" && !item.isHouseFavourite) return false;
      if (dietaryFilter === "sold-out" && item.isAvailable) return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = item.name.toLowerCase().includes(q);
        const matchesDesc = item.description.toLowerCase().includes(q);
        const matchesTags = item.tags?.some((t) => t.toLowerCase().includes(q));
        const matchesCat = item.category.toLowerCase().includes(q);
        if (!matchesName && !matchesDesc && !matchesTags && !matchesCat) {
          return false;
        }
      }

      return true;
    });
  }, [menuItems, selectedCategory, dietaryFilter, searchQuery]);

  // Statistics
  const stats = useMemo(() => {
    return {
      total: menuItems.length,
      veg: menuItems.filter((i) => i.isVegetarian).length,
      nonVeg: menuItems.filter((i) => !i.isVegetarian).length,
      faves: menuItems.filter((i) => i.isHouseFavourite).length,
      soldOut: menuItems.filter((i) => !i.isAvailable).length,
      categoriesCount: menuCategories.length,
    };
  }, [menuItems, menuCategories]);

  // Open Item Modal
  const openItemModal = (item?: CmsMenuItem) => {
    if (item) {
      setEditingItem(item);
      setItemName(item.name);
      setItemCategory(item.category);
      setItemSubcategory(item.subcategory || "");
      setItemDescription(item.description);
      setItemPrice(item.price || "₹180");
      setItemImage(item.image);
      setItemIsVeg(Boolean(item.isVegetarian));
      setItemIsFave(Boolean(item.isHouseFavourite));
      setItemIsAvailable(item.isAvailable !== false);
      setItemIsVisible(item.isVisible !== false);
      setItemTags((item.tags || []).join(", "));
      setItemVariants((item.variants || []).join(", "));
    } else {
      setEditingItem(null);
      setItemName("");
      setItemCategory(menuCategories[0]?.id || "burgers");
      setItemSubcategory("");
      setItemDescription("");
      setItemPrice("₹180");
      setItemImage("/images/menu/burgers/the-classic-fresh.webp");
      setItemIsVeg(false);
      setItemIsFave(false);
      setItemIsAvailable(true);
      setItemIsVisible(true);
      setItemTags("");
      setItemVariants("");
    }
    setItemModalOpen(true);
  };

  // Open Category Modal
  const openCategoryModal = (cat?: CmsMenuCategory) => {
    if (cat) {
      setEditingCategory(cat);
      setCatId(cat.id);
      setCatName(cat.name);
      setCatShortName(cat.shortName || "");
      setCatSubtitle(cat.subtitle || "");
      setCatDescription(cat.description || "");
      setCatIsVisible(cat.isVisible !== false);
      setCatSortOrder(cat.sortOrder || 1);
    } else {
      setEditingCategory(null);
      setCatId("");
      setCatName("");
      setCatShortName("");
      setCatSubtitle("Category " + String.fromCharCode(65 + menuCategories.length));
      setCatDescription("");
      setCatIsVisible(true);
      setCatSortOrder(menuCategories.length + 1);
    }
    setCategoryModalOpen(true);
  };

  // Handle Save Item
  const handleSaveItemSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemName.trim() || !itemCategory.trim()) {
      showToast("Please enter item name and category", "error");
      return;
    }

    setItemSaving(true);
    try {
      const payload: Partial<CmsMenuItem> = {
        id: editingItem ? editingItem.id : undefined,
        name: itemName.trim(),
        category: itemCategory.trim(),
        subcategory: itemSubcategory.trim() || undefined,
        description: itemDescription.trim(),
        price: itemPrice.trim(),
        image: itemImage.trim(),
        isVegetarian: itemIsVeg,
        isHouseFavourite: itemIsFave,
        isAvailable: itemIsAvailable,
        isVisible: itemIsVisible,
        tags: itemTags.split(",").map((t) => t.trim()).filter(Boolean),
        variants: itemVariants.split(",").map((v) => v.trim()).filter(Boolean),
      };

      const success = await onSaveItem(payload);
      if (success) {
        setItemModalOpen(false);
      }
    } finally {
      setItemSaving(false);
    }
  };

  // Handle Save Category
  const handleSaveCategorySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!catId.trim() || !catName.trim()) {
      showToast("Category ID and Name are required", "error");
      return;
    }

    setCategorySaving(true);
    try {
      const payload: Partial<CmsMenuCategory> = {
        id: catId.toLowerCase().trim().replace(/[^a-z0-9-]/g, "-"),
        name: catName.trim(),
        shortName: catShortName.trim() || catName.trim(),
        subtitle: catSubtitle.trim(),
        description: catDescription.trim(),
        isVisible: catIsVisible,
        sortOrder: Number(catSortOrder) || 1,
      };

      const success = await onSaveCategory(payload);
      if (success) {
        setCategoryModalOpen(false);
      }
    } finally {
      setCategorySaving(false);
    }
  };

  // Quick toggle handlers
  const handleQuickToggleAvailable = async (item: CmsMenuItem) => {
    const updated = !item.isAvailable;
    await onSaveItem({
      ...item,
      isAvailable: updated,
    });
    showToast(
      `${item.name} is now marked ${updated ? "IN STOCK" : "SOLD OUT"}.`
    );
  };

  const handleToggleAvailability = async (item: CmsMenuItem) => {
    if (selectedOutletId === "all") {
      await handleQuickToggleAvailable(item);
    } else if (onToggleOutletAvailability) {
      const current = outletMenuAvailability?.[selectedOutletId]?.[item.id] ?? item.isAvailable;
      const updated = !current;
      const success = await onToggleOutletAvailability(selectedOutletId, item.id, updated);
      if (success) {
        showToast(
          `${item.name} is now ${updated ? "IN STOCK" : "SOLD OUT"} at ${outlets.find((o) => o.slug === selectedOutletId)?.name || selectedOutletId}.`,
          "success"
        );
      }
    }
  };

  const handleQuickToggleFavourite = async (item: CmsMenuItem) => {
    const updated = !item.isHouseFavourite;
    await onSaveItem({
      ...item,
      isHouseFavourite: updated,
    });
    showToast(
      `${item.name} is now ${updated ? "added to" : "removed from"} House Favourites.`
    );
  };

  const handleQuickToggleVisibility = async (item: CmsMenuItem) => {
    const updated = !item.isVisible;
    await onSaveItem({
      ...item,
      isVisible: updated,
    });
    showToast(
      `${item.name} is now ${updated ? "visible on" : "hidden from"} website.`
    );
  };

  // Delete confirmation
  const handleConfirmDelete = async () => {
    if (!deleteConfirmId || !deleteType) return;
    setDeleting(true);
    try {
      if (deleteType === "item") {
        await onDeleteItem(deleteConfirmId);
      } else {
        await onDeleteCategory(deleteConfirmId);
      }
      setDeleteConfirmId(null);
      setDeleteType(null);
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-zinc-800">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-black uppercase tracking-tight text-white">
              Menu &amp; Dish Management
            </h2>
            <span className="px-2.5 py-0.5 rounded-full bg-[#B18B5B]/20 text-[#B18B5B] text-[10px] font-black uppercase tracking-wider border border-[#B18B5B]/30">
              {stats.total} Dishes
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-0.5">
            Manage your food &amp; drinks catalog, update prices, toggle availability, and add new seasonal specials.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Menu Price On/Off Switch */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-700/80 shadow-sm">
            <span className="text-[11px] font-bold text-zinc-300 uppercase tracking-wider">Prices:</span>
            <button
              type="button"
              onClick={handleTogglePrices}
              disabled={priceToggleLoading}
              className={`relative inline-flex h-5 w-10 items-center rounded-full transition-colors cursor-pointer ${
                showPrices ? "bg-emerald-600" : "bg-zinc-700"
              }`}
              title={showPrices ? "Menu prices are currently ON. Click to turn OFF." : "Menu prices are currently OFF. Click to turn ON."}
            >
              <span
                className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform ${
                  showPrices ? "translate-x-5" : "translate-x-1"
                }`}
              />
            </button>
            <span className={`text-[10px] font-extrabold uppercase font-mono ${showPrices ? "text-emerald-400" : "text-zinc-500"}`}>
              {showPrices ? "ON" : "OFF"}
            </span>
          </div>

          <button
            type="button"
            onClick={() => openCategoryModal()}
            className="px-3.5 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/80 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Layers className="w-3.5 h-3.5 text-[#B18B5B]" />
            <span>New Category</span>
          </button>
          <button
            type="button"
            onClick={() => openItemModal()}
            className="px-4 py-2 rounded-xl bg-[#B18B5B] hover:bg-[#977348] text-white text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Menu Item</span>
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-3.5">
          <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 block mb-1">
            Total Dishes
          </span>
          <span className="text-2xl font-black text-white">{stats.total}</span>
        </div>
        <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-3.5">
          <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 block mb-1">
            Vegetarian
          </span>
          <span className="text-2xl font-black text-emerald-400">{stats.veg}</span>
        </div>
        <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-3.5">
          <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400 block mb-1">
            Non-Veg
          </span>
          <span className="text-2xl font-black text-rose-400">{stats.nonVeg}</span>
        </div>
        <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-3.5">
          <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 block mb-1">
            House Favourites
          </span>
          <span className="text-2xl font-black text-amber-400">{stats.faves}</span>
        </div>
        <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-3.5">
          <span className="text-[10px] font-bold uppercase tracking-wider text-orange-400 block mb-1">
            Sold Out
          </span>
          <span className="text-2xl font-black text-orange-400">{stats.soldOut}</span>
        </div>
        <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-3.5">
          <span className="text-[10px] font-bold uppercase tracking-wider text-sky-400 block mb-1">
            Categories
          </span>
          <span className="text-2xl font-black text-sky-400">{stats.categoriesCount}</span>
        </div>
      </div>

      {/* Sub-tab Navigation */}
      <div className="flex border-b border-zinc-800">
        <button
          type="button"
          onClick={() => setSubTab("items")}
          className={`px-5 py-2.5 text-xs font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
            subTab === "items"
              ? "border-[#B18B5B] text-white"
              : "border-transparent text-zinc-400 hover:text-white"
          }`}
        >
          Menu Items ({menuItems.length})
        </button>
        <button
          type="button"
          onClick={() => setSubTab("categories")}
          className={`px-5 py-2.5 text-xs font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
            subTab === "categories"
              ? "border-[#B18B5B] text-white"
              : "border-transparent text-zinc-400 hover:text-white"
          }`}
        >
          Menu Categories ({menuCategories.length})
        </button>
      </div>

      {/* ===================== SUB-TAB 1: MENU ITEMS ===================== */}
      {subTab === "items" && (
        <div className="space-y-4">
          {/* Filters Bar */}
          <div className="bg-zinc-900/90 border border-zinc-800 rounded-2xl p-4 flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
              <input
                type="text"
                placeholder="Search dishes by name, ingredients, or tags..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 text-xs bg-zinc-950 border border-zinc-800 rounded-xl text-white placeholder-zinc-500 focus:outline-none focus:border-[#B18B5B]"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Dietary Dropdown & Status Filter */}
            <div className="flex flex-wrap items-center gap-2">
              <select
                value={dietaryFilter}
                onChange={(e) =>
                  setDietaryFilter(
                    e.target.value as "all" | "veg" | "non-veg" | "faves" | "sold-out"
                  )
                }
                className="px-3 py-2 text-xs font-bold rounded-xl bg-zinc-950 border border-zinc-800 text-zinc-200 focus:outline-none focus:border-[#B18B5B] cursor-pointer"
              >
                <option value="all">Dietary: All Dishes</option>
                <option value="veg">Veg Only (Pure Veg)</option>
                <option value="non-veg">Non-Veg Only</option>
                <option value="faves">House Favourites Only</option>
                <option value="sold-out">Sold Out Only</option>
              </select>

              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-3 py-2 text-xs font-bold rounded-xl bg-zinc-950 border border-zinc-800 text-zinc-200 focus:outline-none focus:border-[#B18B5B] cursor-pointer"
              >
                <option value="all">All Categories ({menuItems.length})</option>
                {menuCategories.map((c) => {
                  const count = menuItems.filter((i) => i.category === c.id).length;
                  return (
                    <option key={c.id} value={c.id}>
                      {c.name} ({count})
                    </option>
                  );
                })}
              </select>

              {/* Branch Inventory Selector */}
              {outlets.length > 0 && (
                <div className="flex items-center gap-1.5 bg-zinc-950 border border-[#B18B5B]/40 rounded-xl px-2.5">
                  <Building2 className="w-3.5 h-3.5 text-[#B18B5B] shrink-0" />
                  <select
                    value={selectedOutletId}
                    onChange={(e) => setSelectedOutletId(e.target.value)}
                    className="py-2 text-xs font-bold bg-transparent text-[#B18B5B] focus:outline-none cursor-pointer"
                  >
                    <option value="all" className="bg-zinc-950 text-white">Branch: Global (All 5 Outlets)</option>
                    {outlets.map((o) => (
                      <option key={o.slug} value={o.slug} className="bg-zinc-950 text-white">
                        Branch: {o.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          </div>

          {/* Category Quick Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 custom-scrollbar">
            <button
              type="button"
              onClick={() => setSelectedCategory("all")}
              className={`px-3 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider shrink-0 transition-colors cursor-pointer ${
                selectedCategory === "all"
                  ? "bg-[#B18B5B] text-white"
                  : "bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white"
              }`}
            >
              All ({menuItems.length})
            </button>
            {menuCategories.map((c) => {
              const count = menuItems.filter((i) => i.category === c.id).length;
              const isSelected = selectedCategory === c.id;
              return (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setSelectedCategory(c.id)}
                  className={`px-3 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider shrink-0 transition-colors cursor-pointer ${
                    isSelected
                      ? "bg-[#B18B5B] text-white"
                      : "bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white"
                  }`}
                >
                  {c.shortName || c.name} ({count})
                </button>
              );
            })}
          </div>

          {/* Items Grid */}
          {filteredItems.length === 0 ? (
            <div className="bg-zinc-900/50 border border-zinc-800 rounded-3xl p-12 text-center">
              <UtensilsCrossed className="w-10 h-10 text-zinc-600 mx-auto mb-3" />
              <h3 className="text-base font-bold text-white mb-1">No Menu Items Found</h3>
              <p className="text-xs text-zinc-400 max-w-sm mx-auto mb-4">
                No items match your active search or filters. Try clearing your filters or add a new menu item.
              </p>
              <button
                type="button"
                onClick={() => {
                  setSearchQuery("");
                  setSelectedCategory("all");
                  setDietaryFilter("all");
                }}
                className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold uppercase tracking-wider"
              >
                Clear Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3.5">
              {filteredItems.map((item) => {
                const categoryObj = menuCategories.find((c) => c.id === item.category);
                const isAvailableHere =
                  selectedOutletId === "all"
                    ? item.isAvailable
                    : (outletMenuAvailability?.[selectedOutletId]?.[item.id] ??
                      item.isAvailable);

                return (
                  <div
                    key={item.id}
                    className={`bg-zinc-900 border rounded-2xl p-4 flex flex-col justify-between transition-all ${
                      !item.isVisible
                        ? "border-zinc-800/60 opacity-60"
                        : !isAvailableHere
                        ? "border-amber-500/40 bg-zinc-900/90"
                        : "border-zinc-800 hover:border-zinc-700"
                    }`}
                  >
                    <div>
                      {/* Top Bar: Image, Title, Badges */}
                      <div className="flex gap-3.5 mb-3">
                        <div className="relative w-20 h-20 rounded-xl overflow-hidden bg-zinc-950 shrink-0 border border-zinc-800">
                          {item.image ? (
                            <Image
                              src={item.image}
                              alt={item.name}
                              fill
                              className="object-cover"
                              sizes="80px"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-zinc-600">
                              <ImageIcon className="w-6 h-6" />
                            </div>
                          )}
                          {!isAvailableHere && (
                            <div className="absolute inset-0 bg-black/75 flex items-center justify-center p-1 text-center">
                              <span className="text-[9px] font-black uppercase tracking-wider text-amber-400 leading-tight">
                                SOLD OUT
                              </span>
                            </div>
                          )}
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-1 mb-1">
                            <h3 className="font-sans font-bold text-sm text-white truncate leading-snug">
                              {item.name}
                            </h3>
                            <span className="text-xs font-black text-[#B18B5B] shrink-0 font-mono">
                              {item.price || "₹180"}
                            </span>
                          </div>

                          <div className="flex flex-wrap items-center gap-1.5 mb-2">
                            <span className="px-2 py-0.5 rounded-md bg-zinc-800 text-zinc-400 text-[10px] font-bold uppercase tracking-wider">
                              {categoryObj?.shortName || item.category}
                            </span>

                            {item.isVegetarian ? (
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-emerald-500/10 text-emerald-400 text-[10px] font-bold border border-emerald-500/20">
                                <Leaf className="w-2.5 h-2.5" />
                                <span>VEG</span>
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-rose-500/10 text-rose-400 text-[10px] font-bold border border-rose-500/20">
                                <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
                                <span>NON-VEG</span>
                              </span>
                            )}

                            {item.isHouseFavourite && (
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-amber-500/10 text-amber-400 text-[10px] font-bold border border-amber-500/20">
                                <Star className="w-2.5 h-2.5 fill-amber-400" />
                                <span>FAVE</span>
                              </span>
                            )}
                          </div>

                          <p className="text-[11px] text-zinc-400 line-clamp-2 leading-relaxed">
                            {item.description}
                          </p>
                        </div>
                      </div>

                      {/* Tags / Variants Pill List */}
                      {((item.tags && item.tags.length > 0) || (item.variants && item.variants.length > 0)) && (
                        <div className="flex flex-wrap gap-1 mb-3 pt-2 border-t border-zinc-800/80">
                          {item.tags?.slice(0, 3).map((t, idx) => (
                            <span
                              key={idx}
                              className="text-[9px] px-1.5 py-0.5 rounded bg-zinc-950 text-zinc-500 font-mono"
                            >
                              #{t}
                            </span>
                          ))}
                          {item.variants && item.variants.length > 0 && (
                            <span className="text-[9px] px-1.5 py-0.5 rounded bg-zinc-950 text-amber-500/80 font-medium">
                              +{item.variants.length} options
                            </span>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Bottom Action Controls */}
                    <div className="pt-3 border-t border-zinc-800/80 flex items-center justify-between gap-2">
                      {/* Availability & Favourite Quick Toggles */}
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleToggleAvailability(item)}
                          title={
                            selectedOutletId !== "all"
                              ? `Click to toggle availability at ${
                                  outlets.find((o) => o.slug === selectedOutletId)?.name ||
                                  selectedOutletId
                                }`
                              : item.isAvailable
                              ? "Click to mark Sold Out"
                              : "Click to mark In Stock"
                          }
                          className={`px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-colors cursor-pointer ${
                            isAvailableHere
                              ? "bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border border-emerald-500/20"
                              : "bg-orange-500/20 text-orange-400 hover:bg-orange-500/30 border border-orange-500/30"
                          }`}
                        >
                          {isAvailableHere ? "In Stock" : "Sold Out"}
                        </button>

                        <button
                          type="button"
                          onClick={() => handleQuickToggleFavourite(item)}
                          title="Toggle House Favourite"
                          className={`p-1 rounded-lg border transition-colors cursor-pointer ${
                            item.isHouseFavourite
                              ? "bg-amber-400 text-black border-amber-400"
                              : "bg-zinc-800 text-zinc-400 border-zinc-700 hover:text-white"
                          }`}
                        >
                          <Star className="w-3.5 h-3.5" />
                        </button>

                        <button
                          type="button"
                          onClick={() => handleQuickToggleVisibility(item)}
                          title={item.isVisible ? "Visible on site (Click to hide)" : "Hidden from site (Click to show)"}
                          className={`p-1 rounded-lg border transition-colors cursor-pointer ${
                            item.isVisible
                              ? "bg-zinc-800 text-zinc-300 border-zinc-700 hover:text-white"
                              : "bg-rose-500/10 text-rose-400 border-rose-500/30"
                          }`}
                        >
                          {item.isVisible ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                        </button>
                      </div>

                      {/* Edit / Delete Buttons */}
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => openItemModal(item)}
                          className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-colors cursor-pointer"
                          title="Edit Dish"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setDeleteConfirmId(item.id);
                            setDeleteType("item");
                          }}
                          className="p-1.5 rounded-lg bg-zinc-800 hover:bg-rose-500/20 text-zinc-400 hover:text-rose-400 transition-colors cursor-pointer"
                          title="Delete Dish"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ===================== SUB-TAB 2: MENU CATEGORIES ===================== */}
      {subTab === "categories" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between pb-2">
            <p className="text-xs text-zinc-400">
              Categories define the top sticky filter bar on your public menu. Drag or update sort orders to rearrange them.
            </p>
            <button
              type="button"
              onClick={() => openCategoryModal()}
              className="px-3.5 py-1.5 rounded-xl bg-[#B18B5B] hover:bg-[#977348] text-white text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Category</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {menuCategories
              .sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0))
              .map((cat, idx) => {
                const count = menuItems.filter((i) => i.category === cat.id).length;

                return (
                  <div
                    key={cat.id}
                    className="bg-zinc-900 border border-zinc-800 hover:border-zinc-700 rounded-2xl p-4 flex flex-col justify-between transition-colors"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2">
                          <span className="w-6 h-6 rounded-lg bg-zinc-800 flex items-center justify-center text-[10px] font-black text-zinc-400 font-mono">
                            {cat.sortOrder || idx + 1}
                          </span>
                          <div>
                            <h3 className="font-bold text-sm text-white uppercase tracking-wider">
                              {cat.name}
                            </h3>
                            <span className="text-[10px] text-zinc-400 font-mono">
                              ID: {cat.id} · Short: {cat.shortName || cat.name}
                            </span>
                          </div>
                        </div>

                        <span className="px-2 py-0.5 rounded-md bg-[#B18B5B]/15 text-[#B18B5B] text-[10px] font-black uppercase tracking-wider">
                          {count} Dishes
                        </span>
                      </div>

                      {cat.subtitle && (
                        <p className="text-xs text-amber-400 font-medium mb-1">
                          {cat.subtitle}
                        </p>
                      )}

                      <p className="text-[11px] text-zinc-400 line-clamp-2 leading-relaxed">
                        {cat.description || "No description provided."}
                      </p>
                    </div>

                    <div className="pt-3 mt-3 border-t border-zinc-800 flex items-center justify-between">
                      <span className={`text-[10px] font-bold uppercase tracking-wider ${
                        cat.isVisible !== false ? "text-emerald-400" : "text-zinc-500"
                      }`}>
                        {cat.isVisible !== false ? "Active on Menu" : "Hidden"}
                      </span>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => openCategoryModal(cat)}
                          className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-colors cursor-pointer"
                          title="Edit Category"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            if (count > 0) {
                              showToast(
                                `Cannot delete '${cat.name}'. It contains ${count} dishes. Reassign or delete the dishes first.`,
                                "error"
                              );
                              return;
                            }
                            setDeleteConfirmId(cat.id);
                            setDeleteType("category");
                          }}
                          className="p-1.5 rounded-lg bg-zinc-800 hover:bg-rose-500/20 text-zinc-400 hover:text-rose-400 transition-colors cursor-pointer"
                          title="Delete Category"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* ===================== MODAL: ADD / EDIT MENU ITEM ===================== */}
      {itemModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-zinc-950 border border-zinc-800 rounded-3xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl">
            {/* Modal Header */}
            <div className="p-5 border-b border-zinc-800 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-[#B18B5B]/20 text-[#B18B5B] flex items-center justify-center">
                  <UtensilsCrossed className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white uppercase tracking-wider">
                    {editingItem ? `Edit Dish: ${editingItem.name}` : "Add New Menu Item"}
                  </h3>
                  <span className="text-[10px] text-zinc-400">
                    Saves to the Burger Cartel live database and updates public /menu immediately.
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setItemModalOpen(false)}
                className="p-1 rounded-lg text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSaveItemSubmit} className="flex-1 overflow-y-auto p-5 space-y-4 custom-scrollbar">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Item Name */}
                <div>
                  <label className="text-[11px] font-bold text-zinc-300 uppercase tracking-wider block mb-1">
                    Dish Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. The Classic Double"
                    value={itemName}
                    onChange={(e) => setItemName(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-zinc-900 border border-zinc-700/80 rounded-xl text-white focus:outline-none focus:border-[#B18B5B]"
                  />
                </div>

                {/* Category */}
                <div>
                  <label className="text-[11px] font-bold text-zinc-300 uppercase tracking-wider block mb-1">
                    Category *
                  </label>
                  <select
                    value={itemCategory}
                    onChange={(e) => setItemCategory(e.target.value)}
                    required
                    className="w-full px-3.5 py-2 text-xs bg-zinc-900 border border-zinc-700/80 rounded-xl text-white focus:outline-none focus:border-[#B18B5B]"
                  >
                    {menuCategories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Price */}
                <div>
                  <label className="text-[11px] font-bold text-zinc-300 uppercase tracking-wider block mb-1">
                    Price (₹) *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. ₹180 or ₹220"
                    value={itemPrice}
                    onChange={(e) => setItemPrice(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-zinc-900 border border-zinc-700/80 rounded-xl text-white font-mono focus:outline-none focus:border-[#B18B5B]"
                  />
                </div>

                {/* Subcategory / Type */}
                <div>
                  <label className="text-[11px] font-bold text-zinc-300 uppercase tracking-wider block mb-1">
                    Subcategory (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Handcrafted Smash"
                    value={itemSubcategory}
                    onChange={(e) => setItemSubcategory(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-zinc-900 border border-zinc-700/80 rounded-xl text-white focus:outline-none focus:border-[#B18B5B]"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="text-[11px] font-bold text-zinc-300 uppercase tracking-wider block mb-1">
                  Description *
                </label>
                <textarea
                  required
                  rows={3}
                  placeholder="Appetizing description of ingredients, cheeses, sauces, and bread..."
                  value={itemDescription}
                  onChange={(e) => setItemDescription(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs bg-zinc-900 border border-zinc-700/80 rounded-xl text-white leading-relaxed focus:outline-none focus:border-[#B18B5B]"
                />
              </div>

              {/* Image Path with Quick Select */}
              <div>
                <label className="text-[11px] font-bold text-zinc-300 uppercase tracking-wider block mb-1">
                  Dish Image Path / URL
                </label>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    placeholder="/images/menu/burgers/the-classic-fresh.webp"
                    value={itemImage}
                    onChange={(e) => setItemImage(e.target.value)}
                    className="flex-1 px-3.5 py-2 text-xs bg-zinc-900 border border-zinc-700/80 rounded-xl text-white font-mono focus:outline-none focus:border-[#B18B5B]"
                  />
                  <input
                    type="file"
                    ref={dishFileInputRef}
                    accept="image/png,image/jpeg,image/webp,image/gif"
                    className="hidden"
                    onChange={handleDishImageUpload}
                  />
                  <button
                    type="button"
                    onClick={() => dishFileInputRef.current?.click()}
                    disabled={isUploadingDishImage}
                    className="px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold transition-all border border-zinc-700 flex items-center justify-center gap-1.5 shrink-0 cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5 text-[#B18B5B]" />
                    <span>{isUploadingDishImage ? "Uploading..." : "Select from device"}</span>
                  </button>
                  {itemImage && (
                    <div className="relative w-10 h-10 rounded-xl overflow-hidden bg-zinc-900 shrink-0 border border-zinc-700 self-center">
                      <Image
                        src={itemImage}
                        alt="Preview"
                        fill
                        className="object-cover"
                        sizes="40px"
                      />
                    </div>
                  )}
                </div>
                {galleryItems && galleryItems.length > 0 && (
                  <div className="flex items-center gap-1.5 overflow-x-auto py-1">
                    <span className="text-[10px] text-zinc-500 font-bold shrink-0">Quick Pick:</span>
                    {galleryItems.slice(0, 6).map((g) => (
                      <button
                        key={g.id}
                        type="button"
                        onClick={() => setItemImage(g.src)}
                        title={g.title}
                        className={`relative w-7 h-7 rounded-lg overflow-hidden border shrink-0 transition-transform hover:scale-105 ${
                          itemImage === g.src
                            ? "border-[#B18B5B] ring-1 ring-[#B18B5B]"
                            : "border-zinc-800 opacity-70 hover:opacity-100"
                        }`}
                      >
                        <Image src={g.src} alt={g.alt || g.title} fill className="object-cover" sizes="28px" />
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Toggles Row */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                <label className="flex items-center gap-2 p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={itemIsVeg}
                    onChange={(e) => setItemIsVeg(e.target.checked)}
                    className="accent-emerald-400 w-4 h-4 rounded"
                  />
                  <span className="text-xs font-bold text-emerald-400">Pure Veg</span>
                </label>

                <label className="flex items-center gap-2 p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={itemIsFave}
                    onChange={(e) => setItemIsFave(e.target.checked)}
                    className="accent-amber-400 w-4 h-4 rounded"
                  />
                  <span className="text-xs font-bold text-amber-400">House Fave</span>
                </label>

                <label className="flex items-center gap-2 p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={itemIsAvailable}
                    onChange={(e) => setItemIsAvailable(e.target.checked)}
                    className="accent-sky-400 w-4 h-4 rounded"
                  />
                  <span className="text-xs font-bold text-white">In Stock</span>
                </label>

                <label className="flex items-center gap-2 p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={itemIsVisible}
                    onChange={(e) => setItemIsVisible(e.target.checked)}
                    className="accent-emerald-400 w-4 h-4 rounded"
                  />
                  <span className="text-xs font-bold text-white">Visible on Site</span>
                </label>
              </div>

              {/* Variants and Tags */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                <div>
                  <label className="text-[11px] font-bold text-zinc-300 uppercase tracking-wider block mb-1">
                    Variants (comma separated)
                  </label>
                  <input
                    type="text"
                    placeholder="Chicken Patty, Double Patty"
                    value={itemVariants}
                    onChange={(e) => setItemVariants(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-zinc-900 border border-zinc-700/80 rounded-xl text-white focus:outline-none focus:border-[#B18B5B]"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-zinc-300 uppercase tracking-wider block mb-1">
                    Tags (comma separated)
                  </label>
                  <input
                    type="text"
                    placeholder="burger, chicken, crispy, spicy"
                    value={itemTags}
                    onChange={(e) => setItemTags(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-zinc-900 border border-zinc-700/80 rounded-xl text-white focus:outline-none focus:border-[#B18B5B]"
                  />
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="pt-4 border-t border-zinc-800 flex items-center justify-end gap-2.5 shrink-0">
                <button
                  type="button"
                  onClick={() => setItemModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-zinc-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={itemSaving}
                  className="px-6 py-2 rounded-xl bg-[#B18B5B] hover:bg-[#977348] text-white text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors disabled:opacity-50 cursor-pointer shadow-lg"
                >
                  <Check className="w-4 h-4" />
                  <span>{itemSaving ? "Saving..." : editingItem ? "Save Changes" : "Create Dish"}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===================== MODAL: ADD / EDIT CATEGORY ===================== */}
      {categoryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-zinc-950 border border-zinc-800 rounded-3xl w-full max-w-lg p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-zinc-800 mb-4">
              <h3 className="font-bold text-sm text-white uppercase tracking-wider">
                {editingCategory ? `Edit Category: ${editingCategory.name}` : "Add Menu Category"}
              </h3>
              <button
                type="button"
                onClick={() => setCategoryModalOpen(false)}
                className="p-1 rounded-lg text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCategorySubmit} className="space-y-4">
              <div>
                <label className="text-[11px] font-bold text-zinc-300 uppercase tracking-wider block mb-1">
                  Category ID (slug) *
                </label>
                <input
                  type="text"
                  required
                  disabled={Boolean(editingCategory)}
                  placeholder="e.g. smash-burgers"
                  value={catId}
                  onChange={(e) => setCatId(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs bg-zinc-900 border border-zinc-700/80 rounded-xl text-white font-mono focus:outline-none focus:border-[#B18B5B] disabled:opacity-60"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-zinc-300 uppercase tracking-wider block mb-1">
                  Full Display Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. SMASH BURGERS &amp; SLIDERS"
                  value={catName}
                  onChange={(e) => setCatName(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs bg-zinc-900 border border-zinc-700/80 rounded-xl text-white focus:outline-none focus:border-[#B18B5B]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-bold text-zinc-300 uppercase tracking-wider block mb-1">
                    Short Name (Pills)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Burgers"
                    value={catShortName}
                    onChange={(e) => setCatShortName(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-zinc-900 border border-zinc-700/80 rounded-xl text-white focus:outline-none focus:border-[#B18B5B]"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-zinc-300 uppercase tracking-wider block mb-1">
                    Sort Order
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={catSortOrder}
                    onChange={(e) => setCatSortOrder(parseInt(e.target.value) || 1)}
                    className="w-full px-3.5 py-2 text-xs bg-zinc-900 border border-zinc-700/80 rounded-xl text-white font-mono focus:outline-none focus:border-[#B18B5B]"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-zinc-300 uppercase tracking-wider block mb-1">
                  Subtitle (e.g. Category A)
                </label>
                <input
                  type="text"
                  placeholder="Category A"
                  value={catSubtitle}
                  onChange={(e) => setCatSubtitle(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs bg-zinc-900 border border-zinc-700/80 rounded-xl text-white focus:outline-none focus:border-[#B18B5B]"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-zinc-300 uppercase tracking-wider block mb-1">
                  Category Description
                </label>
                <textarea
                  rows={2}
                  placeholder="Brief description shown above this section on the menu..."
                  value={catDescription}
                  onChange={(e) => setCatDescription(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs bg-zinc-900 border border-zinc-700/80 rounded-xl text-white focus:outline-none focus:border-[#B18B5B]"
                />
              </div>

              <div className="pt-2 flex items-center justify-between">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={catIsVisible}
                    onChange={(e) => setCatIsVisible(e.target.checked)}
                    className="accent-emerald-400 w-4 h-4 rounded"
                  />
                  <span className="text-xs font-bold text-white">Show on Website Menu</span>
                </label>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setCategoryModalOpen(false)}
                    className="px-3.5 py-1.5 text-xs font-bold text-zinc-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={categorySaving}
                    className="px-5 py-2 rounded-xl bg-[#B18B5B] hover:bg-[#977348] text-white text-xs font-bold uppercase tracking-wider transition-colors disabled:opacity-50"
                  >
                    {categorySaving ? "Saving..." : "Save Category"}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===================== DELETE CONFIRMATION MODAL ===================== */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-zinc-950 border border-zinc-800 rounded-3xl w-full max-w-md p-6 shadow-2xl">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/10 text-rose-400 flex items-center justify-center mx-auto mb-4 border border-rose-500/20">
              <AlertCircle className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-base text-white text-center mb-1">
              Delete {deleteType === "item" ? "Menu Item" : "Category"}?
            </h3>
            <p className="text-xs text-zinc-400 text-center mb-6 leading-relaxed">
              Are you sure you want to permanently delete this {deleteType}? This action will remove it from the live website immediately.
            </p>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => {
                  setDeleteConfirmId(null);
                  setDeleteType(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-xs font-bold text-zinc-300 transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={deleting}
                className="flex-1 py-2.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-xs font-bold text-white transition-colors disabled:opacity-50"
              >
                {deleting ? "Deleting..." : "Yes, Delete"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
