"use client";

import React, { useState, useEffect } from "react";
import { ArrowDown } from "lucide-react";
import { fetchCmsContentOnce } from "@/lib/client/cmsClient";

interface EditorialBarProps {
  onOpenLocation?: () => void;
}

export default function EditorialBar({ onOpenLocation }: EditorialBarProps) {
  const [welcomeText] = useState("WELCOME");
  const [locationText, setLocationText] = useState("5 BRANCHES ↗");
  const [statusText] = useState("OPEN DAILY");

  useEffect(() => {
    let mounted = true;
    async function loadEditorial() {
      const data = await fetchCmsContentOnce();
      if (!mounted || !data) return;

      if (data.siteContent?.hero?.locationTagline) {
        // Adapt location text from tagline or branches
        const outletCount = data.outlets?.length || 5;
        setLocationText(`${outletCount} BRANCHES ↗`);
      }
    }
    loadEditorial();

    const handleCmsUpdate = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail) {
        const outletCount = customEvent.detail.outlets?.length || 5;
        setLocationText(`${outletCount} BRANCHES ↗`);
      }
    };

    window.addEventListener("cms:updated", handleCmsUpdate);
    return () => {
      mounted = false;
      window.removeEventListener("cms:updated", handleCmsUpdate);
    };
  }, []);

  const scrollToContent = () => {
    window.scrollTo({
      top: window.innerHeight * 0.9,
      behavior: "smooth",
    });
  };

  return (
    <footer className="w-full z-30">
      {/* Editorial Metadata Row */}
      <div className="w-full px-5 sm:px-8 md:px-12 py-4 sm:py-5 flex flex-wrap items-center justify-between gap-3 text-[10px] sm:text-[11px] md:text-xs font-sans tracking-[0.2em] uppercase text-[#888888] select-none">
        {/* Left: "01 / WELCOME" and "LOCATIONS: 5 BRANCHES" */}
        <div className="flex flex-wrap items-center gap-2.5 sm:gap-4">
          <div className="neu-chip px-3.5 py-1.5 rounded-full flex items-center gap-1.5 font-bold text-white">
            <span className="text-zinc-500">01 /</span>
            <span>{welcomeText}</span>
          </div>

          <button
            type="button"
            onClick={onOpenLocation}
            className="neu-chip px-3.5 py-1.5 rounded-full flex items-center gap-1.5 font-medium hover:text-white transition-colors cursor-pointer"
            title="Click to view all 5 branches"
          >
            <span className="text-zinc-500">LOCATIONS:</span>
            <span className="text-white font-semibold">{locationText}</span>
          </button>
        </div>

        {/* Center: "SCROLL TO EXPLORE ↓" */}
        <button
          type="button"
          onClick={scrollToContent}
          className="neu-flat group hidden sm:flex items-center gap-2 px-4 py-1.5 rounded-full font-semibold text-zinc-300 hover:text-white transition-colors cursor-pointer"
        >
          <span>SCROLL TO EXPLORE</span>
          <ArrowDown className="w-3.5 h-3.5 animate-bounce group-hover:text-white" />
        </button>

        {/* Right: "OPEN DAILY" status badge without hardcoded time */}
        <div className="flex items-center gap-2 font-medium ml-auto sm:ml-0">
          <div className="neu-chip inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-[10px] sm:text-[11px] font-bold text-white">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
            <span>{statusText}</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
