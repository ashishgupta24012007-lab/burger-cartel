"use client";

import React, { useState, useMemo, useEffect } from "react";
import { Star, ChevronLeft, ChevronRight, ExternalLink } from "lucide-react";
import { BRANCH_SUMMARIES, REVIEWS_LIST, CustomerReview, BranchReviewSummary } from "@/data/reviewsData";
import { fetchCmsContentOnce } from "@/lib/client/cmsClient";

interface ReviewsSectionProps {
  onOpenLocation?: () => void;
}

export default function ReviewsSection({}: ReviewsSectionProps) {
  const [reviewsList, setReviewsList] = useState<CustomerReview[]>(REVIEWS_LIST);
  const [selectedBranch, setSelectedBranch] = useState<BranchReviewSummary["id"]>("all");
  const [currentIndex, setCurrentIndex] = useState(0);

  // Sync with live CMS content if modified by admin
  useEffect(() => {
    let mounted = true;
    async function loadReviews() {
      const data = await fetchCmsContentOnce();
      if (!mounted) return;
      if (Array.isArray(data?.reviews)) {
        setReviewsList(
          data.reviews.map((rev) => ({
            ...rev,
            avatarText: rev.avatarText || rev.author.slice(0, 2).toUpperCase(),
            branchId: (rev.branchId as CustomerReview["branchId"]) || "all",
          }))
        );
      }
    }
    loadReviews();

    const handleCmsUpdate = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail && Array.isArray(customEvent.detail.reviews)) {
        setReviewsList(
          customEvent.detail.reviews.map((rev: CustomerReview) => ({
            ...rev,
            avatarText: rev.avatarText || rev.author.slice(0, 2).toUpperCase(),
            branchId: (rev.branchId as CustomerReview["branchId"]) || "all",
          }))
        );
      }
    };

    window.addEventListener("cms:updated", handleCmsUpdate);
    return () => {
      mounted = false;
      window.removeEventListener("cms:updated", handleCmsUpdate);
    };
  }, []);

  // Filter reviews based on active branch tab
  const filteredReviews = useMemo(() => {
    if (selectedBranch === "all") {
      return reviewsList;
    }
    return reviewsList.filter((rev) => rev.branchId === selectedBranch);
  }, [selectedBranch, reviewsList]);

  // Reset carousel index when branch changes
  const handleBranchChange = (branchId: BranchReviewSummary["id"]) => {
    setSelectedBranch(branchId);
    setCurrentIndex(0);
  };

  // Carousel navigation (shows 3 cards at a time on desktop, 1 on mobile)
  const maxIndex = Math.max(0, filteredReviews.length - 1);
  const handlePrev = () => {
    setCurrentIndex((prev) => (prev > 0 ? prev - 1 : maxIndex));
  };
  const handleNext = () => {
    setCurrentIndex((prev) => (prev < maxIndex ? prev + 1 : 0));
  };

  // Slice visible reviews (3 cards sliding)
  const visibleReviews = useMemo(() => {
    const list: CustomerReview[] = [];
    for (let i = 0; i < Math.min(3, filteredReviews.length); i++) {
      const idx = (currentIndex + i) % filteredReviews.length;
      list.push(filteredReviews[idx]);
    }
    return list;
  }, [filteredReviews, currentIndex]);

  return (
    <section
      id="reviews"
      className="relative z-10 py-12 sm:py-16 px-4 sm:px-6 md:px-10 bg-[#F5F0E7] text-[#292925] border-t border-[#E8DED0] transition-colors duration-500 overflow-hidden"
    >
      <div className="max-w-6xl mx-auto">
        {/* ========================================================
            A. COMPACT, AESTHETIC SECTION HEADER
            ======================================================== */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-[#E8DED0] gap-4 mb-6">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full neu-cream-pill text-[10px] font-bold tracking-[0.2em] text-[#B18B5B] uppercase mb-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#B18B5B] animate-pulse" />
              <span>GUEST VOICES</span>
              <span className="text-[#8B8880]">·</span>
              <span className="flex items-center gap-1 text-[#1F2B20]">
                <Star className="w-2.5 h-2.5 fill-[#F2A65A] text-[#F2A65A]" />
                <span>4.2 ★ (877+ REVIEWS)</span>
              </span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-black uppercase tracking-tight text-[#1F2B20]">
              Loved Across North Bengal.
            </h2>
          </div>

          {/* Compact Carousel Nav Controls */}
          <div className="flex items-center gap-2 self-start sm:self-auto">
            <span className="text-[11px] font-bold text-[#736F67] tracking-wider uppercase mr-2 hidden sm:inline">
              {currentIndex + 1} of {filteredReviews.length}
            </span>
            <button
              type="button"
              onClick={handlePrev}
              aria-label="Previous review"
              className="w-9 h-9 rounded-full neu-cream-pill flex items-center justify-center text-[#1F2B20] hover:bg-white transition-all cursor-pointer shadow-xs active:scale-95"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handleNext}
              aria-label="Next review"
              className="w-9 h-9 rounded-full neu-cream-pill flex items-center justify-center text-[#1F2B20] hover:bg-white transition-all cursor-pointer shadow-xs active:scale-95"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ========================================================
            B. CUTE, MINIMAL BRANCH TABS
            ======================================================== */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 mb-6 no-scrollbar scroll-smooth">
          {BRANCH_SUMMARIES.map((branch) => {
            const isActive = selectedBranch === branch.id;
            return (
              <button
                key={branch.id}
                type="button"
                onClick={() => handleBranchChange(branch.id)}
                className={`relative px-3.5 py-1.5 rounded-full text-[11px] font-bold tracking-wider uppercase whitespace-nowrap transition-all duration-200 cursor-pointer select-none flex items-center gap-1.5 ${
                  isActive
                    ? "bg-[#1F2B20] text-white shadow-sm -translate-y-0.5"
                    : "neu-cream-pill text-[#4A4843] hover:text-[#1F2B20] hover:bg-white"
                }`}
              >
                <span>{branch.shortName}</span>
                <span
                  className={`text-[9px] px-1.5 py-0.2 rounded-full font-semibold ${
                    isActive ? "bg-white/20 text-white" : "bg-[#E8DED0] text-[#736F67]"
                  }`}
                >
                  {branch.googleRating}★
                </span>
              </button>
            );
          })}
        </div>

        {/* ========================================================
            C. CURATED 3-CARD COMPACT SHOWCASE (NO LONG SCROLL!)
            ======================================================== */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
          {visibleReviews.map((rev) => (
            <article
              key={rev.id}
              className="neu-cream-card rounded-2xl p-5 sm:p-6 flex flex-col justify-between hover:-translate-y-1 transition-all duration-300 border border-white/80 min-h-[220px]"
            >
              <div>
                {/* Header: Avatar, Name, Rating */}
                <div className="flex items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full neu-cream-disc flex items-center justify-center font-bold text-[11px] text-[#1F2B20] shrink-0 border border-[#E8DED0]">
                      {rev.avatarText}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-tight text-[#1F2B20] flex items-center gap-1">
                        <span>{rev.author}</span>
                        {rev.isLocalGuide && (
                          <span className="text-[8px] font-bold px-1 rounded-sm bg-[#FAF0D9] text-[#B18B5B]">
                            GUIDE
                          </span>
                        )}
                      </h4>
                      <p className="text-[9px] text-[#736F67]">{rev.dateText}</p>
                    </div>
                  </div>

                  {/* 5 Stars */}
                  <div className="flex items-center gap-0.5">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-2.5 h-2.5 fill-[#F2A65A] text-[#F2A65A]" />
                    ))}
                  </div>
                </div>

                {/* Review Body */}
                <p className="text-xs text-[#383733] leading-relaxed line-clamp-4 font-normal">
                  &ldquo;{rev.quote}&rdquo;
                </p>
              </div>

              {/* Card Footer: Branch & Dish Tag */}
              <div className="pt-3 mt-3 border-t border-[#E8DED0]/60 flex items-center justify-between text-[10px] text-[#736F67]">
                <span className="font-bold text-[#B18B5B] uppercase tracking-wider">
                  {rev.branchName}
                </span>
                {rev.highlightDish && (
                  <span className="truncate max-w-[150px] font-medium text-[#4A4843]">
                    {rev.highlightDish}
                  </span>
                )}
              </div>
            </article>
          ))}
        </div>

        {/* ========================================================
            D. CUTE, COMPACT BOTTOM CALLOUT
            ======================================================== */}
        <div className="mt-6 pt-4 border-t border-[#E8DED0] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#736F67]">
          <span className="text-[11px]">
            Based on 877+ verified Google Maps reviews across Darjeeling, Kurseong, and Siliguri.
          </span>
          <a
            href="https://www.google.com/search?q=Burger+Cartel+Siliguri+Darjeeling"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 text-[11px] font-bold text-[#1F2B20] hover:text-[#B18B5B] uppercase tracking-wider transition-colors"
          >
            <span>Rate Us on Google</span>
            <ExternalLink className="w-3 h-3 text-[#B18B5B]" />
          </a>
        </div>
      </div>
    </section>
  );
}
