"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { fetchCmsContentOnce } from "@/lib/client/cmsClient";

interface NavbarProps {
  onOpenMenu?: () => void;
  onOpenLocation?: () => void;
  activeRoute?: "home" | "about" | "order-online" | "menu" | "locations";
}

interface NavItem {
  name: string;
  href: string;
  isRoute?: boolean;
  onClick?: () => void;
}

const DEFAULT_NAV_LINKS: NavItem[] = [
  { name: "HOME", href: "/", isRoute: true },
  { name: "ABOUT", href: "/about", isRoute: true },
  { name: "ORDER ONLINE", href: "/order-online", isRoute: true },
  { name: "MENU", href: "/menu", isRoute: true },
  { name: "OUTLETS", href: "/locations", isRoute: true },
  { name: "REVIEWS", href: "/#reviews" },
  { name: "GALLERY", href: "/#gallery" },
];

export default function Navbar({
  onOpenLocation,
  activeRoute = "home",
}: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [navItems, setNavItems] = useState<NavItem[]>(DEFAULT_NAV_LINKS);

  useEffect(() => {
    let mounted = true;
    async function loadNav() {
      const data = await fetchCmsContentOnce();
      if (!mounted) return;
      if (Array.isArray(data?.siteContent?.navigation) && data.siteContent.navigation.length > 0) {
        setNavItems(
          data.siteContent.navigation
            .filter((item) => item.isVisible !== false)
            .map((item) => ({
              name: item.name.toUpperCase(),
              href: item.href,
              isRoute: item.isRoute !== false,
            }))
        );
      }
    }
    loadNav();

    const handleCmsUpdate = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (Array.isArray(customEvent.detail?.siteContent?.navigation)) {
        setNavItems(
          customEvent.detail.siteContent.navigation
            .filter((item: { isVisible?: boolean }) => item.isVisible !== false)
            .map((item: { name: string; href: string; isRoute?: boolean }) => ({
              name: item.name.toUpperCase(),
              href: item.href,
              isRoute: item.isRoute !== false,
            }))
        );
      }
    };

    window.addEventListener("cms:updated", handleCmsUpdate);
    return () => {
      mounted = false;
      window.removeEventListener("cms:updated", handleCmsUpdate);
    };
  }, []);

  const navLinks = navItems.map((link) => ({
    ...link,
    onClick: link.name.includes("OUTLET") || link.href === "/locations" ? onOpenLocation : undefined,
  }));

  return (
    <header className="w-full z-30">
      {/* Top Bar Row with Subtle Contrast Protection */}
      <nav className="w-full px-5 sm:px-8 md:px-12 py-4 sm:py-5 flex items-center justify-between bg-gradient-to-b from-black/85 via-black/40 to-transparent">
        {/* Left Brand Logo: Neumorphic Disc + Bold Uppercase Inter */}
        <Link
          href="/"
          className="flex items-center gap-3 sm:gap-3.5 group select-none"
        >
          <div className="relative w-11 h-11 sm:w-13 sm:h-13 md:w-14 md:h-14 rounded-full overflow-hidden shrink-0 neu-circle group-hover:border-white/40 transition-all bg-white p-1 shadow-md">
            <Image
              src="/images/logo.webp"
              alt="BURGER CARTEL Logo"
              width={56}
              height={56}
              className="w-full h-full object-contain"
              priority
            />
          </div>
          <div className="flex flex-col leading-tight">
            <span className="font-sans font-black text-sm sm:text-base md:text-lg tracking-[0.14em] text-white uppercase group-hover:text-zinc-200 transition-colors [text-shadow:_0_1px_3px_#000,_0_2px_8px_rgba(0,0,0,0.9)]">
              BURGER CARTEL
            </span>
            <span className="font-sans text-[8px] sm:text-[9px] font-bold tracking-[0.24em] text-[#E5BA7D] uppercase [text-shadow:_0_1px_2px_#000]">
              EST. DARJEELING
            </span>
          </div>
        </Link>

        {/* Centered Minimal Navigation Links (Desktop) */}
        <div className="hidden md:flex items-center gap-1 sm:gap-2 px-3 py-1.5 rounded-full neu-inset">
          {navLinks.map((link) => {
            const isActive =
              (link.name === "HOME" && activeRoute === "home") ||
              (link.name === "ABOUT" && activeRoute === "about") ||
              (link.name === "ORDER ONLINE" && activeRoute === "order-online") ||
              (link.name === "MENU" && activeRoute === "menu") ||
              (link.name === "OUTLETS" && activeRoute === "locations");

            const linkClass = `relative px-4 py-1.5 rounded-full text-xs font-bold tracking-[0.18em] uppercase transition-all ${
              isActive
                ? "neu-convex text-white shadow-sm"
                : "text-zinc-400 hover:text-white"
            }`;

            if (link.isRoute) {
              return (
                <Link
                  key={link.name}
                  href={link.href}
                  onClick={(e) => {
                    if (link.onClick) {
                      e.preventDefault();
                      link.onClick();
                    }
                  }}
                  className={linkClass}
                >
                  {link.name}
                </Link>
              );
            }

            return (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => {
                  if (link.onClick) {
                    e.preventDefault();
                    link.onClick();
                  }
                }}
                className={linkClass}
              >
                {link.name}
              </a>
            );
          })}
        </div>

        {/* Right Neumorphic Button "ORDER ONLINE ↗" */}
        <div className="flex items-center gap-3">
          <Link
            href="/order-online"
            className="neu-convex group px-4 sm:px-5 py-2 sm:py-2.5 rounded-xl text-white text-xs font-bold uppercase tracking-[0.16em] flex items-center gap-1.5 cursor-pointer select-none"
          >
            <span>ORDER ONLINE</span>
            <ArrowUpRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </Link>

          {/* Mobile Menu Toggle */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-1.5 text-zinc-400 hover:text-white md:hidden transition-colors"
            aria-label="Toggle navigation"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-white/10 bg-black/95 backdrop-blur-md px-6 py-5 flex flex-col gap-4 animate-in fade-in slide-in-from-top-2">
          {navLinks.map((link) => {
            const isActive =
              (link.name === "HOME" && activeRoute === "home") ||
              (link.name === "ABOUT" && activeRoute === "about") ||
              (link.name === "ORDER ONLINE" && activeRoute === "order-online") ||
              (link.name === "MENU" && activeRoute === "menu");

            const linkClass = `text-xs font-bold tracking-[0.2em] uppercase py-1 ${
              isActive ? "text-white font-black" : "text-zinc-400 hover:text-white"
            }`;

            if (link.isRoute) {
              return (
                <Link
                  key={link.name}
                  href={link.href}
                  onClick={(e) => {
                    if (link.onClick) {
                      e.preventDefault();
                      link.onClick();
                    }
                    setMobileMenuOpen(false);
                  }}
                  className={linkClass}
                >
                  {link.name}
                </Link>
              );
            }

            return (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => {
                  if (link.onClick) {
                    e.preventDefault();
                    link.onClick();
                  }
                  setMobileMenuOpen(false);
                }}
                className={linkClass}
              >
                {link.name}
              </a>
            );
          })}
          <Link
            href="/order-online"
            onClick={() => setMobileMenuOpen(false)}
            className="w-full mt-2 py-3 border border-white bg-white text-black text-xs font-bold uppercase tracking-widest text-center cursor-pointer block"
          >
            ORDER ONLINE ↗
          </Link>
        </div>
      )}
    </header>
  );
}
