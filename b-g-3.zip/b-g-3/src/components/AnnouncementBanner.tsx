"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { ArrowRight, X } from "lucide-react";
import { fetchCmsContentOnce } from "@/lib/client/cmsClient";
import { sanitizeUrl } from "@/lib/utils/urlSanitizer";

export default function AnnouncementBanner() {
  const [announcement, setAnnouncement] = useState<{
    enabled: boolean;
    text: string;
    link?: string;
    buttonText?: string;
    bgColor?: string;
    textColor?: string;
  } | null>(null);

  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    let mounted = true;
    async function loadAnnouncement() {
      const data = await fetchCmsContentOnce();
      if (!mounted) return;
      if (data?.siteContent?.announcement) {
        setAnnouncement(data.siteContent.announcement);
      }
    }
    loadAnnouncement();

    const handleCmsUpdate = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail?.siteContent?.announcement) {
        setAnnouncement(customEvent.detail.siteContent.announcement);
      }
    };

    window.addEventListener("cms:updated", handleCmsUpdate);
    return () => {
      mounted = false;
      window.removeEventListener("cms:updated", handleCmsUpdate);
    };
  }, []);

  if (!announcement || !announcement.enabled || dismissed || !announcement.text) {
    return null;
  }

  const safeLink = announcement.link ? sanitizeUrl(announcement.link) : "";

  return (
    <aside
      aria-label="Announcement"
      className="relative z-40 w-full py-2.5 px-4 text-xs font-semibold tracking-wide flex items-center justify-center transition-all select-none shadow-sm"
      style={{
        backgroundColor: announcement.bgColor || "#1F2B20",
        color: announcement.textColor || "#FFFFFF",
      }}
    >
      <div className="max-w-6xl mx-auto flex items-center justify-center gap-3 text-center pr-6">
        <span>{announcement.text}</span>
        {safeLink && (
          <Link
            href={safeLink}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 hover:bg-white/25 transition-colors text-[11px] font-bold uppercase tracking-wider underline underline-offset-2"
          >
            <span>{announcement.buttonText || "Learn More"}</span>
            <ArrowRight className="w-3 h-3" />
          </Link>
        )}
      </div>

      <button
        type="button"
        onClick={() => setDismissed(true)}
        className="absolute right-3 top-1/2 -translate-y-1/2 p-1 rounded-full hover:bg-white/15 transition-colors cursor-pointer text-white/80 hover:text-white"
        aria-label="Dismiss announcement"
      >
        <X className="w-3.5 h-3.5" />
      </button>
    </aside>
  );
}
