export const SITE_URL =
  process.env.NEXT_PUBLIC_SITE_URL ||
  (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : "https://burgercartel.in");

export interface OutletSeoData {
  slug: string;
  name: string;
  officialName: string;
  tagline: string;
  description: string;
  region: string;
  locality: string;
  streetAddress: string;
  addressLocality: string;
  addressRegion: string;
  postalCode: string;
  addressCountry: string;
  phone?: string;
  phoneRaw?: string;
  hoursDisplay: string;
  openingHoursSpecification: Array<{
    dayOfWeek: string[];
    opens: string;
    closes: string;
  }>;
  latitude: number;
  longitude: number;
  mapsUrl: string;
  priceRange: string;
  servesCuisine: string[];
  features: string[];
  nearbyLandmarks: string[];
  directionsNote: string;
  image: string;
  ratingValue: number;
  reviewCount: number;
  deliveryPlatforms?: Array<{
    name: string;
    url: string;
  }>;
}

export const OUTLETS_SEO_DATA: Record<OutletSeoData["slug"], OutletSeoData> = {
  panchanai: {
    slug: "panchanai",
    name: "Burger Cartel — Panchanai",
    officialName: "Burger Cartel Siliguri (Panchanai / Salbari)",
    tagline: "Vibrant Neighborhood & Student Evening Hub",
    description:
      "Burger Cartel's spacious Panchanai outlet features freshly baked brioche buns, double smashed prime patties, wood-fired artisan pizzas, and a huge dedicated parking facility along the Siliguri-Salbari corridor.",
    region: "Siliguri",
    locality: "Salbari / Sukna Highway",
    streetAddress: "Parijat Road, Salbari, Panchanai",
    addressLocality: "Siliguri",
    addressRegion: "West Bengal",
    postalCode: "734002",
    addressCountry: "IN",
    phone: "+91 78118 43316",
    phoneRaw: "+917811843316",
    hoursDisplay: "9:00 AM to 9:30 PM (Monday to Sunday)",
    openingHoursSpecification: [
      {
        dayOfWeek: [
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday",
          "Sunday",
        ],
        opens: "09:00",
        closes: "21:30",
      },
    ],
    latitude: 26.7824,
    longitude: 88.3754,
    mapsUrl: "https://maps.app.goo.gl/1oKwaBin9L4rW91q7",
    priceRange: "₹200–₹1,200",
    servesCuisine: ["American", "Burgers", "Pizza", "Cafe", "Fast Food"],
    features: [
      "Huge dedicated parking facility",
      "Spacious indoor dining",
      "Freshly ground smash patties",
      "Wood-fired pizzas baked to order",
    ],
    nearbyLandmarks: [
      "Salbari Bazaar",
      "Sukna Forest Gate",
      "Parijat Road intersection",
    ],
    directionsNote:
      "Located on Parijat Road near Salbari along the foothills highway, easily accessible with ample on-site car and bike parking.",
    image: "/images/gallery/03-burger-cartel-exterior-night.webp",
    ratingValue: 4.1,
    reviewCount: 277,
    deliveryPlatforms: [
      {
        name: "Swiggy",
        url: "https://www.swiggy.com/city/siliguri/burger-cartel-sukna-janta-nagar-rest869349",
      },
    ],
  },

  "pradhan-nagar": {
    slug: "pradhan-nagar",
    name: "Burger Cartel — Pradhan Nagar",
    officialName: "Burger Cartel Pradhan Nagar",
    tagline: "Siliguri Central Dining & Business Corridor",
    description:
      "Located in the heart of Siliguri on Nivedita Road, our Pradhan Nagar branch is celebrated for pulled BBQ pork burgers, smoked ham croissants, watermelon slushies, and artisan cheesecakes in a clean, modern atmosphere.",
    region: "Siliguri",
    locality: "Pradhan Nagar / Ward 2",
    streetAddress: "345/10/1/A Premises, Nivedita Road, Ward 2, Pradhan Nagar",
    addressLocality: "Siliguri",
    addressRegion: "West Bengal",
    postalCode: "734003",
    addressCountry: "IN",
    phone: "+91 92390 17877",
    phoneRaw: "+919239017877",
    hoursDisplay: "8:00 AM to 10:00 PM (Monday to Sunday)",
    openingHoursSpecification: [
      {
        dayOfWeek: [
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday",
          "Sunday",
        ],
        opens: "08:00",
        closes: "22:00",
      },
    ],
    latitude: 26.7271,
    longitude: 88.4239,
    mapsUrl: "https://maps.app.goo.gl/LDovHJgBRH5W5cJg7",
    priceRange: "₹200–₹800",
    servesCuisine: ["American", "Burgers", "Fast Food", "Cafe", "Bakery"],
    features: [
      "Signature Pulled BBQ Pork Burger",
      "Freshly baked breakfast croissants",
      "Clean, air-conditioned dining room",
      "Quick takeaway & delivery counter",
    ],
    nearbyLandmarks: [
      "Siliguri Junction Railway Station (nearby)",
      "Nivedita Road commercial hub",
      "Ward 2 civic center",
    ],
    directionsNote:
      "Conveniently situated along Nivedita Road in Pradhan Nagar, 5 minutes from Siliguri Junction, ideal for shoppers, business lunches, and family dinners.",
    image: "/images/gallery/14-restaurant-interior-wide.webp",
    ratingValue: 4.3,
    reviewCount: 84,
    deliveryPlatforms: [
      {
        name: "Swiggy",
        url: "https://www.swiggy.com/city/siliguri/burger-cartel-janta-nagar-rest1069787",
      },
      {
        name: "Zomato",
        url: "https://www.zomato.com/siliguri/burger-cartel-pradhan-nagar/order",
      },
    ],
  },

  darjeeling: {
    slug: "darjeeling",
    name: "Burger Cartel — Darjeeling",
    officialName: "Burger Cartel Café & Restaurant (Darjeeling Flagship)",
    tagline: "The Original Hilltop Heritage Café",
    description:
      "Perched on the upstairs floor at Chauk Bazaar inside the Hotel Seven Seas building, Burger Cartel Darjeeling serves town-favorite double smash burgers, spicy Gangnam creations, authentic Korean bowls, and specialty Himalayan coffee.",
    region: "Darjeeling",
    locality: "Chauk Bazaar / N. B. Singh Road",
    streetAddress: "Hotel Seven Seas Building, Upstairs, 17 N. B. Singh Road, Chauk Bazaar",
    addressLocality: "Darjeeling",
    addressRegion: "West Bengal",
    postalCode: "734101",
    addressCountry: "IN",
    phone: "+91 99073 32580",
    phoneRaw: "+919907332580",
    hoursDisplay: "9:00 AM to 9:00 PM (Monday to Sunday)",
    openingHoursSpecification: [
      {
        dayOfWeek: [
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday",
          "Sunday",
        ],
        opens: "09:00",
        closes: "21:00",
      },
    ],
    latitude: 27.041,
    longitude: 88.2663,
    mapsUrl: "https://maps.app.goo.gl/FYzxL6N2TYf7a59k8",
    priceRange: "₹200–₹1,000",
    servesCuisine: ["American", "Burgers", "Korean", "Cafe", "Coffee"],
    features: [
      "Voted best burgers in D-town by local guides",
      "Korean specialties: Kimbap, Bibimbap & Gangnam Spice",
      "Upstairs loft with art & acoustic music",
      "Single-origin Himalayan Arabica coffee",
    ],
    nearbyLandmarks: [
      "Chauk Bazaar marketplace",
      "Hotel Seven Seas",
      "Darjeeling Himalayan Railway Station (short walk)",
    ],
    directionsNote:
      "Located in central Chauk Bazaar. Head into the Hotel Seven Seas building and walk up to the restaurant floor for panoramic town atmosphere.",
    image: "/images/gallery/01-interior-wide.webp",
    ratingValue: 4.3,
    reviewCount: 440,
    deliveryPlatforms: [
      {
        name: "Swiggy",
        url: "https://www.swiggy.com/city/darjeeling/central-darjeeling-restaurants/snacks-cuisine-restaurants",
      },
      {
        name: "Zomato",
        url: "https://www.zomato.com/darjeeling/delivery/dish-burger",
      },
    ],
  },

  kurseong: {
    slug: "kurseong",
    name: "Burger Cartel — Kurseong",
    officialName: "Burger Cartel Kurseong",
    tagline: "Clock Tower Transit Hub & Morning Teatime Spot",
    description:
      "Located at the Clock Tower next to Kurseong Station and the heritage DHR Toy Train tracks, this scenic top-floor café serves signature smashed burgers, Thai/Korean fusion, and breakfast brews accompanied by warm Himalayan hospitality.",
    region: "Kurseong",
    locality: "Clock Tower / Motor Stand",
    streetAddress: "Top floor, Clock Tower, near Station & Motor Stand",
    addressLocality: "Kurseong",
    addressRegion: "West Bengal",
    postalCode: "734203",
    addressCountry: "IN",
    hoursDisplay: "9:00 AM to 9:00 PM (Monday to Sunday)",
    openingHoursSpecification: [
      {
        dayOfWeek: [
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday",
          "Sunday",
        ],
        opens: "09:00",
        closes: "21:00",
      },
    ],
    latitude: 26.8812,
    longitude: 88.2778,
    mapsUrl: "https://maps.app.goo.gl/Y9XQPy68UKiyvaee6",
    priceRange: "₹400–₹1,400",
    servesCuisine: ["American", "Burgers", "Asian Fusion", "Cafe", "Coffee"],
    features: [
      "Top-floor views over the hill station and mist",
      "Morning traveler breakfast rush from 9 AM",
      "Warm, hospitable mountain team",
      "Asian fusion & Korean snack selections",
    ],
    nearbyLandmarks: [
      "Kurseong Clock Tower",
      "Kurseong Railway Station (DHR Toy Train)",
      "Kurseong Motor Stand",
    ],
    directionsNote:
      "Situated directly at the landmark Clock Tower. Take the stairs to the top floor overlooking the historic railway junction.",
    image: "/images/gallery/02-interior-plants-seating.webp",
    ratingValue: 3.8,
    reviewCount: 51,
    deliveryPlatforms: [
      {
        name: "Zomato",
        url: "https://www.zomato.com/cs/kurseong/burger-cartel-kurseong-locality-kurseong/order",
      },
    ],
  },

  shivmandir: {
    slug: "shivmandir",
    name: "Burger Cartel — Shivmandir",
    officialName: "Burger Cartel Shivmandir",
    tagline: "Campus Hotspot & Highway Stop",
    description:
      "The go-to hangout for North Bengal University students and NH31 travelers, offering juicy handcrafted burgers, famous crispy onion rings, specialty matcha lattes, and cozy indoor plus open-air patio seating.",
    region: "Siliguri",
    locality: "Near NBU / Shiv Mandir",
    streetAddress: "1st Floor, Atharokhai, Bara Mohansingh, near Shiv Mandir",
    addressLocality: "Siliguri",
    addressRegion: "West Bengal",
    postalCode: "734011",
    addressCountry: "IN",
    hoursDisplay: "9:00 AM to 10:00 PM (Monday to Sunday)",
    openingHoursSpecification: [
      {
        dayOfWeek: [
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday",
          "Sunday",
        ],
        opens: "09:00",
        closes: "22:00",
      },
    ],
    latitude: 26.7095,
    longitude: 88.3562,
    mapsUrl: "https://maps.app.goo.gl/u4ATKF6SmuqRTW7FA",
    priceRange: "₹200–₹600",
    servesCuisine: ["American", "Burgers", "Snacks", "Cafe", "Matcha"],
    features: [
      "Open-air patio and cozy indoor space",
      "Student-friendly pocket pricing",
      "Specialty iced and hot matcha lattes",
      "Famous crispy golden onion rings",
    ],
    nearbyLandmarks: [
      "North Bengal University (NBU) Campus",
      "Historic Shiv Mandir temple",
      "Asian Highway / NH31 bypass",
    ],
    directionsNote:
      "Located in Bara Mohansingh near the North Bengal University gate and Shiv Mandir, 1st floor with visible roadside signage.",
    image: "/images/gallery/04-cafe-restaurant-exterior.webp",
    ratingValue: 3.9,
    reviewCount: 25,
    deliveryPlatforms: [
      {
        name: "Zomato",
        url: "https://www.zomato.com/hi/siliguri/burger-cartel-patiram-jote/order",
      },
    ],
  },
};

export const ALL_OUTLETS_LIST = Object.values(OUTLETS_SEO_DATA);

// -------------------------------------------------------------
// JSON-LD SCHEMA GENERATORS (Schema.org / Google Search Compliant)
// -------------------------------------------------------------

export function generateRestaurantSchema(outlet: OutletSeoData) {
  return {
    "@context": "https://schema.org",
    "@type": "Restaurant",
    "@id": `${SITE_URL}/locations/${outlet.slug}#restaurant`,
    name: outlet.officialName,
    alternateName: outlet.name,
    description: outlet.description,
    url: `${SITE_URL}/locations/${outlet.slug}`,
    image: [`${SITE_URL}${outlet.image}`],
    logo: `${SITE_URL}/images/logo.png`,
    telephone: outlet.phone,
    priceRange: outlet.priceRange,
    servesCuisine: outlet.servesCuisine,
    menu: `${SITE_URL}/menu`,
    hasMap: outlet.mapsUrl,
    address: {
      "@type": "PostalAddress",
      streetAddress: outlet.streetAddress,
      addressLocality: outlet.addressLocality,
      addressRegion: outlet.addressRegion,
      postalCode: outlet.postalCode,
      addressCountry: outlet.addressCountry,
    },
    geo: {
      "@type": "GeoCoordinates",
      latitude: outlet.latitude,
      longitude: outlet.longitude,
    },
    openingHoursSpecification: outlet.openingHoursSpecification.map((spec) => ({
      "@type": "OpeningHoursSpecification",
      dayOfWeek: spec.dayOfWeek,
      opens: spec.opens,
      closes: spec.closes,
    })),
    parentOrganization: {
      "@type": "Organization",
      "@id": `${SITE_URL}#organization`,
      name: "Burger Cartel",
      url: SITE_URL,
      logo: `${SITE_URL}/images/logo.png`,
    },
  };
}

export function generateOrganizationSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "Organization",
    "@id": `${SITE_URL}#organization`,
    name: "Burger Cartel",
    legalName: "Burger Cartel Cafe & Restaurant",
    url: SITE_URL,
    logo: `${SITE_URL}/images/logo.png`,
    sameAs: [
      "https://www.instagram.com/burgercartel.in?mdxt=ZDVpbDN6Z3pwZWMx",
      "https://www.facebook.com/burgercartel.in",
    ],
    description:
      "Premier American burger restaurant, artisan pizzeria, and specialty café with 5 outlets across Darjeeling, Kurseong, and Siliguri.",
    address: {
      "@type": "PostalAddress",
      addressLocality: "Siliguri",
      addressRegion: "West Bengal",
      addressCountry: "IN",
    },
    department: ALL_OUTLETS_LIST.map((outlet) => ({
      "@type": "Restaurant",
      name: outlet.officialName,
      url: `${SITE_URL}/locations/${outlet.slug}`,
      telephone: outlet.phone,
      address: {
        "@type": "PostalAddress",
        streetAddress: outlet.streetAddress,
        addressLocality: outlet.addressLocality,
        addressRegion: outlet.addressRegion,
        postalCode: outlet.postalCode,
        addressCountry: "IN",
      },
    })),
  };
}

export function generateWebSiteSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "@id": `${SITE_URL}#website`,
    name: "Burger Cartel",
    url: SITE_URL,
    description:
      "Official website of Burger Cartel. Handcrafted smash burgers, wood-fired pizza, and artisan coffee in North Bengal.",
    publisher: {
      "@id": `${SITE_URL}#organization`,
    },
  };
}

export function generateBreadcrumbSchema(
  items: Array<{ name: string; url: string }>
) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((item, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: item.name,
      item: item.url.startsWith("http") ? item.url : `${SITE_URL}${item.url}`,
    })),
  };
}

/**
 * Escapes '<' to prevent script-tag injection in application/ld+json blocks
 */
export function safeJsonLd(data: unknown): string {
  return JSON.stringify(data).replace(/</g, "\\u003c");
}
