export interface CustomerReview {
  id: string;
  author: string;
  avatarText: string;
  isLocalGuide?: boolean;
  reviewsCount?: number;
  photosCount?: number;
  rating: number; // 1 to 5
  dateText: string;
  branchId: "all" | "panchanai" | "pradhan-nagar" | "darjeeling" | "kurseong" | "shivmandir";
  branchName: string;
  diningType?: string;
  priceRange?: string;
  highlightDish?: string;
  quote: string;
  isFeatured?: boolean;
}

export interface BranchReviewSummary {
  id: "all" | "panchanai" | "pradhan-nagar" | "darjeeling" | "kurseong" | "shivmandir";
  name: string;
  shortName: string;
  locationArea: string;
  googleRating: number;
  totalReviews: number;
  priceRange: string;
  category: string;
  aiSummary: string;
  keyPraise: string[];
  googleMapsUrl?: string;
}

export const BRANCH_SUMMARIES: BranchReviewSummary[] = [
  {
    id: "all",
    name: "All 5 Branches",
    shortName: "All Locations",
    locationArea: "Darjeeling & Siliguri",
    googleRating: 4.2,
    totalReviews: 877,
    priceRange: "₹200–₹1,200",
    category: "Cafe & American Restaurant",
    aiSummary:
      "Guests across North Bengal praise Burger Cartel for juicy handcrafted patties, freshly baked brioche buns, wood-fired artisan pizzas, hospitable staff, and relaxed atmospheric interiors.",
    keyPraise: [
      "Juicy double-smashed patties",
      "Puffy freshly baked brioche",
      "Artisan pizzas & brews",
      "Warm, attentive team",
    ],
  },
  {
    id: "panchanai",
    name: "Burger Cartel Siliguri (Panchanai)",
    shortName: "Panchanai",
    locationArea: "Parijat Road, Salbari / Sukna Highway",
    googleRating: 4.1,
    totalReviews: 277,
    priceRange: "₹200–₹1,200",
    category: "American Cafe & Restaurant",
    aiSummary:
      "Diners love the juicy and flavorful meat patties, puffy freshly baked buns, and noteworthy pizzas, along with huge parking facility and spacious indoor dining.",
    keyPraise: [
      "Huge parking facility",
      "Puffy freshly baked buns",
      "Crisp wood-fired crust",
      "Aesthetic calm ambience",
    ],
    googleMapsUrl: "https://maps.google.com/?q=Burger+Cartel+Salbari+Siliguri",
  },
  {
    id: "pradhan-nagar",
    name: "Burger Cartel Pradhan Nagar",
    shortName: "Pradhan Nagar",
    locationArea: "Nivedita Road, Ward 2, Siliguri",
    googleRating: 4.3,
    totalReviews: 84,
    priceRange: "₹200–₹800",
    category: "Fast Food & Cafe",
    aiSummary:
      "Famous for its pulled BBQ pork burgers, smoked ham croissants, watermelon slushies, and artisan cheesecake in a clean, hygienic, and vibrant atmosphere.",
    keyPraise: [
      "Pulled BBQ Pork Burger",
      "Smoked Ham Croissant",
      "Watermelon Slushy",
      "Clean, modern interior",
    ],
    googleMapsUrl: "https://maps.google.com/?q=Burger+Cartel+Pradhan+Nagar+Siliguri",
  },
  {
    id: "darjeeling",
    name: "Burger Cartel Darjeeling",
    shortName: "Darjeeling",
    locationArea: "Chauk Bazaar, Hotel Seven Seas (Upstairs)",
    googleRating: 4.3,
    totalReviews: 440,
    priceRange: "₹200–₹1,000",
    category: "Cafe & Restaurant",
    aiSummary:
      "The flagship mountain destination celebrated for the best burgers in D-town, spicy Gangnam creations, authentic Korean bowls, cozy wood-and-art decor, and great music.",
    keyPraise: [
      "Best burgers in D-town",
      "Gangnam Spice & Korean dishes",
      "Upstairs loft & music",
      "Specialty coffee & shakes",
    ],
    googleMapsUrl: "https://maps.google.com/?q=Burger+Cartel+Darjeeling",
  },
  {
    id: "kurseong",
    name: "Burger Cartel Kurseong",
    shortName: "Kurseong",
    locationArea: "Top Floor, Clock Tower, near Station",
    googleRating: 3.8,
    totalReviews: 51,
    priceRange: "₹400–₹1,400",
    category: "Cafe & Asian Fusion",
    aiSummary:
      "Known for Korean, Thai, and Japanese selections alongside Cartel burgers, supported by some of the warmest and friendliest hospitality in the hills.",
    keyPraise: [
      "Genuinely warm & welcoming staff",
      "Korean, Thai & Japanese dishes",
      "Top-floor hill station views",
      "Quality casual dining",
    ],
    googleMapsUrl: "https://maps.google.com/?q=Burger+Cartel+Kurseong",
  },
  {
    id: "shivmandir",
    name: "Burger Cartel Shivmandir",
    shortName: "Shivmandir",
    locationArea: "Near North Bengal University, Bara Mohansingh",
    googleRating: 3.9,
    totalReviews: 25,
    priceRange: "₹200–₹600",
    category: "Cozy Cafe & Hangout",
    aiSummary:
      "A beloved student and local haunt serving top-notch burgers, crispy onion rings, specialty matcha teas, and relaxed outdoor open-air seating.",
    keyPraise: [
      "Specialty matcha tea",
      "Onion rings to die for",
      "Outdoor patio seating",
      "Pocket-friendly quick bites",
    ],
    googleMapsUrl: "https://maps.google.com/?q=Burger+Cartel+Shivmandir",
  },
];

export const REVIEWS_LIST: CustomerReview[] = [
  // FEATURED / PANCHANAI
  {
    id: "rev-1",
    author: "Anita Sadhya",
    avatarText: "AS",
    isLocalGuide: true,
    reviewsCount: 115,
    photosCount: 902,
    rating: 5,
    dateText: "5 months ago",
    branchId: "panchanai",
    branchName: "Panchanai (Siliguri)",
    diningType: "Dine-in",
    highlightDish: "Burgers & Cafe Vibes",
    quote:
      "What a fabulous cafe, worth visiting. Staffs are well behaved, food is fresh and good. Parking facility is huge. Aesthetic songs and cafe is all what we need for a small break from life — Burger Cartel is that cafe which mutes all the noise.",
    isFeatured: true,
  },
  {
    id: "rev-2",
    author: "Ashmri Gurung",
    avatarText: "AG",
    isLocalGuide: true,
    reviewsCount: 30,
    photosCount: 242,
    rating: 5,
    dateText: "11 months ago",
    branchId: "panchanai",
    branchName: "Panchanai (Siliguri)",
    diningType: "Brunch",
    priceRange: "₹200–₹400",
    highlightDish: "Freshly Baked Brioche & Pizzas",
    quote:
      "The burgers feature puffy, freshly baked buns paired with juicy, tender meat patties, perfectly seasoned and well-balanced in flavor. Their pizzas are equally noteworthy, with a crust that achieves the ideal balance between crispness and softness.",
    isFeatured: true,
  },
  // DARJEELING
  {
    id: "rev-3",
    author: "Bobby Singh",
    avatarText: "BS",
    isLocalGuide: true,
    reviewsCount: 1681,
    photosCount: 37063,
    rating: 5,
    dateText: "A year ago",
    branchId: "darjeeling",
    branchName: "Darjeeling Flagship",
    diningType: "Dinner",
    priceRange: "₹800–₹1,000",
    highlightDish: "Interior Atmosphere & Burgers",
    quote:
      "Burger Cartel is located in the heart of Darjeeling upstairs. I must say that it is very nicely decorated — the furnishings, painting, music, furniture, and everything else — it's definitely an experience worth coming up for.",
    isFeatured: true,
  },
  {
    id: "rev-4",
    author: "Shrawan Thapa",
    avatarText: "ST",
    isLocalGuide: false,
    reviewsCount: 6,
    rating: 5,
    dateText: "3 weeks ago",
    branchId: "darjeeling",
    branchName: "Darjeeling Flagship",
    diningType: "Breakfast & Bites",
    highlightDish: "Consistent Handcrafted Burgers",
    quote:
      "I've been a regular at Burger Cartel for quite some time now, and it's easily become one of my go-to places. The burgers are consistently delicious, the portions are satisfying, and the quality has always been great. The staff are friendly.",
    isFeatured: false,
  },
  {
    id: "rev-5",
    author: "Akshay Busa",
    avatarText: "AB",
    isLocalGuide: true,
    reviewsCount: 191,
    photosCount: 1655,
    rating: 5,
    dateText: "Google Verified Review",
    branchId: "darjeeling",
    branchName: "Darjeeling Flagship",
    diningType: "Dine-in",
    highlightDish: "Authentic Pizzas, Milkshakes & Brews",
    quote:
      "Best authentic pizzas and burgers! The staff is very polite and friendly. Food is fresh and uniquely prepared. The ambience is cherry on the cake. We also ordered milkshakes and coffees which were the best in town.",
    isFeatured: false,
  },
  // PRADHAN NAGAR
  {
    id: "rev-6",
    author: "Anisha Rai",
    avatarText: "AR",
    isLocalGuide: true,
    reviewsCount: 62,
    photosCount: 282,
    rating: 5,
    dateText: "A month ago",
    branchId: "pradhan-nagar",
    branchName: "Pradhan Nagar (Siliguri)",
    diningType: "Dine-in",
    priceRange: "₹600–₹800",
    highlightDish: "Smoked Ham Croissant & Pulled Pork",
    quote:
      "Really enjoyed the food at Burger Cartel Pradhan Nagar. The smoked ham croissant and pulled pork burger were both really tasty and the drinks were great too. Ambience and service were pretty much top-notch. Definitely coming back again!",
    isFeatured: true,
  },
  {
    id: "rev-7",
    author: "Google Local Diner",
    avatarText: "GL",
    isLocalGuide: true,
    rating: 5,
    dateText: "Google Community Review",
    branchId: "pradhan-nagar",
    branchName: "Pradhan Nagar (Siliguri)",
    diningType: "Dinner",
    highlightDish: "Pulled BBQ Pork Burger",
    quote:
      "Pulled BBQ Pork Burger — hands down the best dish of the meal. A lovely atmosphere with clean hygienic food and very prompt service.",
    isFeatured: false,
  },
  // KURSEONG
  {
    id: "rev-8",
    author: "Ayush Saha",
    avatarText: "AS",
    isLocalGuide: false,
    reviewsCount: 1,
    photosCount: 4,
    rating: 5,
    dateText: "A year ago",
    branchId: "kurseong",
    branchName: "Kurseong (Clock Tower)",
    diningType: "Lunch",
    priceRange: "₹1,200–₹1,400",
    highlightDish: "Hospitable Team & Burgers",
    quote:
      "Had lunch at Burger Cartel Kurseong, and I just have to say — the service and behavior here are incredible, like wow. The people are genuinely some of the nicest I've ever met, such a warm and welcoming bunch! And the food? Absolutely amazing.",
    isFeatured: true,
  },
  {
    id: "rev-9",
    author: "SwasTeaKa Food Bed Travels",
    avatarText: "SF",
    isLocalGuide: true,
    reviewsCount: 8,
    photosCount: 9,
    rating: 5,
    dateText: "A year ago",
    branchId: "kurseong",
    branchName: "Kurseong (Clock Tower)",
    diningType: "Dinner",
    priceRange: "₹600–₹800",
    highlightDish: "Korean & Asian Fusion",
    quote:
      "The best place when it comes to Korean, Thai or Japanese dishes. Simple and elegant. Staffs are well behaved and they make every effort to keep the customer happy.",
    isFeatured: false,
  },
  // SHIVMANDIR
  {
    id: "rev-10",
    author: "Moon Paul",
    avatarText: "MP",
    isLocalGuide: false,
    reviewsCount: 4,
    rating: 5,
    dateText: "2 months ago",
    branchId: "shivmandir",
    branchName: "Shivmandir (University Area)",
    diningType: "Dinner",
    priceRange: "₹200–₹400",
    highlightDish: "Matcha Latte & Cozy Patio",
    quote:
      "Food was 10/10, highly recommended. I was literally searching for matcha in Shivmandir and they didn't disappoint at all. The inside space was cozy, and the outdoor sitting area is lovely. Loved the cozy interior.",
    isFeatured: true,
  },
  {
    id: "rev-11",
    author: "Ena Bandyopadhyay",
    avatarText: "EB",
    isLocalGuide: true,
    reviewsCount: 51,
    photosCount: 94,
    rating: 5,
    dateText: "2 months ago",
    branchId: "shivmandir",
    branchName: "Shivmandir (University Area)",
    diningType: "Brunch",
    highlightDish: "Crispy Golden Onion Rings",
    quote:
      "Always a favourite place for quick bites! The onion rings are to die for — crispy, flavorful, and served fresh every single time.",
    isFeatured: false,
  },
  {
    id: "rev-12",
    author: "Mohit Roy",
    avatarText: "MR",
    isLocalGuide: true,
    reviewsCount: 16,
    photosCount: 1,
    rating: 5,
    dateText: "4 months ago",
    branchId: "shivmandir",
    branchName: "Shivmandir (University Area)",
    diningType: "Casual Dine-in",
    highlightDish: "Artisan Smashed Burgers",
    quote:
      "Amazing burgers! It's so nice to finally have Burger Cartel here in Shivmandir. Top quality patties, great sauces, and friendly faces.",
    isFeatured: false,
  },
  {
    id: "rev-13",
    author: "Saheli Halder",
    avatarText: "SH",
    isLocalGuide: true,
    reviewsCount: 13,
    photosCount: 34,
    rating: 5,
    dateText: "5 months ago",
    branchId: "darjeeling",
    branchName: "Darjeeling Flagship",
    diningType: "Afternoon Coffee & Bites",
    highlightDish: "Peaceful Dining Atmosphere",
    quote:
      "The food here is really good and delicious. Also the atmosphere is peaceful — perfect spot to read, talk, and enjoy great food in the hills.",
    isFeatured: false,
  },
];
