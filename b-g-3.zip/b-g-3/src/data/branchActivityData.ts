export type DayOfWeek = "MON" | "TUE" | "WED" | "THU" | "FRI" | "SAT" | "SUN";

export interface HourlyActivity {
  hour: number; // 9 to 21 (9 AM to 9 PM)
  label: string; // "9a", "12p", "3p", "6p", "9p"
  displayHour: string; // "9 AM", "12 PM", "7 PM"
  activity: number; // 0 to 100 relative percentage
  status:
    | "Usually quiet"
    | "Usually not busy"
    | "Usually a little busy"
    | "Moderate activity"
    | "Usually busy"
    | "Usually as busy as it gets"
    | "Peak hours"
    | "Closed";
  isLive?: boolean;
  liveStatus?: string; // e.g. "Live: A little busy", "Live: Not too busy"
  liveNote?: string; // e.g. "Usually no wait"
}

export interface DayData {
  day: DayOfWeek;
  dayFull: string;
  isVerifiedSnapshot: boolean;
  defaultSelectedHour: number; // Hour to highlight by default (e.g. 19 for 7 PM, 21 for 9 PM Live)
  hours: HourlyActivity[];
}

export interface BranchActivity {
  id: "panchanai" | "pradhan-nagar" | "darjeeling" | "kurseong" | "shivmandir";
  name: string;
  shortName: string;
  tagline: string;
  neighborhood: string;
  address: string;
  mapsUrl: string;
  operatingHours: string;
  daysOpen: string;
  typicalDwellTime: string; // Directly from Google Maps screenshot
  verifiedDay: DayOfWeek;
  verifiedReference: string; // Description of screenshot evidence
  patternSummary: string;
  highlights: string[];
  days: Record<DayOfWeek, DayData>;
}

// Helper to determine status from activity value
function getStatusForActivity(activity: number): HourlyActivity["status"] {
  if (activity === 0) return "Closed";
  if (activity <= 18) return "Usually quiet";
  if (activity <= 32) return "Usually not busy";
  if (activity <= 52) return "Usually a little busy";
  if (activity <= 72) return "Moderate activity";
  if (activity <= 80) return "Usually busy";
  return "Usually as busy as it gets";
}

// -------------------------------------------------------------
// 1. PANCHANAI (Parijat Road / Salbari) — Screenshot 1
// -------------------------------------------------------------
// Reference: media_1793291690827_b12e9f30.png
// Thursday verified snapshot: 9p Live bar (coral) with "Live: A little busy / Usually no wait"
// Dwell time: "People typically spend 10 min to 1 hr here"
// -------------------------------------------------------------
const panchanaiThursdayHours: HourlyActivity[] = [
  { hour: 9, label: "9a", displayHour: "9 AM", activity: 16, status: "Usually quiet" },
  { hour: 10, label: "10a", displayHour: "10 AM", activity: 22, status: "Usually not busy" },
  { hour: 11, label: "11a", displayHour: "11 AM", activity: 25, status: "Usually not busy" },
  { hour: 12, label: "12p", displayHour: "12 PM", activity: 28, status: "Usually not busy" },
  { hour: 13, label: "1p", displayHour: "1 PM", activity: 26, status: "Usually not busy" },
  { hour: 14, label: "2p", displayHour: "2 PM", activity: 28, status: "Usually not busy" },
  { hour: 15, label: "3p", displayHour: "3 PM", activity: 32, status: "Usually not busy" },
  { hour: 16, label: "4p", displayHour: "4 PM", activity: 42, status: "Usually a little busy" },
  { hour: 17, label: "5p", displayHour: "5 PM", activity: 56, status: "Moderate activity" },
  { hour: 18, label: "6p", displayHour: "6 PM", activity: 74, status: "Usually busy" },
  { hour: 19, label: "7p", displayHour: "7 PM", activity: 80, status: "Usually as busy as it gets" },
  { hour: 20, label: "8p", displayHour: "8 PM", activity: 68, status: "Usually busy" },
  {
    hour: 21,
    label: "9p",
    displayHour: "9 PM",
    activity: 58,
    status: "Usually a little busy",
    isLive: true,
    liveStatus: "Live: A little busy",
    liveNote: "Usually no wait",
  },
];

function generatePanchanaiWeek(): Record<DayOfWeek, DayData> {
  const days: DayOfWeek[] = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];
  const fullNames: Record<DayOfWeek, string> = {
    MON: "Monday",
    TUE: "Tuesday",
    WED: "Wednesday",
    THU: "Thursday",
    FRI: "Friday",
    SAT: "Saturday",
    SUN: "Sunday",
  };

  const result = {} as Record<DayOfWeek, DayData>;

  days.forEach((day) => {
    if (day === "THU") {
      result.THU = {
        day: "THU",
        dayFull: "Thursday",
        isVerifiedSnapshot: true,
        defaultSelectedHour: 21,
        hours: panchanaiThursdayHours,
      };
    } else {
      // Calibrated relative curve based on verified pattern
      const multiplier =
        day === "SAT" || day === "SUN" ? 1.15 : day === "FRI" ? 1.1 : 0.94;

      const hours: HourlyActivity[] = panchanaiThursdayHours.map((h) => {
        const adjustedActivity = Math.min(
          96,
          Math.max(10, Math.round(h.activity * multiplier))
        );
        return {
          ...h,
          activity: adjustedActivity,
          status: getStatusForActivity(adjustedActivity),
          isLive: false,
          liveStatus: undefined,
          liveNote: undefined,
        };
      });

      result[day] = {
        day,
        dayFull: fullNames[day],
        isVerifiedSnapshot: false,
        defaultSelectedHour: 19,
        hours,
      };
    }
  });

  return result;
}

// -------------------------------------------------------------
// 2. PRADHAN NAGAR — Screenshot 2
// -------------------------------------------------------------
// Reference: media_1793291700809_1ff978fe.png
// Thursday verified snapshot: 9p Live bar (coral) with "Live: Not too busy"
// Peak at 8p (~82%)
// -------------------------------------------------------------
const pradhanNagarThursdayHours: HourlyActivity[] = [
  { hour: 9, label: "9a", displayHour: "9 AM", activity: 20, status: "Usually quiet" },
  { hour: 10, label: "10a", displayHour: "10 AM", activity: 22, status: "Usually not busy" },
  { hour: 11, label: "11a", displayHour: "11 AM", activity: 24, status: "Usually not busy" },
  { hour: 12, label: "12p", displayHour: "12 PM", activity: 24, status: "Usually not busy" },
  { hour: 13, label: "1p", displayHour: "1 PM", activity: 26, status: "Usually not busy" },
  { hour: 14, label: "2p", displayHour: "2 PM", activity: 27, status: "Usually not busy" },
  { hour: 15, label: "3p", displayHour: "3 PM", activity: 31, status: "Usually not busy" },
  { hour: 16, label: "4p", displayHour: "4 PM", activity: 35, status: "Usually a little busy" },
  { hour: 17, label: "5p", displayHour: "5 PM", activity: 48, status: "Usually a little busy" },
  { hour: 18, label: "6p", displayHour: "6 PM", activity: 62, status: "Moderate activity" },
  { hour: 19, label: "7p", displayHour: "7 PM", activity: 76, status: "Usually busy" },
  { hour: 20, label: "8p", displayHour: "8 PM", activity: 82, status: "Usually as busy as it gets" },
  {
    hour: 21,
    label: "9p",
    displayHour: "9 PM",
    activity: 52,
    status: "Usually a little busy",
    isLive: true,
    liveStatus: "Live: Not too busy",
    liveNote: "Steady evening flow",
  },
];

function generatePradhanNagarWeek(): Record<DayOfWeek, DayData> {
  const days: DayOfWeek[] = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];
  const fullNames: Record<DayOfWeek, string> = {
    MON: "Monday",
    TUE: "Tuesday",
    WED: "Wednesday",
    THU: "Thursday",
    FRI: "Friday",
    SAT: "Saturday",
    SUN: "Sunday",
  };

  const result = {} as Record<DayOfWeek, DayData>;

  days.forEach((day) => {
    if (day === "THU") {
      result.THU = {
        day: "THU",
        dayFull: "Thursday",
        isVerifiedSnapshot: true,
        defaultSelectedHour: 21,
        hours: pradhanNagarThursdayHours,
      };
    } else {
      const multiplier =
        day === "SAT" || day === "SUN" ? 1.18 : day === "FRI" ? 1.12 : 0.92;

      const hours: HourlyActivity[] = pradhanNagarThursdayHours.map((h) => {
        const adjustedActivity = Math.min(
          98,
          Math.max(12, Math.round(h.activity * multiplier))
        );
        return {
          ...h,
          activity: adjustedActivity,
          status: getStatusForActivity(adjustedActivity),
          isLive: false,
          liveStatus: undefined,
          liveNote: undefined,
        };
      });

      result[day] = {
        day,
        dayFull: fullNames[day],
        isVerifiedSnapshot: false,
        defaultSelectedHour: 20,
        hours,
      };
    }
  });

  return result;
}

// -------------------------------------------------------------
// 3. DARJEELING (Chauk Bazaar) — Screenshot 3
// -------------------------------------------------------------
// Reference: media_1793291707648_1c636b71.png
// Thursday verified snapshot: 7pm selected (blue) "7pm: Usually a little busy"
// Dwell time: "People typically spend 30 min to 3 hr here"
// 9p is closed / zero (mountain hill station closes early)
// -------------------------------------------------------------
const darjeelingThursdayHours: HourlyActivity[] = [
  { hour: 9, label: "9a", displayHour: "9 AM", activity: 18, status: "Usually quiet" },
  { hour: 10, label: "10a", displayHour: "10 AM", activity: 18, status: "Usually quiet" },
  { hour: 11, label: "11a", displayHour: "11 AM", activity: 20, status: "Usually not busy" },
  { hour: 12, label: "12p", displayHour: "12 PM", activity: 20, status: "Usually not busy" },
  { hour: 13, label: "1p", displayHour: "1 PM", activity: 17, status: "Usually quiet" },
  { hour: 14, label: "2p", displayHour: "2 PM", activity: 16, status: "Usually quiet" },
  { hour: 15, label: "3p", displayHour: "3 PM", activity: 22, status: "Usually not busy" },
  { hour: 16, label: "4p", displayHour: "4 PM", activity: 28, status: "Usually not busy" },
  { hour: 17, label: "5p", displayHour: "5 PM", activity: 33, status: "Usually a little busy" },
  { hour: 18, label: "6p", displayHour: "6 PM", activity: 42, status: "Usually a little busy" },
  { hour: 19, label: "7p", displayHour: "7 PM", activity: 52, status: "Usually a little busy" },
  { hour: 20, label: "8p", displayHour: "8 PM", activity: 47, status: "Usually a little busy" },
  { hour: 21, label: "9p", displayHour: "9 PM", activity: 0, status: "Closed" },
];

function generateDarjeelingWeek(): Record<DayOfWeek, DayData> {
  const days: DayOfWeek[] = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];
  const fullNames: Record<DayOfWeek, string> = {
    MON: "Monday",
    TUE: "Tuesday",
    WED: "Wednesday",
    THU: "Thursday",
    FRI: "Friday",
    SAT: "Saturday",
    SUN: "Sunday",
  };

  const result = {} as Record<DayOfWeek, DayData>;

  days.forEach((day) => {
    if (day === "THU") {
      result.THU = {
        day: "THU",
        dayFull: "Thursday",
        isVerifiedSnapshot: true,
        defaultSelectedHour: 19,
        hours: darjeelingThursdayHours,
      };
    } else {
      const multiplier =
        day === "SAT" || day === "SUN" ? 1.25 : day === "FRI" ? 1.1 : 0.9;

      const hours: HourlyActivity[] = darjeelingThursdayHours.map((h) => {
        if (h.hour === 21) {
          return { ...h, activity: 0, status: "Closed" };
        }
        const adjustedActivity = Math.min(
          85,
          Math.max(12, Math.round(h.activity * multiplier))
        );
        return {
          ...h,
          activity: adjustedActivity,
          status: getStatusForActivity(adjustedActivity),
        };
      });

      result[day] = {
        day,
        dayFull: fullNames[day],
        isVerifiedSnapshot: false,
        defaultSelectedHour: 19,
        hours,
      };
    }
  });

  return result;
}

// -------------------------------------------------------------
// 4. KURSEONG — Screenshot 4
// -------------------------------------------------------------
// Reference: media_1793291716013_3c2a9d1b.png
// Thursday verified snapshot: 10am selected (blue) "10am: Usually as busy as it gets"
// Unique morning rush (~62% at 10a) + evening rush (4p-6p ~52%)
// 9p is closed
// -------------------------------------------------------------
const kurseongThursdayHours: HourlyActivity[] = [
  { hour: 9, label: "9a", displayHour: "9 AM", activity: 50, status: "Usually a little busy" },
  { hour: 10, label: "10a", displayHour: "10 AM", activity: 62, status: "Usually as busy as it gets" },
  { hour: 11, label: "11a", displayHour: "11 AM", activity: 38, status: "Usually a little busy" },
  { hour: 12, label: "12p", displayHour: "12 PM", activity: 28, status: "Usually not busy" },
  { hour: 13, label: "1p", displayHour: "1 PM", activity: 22, status: "Usually not busy" },
  { hour: 14, label: "2p", displayHour: "2 PM", activity: 35, status: "Usually a little busy" },
  { hour: 15, label: "3p", displayHour: "3 PM", activity: 32, status: "Usually not busy" },
  { hour: 16, label: "4p", displayHour: "4 PM", activity: 52, status: "Moderate activity" },
  { hour: 17, label: "5p", displayHour: "5 PM", activity: 50, status: "Usually a little busy" },
  { hour: 18, label: "6p", displayHour: "6 PM", activity: 52, status: "Moderate activity" },
  { hour: 19, label: "7p", displayHour: "7 PM", activity: 40, status: "Usually a little busy" },
  { hour: 20, label: "8p", displayHour: "8 PM", activity: 30, status: "Usually not busy" },
  { hour: 21, label: "9p", displayHour: "9 PM", activity: 0, status: "Closed" },
];

function generateKurseongWeek(): Record<DayOfWeek, DayData> {
  const days: DayOfWeek[] = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];
  const fullNames: Record<DayOfWeek, string> = {
    MON: "Monday",
    TUE: "Tuesday",
    WED: "Wednesday",
    THU: "Thursday",
    FRI: "Friday",
    SAT: "Saturday",
    SUN: "Sunday",
  };

  const result = {} as Record<DayOfWeek, DayData>;

  days.forEach((day) => {
    if (day === "THU") {
      result.THU = {
        day: "THU",
        dayFull: "Thursday",
        isVerifiedSnapshot: true,
        defaultSelectedHour: 10,
        hours: kurseongThursdayHours,
      };
    } else {
      const multiplier =
        day === "SAT" || day === "SUN" ? 1.2 : day === "FRI" ? 1.08 : 0.95;

      const hours: HourlyActivity[] = kurseongThursdayHours.map((h) => {
        if (h.hour === 21) {
          return { ...h, activity: 0, status: "Closed" };
        }
        const adjustedActivity = Math.min(
          90,
          Math.max(14, Math.round(h.activity * multiplier))
        );
        return {
          ...h,
          activity: adjustedActivity,
          status: getStatusForActivity(adjustedActivity),
        };
      });

      result[day] = {
        day,
        dayFull: fullNames[day],
        isVerifiedSnapshot: false,
        defaultSelectedHour: 10,
        hours,
      };
    }
  });

  return result;
}

// -------------------------------------------------------------
// 5. SHIVMANDIR — Screenshot 5
// -------------------------------------------------------------
// Reference: media_1793291723813_a47e248d.png
// Wednesday verified snapshot: 12pm selected (blue) "12pm: Usually a little busy"
// Midday lunch surge (12p ~48%) + late afternoon dip (4p ~8%) + dinner rebound (9p ~32%)
// -------------------------------------------------------------
const shivmandirWednesdayHours: HourlyActivity[] = [
  { hour: 9, label: "9a", displayHour: "9 AM", activity: 22, status: "Usually not busy" },
  { hour: 10, label: "10a", displayHour: "10 AM", activity: 30, status: "Usually not busy" },
  { hour: 11, label: "11a", displayHour: "11 AM", activity: 38, status: "Usually a little busy" },
  { hour: 12, label: "12p", displayHour: "12 PM", activity: 48, status: "Usually a little busy" },
  { hour: 13, label: "1p", displayHour: "1 PM", activity: 36, status: "Usually a little busy" },
  { hour: 14, label: "2p", displayHour: "2 PM", activity: 26, status: "Usually not busy" },
  { hour: 15, label: "3p", displayHour: "3 PM", activity: 12, status: "Usually quiet" },
  { hour: 16, label: "4p", displayHour: "4 PM", activity: 8, status: "Usually quiet" },
  { hour: 17, label: "5p", displayHour: "5 PM", activity: 18, status: "Usually quiet" },
  { hour: 18, label: "6p", displayHour: "6 PM", activity: 20, status: "Usually not busy" },
  { hour: 19, label: "7p", displayHour: "7 PM", activity: 32, status: "Usually not busy" },
  { hour: 20, label: "8p", displayHour: "8 PM", activity: 26, status: "Usually not busy" },
  { hour: 21, label: "9p", displayHour: "9 PM", activity: 32, status: "Usually not busy" },
];

function generateShivmandirWeek(): Record<DayOfWeek, DayData> {
  const days: DayOfWeek[] = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];
  const fullNames: Record<DayOfWeek, string> = {
    MON: "Monday",
    TUE: "Tuesday",
    WED: "Wednesday",
    THU: "Thursday",
    FRI: "Friday",
    SAT: "Saturday",
    SUN: "Sunday",
  };

  const result = {} as Record<DayOfWeek, DayData>;

  days.forEach((day) => {
    if (day === "WED") {
      result.WED = {
        day: "WED",
        dayFull: "Wednesday",
        isVerifiedSnapshot: true,
        defaultSelectedHour: 12,
        hours: shivmandirWednesdayHours,
      };
    } else {
      const multiplier =
        day === "SAT" || day === "SUN" ? 1.25 : day === "FRI" ? 1.15 : 0.95;

      const hours: HourlyActivity[] = shivmandirWednesdayHours.map((h) => {
        const adjustedActivity = Math.min(
          92,
          Math.max(6, Math.round(h.activity * multiplier))
        );
        return {
          ...h,
          activity: adjustedActivity,
          status: getStatusForActivity(adjustedActivity),
        };
      });

      result[day] = {
        day,
        dayFull: fullNames[day],
        isVerifiedSnapshot: false,
        defaultSelectedHour: 12,
        hours,
      };
    }
  });

  return result;
}

// -------------------------------------------------------------
// MASTER EXPORT: All 5 Branches in the Exact User-Specified Order
// -------------------------------------------------------------
export const BRANCH_ACTIVITIES: BranchActivity[] = [
  {
    id: "panchanai",
    name: "Panchanai (Parijat Road / Salbari)",
    shortName: "Panchanai",
    tagline: "Vibrant Neighborhood & Student Evening Hub",
    neighborhood: "Parijat Road, Salbari",
    address: "Parijat Rd, Siliguri, Panchanai, West Bengal 734002",
    mapsUrl: "https://maps.app.goo.gl/1oKwaBin9L4rW91q7",
    operatingHours: "9:00 AM – 9:30 PM",
    daysOpen: "Monday to Sunday",
    typicalDwellTime: "People typically spend 10 min to 1 hr here",
    verifiedDay: "THU",
    verifiedReference: "Google Maps Popular Times (Thursday 9 PM Live snapshot)",
    patternSummary:
      "Steady afternoon bites build into an energetic peak dinner rush between 6 PM and 8 PM, tapering gently into a relaxed late evening with minimal wait.",
    highlights: [
      "Peak hours: 6 PM – 8 PM (7 PM high of ~80%)",
      "Fast turnover with quick-service counter seating",
      "Wood-fired pizzas and smash burgers draw evening crowds",
    ],
    days: generatePanchanaiWeek(),
  },
  {
    id: "pradhan-nagar",
    name: "Pradhan Nagar",
    shortName: "Pradhan Nagar",
    tagline: "Siliguri Central Dining & Business Corridor",
    neighborhood: "Nivedita Road, Ward 2, Siliguri",
    address: "Nivedita Rd, Ward 2, Pradhan Nagar, Siliguri, West Bengal 734003",
    mapsUrl: "https://maps.app.goo.gl/LDovHJgBRH5W5cJg7",
    operatingHours: "8:00 AM – 10:00 PM",
    daysOpen: "Monday to Sunday",
    typicalDwellTime: "People typically spend 15 min to 1.5 hr here",
    verifiedDay: "THU",
    verifiedReference: "Google Maps Popular Times (Thursday 9 PM Live snapshot)",
    patternSummary:
      "A calm morning and afternoon flow transforms into our most spirited evening atmosphere, peaking at 8 PM as families, shoppers, and friends gather.",
    highlights: [
      "Peak hour: 8 PM (highest activity at ~82%)",
      "Spacious dining room suited for group celebrations",
      "Steady post-work dinner flow through 10 PM",
    ],
    days: generatePradhanNagarWeek(),
  },
  {
    id: "darjeeling",
    name: "Darjeeling (Chauk Bazaar)",
    shortName: "Darjeeling",
    tagline: "The Original Hilltop Heritage Café",
    neighborhood: "Chauk Bazaar, Hotel Seven Seas",
    address:
      "Hotel Seven Seas Building, 17 N, B Singh Road, Chauk Bazaar, Darjeeling, West Bengal 734101",
    mapsUrl: "https://maps.app.goo.gl/FYzxL6N2TYf7a59k8",
    operatingHours: "9:00 AM – 9:00 PM",
    daysOpen: "Monday to Sunday",
    typicalDwellTime: "People typically spend 30 min to 3 hr here",
    verifiedDay: "THU",
    verifiedReference: "Google Maps Popular Times (Thursday 7 PM snapshot)",
    patternSummary:
      "Visitors linger longest here—often up to 3 hours over single-estate coffee, mountain fog views, and smash burgers. Evenings peak cozily around 7 PM before early hill closing.",
    highlights: [
      "Peak hour: 7 PM (activity ~52%)",
      "Extended dwell time (30 min – 3 hr) for relaxed cafe conversations",
      "Early mountain closing: wraps up comfortably by 8:30 PM",
    ],
    days: generateDarjeelingWeek(),
  },
  {
    id: "kurseong",
    name: "Kurseong",
    shortName: "Kurseong",
    tagline: "Clock Tower Transit Hub & Morning Teatime Spot",
    neighborhood: "Top Floor, Clock Tower, near Station",
    address: "Top floor, Clock tower, near Station, Kurseong, West Bengal 734203",
    mapsUrl: "https://maps.app.goo.gl/Y9XQPy68UKiyvaee6",
    operatingHours: "9:00 AM – 9:00 PM",
    daysOpen: "Monday to Sunday",
    typicalDwellTime: "People typically spend 20 min to 1 hr here",
    verifiedDay: "THU",
    verifiedReference: "Google Maps Popular Times (Thursday 10 AM snapshot)",
    patternSummary:
      "Features a distinct two-peak rhythm: an early morning breakfast and traveler rush at 10 AM ('As busy as it gets'), followed by a second afternoon surge from 4 PM to 6 PM.",
    highlights: [
      "Morning peak: 10 AM (~62% activity, breakfast & brunch)",
      "Afternoon teatime second wave: 4 PM – 6 PM (~52%)",
      "Convenient transit stop overlooking the Kurseong toy train tracks",
    ],
    days: generateKurseongWeek(),
  },
  {
    id: "shivmandir",
    name: "Shivmandir",
    shortName: "Shivmandir",
    tagline: "Campus Hotspot & Highway Stop",
    neighborhood: "Shiv Mandir, Bara Mohansingh",
    address: "Shiv Mandir, Siliguri, Bara Mohansingh, West Bengal 734011",
    mapsUrl: "https://maps.app.goo.gl/u4ATKF6SmuqRTW7FA",
    operatingHours: "9:00 AM – 10:00 PM",
    daysOpen: "Monday to Sunday",
    typicalDwellTime: "People typically spend 15 min to 1 hr here",
    verifiedDay: "WED",
    verifiedReference: "Google Maps Popular Times (Wednesday 12 PM snapshot)",
    patternSummary:
      "Driven by North Bengal University students and highway travelers, featuring a prominent midday lunch spike around 12 PM, an afternoon lull, and an active evening social scene.",
    highlights: [
      "Midday lunch peak: 12 PM (~48% student rush)",
      "Quiet study & chill hours: 3 PM – 5 PM (<15% activity)",
      "Late evening hangout hours through 9:30 PM",
    ],
    days: generateShivmandirWeek(),
  },
];
