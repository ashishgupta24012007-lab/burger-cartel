export interface MenuItem {
  id: string;
  name: string;
  category: string;
  subcategory?: string;
  description: string;
  image: string;
  isVegetarian?: boolean;
  isHouseFavourite?: boolean;
  variants?: string[];
  tags?: string[];
}

export interface MenuCategoryConfig {
  id: string;
  name: string;
  shortName?: string;
  subtitle: string;
  description: string;
}

export const MENU_CATEGORIES: MenuCategoryConfig[] = [
  {
    id: "burgers",
    name: "BURGERS",
    shortName: "Burgers",
    subtitle: "Category A",
    description: "Handcrafted patties, custom prime cuts, and fresh brioche buns built with bold character.",
  },
  {
    id: "pizzas",
    name: "PIZZAS",
    shortName: "Pizzas",
    subtitle: "Category B",
    description: "Classic Neapolitan-inspired thin crust with hand-stretched dough and slow-simmered homemade sauces.",
  },
  {
    id: "croissants",
    name: "CROISSANTS & CROISSANT BURGERS",
    shortName: "Croissants",
    subtitle: "Category C",
    description: "Golden flaky all-butter pastry layered with artisanal fillings, melted cheese, and signature secret sauces.",
  },
  {
    id: "sandwiches",
    name: "SANDWICHES & SUBS",
    shortName: "Sandwiches",
    subtitle: "Category D",
    description: "Toasted Cartel bread and buttery rolls stacked high with slow-cooked meats, crispy greens, and house dressings.",
  },
  {
    id: "hotdogs",
    name: "HOT DOGS",
    shortName: "Hot Dogs",
    subtitle: "Category E",
    description: "Gourmet hot dogs loaded with pulled meats, house-made roasted relishes, and artisanal toppings.",
  },
  {
    id: "pasta",
    name: "PASTA",
    shortName: "Pasta",
    subtitle: "Category F",
    description: "Al dente Italian pastas prepared fresh with homemade walnut pesto, velvety Alfredo, or spicy Arrabbiata.",
  },
  {
    id: "mains",
    name: "MAINS",
    shortName: "Mains",
    subtitle: "Category G",
    description: "Hearty slow-roasted steaks and chops served with creamy mashed potatoes and rich mushroom gravy.",
  },
  {
    id: "breakfast",
    name: "BREAKFAST & BRUNCH",
    shortName: "Breakfast",
    subtitle: "Category H",
    description: "From Darjeeling hometown classics to fluffy pancake stacks and hollandaise poached eggs.",
  },
  {
    id: "korean",
    name: "KOREAN SETS",
    shortName: "Korean",
    subtitle: "Category I",
    description: "Communal table-side feasts, sizzling Bulgogi, bubbling Hot Pot, and banchan side dishes.",
  },
  {
    id: "noodles-rice",
    name: "NOODLES & RICE BOWLS",
    shortName: "Rice & Noodles",
    subtitle: "Category J",
    description: "Kathmandu spiced noodles, Korean army stew, Thai pad thai, and sizzling dolsot rice bowls.",
  },
  {
    id: "salads",
    name: "SALADS",
    shortName: "Salads",
    subtitle: "Category K",
    description: "Crisp garden greens, hand-pounded Thai papaya, and seasoned crispy pork tossed in house vinaigrettes.",
  },
  {
    id: "sides",
    name: "SNACKS & SIDES",
    shortName: "Sides",
    subtitle: "Category L",
    description: "Thin shoestring fries, herbed garlic bread, golden onion rings, and glazed signature chicken wings.",
  },
  {
    id: "specials",
    name: "SPECIALS",
    shortName: "Specials",
    subtitle: "Category M",
    description: "Signature crowd favorites and Korean street rolls crafted with Chef Kwai's distinct attitude.",
  },
  {
    id: "beverages",
    name: "BEVERAGES",
    shortName: "Beverages",
    subtitle: "Category N",
    description: "Pure Darjeeling tea infusions, thick milkshakes, fizzy coolers, artisan coffee, and chilled smoothies.",
  },
];

export const PIZZA_CUSTOM_ADDONS = [
  "Extra Mozzarella Cheese",
  "Crisp Bacon Rashers",
  "Pickled Jalapeños",
  "Shaved Red Onions",
  "Poached Shrimps",
  "Homemade Walnut Pesto",
  "Sweet Pineapple",
  "Roasted Capsicum",
];

export const CROISSANT_BURGER_OPTIONS = [
  "Gangnam Spice",
  "Hot Fuss",
  "Dirty Bird",
  "BBQ Buster",
  "Teriyaki Boys",
  "Spice Master",
  "Shrimpstic",
  "Corny Paneer",
  "The Classic",
  "Pulled Porkey",
  "Bacon & Cheese",
];

export const BREAKFAST_ADDONS = [
  "Cheddar Cheese",
  "Crisp Bacon",
  "Fresh Side Salad",
  "Peanut Butter",
  "Extra Eggs (Any Style)",
  "Fresh Banana",
];

export const MASTER_MENU_ITEMS: MenuItem[] = [
  // ==========================================
  // CATEGORY A — BURGERS
  // ==========================================
  {
    id: "the-classic",
    name: "The Classic",
    category: "burgers",
    description:
      "A classic hamburger with rich melted cheddar cheese, sweet grilled onions, fresh tomato slices, and homemade secret sauce. Tender chicken and gourmet patty options available.",
    image: "/images/menu/burgers/the-classic-fresh.webp",
    isHouseFavourite: true,
    variants: ["Chicken Patty", "Double Patty"],
    tags: ["burger", "chicken", "classic"],
  },
  {
    id: "crispy-bird",
    name: "Crispy Bird",
    category: "burgers",
    description:
      "Juicy golden-fried chicken fillet, melted cheddar cheese, caramelized grilled onions, tangy tomato relish, and signature secret sauce on toasted brioche.",
    image: "/images/menu/burgers/crispy-bird-fresh.webp",
    isHouseFavourite: true,
    tags: ["burger", "chicken", "crispy"],
  },
  {
    id: "gangnam-spice",
    name: "Gangnam Spice",
    category: "burgers",
    description:
      "Crispy fried chicken dredged in fiery Korean glaze, topped with house tomato relish, grilled onions, cooling sour cream sauce, and melted cheddar.",
    image: "/images/menu/burgers/gangnam-spice-fresh.webp",
    isHouseFavourite: true,
    tags: ["burger", "korean", "spicy", "chicken"],
  },
  {
    id: "hot-chick",
    name: "Hot Chick",
    category: "burgers",
    description:
      "Hot and spicy fried chicken glazed in fiery barbecue or chilli-mustard sauce, crunchy house coleslaw, pickles, and our signature secret sauce.",
    image: "/images/menu/burgers/hot-chick-fresh.webp",
    tags: ["burger", "spicy", "chicken"],
  },
  {
    id: "dirty-bird",
    name: "Dirty Bird",
    category: "burgers",
    description:
      "Crispy fried chicken generously dusted with fiery peri-peri seasoning, paired with homemade tomato relish, sweet grilled onions, and crisp lettuce.",
    image: "/images/menu/burgers/dirty-bird.webp",
    tags: ["burger", "peri-peri", "chicken"],
  },
  {
    id: "corny-paneer",
    name: "Corny Paneer",
    category: "burgers",
    description:
      "Handcrafted vegetarian paneer-and-corn patty layered with sweet grilled onions, tomato relish, sour cream, and homemade cartel sauce.",
    image: "/images/menu/burgers/corny-paneer-fresh.webp",
    isVegetarian: true,
    tags: ["burger", "vegetarian", "paneer"],
  },
  {
    id: "bbq-buster",
    name: "BBQ-Buster",
    category: "burgers",
    description:
      "Crispy seasoned vegetarian fried patty glazed with savory Korean barbecue sauce, accompanied by tomato relish, grilled onions, and fresh greens.",
    image: "/images/menu/burgers/bbq-buster-fresh.webp",
    isVegetarian: true,
    tags: ["burger", "vegetarian", "bbq"],
  },
  {
    id: "magic-mushroom",
    name: "Magic Mushroom",
    category: "burgers",
    description:
      "Savory pulled barbecue mushrooms topped with melted cheddar cheese, caramelized grilled onions, fresh tomato relish, and rich sour cream sauce.",
    image: "/images/menu/burgers/magic-mushroom-fresh.webp",
    isVegetarian: true,
    tags: ["burger", "vegetarian", "mushroom"],
  },
  {
    id: "bacon-and-cheese",
    name: "Bacon & Cheese",
    category: "burgers",
    description:
      "Thick savory bacon rashers paired with melted cheddar cheese, homemade tomato relish, grilled onions, and secret sauce. Retains meat variants supported by outlet.",
    image: "/images/menu/burgers/bacon-and-cheese-fresh.webp",
    isHouseFavourite: true,
    variants: ["Chicken Patty Base", "Gourmet Patty Base"],
    tags: ["burger", "bacon", "cheese"],
  },
  {
    id: "pulled-porky",
    name: "Pulled Porky",
    category: "burgers",
    description:
      "Slow-cooked tender barbecue pulled pork served on a crunchy bed of house coleslaw with pickled cucumber and melted cheddar cheese.",
    image: "/images/menu/burgers/pulled-porky-fresh.webp",
    tags: ["burger", "pork", "bbq"],
  },
  {
    id: "big-monster",
    name: "Big Monster",
    category: "burgers",
    description:
      "Cartel double hamburger loaded with double cheddar cheese, grilled onions, sliced tomato, secret sauce, and crowned with crispy beer-battered onion rings.",
    image: "/images/menu/burgers/big-monster-fresh.webp",
    isHouseFavourite: true,
    tags: ["burger", "double", "monster", "signature"],
  },

  // ==========================================
  // CATEGORY B — PIZZAS
  // ==========================================
  {
    id: "miss-margherita",
    name: "Miss Margherita",
    category: "pizzas",
    description:
      "Classic Neapolitan thin-crust pizza baked with hand-pulled mozzarella cheese, homemade Italian tomato sauce, and aromatic fresh sweet basil.",
    image: "/images/menu/pizzas/miss-margherita.webp",
    isVegetarian: true,
    isHouseFavourite: true,
    tags: ["pizza", "margherita", "vegetarian", "classic"],
  },
  {
    id: "so-corny",
    name: "So-Corny",
    category: "pizzas",
    description:
      "Stone-baked thin crust pizza topped with bubbly mozzarella, sweet golden corn kernels, sliced red onions, and homemade tomato sauce.",
    image: "/images/menu/pizzas/so-corny.webp",
    isVegetarian: true,
    tags: ["pizza", "corn", "vegetarian"],
  },
  {
    id: "shroom-n-onion",
    name: "Shroom N Onion",
    category: "pizzas",
    description:
      "Caramelized onions and savory pulled barbecue mushrooms over melted mozzarella with shaved red onions on slow-fermented dough.",
    image: "/images/menu/pizzas/shroom-n-onion.webp",
    isVegetarian: true,
    tags: ["pizza", "mushroom", "vegetarian"],
  },
  {
    id: "pepper-jack",
    name: "Pepper Jack",
    category: "pizzas",
    description:
      "Roasted sweet bell peppers, pickled jalapeños, and fragrant cherry tomato confit layered over creamy melted mozzarella.",
    image: "/images/menu/pizzas/pepper-jack.webp",
    isVegetarian: true,
    tags: ["pizza", "peppers", "jalapeno", "vegetarian"],
  },
  {
    id: "pepperoni-pork",
    name: "Pepperoni Pork",
    category: "pizzas",
    description:
      "Crisp hand-stretched margherita pizza topped with generous spicy pork sausage slices, mozzarella, and torn Italian basil.",
    image: "/images/menu/pizzas/pepperoni-pork.webp",
    isHouseFavourite: true,
    tags: ["pizza", "pepperoni", "pork"],
  },
  {
    id: "marinara-chick",
    name: "Marinara Chick",
    category: "pizzas",
    description:
      "Spicy minced chicken simmered in homemade marinara sauce, topped with shaved red onions and pickled jalapeños over melted cheese.",
    image: "/images/menu/pizzas/marinara-chick.webp",
    tags: ["pizza", "chicken", "spicy"],
  },
  {
    id: "desi-tandoori",
    name: "Desi Tandoori",
    category: "pizzas",
    description:
      "Grilled tandoori chicken, cooling mint raita drizzle, pickled red onions, and fresh coriander leaves on our artisanal pizza crust.",
    image: "/images/menu/pizzas/desi-tandoori.webp",
    tags: ["pizza", "tandoori", "chicken"],
  },
  {
    id: "chicken-pepperoni",
    name: "Chicken Pepperoni / Double Pepperoni",
    category: "pizzas",
    description:
      "Classic artisanal pizza topped with savory chicken or pork pepperoni sausage slices, depending on the outlet's actual offering.",
    image: "/images/menu/pizzas/chicken-pepperoni.webp",
    variants: ["Chicken Pepperoni", "Pork Pepperoni (Branch specific)"],
    tags: ["pizza", "pepperoni", "chicken"],
  },

  // ==========================================
  // CATEGORY C — CROISSANTS & CROISSANT BURGERS
  // ==========================================
  {
    id: "smoked-ham-crosswich",
    name: "Smoked Ham Crosswich",
    category: "croissants",
    description:
      "Flaky all-butter croissant sandwich filled with delicate sliced smoked ham, melted mozzarella, and homemade secret sauce.",
    image: "/images/menu/croissants/smoked-ham-crosswich.webp",
    tags: ["croissant", "ham", "sandwich"],
  },
  {
    id: "baconator-croissant",
    name: "Baconator Croissant",
    category: "croissants",
    description:
      "A BLT-inspired croissant with crispy bacon rashers, fresh crisp lettuce, juicy tomato slices, and secret sauce spread in buttery layered pastry.",
    image: "/images/menu/croissants/baconator-croissant.webp",
    isHouseFavourite: true,
    tags: ["croissant", "bacon", "blt"],
  },
  {
    id: "shroom-cheese-whiz",
    name: "Shroom Cheese Whiz Sandwich",
    category: "croissants",
    description:
      "Sautéed mushrooms, melted cheese slices, and mozzarella with homemade tomato relish and creamy garlic aioli on flaky French pastry.",
    image: "/images/menu/croissants/shroom-cheese-whiz.webp",
    isVegetarian: true,
    tags: ["croissant", "mushroom", "cheese", "vegetarian"],
  },
  {
    id: "corn-and-onion-delight",
    name: "Corn & Onion Delight",
    category: "croissants",
    description:
      "A flavorful blend of golden sweet corn, caramelized onions, melted cheese, and garlic aioli packed inside a warm croissant.",
    image: "/images/menu/croissants/corn-and-onion-delight.webp",
    isVegetarian: true,
    tags: ["croissant", "corn", "onion", "vegetarian"],
  },
  {
    id: "the-cross-burger",
    name: "The Cross Burger",
    category: "croissants",
    description:
      "Your favorite Burger Cartel patty adapted into a flaky, buttery croissant bun with crisp lettuce, tomato, and secret sauce.",
    image: "/images/menu/croissants/the-cross-burger.webp",
    tags: ["croissant", "cross-burger", "signature"],
  },
  {
    id: "the-cross-monster",
    name: "The Cross-Monster",
    category: "croissants",
    description:
      "Double patty croissant monster with fresh lettuce, sliced tomato, melted cheese, fluffy scrambled egg, and special homemade secret sauce.",
    image: "/images/menu/croissants/the-cross-monster.webp",
    isHouseFavourite: true,
    variants: ["Chicken Double Patty", "Gourmet Double Patty"],
    tags: ["croissant", "double", "monster"],
  },
  {
    id: "the-club-croissant",
    name: "The Club Croissant",
    category: "croissants",
    description:
      "A generous combination of grilled and crispy patties, two cheese slices, tomato, and homemade secret sauce tucked inside a butter croissant.",
    image: "/images/menu/croissants/the-club-croissant.webp",
    variants: ["Chicken Patty", "Gourmet Patty"],
    tags: ["croissant", "club", "cheese"],
  },

  // ==========================================
  // CATEGORY D — SANDWICHES & SUBS
  // ==========================================
  {
    id: "club-sandwich",
    name: "Club Sandwich",
    category: "sandwiches",
    description:
      "Classic multi-layered club sandwich with chicken, crispy bacon, fresh lettuce, tomato slices, and mayonnaise on toasted bread, cut into quarters.",
    image: "/images/menu/sandwiches/club-sandwich.webp",
    isHouseFavourite: true,
    tags: ["sandwich", "club", "chicken", "bacon"],
  },
  {
    id: "tuna-melty",
    name: "Tuna Melty",
    category: "sandwiches",
    description:
      "Seasoned tuna salad with fresh herbs and crisp lettuce greens served on warm, buttery toasted bread rolls.",
    image: "/images/menu/sandwiches/tuna-melty.webp",
    tags: ["sandwich", "tuna", "seafood"],
  },
  {
    id: "shrimp-roll",
    name: "Shrimp Roll",
    category: "sandwiches",
    description:
      "Lemon and garlic mayonnaise dredged poached prawns with pickled onions and fresh greens in a soft, buttery bread roll.",
    image: "/images/menu/sandwiches/shrimp-roll.webp",
    tags: ["sandwich", "shrimp", "seafood", "roll"],
  },
  {
    id: "roast-pork-sub",
    name: "Roast Pork Sub",
    category: "sandwiches",
    description:
      "Slow-roasted tender pork with sweet grilled onions, crunchy pickled cucumber, and house coleslaw served in a toasted bread sub.",
    image: "/images/menu/sandwiches/roast-pork.webp",
    tags: ["sandwich", "sub", "pork"],
  },
  {
    id: "sloppy-chick",
    name: "Sloppy Chick",
    category: "sandwiches",
    description:
      "Spicy minced chicken cooked in rich marinara sauce with sautéed sweet peppers, grilled onions, and crunchy coleslaw.",
    image: "/images/menu/sandwiches/sloppy-chick.webp",
    tags: ["sandwich", "sub", "chicken", "spicy"],
  },

  // ==========================================
  // CATEGORY E — HOT DOGS
  // ==========================================
  {
    id: "porky-dog",
    name: "Porky Dog",
    category: "hotdogs",
    description:
      "Chicken hot dog loaded with homemade pulled pork, pickled cucumber slices, and crispy deep-fried onions.",
    image: "/images/menu/hotdogs/porky-dog.webp",
    isHouseFavourite: true,
    tags: ["hotdog", "pork", "pulled-pork"],
  },
  {
    id: "classic-dog",
    name: "Classic Dog",
    category: "hotdogs",
    description:
      "Classic chicken hot dog topped with crunchy pickled cucumber, sweet caramelized onions, American yellow mustard, and tomato ketchup.",
    image: "/images/menu/hotdogs/classic-dog.webp",
    tags: ["hotdog", "classic", "chicken"],
  },
  {
    id: "chilli-dog",
    name: "Chilli Dog",
    category: "hotdogs",
    description:
      "Chicken hot dog loaded with homemade roasted chilli relish, tangy pickled onions, mustard, and ketchup.",
    image: "/images/menu/hotdogs/chilli-dog.webp",
    tags: ["hotdog", "chilli", "spicy"],
  },

  // ==========================================
  // CATEGORY F — PASTA
  // ==========================================
  {
    id: "spaghetti-carbonara",
    name: "Spaghetti Carbonara",
    category: "pasta",
    description:
      "Classic spaghetti tossed in authentic egg yolk and aged Parmesan cheese sauce, with crispy bacon or chicken.",
    image: "/images/menu/pasta/spaghetti-carbonara.webp",
    isHouseFavourite: true,
    variants: ["Crispy Bacon", "Chicken", "Vegetarian"],
    tags: ["pasta", "spaghetti", "carbonara"],
  },
  {
    id: "spaghetti-meatballs",
    name: "Spaghetti Meatballs",
    category: "pasta",
    description:
      "Minced chicken and Parmesan meatballs simmered in homemade marinara sauce with cherry tomatoes, local greens, and basil.",
    image: "/images/menu/pasta/spaghetti-meatballs.webp",
    tags: ["pasta", "meatballs", "chicken"],
  },
  {
    id: "mushroom-pasta",
    name: "Mushroom Pasta",
    category: "pasta",
    description:
      "Tender sautéed button mushrooms folded in our homemade roasted garlic and velvety cream sauce.",
    image: "/images/menu/pasta/mushroom-pasta.webp",
    isVegetarian: true,
    tags: ["pasta", "mushroom", "vegetarian", "cream"],
  },
  {
    id: "penne-arrabbiata",
    name: "Penne Arrabbiata",
    category: "pasta",
    description:
      "Penne pasta tossed in spicy red chilli marinara sauce with sweet cherry tomatoes, local greens, and fresh basil.",
    image: "/images/menu/pasta/penne-arrabbiata.webp",
    variants: ["Chicken", "Vegetarian"],
    tags: ["pasta", "arrabbiata", "spicy"],
  },
  {
    id: "spaghetti-pesto",
    name: "Spaghetti Pesto",
    category: "pasta",
    description:
      "Homemade toasted walnut pesto with ripe cherry tomatoes, fresh basil leaves, and shaved Parmesan cheese.",
    image: "/images/menu/pasta/spaghetti-pesto.webp",
    variants: ["Walnut Pesto (Veg)", "Prawns / Shrimp Option"],
    tags: ["pasta", "pesto", "walnut"],
  },
  {
    id: "penne-alfredo",
    name: "Penne Alfredo",
    category: "pasta",
    description:
      "Penne in silky white Parmesan cream sauce with local greens, cherry tomatoes, and aromatic herbs.",
    image: "/images/menu/pasta/penne-alfredo.webp",
    variants: ["Chicken", "Vegetarian"],
    tags: ["pasta", "alfredo", "cream"],
  },

  // ==========================================
  // CATEGORY G — MAINS
  // ==========================================
  {
    id: "roast-chicken-steak",
    name: "Roast Chicken Steak",
    category: "mains",
    description:
      "Slow-roasted bone-in chicken thigh with creamy garlic mashed potatoes, roasted vegetables, and savory onion-and-mushroom gravy.",
    image: "/images/menu/mains/roast-chicken-steak.webp",
    isHouseFavourite: true,
    tags: ["mains", "chicken", "steak"],
  },
  {
    id: "pork-chops",
    name: "Pork Chops",
    category: "mains",
    description:
      "Slow-roasted pork chops served over buttered mashed potatoes with rich caramelized onion and mushroom gravy.",
    image: "/images/menu/mains/pork-chops.webp",
    tags: ["mains", "pork", "chops"],
  },
  {
    id: "hamburger-steak",
    name: "Hamburger Steak",
    category: "mains",
    description:
      "Burger Cartel signature burger patties served over fluffy mashed potatoes with dark onion gravy, toasted bread, and a fried egg topping.",
    image: "/images/menu/mains/hamburger-steak.webp",
    tags: ["mains", "hamburger", "steak", "egg"],
  },

  // ==========================================
  // CATEGORY H — BREAKFAST & BRUNCH
  // ==========================================
  {
    id: "eggs-benny",
    name: "Eggs Benny",
    category: "breakfast",
    description:
      "Classic Eggs Benedict with rich hollandaise sauce, perfectly poached eggs, bacon or chicken, and fresh side salad.",
    image: "/images/menu/breakfast/eggs-benny.webp",
    isHouseFavourite: true,
    variants: ["Crispy Bacon", "Chicken"],
    tags: ["breakfast", "eggs", "benedict"],
  },
  {
    id: "indy-masala-omelet",
    name: "Indy Masala Omelet",
    category: "breakfast",
    description:
      "Indian-style fluffy spiced masala omelette folded with chopped onions, green chillies, and fresh herbs, served with buttered toast and garden salad.",
    image: "/images/menu/breakfast/indy-masala-omelet.webp",
    tags: ["breakfast", "omelet", "eggs"],
  },
  {
    id: "eggs-on-toast",
    name: "Eggs on Toast",
    category: "breakfast",
    description:
      "Eggs prepared to your preference (sunny-side up, scrambled, or poached) served with buttered toast and crisp side salad.",
    image: "/images/menu/breakfast/eggs-on-toast.webp",
    tags: ["breakfast", "eggs", "toast"],
  },
  {
    id: "banana-pancake",
    name: "Banana Pancake",
    category: "breakfast",
    description:
      "Wholesome banana and oats pancake stack topped with tart blueberry compote and light whipped cream.",
    image: "/images/menu/breakfast/banana-pancake.webp",
    isVegetarian: true,
    tags: ["breakfast", "pancakes", "banana", "vegetarian"],
  },
  {
    id: "pancakes",
    name: "Pancakes",
    category: "breakfast",
    description:
      "Golden griddled buttermilk pancake stack available in banana, rich chocolate, or Nutella variations.",
    image: "/images/menu/breakfast/pancakes.webp",
    isVegetarian: true,
    variants: ["Banana", "Chocolate", "Nutella"],
    tags: ["breakfast", "pancakes", "nutella", "vegetarian"],
  },
  {
    id: "cartel-hometown-brekkie",
    name: "Cartel Hometown Brekkie",
    category: "breakfast",
    description:
      "Darjeeling heritage breakfast: Traditional aludum, sadeko sausage with homemade achar, sautéed masala mushrooms, masala omelette, and authentic Tibetan flatbread.",
    image: "/images/menu/breakfast/cartel-hometown-brekkie.webp",
    isHouseFavourite: true,
    tags: ["breakfast", "darjeeling", "heritage", "signature"],
  },
  {
    id: "cartel-big-brekkie",
    name: "Cartel Big Brekkie",
    category: "breakfast",
    description:
      "Crispy bacon rashers, smoked sausages, sautéed button mushrooms, grilled tomatoes, fluffy scrambled eggs, homemade baked beans, side salad, and toasted Cartel bread.",
    image: "/images/menu/breakfast/cartel-big-brekkie.webp",
    isHouseFavourite: true,
    tags: ["breakfast", "platter", "bacon", "signature"],
  },

  // ==========================================
  // CATEGORY I — KOREAN SETS
  // ==========================================
  {
    id: "bulgogi-set",
    name: "Bulgogi Set",
    category: "korean",
    description:
      "Classic Korean sliced meat marinated in sweet and savory soy sauce, sesame oil, and garlic, grilled to tender perfection. Served with rice and traditional banchan sides.",
    image: "/images/menu/korean/bulgogi-set.webp",
    isHouseFavourite: true,
    tags: ["korean", "bulgogi", "rice"],
  },
  {
    id: "dakgalbi-set",
    name: "Dakgalbi Set",
    category: "korean",
    description:
      "Chuncheon-style marinated chicken stir-fried with green cabbage, carrots, spring onions, and spicy gochujang chili sauce. Served with banchan sides and rice.",
    image: "/images/menu/korean/dakgalbi-set.webp",
    tags: ["korean", "dakgalbi", "chicken", "spicy"],
  },
  {
    id: "hot-pot",
    name: "Hot Pot",
    category: "korean",
    description:
      "Simmering aromatic communal broth cooked table-side with sliced meats, garden vegetables, meatballs, and ramen noodles. Choice of sesame-miso or spicy mala broth.",
    image: "/images/menu/korean/hot-pot.webp",
    variants: ["Sesame-Miso Broth", "Mala Spicy Broth"],
    tags: ["korean", "hotpot", "noodles", "soup"],
  },
  {
    id: "korean-bbq",
    name: "Korean BBQ",
    category: "korean",
    description:
      "Interactive table-grill experience where diners grill their choice of marinated meats, accompanied by kimchi, pickled banchan, fresh lettuce wraps, and dipping sauces.",
    image: "/images/menu/korean/korean-bbq.webp",
    isHouseFavourite: true,
    variants: ["Chicken", "Pork"],
    tags: ["korean", "bbq", "grill", "signature"],
  },

  // ==========================================
  // CATEGORY J — NOODLES & RICE BOWLS
  // ==========================================
  {
    id: "keema-noodles",
    name: "Keema Noodles",
    category: "noodles-rice",
    description:
      "Kathmandu-style spicy minced chicken cooked with regional spices, served over warm noodles with a boiled egg and sliced spring onions.",
    image: "/images/menu/noodles-rice/keema-noodles.webp",
    tags: ["noodles", "keema", "spicy"],
  },
  {
    id: "budae-jjigae",
    name: "Budae-Jjigae",
    category: "noodles-rice",
    description:
      "Korean army-style stew loaded with chicken ham, sausage, tangy kimchi, ramen noodles, mushrooms, spring onions, and rich gochujang broth.",
    image: "/images/menu/noodles-rice/budae-jjigae.webp",
    isHouseFavourite: true,
    tags: ["noodles", "korean", "stew", "budae"],
  },
  {
    id: "pad-thai",
    name: "Pad Thai",
    category: "noodles-rice",
    description:
      "Stir-fried rice noodles in sweet-tangy tamarind sauce with bean sprouts, crushed peanuts, fried tofu, and meat of choice.",
    image: "/images/menu/noodles-rice/pad-thai.webp",
    variants: ["Chicken", "Prawns", "Vegetarian"],
    tags: ["noodles", "thai", "pad-thai"],
  },
  {
    id: "naruto-power-bowl",
    name: "Naruto Power Bowl",
    category: "noodles-rice",
    description:
      "Flavorful Korean kimchi ramen bowl loaded with crispy fried chicken, soft-boiled marinated egg, braised mushrooms, and scallions.",
    image: "/images/menu/noodles-rice/naruto-power-bowl.webp",
    isHouseFavourite: true,
    tags: ["noodles", "ramen", "chicken", "kimchi"],
  },
  {
    id: "chinese-noodle-set",
    name: "Chinese Noodle Set",
    category: "noodles-rice",
    description:
      "Wok-tossed noodles with garden vegetables, red chillies, and savory garlic sauce. Choice of chicken, pork, or vegetables.",
    image: "/images/menu/noodles-rice/chinese-noodle-set.webp",
    variants: ["Chicken", "Pork", "Vegetables"],
    tags: ["noodles", "chinese", "wok"],
  },
  {
    id: "dolsot-bibimbap",
    name: "Dolsot Bibimbap",
    category: "noodles-rice",
    description:
      "Sizzling stone bowl rice topped with seasoned cucumber kimchi, sautéed carrots, mushrooms, protein of choice, and topped with a fried egg.",
    image: "/images/menu/noodles-rice/dolsot-bibimbap.webp",
    variants: ["Chicken", "Pork", "Vegetables"],
    tags: ["rice", "bibimbap", "korean"],
  },
  {
    id: "chicken-karate-fry-rice-bowl",
    name: "Chicken Karate Fry Rice Bowl",
    category: "noodles-rice",
    description:
      "Crispy Japanese-style fried chicken with spicy mayo served over steamed jasmine rice, with a side of Thai Somtam salad and pickled radish.",
    image: "/images/menu/noodles-rice/chicken-karate-fry-rice-bowl.webp",
    isHouseFavourite: true,
    tags: ["rice", "chicken", "katsu"],
  },
  {
    id: "kimchi-fried-rice",
    name: "Kimchi Fried Rice",
    category: "noodles-rice",
    description:
      "Homemade aged kimchi stir-fried with steamed rice, green onions, toasted sesame oil, nori seaweed, and topped with a sunny-side-up egg.",
    image: "/images/menu/noodles-rice/kimchi-fried-rice.webp",
    tags: ["rice", "kimchi", "korean"],
  },
  {
    id: "chinese-rice-set",
    name: "Chinese Rice Set",
    category: "noodles-rice",
    description:
      "Classic stir-fried rice with seasonal vegetables, red chillies, and your choice of chicken, pork, or vegetables.",
    image: "/images/menu/noodles-rice/chinese-rice-set.webp",
    variants: ["Chicken", "Pork", "Vegetables"],
    tags: ["rice", "chinese", "fried-rice"],
  },

  // ==========================================
  // CATEGORY K — SALADS
  // ==========================================
  {
    id: "somtam-salad",
    name: "Somtam Salad",
    category: "salads",
    description:
      "Traditional Thai green papaya salad hand-pounded with fresh raw papaya, long beans, sweet cherry tomatoes, lime juice, palm sugar, and light savory dressing.",
    image: "/images/menu/salads/somtam-salad.webp",
    tags: ["salad", "thai", "somtam", "papaya"],
  },
  {
    id: "crispy-pork-salad",
    name: "Crispy Pork Salad",
    category: "salads",
    description:
      "Crispy seasoned pork slices served over a refreshing mix of crisp garden salad greens, fresh herbs, and a zesty house citrus dressing.",
    image: "/images/menu/salads/crispy-pork-salad.webp",
    isHouseFavourite: true,
    tags: ["salad", "pork", "crispy"],
  },
  {
    id: "chicken-caesar-salad",
    name: "Chicken Caesar Salad",
    category: "salads",
    description:
      "Crisp romaine lettuce, golden herbed croutons, shaved Parmesan cheese, and fresh cucumber tossed in rich, creamy Caesar dressing with grilled chicken.",
    image: "/images/menu/salads/chicken-caesar-salad.webp",
    tags: ["salad", "caesar", "chicken"],
  },

  // ==========================================
  // CATEGORY L — SNACKS & SIDES
  // ==========================================
  {
    id: "shoestring-fries",
    name: "Shoestring Fries",
    category: "sides",
    description: "Crispy, golden-fried thin-cut shoestring potatoes tossed in sea salt.",
    image: "/images/menu/sides/shoestring-fries-fresh.webp",
    isVegetarian: true,
    tags: ["sides", "fries", "vegetarian"],
  },
  {
    id: "peri-peri-fries",
    name: "Peri Peri Fries",
    category: "sides",
    description: "Golden shoestring fries tossed in our signature smoky peri-peri spice blend.",
    image: "/images/menu/sides/peri-peri-fries-fresh.webp",
    isVegetarian: true,
    tags: ["sides", "fries", "peri-peri", "vegetarian"],
  },
  {
    id: "garlic-bread",
    name: "Garlic Bread",
    category: "sides",
    description: "Artisanal Cartel bread slices toasted with fragrant garlic butter, fresh parsley, and melted cheese.",
    image: "/images/menu/sides/garlic-bread-fresh.webp",
    isVegetarian: true,
    tags: ["sides", "bread", "garlic", "vegetarian"],
  },
  {
    id: "onion-rings",
    name: "Onion Rings",
    category: "sides",
    description: "Crispy golden beer-battered sweet onion rings served hot with secret dipping sauce.",
    image: "/images/menu/sides/onion-rings-fresh.webp",
    isVegetarian: true,
    tags: ["sides", "onion-rings", "vegetarian"],
  },
  {
    id: "mozzarella-sticks",
    name: "Mozzarella Sticks",
    category: "sides",
    description: "Breaded mozzarella fingers fried to a crisp golden brown with an irresistible stretchy cheese pull.",
    image: "/images/menu/sides/mozzarella-sticks-fresh.webp",
    isVegetarian: true,
    tags: ["sides", "cheese", "vegetarian"],
  },
  {
    id: "hot-wings",
    name: "Hot Wings",
    category: "sides",
    description:
      "Crispy fried chicken wings tossed in your choice of sauce: Smoky BBQ Goodness, Fiery Korean Hotness, or Sriracha Fire.",
    image: "/images/menu/sides/hot-wings-fresh.webp",
    isHouseFavourite: true,
    variants: ["BBQ Goodness", "Korean Hotness", "Sriracha Fire"],
    tags: ["sides", "wings", "chicken", "spicy"],
  },

  // ==========================================
  // CATEGORY M — SPECIALS
  // ==========================================
  {
    id: "chicken-karate-fry-special",
    name: "Chicken Karate Fry",
    category: "specials",
    description:
      "Chef Kwai's signature golden-fried chicken cutlet drizzled with Japanese spicy mayo, served with fragrant steamed rice, Thai Somtam salad, and pink pickled radish.",
    image: "/images/menu/specials/chicken-karate-fry.webp",
    isHouseFavourite: true,
    tags: ["specials", "chicken", "katsu", "signature"],
  },
  {
    id: "kimbap-special",
    name: "Kimbap",
    category: "specials",
    description:
      "Korean seaweed rice rolls hand-rolled with sesame rice and pickled vegetables. Available with Crispy Chicken, Chicken Sausage, Magic Mushroom (Veg), or Tuna fillings.",
    image: "/images/menu/specials/kimbap.webp",
    isHouseFavourite: true,
    variants: ["Crispy Chicken", "Chicken Sausage", "Magic Mushroom (Veg)", "Tuna"],
    tags: ["specials", "kimbap", "korean", "rolls"],
  },

  // ==========================================
  // CATEGORY N — BEVERAGES
  // ==========================================
  // Healthy Smoothies
  {
    id: "berry-bliss",
    name: "Berry Bliss Smoothie",
    category: "beverages",
    subcategory: "Healthy Smoothies",
    description: "Antioxidant-rich blend of mixed berries, Greek yoghurt, raw honey, chia seeds, and milk.",
    image: "/images/menu/beverages/berry-bliss.webp",
    isVegetarian: true,
    tags: ["beverages", "smoothie", "berry", "healthy"],
  },
  {
    id: "peanut-butter-banana",
    name: "Peanut Butter & Banana Smoothie",
    category: "beverages",
    subcategory: "Healthy Smoothies",
    description: "Natural roasted peanut butter, Medjool dates, ripe banana, and chilled milk.",
    image: "/images/menu/beverages/peanut-butter-banana-fresh.webp",
    isVegetarian: true,
    tags: ["beverages", "smoothie", "peanut-butter", "banana"],
  },
  {
    id: "strawberry-cheesecake-smoothie",
    name: "Strawberry Cheesecake Smoothie",
    category: "beverages",
    subcategory: "Healthy Smoothies",
    description: "Dessert-inspired smoothie with fresh strawberries, cream cheese blend, and biscuit crumbs.",
    image: "/images/menu/beverages/strawberry-cheesecake-smoothie-fresh.webp",
    isVegetarian: true,
    tags: ["beverages", "smoothie", "strawberry"],
  },
  {
    id: "chocolate-protein-smoothie",
    name: "Chocolate Protein Smoothie",
    category: "beverages",
    subcategory: "Healthy Smoothies",
    description: "Dark Dutch cocoa, energy-rich dates, sweet banana, honey, and wholesome milk.",
    image: "/images/menu/beverages/chocolate-protein-smoothie-fresh.webp",
    isVegetarian: true,
    tags: ["beverages", "smoothie", "chocolate", "protein"],
  },
  {
    id: "healthy-caramel-smoothie",
    name: "Healthy Caramel Smoothie",
    category: "beverages",
    subcategory: "Healthy Smoothies",
    description: "Naturally sweet caramel smoothie blended from dates, banana, natural vanilla, and chilled milk.",
    image: "/images/menu/beverages/caramel-smoothie-fresh.webp",
    isVegetarian: true,
    tags: ["beverages", "smoothie", "caramel"],
  },

  // Iced Teas
  {
    id: "iced-teas-collection",
    name: "Artisan Iced Teas",
    category: "beverages",
    subcategory: "Iced Teas",
    description: "Refreshing cold-brewed tea poured over crystal ice with fresh mint and citrus fruit wheels.",
    image: "/images/menu/beverages/iced-tea.webp",
    isVegetarian: true,
    variants: ["Lemon Iced Tea", "Peach Iced Tea", "Passionfruit Iced Tea", "Green Apple Iced Tea"],
    tags: ["beverages", "iced-tea", "lemon", "peach"],
  },

  // Fizzy Floats & Coolers
  {
    id: "fizzy-floats-collection",
    name: "Fizzy Floats & Coolers",
    category: "beverages",
    subcategory: "Fizzy Floats & Coolers",
    description: "Sparkling botanical refreshers and fruity floats infused with fresh mint and crushed ice.",
    image: "/images/menu/beverages/fizzy-floats.webp",
    isVegetarian: true,
    variants: [
      "Strawberry Float",
      "Passionfruit Float",
      "Peach Float",
      "Green Apple Float",
      "Fresh Lime Soda",
      "Classic Mojito",
    ],
    tags: ["beverages", "float", "cooler", "mojito", "fizzy"],
  },

  // Milkshakes
  {
    id: "milkshakes-collection",
    name: "Handcrafted Milkshakes",
    category: "beverages",
    subcategory: "Milkshakes",
    description: "Thick, creamy diner-style shakes blended with whole milk and topped with fresh whipped cream swirl.",
    image: "/images/menu/beverages/milkshake.webp",
    isVegetarian: true,
    isHouseFavourite: true,
    variants: [
      "Strawberry Milkshake",
      "Vanilla Milkshake",
      "Chocolate Milkshake",
      "Banana Cheesecake Milkshake",
      "Oreo Milkshake",
    ],
    tags: ["beverages", "milkshake", "chocolate", "strawberry", "oreo"],
  },

  // Hot Coffee & Chocolate
  {
    id: "hot-coffee-collection",
    name: "Artisan Hot Coffee & Chocolate",
    category: "beverages",
    subcategory: "Hot Coffee & Chocolate",
    description: "Locally roasted Himalayan Arabica espresso pulled fresh with velvety microfoam latte art.",
    image: "/images/menu/beverages/hot-coffee.webp",
    isVegetarian: true,
    variants: [
      "Flat White",
      "Cappuccino",
      "Vanilla Cappuccino",
      "Americano",
      "Cafe Latte",
      "Single / Double Espresso",
      "Rich Hot Chocolate",
    ],
    tags: ["beverages", "coffee", "espresso", "latte", "hot-chocolate"],
  },

  // Iced Coffee
  {
    id: "iced-coffee-collection",
    name: "Specialty Iced Coffee",
    category: "beverages",
    subcategory: "Iced Coffee",
    description: "Chilled espresso poured over ice and cold milk with handcrafted syrups and cream floats.",
    image: "/images/menu/beverages/iced-latte.webp",
    isVegetarian: true,
    variants: [
      "Iced Coffee",
      "Iced Chocolate",
      "Iced Americano",
      "Iced Caramel Latte",
      "Iced Caramel Macchiato",
      "Iced Vanilla Shake Espresso",
    ],
    tags: ["beverages", "iced-coffee", "macchiato", "cold-brew"],
  },

  // Darjeeling Tea & Infusions
  {
    id: "darjeeling-tea-collection",
    name: "Authentic Darjeeling Teas & Herbal Infusions",
    category: "beverages",
    subcategory: "Darjeeling Tea & Infusions",
    description: "Single-estate high-grown Darjeeling teas and calming herbal flower infusions served hot.",
    image: "/images/menu/beverages/darjeeling-tea.webp",
    isVegetarian: true,
    isHouseFavourite: true,
    variants: [
      "Darjeeling Standard Black Tea",
      "Pure Green Tea",
      "Peach Tea",
      "Fragrant Jasmine Tea",
      "Kashmiri Kahwa Tea",
      "Chamomile Blossom Tea",
      "Hibiscus Herbal Infusion",
      "Fresh Lemon Tea",
      "Purple Tea",
      "Ginger Lemon Tea",
      "Hot Fresh Lime Water",
    ],
    tags: ["beverages", "tea", "darjeeling", "herbal", "infusion"],
  },

  // Slushies
  {
    id: "slushies-collection",
    name: "Fruit Slushies",
    category: "beverages",
    subcategory: "Slushies",
    description: "Ultra-refreshing crushed-ice fruit slushies bursting with real fruit pulp and ice crystals.",
    image: "/images/menu/beverages/watermelon-slushy.webp",
    isVegetarian: true,
    variants: ["Watermelon Slushy", "Peach Slushy", "Green Apple Slushy"],
    tags: ["beverages", "slushy", "watermelon", "peach", "apple"],
  },
];
