import crypto from "crypto";
import {
  readAuthDatabase,
  writeAuthDatabase,
} from "./store.ts";
import type {
  AdminRecord,
  SessionRecord,
} from "./store.ts";
import {
  checkRateLimitDb,
  recordFailedAttemptDb,
  resetRateLimitDb,
  cleanupExpiredBuckets,
} from "./rateLimit.ts";
import {
  getAdminByAdminId,
  createSession as createPgSession,
  validateSession as validatePgSession,
  invalidateSession as invalidatePgSession,
  revokeAllSessions as revokeAllPgSessions,
  recordLoginSuccess as recordPgLoginSuccess,
  recordLoginFailure as recordPgLoginFailure,
  isBootstrapNeeded as isPgBootstrapNeeded,
  bootstrapInitialAdmin as bootstrapPgInitialAdmin,
  hashToken,
} from "./postgresAuthStore.ts";
import { getDb } from "../db/index.ts";

function scryptPromise(
  password: string | Buffer,
  salt: string | Buffer,
  keylen: number,
  options: crypto.ScryptOptions
): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    crypto.scrypt(password, salt, keylen, options, (err, derivedKey) => {
      if (err) reject(err);
      else resolve(derivedKey);
    });
  });
}

const SESSION_DURATION_HOURS = 24;
const LOCKOUT_DURATION_MINUTES = 15;

/**
 * Concurrency Throttle:
 * Limits simultaneous CPU-intensive Scrypt derivations to prevent
 * event-loop blocking and denial-of-service under burst login attempts.
 */
class ScryptSemaphore {
  private active = 0;
  private queue: Array<() => void> = [];
  private maxConcurrent: number;

  constructor(maxConcurrent: number = 4) {
    this.maxConcurrent = maxConcurrent;
  }

  async acquire(): Promise<() => void> {
    if (this.active < this.maxConcurrent) {
      this.active++;
      return () => this.release();
    }
    return new Promise((resolve) => {
      this.queue.push(() => {
        this.active++;
        resolve(() => this.release());
      });
    });
  }

  private release(): void {
    this.active--;
    if (this.queue.length > 0 && this.active < this.maxConcurrent) {
      const next = this.queue.shift();
      if (next) next();
    }
  }
}

const scryptLimiter = new ScryptSemaphore(4);

// Constant dummy salt and hash computed once at process startup for constant-time verification
const DUMMY_SALT = "0123456789abcdef0123456789abcdef";
const DUMMY_HASH = crypto
  .scryptSync("burger_cartel_timing_mitigation_password", DUMMY_SALT, 64, {
    N: 16384,
    r: 8,
    p: 1,
    maxmem: 32 * 1024 * 1024,
  })
  .toString("hex");

/**
 * Derives a cryptographically strong scrypt hash asynchronously.
 * Throttled by semaphore to prevent CPU exhaustion.
 */
export async function hashPassword(
  password: string
): Promise<{ hash: string; salt: string }> {
  if (
    !password ||
    typeof password !== "string" ||
    password.length < 8 ||
    password.length > 128
  ) {
    throw new Error("Password must be between 8 and 128 characters.");
  }

  const salt = crypto.randomBytes(16).toString("hex");
  const release = await scryptLimiter.acquire();
  try {
    const derived = await scryptPromise(password, salt, 64, {
      N: 16384,
      r: 8,
      p: 1,
      maxmem: 32 * 1024 * 1024,
    });
    return {
      hash: derived.toString("hex"),
      salt,
    };
  } finally {
    release();
  }
}

/**
 * Verifies password against stored scrypt hash in constant time asynchronously.
 */
export async function verifyPassword(
  passwordInput: string,
  storedHash: string,
  storedSalt: string
): Promise<boolean> {
  if (!passwordInput || !storedHash || !storedSalt) return false;

  const release = await scryptLimiter.acquire();
  try {
    const derived = await scryptPromise(passwordInput, storedSalt, 64, {
      N: 16384,
      r: 8,
      p: 1,
      maxmem: 32 * 1024 * 1024,
    });
    const derivedHex = derived.toString("hex");

    const derivedBuffer = Buffer.from(derivedHex, "hex");
    const storedBuffer = Buffer.from(storedHash, "hex");

    if (derivedBuffer.length !== storedBuffer.length) {
      return false;
    }

    return crypto.timingSafeEqual(derivedBuffer, storedBuffer);
  } catch (err) {
    console.error("[Security] Password verification error:", err);
    return false;
  } finally {
    release();
  }
}

let runtimeSessionSecret: string | null = null;

function getSessionSecret(): Buffer {
  const secret = process.env.SESSION_SECRET || process.env.ADMIN_STORE_KEY;
  if (secret) {
    return crypto.createHash("sha256").update(secret).digest();
  }
  if (process.env.NODE_ENV === "production") {
    throw new Error(
      "[SECURITY FATAL] Mandatory secret SESSION_SECRET is missing in production environment. Refusing to operate in insecure state."
    );
  }
  if (!runtimeSessionSecret) {
    runtimeSessionSecret = crypto.randomBytes(32).toString("hex");
  }
  return crypto.createHash("sha256").update(runtimeSessionSecret).digest();
}

/**
 * Signs a session token with HMAC-SHA256
 */
export function signSessionToken(rawToken: string): string {
  const key = getSessionSecret();
  const signature = crypto
    .createHmac("sha256", key)
    .update(rawToken)
    .digest("hex");
  return `${rawToken}.${signature}`;
}

/**
 * Verifies signed session token and extracts raw token in constant time
 */
export function verifySignedToken(signedToken: string): string | null {
  if (!signedToken || typeof signedToken !== "string") return null;
  const parts = signedToken.split(".");
  if (parts.length !== 2) return null;

  const [token, signature] = parts;
  if (!token || !signature) return null;

  const key = getSessionSecret();
  const expectedSig = crypto
    .createHmac("sha256", key)
    .update(token)
    .digest("hex");

  try {
    const sigBuffer = Buffer.from(signature, "hex");
    const expBuffer = Buffer.from(expectedSig, "hex");

    if (sigBuffer.length !== expBuffer.length) {
      return null;
    }

    if (crypto.timingSafeEqual(sigBuffer, expBuffer)) {
      return token;
    }
  } catch {
    return null;
  }
  return null;
}

/**
 * Rate Limiter delegating to PostgreSQL-backed distributed rate limiter.
 */
export async function checkRateLimit(key: string): Promise<{
  allowed: boolean;
  remainingAttempts: number;
  lockedUntil?: string;
}> {
  return await checkRateLimitDb(key);
}

/**
 * Records a failed attempt and locks if threshold is reached.
 */
export async function recordFailedAttempt(key: string): Promise<{
  locked: boolean;
  lockedUntil?: string;
}> {
  return await recordFailedAttemptDb(key);
}

/**
 * Resets rate limit on successful authentication.
 */
export async function resetRateLimit(key: string): Promise<void> {
  await resetRateLimitDb(key);
}

/**
 * Checks if the system needs initial administrator provisioning.
 * Authoritative check against PostgreSQL admin_users table.
 */
export async function isInitialSetupNeeded(): Promise<boolean> {
  await runAutomatedBootstrap();
  const sql = getDb();
  if (sql) {
    return await isPgBootstrapNeeded();
  }
  const db = readAuthDatabase();
  return db.admins.length === 0;
}

/**
 * Attempts automated bootstrap from environment if configured
 */
export async function runAutomatedBootstrap(): Promise<boolean> {
  const initialId = process.env.INITIAL_ADMIN_ID;
  const initialPass = process.env.INITIAL_ADMIN_PASSWORD;

  if (!initialId || !initialPass) return false;

  const sql = getDb();
  if (sql) {
    const needed = await isPgBootstrapNeeded();
    if (!needed) return false;

    const { hash, salt } = await hashPassword(initialPass);
    return await bootstrapPgInitialAdmin(initialId, hash, salt);
  }

  const db = readAuthDatabase();
  if (db.admins.length > 0 || db.config.bootstrapCompleted) {
    return false;
  }

  const { hash, salt } = await hashPassword(initialPass);
  const now = new Date().toISOString();

  const initialAdmin: AdminRecord = {
    id: crypto.randomUUID(),
    adminId: initialId.trim(),
    passwordHash: hash,
    salt,
    role: "superadmin",
    roleId: "superadmin",
    createdAt: now,
    updatedAt: now,
    mustChangePassword: true,
  };

  db.admins.push(initialAdmin);
  db.config.bootstrapCompleted = true;
  db.config.bootstrapDate = now;
  writeAuthDatabase(db);
  return true;
}

/**
 * Authenticates credentials against authoritative PostgreSQL persistent store
 * with dual-key rate limiting (IP & Account) and Account Lockout DoS immunity.
 */
export async function authenticateAdmin(
  adminIdInput: string,
  passwordInput: string,
  clientIp = "local"
): Promise<{
  success: boolean;
  admin?: AdminRecord;
  error?: string;
}> {
  const cleanId = adminIdInput.trim().toLowerCase();
  const ipKey = `ip:${clientIp}`;
  const userKey = `user:${cleanId}`;

  // 1. IP rate limiting: strict threshold stops brute-force from single IP
  const ipLimit = await checkRateLimitDb(ipKey);
  if (!ipLimit.allowed) {
    const lockMinutes = ipLimit.lockedUntil
      ? Math.ceil((new Date(ipLimit.lockedUntil).getTime() - Date.now()) / 60000)
      : LOCKOUT_DURATION_MINUTES;
    return {
      success: false,
      error: `Too many failed attempts from your IP. Access locked for ${lockMinutes} minutes.`,
    };
  }

  // Ensure bootstrap check has run
  await runAutomatedBootstrap();

  const sql = getDb();
  if (sql) {
    const admin = await getAdminByAdminId(cleanId);

    // Timing Attack Defense:
    // If the admin account does not exist, compute verifyPassword against DUMMY_HASH.
    if (!admin) {
      await verifyPassword(passwordInput, DUMMY_HASH, DUMMY_SALT);
      await recordFailedAttemptDb(ipKey);
      await recordFailedAttemptDb(userKey);
      return {
        success: false,
        error: "Invalid Admin ID or Password.",
      };
    }

    // Check persistent account lockout in PostgreSQL
    if (admin.lockedUntil && new Date(admin.lockedUntil).getTime() > Date.now()) {
      const lockMinutes = Math.ceil(
        (new Date(admin.lockedUntil).getTime() - Date.now()) / 60000
      );
      return {
        success: false,
        error: `Account temporarily locked due to multiple failed logins. Access locked for ${lockMinutes} minutes.`,
      };
    }

    const isValid = await verifyPassword(passwordInput, admin.passwordHash, admin.salt);
    if (!isValid) {
      await recordFailedAttemptDb(ipKey);
      await recordFailedAttemptDb(userKey);
      await recordPgLoginFailure(admin.adminId, clientIp);

      const userLimit = await checkRateLimitDb(userKey);
      if (!userLimit.allowed) {
        const lockMinutes = userLimit.lockedUntil
          ? Math.ceil((new Date(userLimit.lockedUntil).getTime() - Date.now()) / 60000)
          : LOCKOUT_DURATION_MINUTES;
        return {
          success: false,
          error: `Account temporarily locked due to multiple failed logins. Access locked for ${lockMinutes} minutes.`,
        };
      }

      return {
        success: false,
        error: "Invalid Admin ID or Password.",
      };
    }

    // Success: reset rate limits and record login success
    await resetRateLimitDb(ipKey);
    await resetRateLimitDb(userKey);
    await recordPgLoginSuccess(admin.adminId, clientIp);
    cleanupExpiredBuckets().catch(() => {});

    const adminRecord: AdminRecord = {
      id: admin.id,
      adminId: admin.adminId,
      passwordHash: admin.passwordHash,
      salt: admin.salt,
      role: admin.role,
      roleId: admin.roleId,
      mustChangePassword: admin.mustChangePassword,
      email: admin.email,
      assignedOutletId: admin.assignedOutletId,
      permissions: admin.permissions,
      createdAt: admin.createdAt,
      updatedAt: admin.updatedAt,
    };

    return { success: true, admin: adminRecord };
  }

  // Local fallback if DB is not configured
  const db = readAuthDatabase();
  const admin = db.admins.find(
    (a) => a.adminId.toLowerCase() === cleanId
  );

  if (!admin) {
    await verifyPassword(passwordInput, DUMMY_HASH, DUMMY_SALT);
    await recordFailedAttemptDb(ipKey);
    await recordFailedAttemptDb(userKey);
    return {
      success: false,
      error: "Invalid Admin ID or Password.",
    };
  }

  const isValid = await verifyPassword(passwordInput, admin.passwordHash, admin.salt);
  if (!isValid) {
    await recordFailedAttemptDb(ipKey);
    await recordFailedAttemptDb(userKey);

    const userLimit = await checkRateLimitDb(userKey);
    if (!userLimit.allowed) {
      const lockMinutes = userLimit.lockedUntil
        ? Math.ceil((new Date(userLimit.lockedUntil).getTime() - Date.now()) / 60000)
        : LOCKOUT_DURATION_MINUTES;
      return {
        success: false,
        error: `Account temporarily locked due to multiple failed logins. Access locked for ${lockMinutes} minutes.`,
      };
    }

    return {
      success: false,
      error: "Invalid Admin ID or Password.",
    };
  }

  await resetRateLimitDb(ipKey);
  await resetRateLimitDb(userKey);
  cleanupExpiredBuckets().catch(() => {});

  return { success: true, admin };
}

/**
 * Creates an authoritative persistent server session in PostgreSQL
 */
export async function createAdminSession(
  adminId: string,
  ip?: string,
  userAgent?: string
): Promise<{ signedToken: string; expiresAt: Date }> {
  const sql = getDb();
  if (sql) {
    const { rawToken, expiresAt } = await createPgSession(adminId, ip, userAgent);
    const signedToken = signSessionToken(rawToken);
    return { signedToken, expiresAt };
  }

  const rawToken = crypto.randomBytes(32).toString("hex");
  const tokenHash = hashToken(rawToken);
  const now = new Date();
  const expiresAt = new Date(now.getTime() + SESSION_DURATION_HOURS * 60 * 60 * 1000);

  const session: SessionRecord = {
    id: crypto.randomUUID(),
    tokenHash,
    adminId,
    createdAt: now.toISOString(),
    expiresAt: expiresAt.toISOString(),
    ip,
    userAgent,
  };

  const db = readAuthDatabase();
  db.sessions = db.sessions.filter((s) => new Date(s.expiresAt).getTime() > Date.now());
  db.sessions.push(session);
  writeAuthDatabase(db);

  const signedToken = signSessionToken(rawToken);
  return { signedToken, expiresAt };
}

/**
 * Validates a signed session token against PostgreSQL with User-Agent integrity verification
 */
export async function validateAdminSession(
  signedToken: string,
  currentUa?: string
): Promise<{
  valid: boolean;
  admin?: AdminRecord;
}> {
  const rawToken = verifySignedToken(signedToken);
  if (!rawToken) return { valid: false };

  const sql = getDb();
  if (sql) {
    const res = await validatePgSession(rawToken, currentUa);
    if (!res.valid || !res.admin) return { valid: false };

    const admin: AdminRecord = {
      id: res.admin.id,
      adminId: res.admin.adminId,
      passwordHash: "",
      salt: "",
      role: res.admin.role,
      roleId: res.admin.roleId,
      mustChangePassword: res.admin.mustChangePassword,
      email: res.admin.email,
      assignedOutletId: res.admin.assignedOutletId,
      permissions: res.admin.permissions,
      createdAt: res.admin.createdAt,
      updatedAt: res.admin.updatedAt,
    };
    return { valid: true, admin };
  }

  const tokenHash = hashToken(rawToken);
  const db = readAuthDatabase();
  const session = db.sessions.find((s) => s.tokenHash === tokenHash);

  if (!session) return { valid: false };

  if (new Date(session.expiresAt).getTime() < Date.now()) {
    db.sessions = db.sessions.filter((s) => s.tokenHash !== tokenHash);
    writeAuthDatabase(db);
    return { valid: false };
  }

  if (session.userAgent && currentUa && session.userAgent !== currentUa) {
    db.sessions = db.sessions.filter((s) => s.tokenHash !== tokenHash);
    writeAuthDatabase(db);
    return { valid: false };
  }

  const admin = db.admins.find((a) => a.adminId === session.adminId);
  if (!admin) return { valid: false };

  return { valid: true, admin };
}

/**
 * Terminates an active session in PostgreSQL
 */
export async function invalidateAdminSession(signedToken: string): Promise<void> {
  const rawToken = verifySignedToken(signedToken);
  if (!rawToken) return;

  const sql = getDb();
  if (sql) {
    await invalidatePgSession(rawToken);
    return;
  }

  const tokenHash = hashToken(rawToken);
  const db = readAuthDatabase();
  db.sessions = db.sessions.filter((s) => s.tokenHash !== tokenHash);
  writeAuthDatabase(db);
}

/**
 * Revokes all active sessions for a specific admin account across PostgreSQL
 */
export async function revokeAllAdminSessions(adminId: string): Promise<void> {
  const sql = getDb();
  if (sql) {
    await revokeAllPgSessions(adminId);
    return;
  }

  const db = readAuthDatabase();
  const initialCount = db.sessions.length;
  db.sessions = db.sessions.filter(
    (s) => s.adminId.toLowerCase() !== adminId.toLowerCase()
  );
  if (db.sessions.length !== initialCount) {
    writeAuthDatabase(db);
  }
}
