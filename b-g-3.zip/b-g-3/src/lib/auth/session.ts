import { cookies, headers } from "next/headers.js";
import {
  validateAdminSession,
  invalidateAdminSession,
} from "./security.ts";
import type { AdminRecord } from "./store.ts";

export const BASE_COOKIE_NAME = "burger_cartel_admin_session";
export const HOST_COOKIE_NAME = `__Host-${BASE_COOKIE_NAME}`;
export const SESSION_COOKIE_NAME = BASE_COOKIE_NAME;

export const NO_CACHE_HEADERS = {
  "Cache-Control": "no-store, no-cache, must-revalidate, private",
  Pragma: "no-cache",
};

/**
 * Retrieves client IP from standard proxy headers, resilient against X-Forwarded-For spoofing
 */
export async function getClientIp(): Promise<string> {
  const headerList = await headers();
  
  // Prefer direct edge-assigned headers if present
  const cfIp = headerList.get("cf-connecting-ip");
  if (cfIp) {
    const sanitized = cfIp.replace(/[^0-9a-fA-F:.]/g, "").slice(0, 45);
    if (sanitized) return sanitized;
  }

  const realIp = headerList.get("x-real-ip");
  if (realIp) {
    const sanitized = realIp.replace(/[^0-9a-fA-F:.]/g, "").slice(0, 45);
    if (sanitized) return sanitized;
  }

  const forwarded = headerList.get("x-forwarded-for");
  let rawIp = "127.0.0.1";
  if (forwarded) {
    // Reverse proxies append the real connecting client to the end of the chain.
    // Reading parts[parts.length - 1] prevents attackers from spoofing their IP by prepending fake IPs.
    const parts = forwarded.split(",").map((p) => p.trim()).filter(Boolean);
    if (parts.length > 0) {
      rawIp = parts[parts.length - 1];
    }
  }

  // Sanitize IP: accept only valid IPv4/IPv6 hex, dots, colons; clamp to 45 characters
  const sanitized = rawIp.replace(/[^0-9a-fA-F:.]/g, "").slice(0, 45);
  return sanitized || "127.0.0.1";
}

/**
 * Gets user-agent header, sanitizing control characters and capping length
 */
export async function getUserAgent(): Promise<string> {
  const headerList = await headers();
  const rawUa = headerList.get("user-agent") || "unknown";
  // Strip non-printable ASCII and control characters, cap to 255 chars
  return rawUa.replace(/[^\x20-\x7E]/g, "").slice(0, 255) || "unknown";
}

/**
 * Determines whether the connection is secure HTTPS and suitable for __Host- cookie prefixes
 */
async function isSecureConnection(): Promise<boolean> {
  const headerList = await headers();
  const proto = headerList.get("x-forwarded-proto") || "";
  const host = headerList.get("host") || "";
  const isLocalhost =
    host.startsWith("localhost") ||
    host.startsWith("127.0.0.1") ||
    host.startsWith("::1");

  return proto === "https" || (!isLocalhost && process.env.NODE_ENV === "production");
}

/**
 * Verifies current admin session from HTTP-only cookie with session-hijacking detection.
 * Checks both __Host- prefixed and standard cookie names for backward compatibility.
 */
export async function getAdminSession(): Promise<{
  authenticated: boolean;
  admin?: AdminRecord;
}> {
  const cookieStore = await cookies();
  const sessionCookie =
    cookieStore.get(HOST_COOKIE_NAME) || cookieStore.get(BASE_COOKIE_NAME);

  if (!sessionCookie || !sessionCookie.value) {
    return { authenticated: false };
  }

  const currentUa = await getUserAgent();
  const result = await validateAdminSession(sessionCookie.value, currentUa);
  if (!result.valid || !result.admin) {
    return { authenticated: false };
  }

  return {
    authenticated: true,
    admin: result.admin,
  };
}

/**
 * Verifies that the request origin matches the server host (CSRF protection for state-changing endpoints)
 */
export function assertSameOrigin(req: Request): boolean {
  // Reject cross-site fetch explicitly tagged by modern browsers
  const secFetchSite = req.headers.get("sec-fetch-site");
  if (secFetchSite && secFetchSite === "cross-site") {
    return false;
  }

  const origin = req.headers.get("origin");
  const host = req.headers.get("host") || "";
  
  if (origin) {
    try {
      const originUrl = new URL(origin);
      return originUrl.host.toLowerCase() === host.toLowerCase();
    } catch {
      return false;
    }
  }

  const referer = req.headers.get("referer");
  if (referer) {
    try {
      const refererUrl = new URL(referer);
      return refererUrl.host.toLowerCase() === host.toLowerCase();
    } catch {
      return false;
    }
  }

  // For state-changing methods (POST, PUT, DELETE, PATCH):
  // Browsers must include Origin or Referer. If both are missing:
  const method = req.method ? req.method.toUpperCase() : "GET";
  if (["POST", "PUT", "DELETE", "PATCH"].includes(method)) {
    if (process.env.NODE_ENV !== "production") {
      // In local dev/testing, allow requests to localhost/127.0.0.1
      if (host.startsWith("localhost") || host.startsWith("127.0.0.1") || host.startsWith("::1")) {
        return true;
      }
    }
    return false;
  }

  return true;
}

/**
 * Sets secure HTTP-only session cookie.
 * In HTTPS production environments, applies the RFC 6265bis __Host- cookie prefix
 * with Secure, SameSite=Strict, Path=/, and no Domain attribute.
 */
export async function setAdminSessionCookie(
  signedToken: string,
  expiresAt: Date
): Promise<void> {
  const cookieStore = await cookies();
  const isSecure = await isSecureConnection();

  if (isSecure) {
    // RFC 6265bis __Host- prefix: guarantees host-only, HTTPS-only, root path
    cookieStore.set(HOST_COOKIE_NAME, signedToken, {
      httpOnly: true,
      secure: true,
      sameSite: "strict",
      path: "/",
      expires: expiresAt,
    });
    // Remove legacy cookie without prefix if present
    cookieStore.delete(BASE_COOKIE_NAME);
  } else {
    // Local development fallback (HTTP loopback)
    cookieStore.set(BASE_COOKIE_NAME, signedToken, {
      httpOnly: true,
      secure: false,
      sameSite: "strict",
      path: "/",
      expires: expiresAt,
    });
  }
}

/**
 * Clears session cookie and invalidates session from database
 */
export async function clearAdminSession(): Promise<void> {
  const cookieStore = await cookies();
  const hostCookie = cookieStore.get(HOST_COOKIE_NAME);
  const baseCookie = cookieStore.get(BASE_COOKIE_NAME);

  const tokenValue = hostCookie?.value || baseCookie?.value;
  if (tokenValue) {
    await invalidateAdminSession(tokenValue);
  }

  cookieStore.delete(HOST_COOKIE_NAME);
  cookieStore.delete(BASE_COOKIE_NAME);
}
