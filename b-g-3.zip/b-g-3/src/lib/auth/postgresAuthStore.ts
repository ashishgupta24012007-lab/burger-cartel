/**
 * PostgreSQL-Backed Administrator Persistence & Session Store
 * Authoritative persistence layer for Administrator identities, credentials,
 * sessions, account security states, and role-based permissions.
 */

import crypto from "crypto";
import { getDb } from "../db/index.ts";
import { readAuthDatabase } from "./store.ts";

export interface DbAdminUser {
  id: string; // UUID primary key
  adminId: string; // Unique alphanumeric admin handle (e.g. BC-ADMIN-SETUP-01)
  passwordHash: string;
  salt: string;
  role: string;
  roleId: string;
  mustChangePassword: boolean;
  email?: string | null;
  assignedOutletId?: string | null;
  failedLoginAttempts: number;
  lockedUntil?: Date | string | null;
  lastLoginAt?: Date | string | null;
  createdAt: string;
  updatedAt: string;
  permissions: string[];
}

export interface DbAdminSession {
  id: string;
  tokenHash: string;
  adminId: string;
  ip: string;
  userAgent: string;
  expiresAt: string;
  createdAt: string;
}

const SESSION_DURATION_HOURS = 24;
const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_MINUTES = 15;

/**
 * Hash raw token for secure database indexing
 */
export function hashToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

let migrationExecuted = false;

/**
 * Safely migrates existing encrypted credentials from admin-auth.json.enc
 * into PostgreSQL admin_users without credential destruction or disruption.
 */
export async function migrateLegacyStoreIfNeeded(): Promise<number> {
  if (migrationExecuted) return 0;
  migrationExecuted = true;

  const sql = getDb();
  if (!sql) return 0;

  try {
    const fileDb = readAuthDatabase();
    if (!fileDb.admins || fileDb.admins.length === 0) return 0;

    let migratedCount = 0;
    for (const legacyAdmin of fileDb.admins) {
      const existing = await sql`
        SELECT id FROM admin_users 
        WHERE LOWER(admin_id) = LOWER(${legacyAdmin.adminId})
        LIMIT 1
      `;

      if (existing.length === 0) {
        await sql`
          INSERT INTO admin_users (
            id, admin_id, password_hash, salt, role, role_id,
            must_change_password, failed_login_attempts, created_at, updated_at
          ) VALUES (
            gen_random_uuid(),
            ${legacyAdmin.adminId},
            ${legacyAdmin.passwordHash},
            ${legacyAdmin.salt},
            'superadmin',
            'superadmin',
            ${Boolean(legacyAdmin.mustChangePassword)},
            0,
            ${legacyAdmin.createdAt ? new Date(legacyAdmin.createdAt) : new Date()},
            ${legacyAdmin.updatedAt ? new Date(legacyAdmin.updatedAt) : new Date()}
          )
          ON CONFLICT (admin_id) DO NOTHING
        `;
        migratedCount++;
      }
    }

    if (migratedCount > 0) {
      console.log(`[AuthStore] Migrated ${migratedCount} legacy administrator(s) to PostgreSQL.`);
    }
    return migratedCount;
  } catch {
    // Non-fatal: if file doesn't exist or already migrated, continue
    return 0;
  }
}

/**
 * Retrieves administrator record by adminId (case-insensitive)
 */
export async function getAdminByAdminId(adminId: string): Promise<DbAdminUser | null> {
  const sql = getDb();
  if (!sql) return null;

  await migrateLegacyStoreIfNeeded();

  const rows = await sql`
    SELECT 
      u.id,
      u.admin_id AS "adminId",
      u.password_hash AS "passwordHash",
      u.salt,
      COALESCE(u.role_id, u.role, 'editor') AS "role",
      COALESCE(u.role_id, 'editor') AS "roleId",
      u.must_change_password AS "mustChangePassword",
      u.email,
      u.assigned_outlet_id AS "assignedOutletId",
      u.failed_login_attempts AS "failedLoginAttempts",
      u.locked_until AS "lockedUntil",
      u.last_login_at AS "lastLoginAt",
      u.created_at AS "createdAt",
      u.updated_at AS "updatedAt",
      COALESCE(r.permissions, '["cms:draft"]'::jsonb) AS permissions
    FROM admin_users u
    LEFT JOIN admin_roles r ON u.role_id = r.id
    WHERE LOWER(u.admin_id) = LOWER(${adminId.trim()})
    LIMIT 1
  `;

  if (rows.length === 0) return null;
  const row = rows[0];

  return {
    id: String(row.id),
    adminId: String(row.adminId),
    passwordHash: String(row.passwordHash),
    salt: String(row.salt),
    role: String(row.role),
    roleId: String(row.roleId),
    mustChangePassword: Boolean(row.mustChangePassword),
    email: row.email ? String(row.email) : null,
    assignedOutletId: row.assignedOutletId ? String(row.assignedOutletId) : null,
    failedLoginAttempts: Number(row.failedLoginAttempts || 0),
    lockedUntil: row.lockedUntil ? new Date(row.lockedUntil as string) : null,
    lastLoginAt: row.lastLoginAt ? new Date(row.lastLoginAt as string) : null,
    createdAt: new Date(row.createdAt as string).toISOString(),
    updatedAt: new Date(row.updatedAt as string).toISOString(),
    permissions: Array.isArray(row.permissions) ? (row.permissions as string[]) : [],
  };
}

/**
 * Retrieves administrator record by UUID
 */
export async function getAdminById(id: string): Promise<DbAdminUser | null> {
  const sql = getDb();
  if (!sql) return null;

  const rows = await sql`
    SELECT 
      u.id,
      u.admin_id AS "adminId",
      u.password_hash AS "passwordHash",
      u.salt,
      COALESCE(u.role_id, u.role, 'editor') AS "role",
      COALESCE(u.role_id, 'editor') AS "roleId",
      u.must_change_password AS "mustChangePassword",
      u.email,
      u.assigned_outlet_id AS "assignedOutletId",
      u.failed_login_attempts AS "failedLoginAttempts",
      u.locked_until AS "lockedUntil",
      u.last_login_at AS "lastLoginAt",
      u.created_at AS "createdAt",
      u.updated_at AS "updatedAt",
      COALESCE(r.permissions, '["cms:draft"]'::jsonb) AS permissions
    FROM admin_users u
    LEFT JOIN admin_roles r ON u.role_id = r.id
    WHERE u.id = ${id}::uuid
    LIMIT 1
  `;

  if (rows.length === 0) return null;
  const row = rows[0];

  return {
    id: String(row.id),
    adminId: String(row.adminId),
    passwordHash: String(row.passwordHash),
    salt: String(row.salt),
    role: String(row.role),
    roleId: String(row.roleId),
    mustChangePassword: Boolean(row.mustChangePassword),
    email: row.email ? String(row.email) : null,
    assignedOutletId: row.assignedOutletId ? String(row.assignedOutletId) : null,
    failedLoginAttempts: Number(row.failedLoginAttempts || 0),
    lockedUntil: row.lockedUntil ? new Date(row.lockedUntil as string) : null,
    lastLoginAt: row.lastLoginAt ? new Date(row.lastLoginAt as string) : null,
    createdAt: new Date(row.createdAt as string).toISOString(),
    updatedAt: new Date(row.updatedAt as string).toISOString(),
    permissions: Array.isArray(row.permissions) ? (row.permissions as string[]) : [],
  };
}

/**
 * Updates administrator password, clears must_change_password flag,
 * and revokes all active sessions.
 */
export async function updateAdminPassword(
  adminId: string,
  newHash: string,
  newSalt: string
): Promise<boolean> {
  const sql = getDb();
  if (!sql) return false;

  const result = await sql`
    UPDATE admin_users
    SET 
      password_hash = ${newHash},
      salt = ${newSalt},
      must_change_password = FALSE,
      failed_login_attempts = 0,
      locked_until = NULL,
      updated_at = NOW()
    WHERE LOWER(admin_id) = LOWER(${adminId.trim()})
    RETURNING id
  `;

  if (result.length > 0) {
    // Revoke all existing sessions for this administrator
    await revokeAllSessions(adminId);
    return true;
  }
  return false;
}

/**
 * Records successful login: clears failed attempts and updates last_login_at
 */
export async function recordLoginSuccess(adminId: string, clientIp: string): Promise<void> {
  const sql = getDb();
  if (!sql) return;

  await sql`
    UPDATE admin_users
    SET 
      failed_login_attempts = 0,
      locked_until = NULL,
      last_login_at = NOW(),
      updated_at = NOW()
    WHERE LOWER(admin_id) = LOWER(${adminId.trim()})
  `;

  // Append audit log
  await sql`
    INSERT INTO audit_logs (id, event, admin_id, ip, details, timestamp)
    VALUES (
      gen_random_uuid(),
      'LOGIN_SUCCESS',
      ${adminId},
      ${clientIp},
      'Administrator authenticated successfully via PostgreSQL.',
      NOW()
    )
  `.catch(() => {});
}

/**
 * Records failed login attempt and applies account lockout if threshold reached
 */
export async function recordLoginFailure(
  adminId: string,
  clientIp: string
): Promise<{ locked: boolean; lockedUntil?: Date }> {
  const sql = getDb();
  if (!sql) return { locked: false };

  const res = await sql`
    UPDATE admin_users
    SET 
      failed_login_attempts = failed_login_attempts + 1,
      locked_until = CASE 
        WHEN failed_login_attempts + 1 >= ${MAX_FAILED_ATTEMPTS} 
        THEN NOW() + (${LOCKOUT_MINUTES} || ' minutes')::interval
        ELSE locked_until
      END,
      updated_at = NOW()
    WHERE LOWER(admin_id) = LOWER(${adminId.trim()})
    RETURNING failed_login_attempts, locked_until
  `;

  if (res.length > 0 && res[0].locked_until) {
    const lockDate = new Date(res[0].locked_until as string);
    await sql`
      INSERT INTO audit_logs (id, event, admin_id, ip, details, timestamp)
      VALUES (
        gen_random_uuid(),
        'ACCOUNT_LOCKED',
        ${adminId},
        ${clientIp},
        ${`Account locked for ${LOCKOUT_MINUTES} minutes after ${MAX_FAILED_ATTEMPTS} failed attempts.`},
        NOW()
      )
    `.catch(() => {});
    return { locked: true, lockedUntil: lockDate };
  }

  await sql`
    INSERT INTO audit_logs (id, event, admin_id, ip, details, timestamp)
    VALUES (
      gen_random_uuid(),
      'LOGIN_FAILED',
      ${adminId},
      ${clientIp},
      'Failed password authentication attempt.',
      NOW()
    )
  `.catch(() => {});

  return { locked: false };
}

/**
 * Creates an authoritative PostgreSQL-backed admin session
 */
export async function createSession(
  adminId: string,
  ip = "127.0.0.1",
  userAgent = "unknown"
): Promise<{ rawToken: string; expiresAt: Date }> {
  const sql = getDb();
  if (!sql) {
    throw new Error("[AuthStore] Database connection required for session creation.");
  }

  const rawToken = crypto.randomBytes(32).toString("hex");
  const tokenHash = hashToken(rawToken);
  const now = new Date();
  const expiresAt = new Date(now.getTime() + SESSION_DURATION_HOURS * 60 * 60 * 1000);

  // Clean up expired sessions opportunistically
  await sql`DELETE FROM admin_sessions WHERE expires_at < NOW()`.catch(() => {});

  await sql`
    INSERT INTO admin_sessions (
      id, token_hash, admin_id, ip, user_agent, expires_at, created_at
    ) VALUES (
      gen_random_uuid(),
      ${tokenHash},
      ${adminId},
      ${ip.slice(0, 45)},
      ${userAgent.slice(0, 255)},
      ${expiresAt.toISOString()}::timestamptz,
      ${now.toISOString()}::timestamptz
    )
  `;

  return { rawToken, expiresAt };
}

/**
 * Validates a session token against PostgreSQL with User-Agent integrity check
 */
export async function validateSession(
  rawToken: string,
  currentUa?: string
): Promise<{ valid: boolean; admin?: DbAdminUser }> {
  const sql = getDb();
  if (!sql) return { valid: false };

  const tokenHash = hashToken(rawToken);

  const rows = await sql`
    SELECT 
      s.id AS "sessionId",
      s.token_hash AS "tokenHash",
      s.admin_id AS "sessionAdminId",
      s.user_agent AS "sessionUserAgent",
      s.expires_at AS "expiresAt",
      u.id AS "adminUuid",
      u.admin_id AS "adminId",
      u.role_id AS "roleId",
      COALESCE(u.role_id, u.role, 'editor') AS "role",
      u.must_change_password AS "mustChangePassword",
      u.email,
      u.assigned_outlet_id AS "assignedOutletId",
      u.locked_until AS "lockedUntil",
      COALESCE(r.permissions, '["cms:draft"]'::jsonb) AS permissions
    FROM admin_sessions s
    JOIN admin_users u ON LOWER(s.admin_id) = LOWER(u.admin_id)
    LEFT JOIN admin_roles r ON u.role_id = r.id
    WHERE s.token_hash = ${tokenHash}
    LIMIT 1
  `;

  if (rows.length === 0) return { valid: false };
  const row = rows[0];

  // Expiration check
  const expiresAt = new Date(row.expiresAt as string);
  if (expiresAt.getTime() < Date.now()) {
    await sql`DELETE FROM admin_sessions WHERE token_hash = ${tokenHash}`.catch(() => {});
    return { valid: false };
  }

  // Session Hijacking Protection (User-Agent verification)
  const sessionUa = String(row.sessionUserAgent || "");
  if (sessionUa && currentUa && sessionUa !== "unknown" && currentUa !== "unknown" && sessionUa !== currentUa) {
    await sql`DELETE FROM admin_sessions WHERE token_hash = ${tokenHash}`.catch(() => {});
    await sql`
      INSERT INTO audit_logs (id, event, admin_id, details, timestamp)
      VALUES (
        gen_random_uuid(),
        'SESSION_HIJACK_DETECTED',
        ${row.adminId},
        'Session revoked: User-Agent header mismatch.',
        NOW()
      )
    `.catch(() => {});
    return { valid: false };
  }

  // Account Lockout check
  if (row.lockedUntil && new Date(row.lockedUntil as string).getTime() > Date.now()) {
    return { valid: false };
  }

  const admin: DbAdminUser = {
    id: String(row.adminUuid),
    adminId: String(row.adminId),
    passwordHash: "",
    salt: "",
    role: String(row.role),
    roleId: String(row.roleId),
    mustChangePassword: Boolean(row.mustChangePassword),
    email: row.email ? String(row.email) : null,
    assignedOutletId: row.assignedOutletId ? String(row.assignedOutletId) : null,
    failedLoginAttempts: 0,
    createdAt: "",
    updatedAt: "",
    permissions: Array.isArray(row.permissions) ? (row.permissions as string[]) : [],
  };

  return { valid: true, admin };
}

/**
 * Invalidates a single session by raw token (Logout)
 */
export async function invalidateSession(rawToken: string): Promise<void> {
  const sql = getDb();
  if (!sql) return;

  const tokenHash = hashToken(rawToken);
  await sql`DELETE FROM admin_sessions WHERE token_hash = ${tokenHash}`;
}

/**
 * Revokes all active sessions for an administrator (Security event / password reset)
 */
export async function revokeAllSessions(adminId: string): Promise<void> {
  const sql = getDb();
  if (!sql) return;

  await sql`DELETE FROM admin_sessions WHERE LOWER(admin_id) = LOWER(${adminId.trim()})`;
}

/**
 * Checks whether the administrator account exists in PostgreSQL
 */
export async function isBootstrapNeeded(): Promise<boolean> {
  const sql = getDb();
  if (!sql) return false;

  await migrateLegacyStoreIfNeeded();

  const rows = await sql`SELECT COUNT(*) as count FROM admin_users`;
  return Number(rows[0]?.count || 0) === 0;
}

/**
 * Bootstraps initial administrator account into PostgreSQL if table is empty
 */
export async function bootstrapInitialAdmin(
  adminId: string,
  passwordHash: string,
  salt: string
): Promise<boolean> {
  const sql = getDb();
  if (!sql) return false;

  const needed = await isBootstrapNeeded();
  if (!needed) return false;

  await sql`
    INSERT INTO admin_users (
      id, admin_id, password_hash, salt, role, role_id,
      must_change_password, failed_login_attempts, created_at, updated_at
    ) VALUES (
      gen_random_uuid(),
      ${adminId.trim()},
      ${passwordHash},
      ${salt},
      'superadmin',
      'superadmin',
      TRUE,
      0,
      NOW(),
      NOW()
    )
    ON CONFLICT (admin_id) DO NOTHING
  `;

  return true;
}
