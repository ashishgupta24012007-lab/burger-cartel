/**
 * Distributed Rate Limiting — PostgreSQL-backed sliding-window implementation.
 * 
 * Uses the `rate_limit_buckets` table created in Migration 003 for atomic,
 * multi-instance-safe rate limiting with automatic expiry.
 *
 * Schema:
 *   key         VARCHAR PRIMARY KEY  -- "ip:<addr>" or "user:<id>" or "cred_change:<id>"
 *   tokens      INTEGER NOT NULL     -- remaining failed attempts before lockout
 *   last_refill TIMESTAMPTZ NOT NULL -- last time the bucket was checked/refilled
 *   expires_at  TIMESTAMPTZ NOT NULL -- when this record can be garbage collected
 *
 * Algorithm: Inverted token bucket.
 *   - Each key starts with `MAX_FAILED_ATTEMPTS` tokens.
 *   - Each failed attempt consumes one token via atomic SQL.
 *   - When tokens reach 0, the key is locked for `LOCKOUT_DURATION_MINUTES`.
 *   - On successful auth, the key is deleted (reset).
 *   - Expired records are cleaned up opportunistically.
 *
 * Fail-open: If the database is unreachable, the request is ALLOWED (with warning log).
 *            This prevents auth DoS when the DB is temporarily unavailable.
 */

import { getDb } from "../db/index.ts";

const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_DURATION_MINUTES = 15;

// In-memory fallback for local execution / unit tests when DB is not configured
const inMemoryBuckets = new Map<string, { tokens: number; expiresAt: number }>();

export interface RateLimitResult {
  allowed: boolean;
  remainingAttempts: number;
  lockedUntil?: string;
}

/**
 * Checks whether a rate-limit key is currently locked out.
 * Returns { allowed, remainingAttempts, lockedUntil? }
 */
export async function checkRateLimitDb(key: string): Promise<RateLimitResult> {
  const sql = getDb();
  if (!sql) {
    const bucket = inMemoryBuckets.get(key);
    if (!bucket) return { allowed: true, remainingAttempts: MAX_FAILED_ATTEMPTS };
    if (Date.now() >= bucket.expiresAt) {
      inMemoryBuckets.delete(key);
      return { allowed: true, remainingAttempts: MAX_FAILED_ATTEMPTS };
    }
    if (bucket.tokens <= 0) {
      return {
        allowed: false,
        remainingAttempts: 0,
        lockedUntil: new Date(bucket.expiresAt).toISOString(),
      };
    }
    return { allowed: true, remainingAttempts: bucket.tokens };
  }

  try {
    const rows = await sql`
      SELECT tokens, last_refill, expires_at
      FROM rate_limit_buckets
      WHERE key = ${key}
    `;

    if (rows.length === 0) {
      // No record: full quota available
      return { allowed: true, remainingAttempts: MAX_FAILED_ATTEMPTS };
    }

    const record = rows[0];
    const now = Date.now();
    const expiresAt = new Date(record.expires_at).getTime();

    // If the record has expired, clean it up and allow
    if (now >= expiresAt) {
      await sql`DELETE FROM rate_limit_buckets WHERE key = ${key}`;
      return { allowed: true, remainingAttempts: MAX_FAILED_ATTEMPTS };
    }

    const tokens = Number(record.tokens);
    if (tokens <= 0) {
      // Locked out
      return {
        allowed: false,
        remainingAttempts: 0,
        lockedUntil: new Date(expiresAt).toISOString(),
      };
    }

    return { allowed: true, remainingAttempts: tokens };
  } catch (err) {
    console.error("[RateLimit] DB check failed — fail-open for key:", key, err);
    return { allowed: true, remainingAttempts: MAX_FAILED_ATTEMPTS };
  }
}

/**
 * Records a failed authentication attempt atomically.
 * Uses INSERT ... ON CONFLICT DO UPDATE for concurrent safety.
 *
 * Returns { locked, lockedUntil? }
 */
export async function recordFailedAttemptDb(key: string): Promise<{
  locked: boolean;
  lockedUntil?: string;
}> {
  const sql = getDb();
  if (!sql) {
    const lockoutMs = LOCKOUT_DURATION_MINUTES * 60 * 1000;
    const expiresAt = Date.now() + lockoutMs;
    const current = inMemoryBuckets.get(key);
    const tokens = current && Date.now() < current.expiresAt
      ? Math.max(current.tokens - 1, 0)
      : MAX_FAILED_ATTEMPTS - 1;
    inMemoryBuckets.set(key, { tokens, expiresAt });
    if (tokens <= 0) {
      return {
        locked: true,
        lockedUntil: new Date(expiresAt).toISOString(),
      };
    }
    return { locked: false };
  }

  try {
    // Lockout expiry: extend on every failed attempt
    const lockoutMs = LOCKOUT_DURATION_MINUTES * 60 * 1000;
    const expiresAt = new Date(Date.now() + lockoutMs);

    // Atomic upsert: start with MAX_FAILED_ATTEMPTS-1 on first failure,
    // then decrement on subsequent failures. Never go below 0.
    const rows = await sql`
      INSERT INTO rate_limit_buckets (key, tokens, last_refill, expires_at)
      VALUES (${key}, ${MAX_FAILED_ATTEMPTS - 1}, NOW(), ${expiresAt.toISOString()}::timestamptz)
      ON CONFLICT (key) DO UPDATE SET
        tokens = GREATEST(rate_limit_buckets.tokens - 1, 0),
        last_refill = NOW(),
        expires_at = ${expiresAt.toISOString()}::timestamptz
      RETURNING tokens, expires_at
    `;

    const remaining = Number(rows[0].tokens);
    if (remaining <= 0) {
      return {
        locked: true,
        lockedUntil: new Date(rows[0].expires_at).toISOString(),
      };
    }
    return { locked: false };
  } catch (err) {
    console.error("[RateLimit] DB record failed — fail-open for key:", key, err);
    return { locked: false };
  }
}

/**
 * Resets rate limiting on successful authentication.
 */
export async function resetRateLimitDb(key: string): Promise<void> {
  const sql = getDb();
  if (!sql) {
    inMemoryBuckets.delete(key);
    return;
  }

  try {
    await sql`DELETE FROM rate_limit_buckets WHERE key = ${key}`;
  } catch (err) {
    console.error("[RateLimit] DB reset failed for key:", key, err);
  }
}

/**
 * Opportunistic cleanup of expired rate limit records.
 * Called periodically (e.g. after successful auth) to prevent table bloat.
 */
export async function cleanupExpiredBuckets(): Promise<void> {
  const sql = getDb();
  if (!sql) {
    const now = Date.now();
    for (const [k, v] of inMemoryBuckets.entries()) {
      if (now >= v.expiresAt) inMemoryBuckets.delete(k);
    }
    return;
  }

  try {
    await sql`DELETE FROM rate_limit_buckets WHERE expires_at < NOW()`;
  } catch (err) {
    console.error("[RateLimit] Cleanup failed:", err);
  }
}
