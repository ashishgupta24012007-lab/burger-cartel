/**
 * Branch-Level Authorization — PostgreSQL-backed outlet access control.
 *
 * Verifies that an admin user has permission to manage a specific outlet.
 * Uses the `admin_user_outlets` junction table and `admin_roles` for RBAC.
 *
 * Rules:
 *   1. Superadmin role → access ALL outlets (bypass check)
 *   2. Non-superadmin → must have explicit row in `admin_user_outlets`
 *   3. Default deny: if no matching row and not superadmin, reject
 */

import { getDb } from "../db/index.ts";

/**
 * Checks if an admin user is authorized to manage a specific outlet.
 *
 * @param adminUserId - UUID of the admin user (from admin_users.id)
 * @param outletId - Outlet slug/ID (from outlets.id)
 * @returns true if authorized, false otherwise
 */
export async function assertAuthorizedForOutlet(
  adminUserId: string,
  outletId: string
): Promise<boolean> {
  const sql = getDb();
  if (!sql) {
    // If DB is not configured, deny by default in production, allow in dev
    if (process.env.NODE_ENV === "production") {
      console.error("[BranchAuth] Database not configured — denying outlet access in production");
      return false;
    }
    return true;
  }

  try {
    // 1. Check if user is superadmin (bypass outlet restriction)
    const roleRows = await sql`
      SELECT ar.id as role_id
      FROM admin_users au
      JOIN admin_roles ar ON au.role_id = ar.id
      WHERE au.id = ${adminUserId}
        AND ar.id = 'superadmin'
    `;

    if (roleRows.length > 0) {
      return true; // Superadmin: unrestricted access
    }

    // 2. Check explicit outlet assignment
    const assignmentRows = await sql`
      SELECT 1
      FROM admin_user_outlets
      WHERE admin_id = ${adminUserId}
        AND outlet_id = ${outletId}
    `;

    return assignmentRows.length > 0;
  } catch (err) {
    console.error("[BranchAuth] Authorization check failed:", err);
    // Fail-closed: deny access on error
    return false;
  }
}

/**
 * Returns the list of outlet IDs an admin user is authorized to manage.
 * Superadmins get ALL outlets.
 *
 * @param adminUserId - UUID of the admin user
 * @returns Array of outlet IDs, or ['*'] for superadmin
 */
export async function getAuthorizedOutlets(
  adminUserId: string
): Promise<string[]> {
  const sql = getDb();
  if (!sql) return [];

  try {
    // Check superadmin
    const roleRows = await sql`
      SELECT ar.id as role_id
      FROM admin_users au
      JOIN admin_roles ar ON au.role_id = ar.id
      WHERE au.id = ${adminUserId}
        AND ar.id = 'superadmin'
    `;

    if (roleRows.length > 0) {
      return ["*"]; // Superadmin wildcard
    }

    // Get explicitly assigned outlets
    const rows = await sql`
      SELECT outlet_id FROM admin_user_outlets
      WHERE admin_id = ${adminUserId}
      ORDER BY outlet_id
    `;

    return rows.map((r) => String(r.outlet_id));
  } catch (err) {
    console.error("[BranchAuth] Failed to get authorized outlets:", err);
    return [];
  }
}
