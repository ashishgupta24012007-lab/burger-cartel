import fs from "fs";
import path from "path";
import crypto from "crypto";

export interface AdminRecord {
  id: string;
  adminId: string;
  passwordHash: string;
  salt: string;
  role?: string;
  roleId?: string;
  createdAt: string;
  updatedAt: string;
  mustChangePassword?: boolean;
  email?: string | null;
  assignedOutletId?: string | null;
  permissions?: string[];
}

export interface SessionRecord {
  id: string;
  tokenHash: string;
  adminId: string;
  createdAt: string;
  expiresAt: string;
  ip?: string;
  userAgent?: string;
}

export interface RateLimitRecord {
  attempts: number;
  lastAttempt: string;
  lockedUntil?: string;
}

export interface AuditLogEntry {
  id: string;
  event: string;
  adminId?: string;
  timestamp: string;
  ip?: string;
  details?: string;
}

export interface AuthDatabaseSchema {
  admins: AdminRecord[];
  sessions: SessionRecord[];
  rateLimits: Record<string, RateLimitRecord>;
  config: {
    bootstrapCompleted: boolean;
    bootstrapDate?: string;
    phoneAuthEnabled: boolean;
  };
  auditLogs: AuditLogEntry[];
}

const DATA_DIR = path.join(process.cwd(), "data");
const DEFAULT_STORE_FILE = "admin-auth.json.enc";

function getStorePaths(): { dataDir: string; storePath: string } {
  const fileName = process.env.ADMIN_STORE_FILENAME || DEFAULT_STORE_FILE;
  return {
    dataDir: DATA_DIR,
    storePath: path.join(DATA_DIR, fileName),
  };
}

let runtimeStoreKey: string | null = null;

function getEncryptionKey(): Buffer {
  const secret = process.env.ADMIN_STORE_KEY || process.env.SESSION_SECRET;
  if (secret) {
    return crypto.createHash("sha256").update(secret).digest();
  }
  if (process.env.NODE_ENV === "production") {
    throw new Error(
      "[SECURITY FATAL] Mandatory secret ADMIN_STORE_KEY or SESSION_SECRET is missing in production environment. Refusing to start in insecure state."
    );
  }
  if (!runtimeStoreKey) {
    runtimeStoreKey = crypto.randomBytes(32).toString("hex");
  }
  return crypto.createHash("sha256").update(runtimeStoreKey).digest();
}

function encrypt(data: string, key: Buffer): string {
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  let encrypted = cipher.update(data, "utf8", "hex");
  encrypted += cipher.final("hex");
  const authTag = cipher.getAuthTag().toString("hex");
  return `${iv.toString("hex")}:${authTag}:${encrypted}`;
}

function decrypt(cipherText: string, key: Buffer): string {
  const parts = cipherText.split(":");
  if (parts.length !== 3) {
    throw new Error("Invalid encrypted format");
  }
  const [ivHex, authTagHex, encryptedHex] = parts;
  const iv = Buffer.from(ivHex, "hex");
  const authTag = Buffer.from(authTagHex, "hex");
  const decipher = crypto.createDecipheriv("aes-256-gcm", key, iv);
  decipher.setAuthTag(authTag);
  let decrypted = decipher.update(encryptedHex, "hex", "utf8");
  decrypted += decipher.final("utf8");
  return decrypted;
}

function getInitialDatabase(): AuthDatabaseSchema {
  return {
    admins: [],
    sessions: [],
    rateLimits: {},
    config: {
      bootstrapCompleted: false,
      phoneAuthEnabled: false,
    },
    auditLogs: [],
  };
}

/**
 * Reads and decrypts the persistent local auth database
 */
export function readAuthDatabase(): AuthDatabaseSchema {
  const { dataDir, storePath } = getStorePaths();
  try {
    if (!fs.existsSync(/*turbopackIgnore: true*/ dataDir)) {
      fs.mkdirSync(/*turbopackIgnore: true*/ dataDir, { recursive: true, mode: 0o700 });
    }

    if (!fs.existsSync(/*turbopackIgnore: true*/ storePath)) {
      const initial = getInitialDatabase();
      writeAuthDatabase(initial);
      return initial;
    }

    const fileContent = fs.readFileSync(/*turbopackIgnore: true*/ storePath, "utf8");
    if (!fileContent.trim()) {
      const initial = getInitialDatabase();
      writeAuthDatabase(initial);
      return initial;
    }

    const key = getEncryptionKey();
    const decryptedJson = decrypt(fileContent, key);
    return JSON.parse(decryptedJson) as AuthDatabaseSchema;
  } catch (err) {
    console.error("[AuthStore] Decryption or read failed for auth store:", err);
    // If file exists and has content, do NOT overwrite it silently with an empty database.
    // Preserve the file and throw an error so administrator credentials are not destroyed.
    if (fs.existsSync(/*turbopackIgnore: true*/ storePath) && fs.statSync(/*turbopackIgnore: true*/ storePath).size > 0) {
      throw new Error("Failed to decrypt authentication store. Verify ADMIN_STORE_KEY or SESSION_SECRET.");
    }
    const initial = getInitialDatabase();
    writeAuthDatabase(initial);
    return initial;
  }
}

// In-memory mutex to serialize write transactions and eliminate lost-update race conditions
let writeQueue = Promise.resolve();

/**
 * Encrypts and writes the database with atomic file replacement and log pruning
 */
export function writeAuthDatabase(data: AuthDatabaseSchema): void {
  const { dataDir, storePath } = getStorePaths();
  if (!fs.existsSync(/*turbopackIgnore: true*/ dataDir)) {
    fs.mkdirSync(/*turbopackIgnore: true*/ dataDir, { recursive: true, mode: 0o700 });
  }

  // Prune audit logs to last 200 entries to prevent storage exhaustion
  if (data.auditLogs && data.auditLogs.length > 200) {
    data.auditLogs = data.auditLogs.slice(-200);
  }

  // Clean up expired rate limits older than 30 minutes
  const now = Date.now();
  if (data.rateLimits) {
    for (const [key, record] of Object.entries(data.rateLimits)) {
      if (record.lockedUntil) {
        if (new Date(record.lockedUntil).getTime() < now) {
          delete data.rateLimits[key];
        }
      } else if (record.lastAttempt) {
        const lastTime = new Date(record.lastAttempt).getTime();
        if (now - lastTime > 30 * 60 * 1000) {
          delete data.rateLimits[key];
        }
      }
    }

    // Prevent memory & storage exhaustion from spoofed or distributed IP floods (cap to 500 active records)
    const activeKeys = Object.keys(data.rateLimits);
    if (activeKeys.length > 500) {
      const sorted = activeKeys.sort((a, b) => {
        const tA = new Date(data.rateLimits[a].lastAttempt || 0).getTime();
        const tB = new Date(data.rateLimits[b].lastAttempt || 0).getTime();
        return tA - tB;
      });
      const excess = sorted.slice(0, sorted.length - 500);
      for (const k of excess) {
        delete data.rateLimits[k];
      }
    }
  }

  const key = getEncryptionKey();
  const serialized = JSON.stringify(data, null, 2);
  const cipherText = encrypt(serialized, key);

  // Write atomically to temp file, then rename
  const tempPath = `${storePath}.tmp.${crypto.randomBytes(6).toString("hex")}`;
  fs.writeFileSync(tempPath, cipherText, { mode: 0o600 });
  fs.renameSync(tempPath, storePath);
}

/**
 * Thread-safe / asynchronous mutex for executing atomic read-modify-write operations
 */
export async function mutateAuthDatabase<T>(
  mutator: (db: AuthDatabaseSchema) => T | Promise<T>
): Promise<T> {
  const operation = writeQueue.then(async () => {
    const db = readAuthDatabase();
    const result = await mutator(db);
    writeAuthDatabase(db);
    return result;
  });

  // Ensure queue advances even if mutator throws
  writeQueue = operation.then(() => {}, () => {});
  return operation;
}
