/**
 * Role-Based Access Control (RBAC) & Server-Side Permission Verification
 * Enforces strict principle of least privilege across all CMS operations.
 */

import type { AdminRecord } from "./store.ts";
import { assertAuthorizedForOutlet } from "./branchAuth.ts";
import { getAdminById } from "./postgresAuthStore.ts";

export type SystemPermission =
  | "*"
  | "cms:draft"
  | "cms:publish"
  | "media:upload"
  | "outlets:update"
  | "inventory:override"
  | "system:admin";

/**
 * Authoritative Server-Side Action Permission Matrix
 */
export const ACTION_PERMISSION_MATRIX: Record<string, SystemPermission> = {
  // Site Content
  UPDATE_SITE_CONTENT: "cms:draft",
  UPDATE_HERO: "cms:draft",
  UPDATE_ANNOUNCEMENT: "cms:draft",
  UPDATE_ABOUT: "cms:draft",
  UPDATE_CONTACT: "cms:draft",
  UPDATE_NAVIGATION: "cms:draft",
  UPDATE_FOOTER: "cms:draft",
  UPDATE_PAGE_SEO: "cms:draft",
  UPDATE_SEO: "cms:draft",

  // Menu Management
  SAVE_MENU_CATEGORY: "cms:draft",
  UPDATE_CATEGORY: "cms:draft",
  DELETE_MENU_CATEGORY: "cms:draft",
  SAVE_MENU_ITEM: "cms:draft",
  UPDATE_MENU_ITEM: "cms:draft",
  DELETE_MENU_ITEM: "cms:draft",
  UPDATE_MENU_SETTINGS: "cms:draft",

  // Customer Reviews & Feedback
  ADD_REVIEW: "cms:draft",
  UPDATE_REVIEW: "cms:draft",
  TOGGLE_REVIEW_VISIBILITY: "cms:draft",
  DELETE_REVIEW: "cms:draft",

  // Custom Pages
  SAVE_CUSTOM_PAGE: "cms:draft",
  DELETE_CUSTOM_PAGE: "cms:draft",

  // Gallery & Media
  ADD_GALLERY_ITEM: "media:upload",
  UPDATE_GALLERY_ITEM: "media:upload",
  DELETE_GALLERY_ITEM: "media:upload",

  // Branch Outlets & Operations
  UPDATE_OUTLET: "outlets:update",
  SET_OUTLET_ITEM_AVAILABILITY: "inventory:override",
  TOGGLE_OUTLET_ITEM_AVAILABILITY: "inventory:override",
  SET_OUTLET_ITEM_PRICE_OVERRIDE: "inventory:override",
  SET_OUTLET_MENU_PRICE_OVERRIDE: "inventory:override",

  // Publishing & Release Approvals (Superadmin only)
  PUBLISH_ALL: "cms:publish",
  PUBLISH_RELEASE: "cms:publish",
  APPROVE_REVISION: "cms:publish",
  ROLLBACK_RELEASE: "cms:publish",
  LIST_RELEASES: "cms:draft",

  // Disaster Recovery & Database Maintenance (Superadmin only)
  CREATE_BACKUP: "system:admin",
  RESTORE_BACKUP: "system:admin",
  RESET_DEFAULTS: "system:admin",
  LIST_BACKUPS: "system:admin",
};

/**
 * Validates that an administrator session is authorized to execute a requested action.
 * Evaluates against authoritative database records, never trusting client-supplied role claims.
 */
export async function verifyRbacPermission(
  adminSessionUser: AdminRecord,
  action: string,
  context?: { outletId?: string }
): Promise<{ authorized: boolean; error?: string; status?: number }> {
  const requiredPermission = ACTION_PERMISSION_MATRIX[action];

  if (!requiredPermission) {
    return {
      authorized: false,
      error: `Forbidden: Action '${action}' is not defined in the system security matrix.`,
      status: 403,
    };
  }

  // Load live user permissions directly from PostgreSQL to prevent stale session privileges
  const liveAdmin = await getAdminById(adminSessionUser.id).catch(() => null);
  const permissions = liveAdmin?.permissions || adminSessionUser.permissions || [];
  const roleId = liveAdmin?.roleId || adminSessionUser.roleId || "editor";

  // 1. Superadmin wildcard bypasses all restrictions
  if (roleId === "superadmin" || permissions.includes("*")) {
    return { authorized: true };
  }

  // 2. Check general action permission
  const hasPermission =
    permissions.includes(requiredPermission) ||
    permissions.includes("*");

  if (!hasPermission) {
    return {
      authorized: false,
      error: `Forbidden: Your role ('${roleId}') lacks permission '${requiredPermission}' required for action '${action}'.`,
      status: 403,
    };
  }

  // 3. For branch-scoped operations (hours, menu availability, price overrides):
  // Enforce branch-level data boundary
  if (requiredPermission === "outlets:update" || requiredPermission === "inventory:override") {
    const targetOutlet = context?.outletId;
    if (!targetOutlet) {
      return {
        authorized: false,
        error: "Forbidden: Branch-scoped operations require a target outlet identifier.",
        status: 403,
      };
    }

    const isAuthorizedForBranch = await assertAuthorizedForOutlet(adminSessionUser.id, targetOutlet);
    if (!isAuthorizedForBranch) {
      return {
        authorized: false,
        error: `Forbidden: You are not authorized to manage outlet '${targetOutlet}'.`,
        status: 403,
      };
    }
  }

  return { authorized: true };
}
