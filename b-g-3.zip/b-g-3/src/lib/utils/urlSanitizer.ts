/**
 * Burger Cartel URL Sanitization Utility
 * 
 * Protects against Stored XSS, DOM-based XSS, and Open Redirects by strictly
 * validating URI schemes and rejecting javascript:, data:, vbscript:, and protocol-relative URLs.
 */

const ALLOWED_PROTOCOLS = new Set(["http:", "https:", "mailto:", "tel:"]);

/**
 * Validates whether a given URL string uses a safe protocol or relative path
 */
export function isSafeUrl(url: unknown): boolean {
  if (typeof url !== "string") return false;
  const trimmed = url.trim();
  if (!trimmed) return false;

  // Reject ASCII control characters, null bytes, and non-printable characters
  // that attackers use to bypass string matching (e.g., java\0script:)
  if (/[\x00-\x1F\x7F]/.test(trimmed)) {
    return false;
  }

  // Safe relative paths: must start with single '/' and NOT '//' (open redirect) or '/\'
  if (trimmed.startsWith("/")) {
    return !trimmed.startsWith("//") && !trimmed.startsWith("/\\");
  }

  // Safe fragment / anchor links (e.g. #reviews, #gallery)
  if (trimmed.startsWith("#")) {
    return true;
  }

  // Absolute URLs: parse strictly with standard WHATWG URL parser
  try {
    const parsed = new URL(trimmed);
    return ALLOWED_PROTOCOLS.has(parsed.protocol.toLowerCase());
  } catch {
    return false;
  }
}

/**
 * Sanitizes an untrusted URL string. Returns the trimmed URL if safe,
 * or the provided fallback string (defaults to '#') if dangerous or invalid.
 */
export function sanitizeUrl(url: unknown, fallback: string = "#"): string {
  if (isSafeUrl(url)) {
    return (url as string).trim();
  }
  return fallback;
}
