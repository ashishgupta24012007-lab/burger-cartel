/**
 * Burger Cartel Media File Signature Validator
 * 
 * Inspects binary magic bytes, MIME types, and file content to prevent:
 * - File-type spoofing (e.g. uploading an executable disguised as an image)
 * - Stored XSS via SVG or HTML files with embedded scripts
 * - Server-side execution of uploaded scripts
 */

export interface ImageValidationResult {
  valid: boolean;
  extension?: "jpg" | "png" | "webp";
  mimeType?: string;
  error?: string;
}

/**
 * Validates actual binary file signatures (magic bytes) to prevent file-type spoofing
 */
export function validateImageMagicBytes(buffer: Buffer): ImageValidationResult {
  if (!buffer || buffer.length < 12) {
    return { valid: false, error: "File too small or truncated." };
  }

  // 1. Inspect first 1KB for dangerous markup/scripts (SVG, HTML, XML, PHP)
  const headerPreview = buffer.subarray(0, Math.min(buffer.length, 1024)).toString("utf8").toLowerCase();
  if (
    headerPreview.includes("<svg") ||
    headerPreview.includes("<?xml") ||
    headerPreview.includes("<!doctype") ||
    headerPreview.includes("<html") ||
    headerPreview.includes("<script") ||
    headerPreview.includes("<?php")
  ) {
    return {
      valid: false,
      error: "Executable, SVG, or HTML script-containing files are strictly prohibited.",
    };
  }

  // 2. JPEG Signature: FF D8 FF
  if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
    return { valid: true, extension: "jpg", mimeType: "image/jpeg" };
  }

  // 3. PNG Signature: 89 50 4E 47 0D 0A 1A 0A
  if (
    buffer[0] === 0x89 &&
    buffer[1] === 0x50 &&
    buffer[2] === 0x4e &&
    buffer[3] === 0x47 &&
    buffer[4] === 0x0d &&
    buffer[5] === 0x0a &&
    buffer[6] === 0x1a &&
    buffer[7] === 0x0a
  ) {
    return { valid: true, extension: "png", mimeType: "image/png" };
  }

  // 4. WebP Signature: RIFF....WEBP
  // Bytes 0-3: 52 49 46 46 (RIFF), Bytes 8-11: 57 45 42 50 (WEBP)
  if (
    buffer[0] === 0x52 &&
    buffer[1] === 0x49 &&
    buffer[2] === 0x46 &&
    buffer[3] === 0x46 &&
    buffer[8] === 0x57 &&
    buffer[9] === 0x45 &&
    buffer[10] === 0x42 &&
    buffer[11] === 0x50
  ) {
    return { valid: true, extension: "webp", mimeType: "image/webp" };
  }

  return {
    valid: false,
    error: "Invalid file signature. Only standard JPEG, PNG, or WebP images are permitted.",
  };
}
