/**
 * Unified Client-Side CMS Data Fetcher & Reactive Synchroniser
 * 
 * Provides:
 * 1. Controlled caching with short TTL (15s fresh window).
 * 2. Explicit cache invalidation (`invalidateCmsClientCache()`).
 * 3. Broadcast synchronization (`broadcastCmsUpdate()`).
 * 4. Automatic refetch on window focus / tab visibility change.
 * 5. Type-safe access to siteContent, menu, outlets, reviews, gallery, and customPages.
 */

import type { CmsDatabaseSchema } from "@/lib/cms/store";

let cachedData: CmsDatabaseSchema | null = null;
let cacheTimestamp = 0;
let inflightPromise: Promise<CmsDatabaseSchema | null> | null = null;
const CACHE_TTL_MS = 15000; // 15-second fresh cache window

/**
 * Invalidates the in-memory client cache to guarantee the next call fetches from the server.
 */
export function invalidateCmsClientCache(): void {
  cachedData = null;
  cacheTimestamp = 0;
  inflightPromise = null;
}

/**
 * Broadcasts newly published or saved CMS data across all active components in the current window.
 */
export function broadcastCmsUpdate(data: CmsDatabaseSchema): void {
  cachedData = data;
  cacheTimestamp = Date.now();
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("cms:updated", { detail: data }));
  }
}

/**
 * Fetches the latest published CMS content with controlled caching and deduplication.
 */
export async function fetchCmsContent(options?: { forceFresh?: boolean }): Promise<CmsDatabaseSchema | null> {
  const now = Date.now();
  
  if (!options?.forceFresh && cachedData && now - cacheTimestamp < CACHE_TTL_MS) {
    return cachedData;
  }

  if (inflightPromise) {
    return inflightPromise;
  }

  inflightPromise = fetch("/api/cms/content", {
    cache: "no-store",
    headers: {
      Pragma: "no-cache",
      "Cache-Control": "no-cache",
    },
  })
    .then(async (res) => {
      if (!res.ok) throw new Error(`CMS content fetch failed with status ${res.status}`);
      const json = await res.json();
      if (!json.success) throw new Error(json.error || "CMS content returned unsuccessful");
      
      const schema: CmsDatabaseSchema = {
        siteContent: json.siteContent,
        menuCategories: json.menuCategories || [],
        menuItems: json.menuItems || [],
        outlets: json.outlets || [],
        reviews: json.reviews || [],
        gallery: json.gallery || [],
        customPages: json.customPages || [],
        outletMenuAvailability: json.outletMenuAvailability || {},
        outletMenuOverrides: json.outletMenuOverrides || {},
        updatedAt: json.updatedAt || new Date().toISOString(),
        publishedAt: json.publishedAt,
      };

      cachedData = schema;
      cacheTimestamp = Date.now();
      return schema;
    })
    .catch((err) => {
      console.warn("[cmsClient] Failed to fetch latest CMS data:", err);
      return cachedData; // Fallback to last known good cache if available
    })
    .finally(() => {
      inflightPromise = null;
    });

  return inflightPromise;
}

/**
 * Backwards-compatible alias for existing components.
 */
export async function fetchCmsContentOnce(options?: { forceFresh?: boolean }): Promise<CmsDatabaseSchema | null> {
  return fetchCmsContent(options);
}

/**
 * Subscribes to live CMS update events.
 * Returns an unsubscribe cleanup function.
 */
export function onCmsUpdate(callback: (data: CmsDatabaseSchema) => void): () => void {
  if (typeof window === "undefined") return () => {};
  const handler = (e: Event) => {
    const detail = (e as CustomEvent<CmsDatabaseSchema>).detail;
    if (detail) callback(detail);
  };
  window.addEventListener("cms:updated", handler);
  return () => window.removeEventListener("cms:updated", handler);
}

// Set up reactive background refresh on tab focus / window visibility in browser
if (typeof window !== "undefined") {
  const onFocusOrVisible = () => {
    if (document.visibilityState === "visible") {
      const now = Date.now();
      if (now - cacheTimestamp > CACHE_TTL_MS) {
        fetchCmsContent({ forceFresh: true }).then((data) => {
          if (data) {
            window.dispatchEvent(new CustomEvent("cms:updated", { detail: data }));
          }
        });
      }
    }
  };

  window.addEventListener("focus", onFocusOrVisible);
  document.addEventListener("visibilitychange", onFocusOrVisible);
}
