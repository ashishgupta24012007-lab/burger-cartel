import dns from "node:dns";
import { neon } from "@neondatabase/serverless";
import type { NeonQueryFunction } from "@neondatabase/serverless";

if (typeof dns?.setDefaultResultOrder === "function") {
  try {
    dns.setDefaultResultOrder("ipv4first");
  } catch {
    // Ignore in non-Node environments
  }
}

let cachedSql: NeonQueryFunction<false, false> | null = null;

export function isPostgresConfigured(): boolean {
  return Boolean(process.env.DATABASE_URL && process.env.DATABASE_URL.startsWith("postgres"));
}

export function getDb(): NeonQueryFunction<false, false> | null {
  if (!isPostgresConfigured()) {
    return null;
  }

  if (!cachedSql) {
    cachedSql = neon(process.env.DATABASE_URL!);
  }

  return cachedSql;
}
