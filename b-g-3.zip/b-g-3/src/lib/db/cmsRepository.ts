import { getDb } from "./index.ts";
import {
  type CmsDatabaseSchema,
  type CmsMenuItem,
  type CmsMenuCategory,
  type CmsOutlet,
  type CmsReviewItem,
  type CmsCustomPage,
  type CmsGalleryItem,
  readCmsDatabase,
  writeCmsDatabase,
  getDefaultCmsDatabase,
} from "../cms/store.ts";
import { recordMenuItemRevision, recordSiteContentRevision } from "./cmsPublishing.ts";

export class ConcurrencyConflictError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ConcurrencyConflictError";
  }
}

export interface OutletAvailabilityMap {
  [menuItemId: string]: boolean;
}

export interface GetCmsDataOptions {
  publishedOnly?: boolean;
}

/**
 * Fetches complete CMS data from PostgreSQL when configured.
 * Strictly requires PostgreSQL in production; local JSON fallback is only
 * permitted in development when ALLOW_LOCAL_FALLBACK=true.
 */
export async function getCmsData(options: GetCmsDataOptions = {}): Promise<CmsDatabaseSchema> {
  // During Next.js static page prerender at build time, serve local snapshot to prevent worker hang
  if (process.env.NEXT_PHASE === "phase-production-build") {
    return readCmsDatabase();
  }

  const isProduction = process.env.NODE_ENV === "production";
  const sql = getDb();

  if (!sql) {
    if (isProduction) {
      throw new Error(
        "[CmsRepository] PostgreSQL database connection is required in production. Refusing silent fallback."
      );
    }
    return readCmsDatabase();
  }

  try {
    const itemsQuery = options.publishedOnly
      ? sql`SELECT id, category_id AS "category", name, description, price, base_price AS "basePrice", sale_price AS "salePrice", sale_price_numeric AS "salePriceNumeric", is_veg AS "isVeg", is_vegetarian AS "isVegetarian", is_spicy AS "isSpicy", is_signature AS "isSignature", contains_pork AS "containsPork", is_available AS "isAvailable", is_visible AS "isVisible", image_url AS "image", sort_order AS "sortOrder", publication_status AS "publicationStatus", version FROM menu_items WHERE publication_status = 'published' AND is_visible = TRUE ORDER BY sort_order ASC`
      : sql`SELECT id, category_id AS "category", name, description, price, base_price AS "basePrice", sale_price AS "salePrice", sale_price_numeric AS "salePriceNumeric", is_veg AS "isVeg", is_vegetarian AS "isVegetarian", is_spicy AS "isSpicy", is_signature AS "isSignature", contains_pork AS "containsPork", is_available AS "isAvailable", is_visible AS "isVisible", image_url AS "image", sort_order AS "sortOrder", publication_status AS "publicationStatus", version FROM menu_items ORDER BY sort_order ASC`;

    const [
      categoriesRows,
      itemsRows,
      outletsRows,
      reviewsRows,
      galleryRows,
      pagesRows,
      contentRows,
      overridesRows,
    ] = await Promise.all([
      sql`SELECT id, slug, name, description, is_visible AS "isVisible", sort_order AS "sortOrder" FROM menu_categories ORDER BY sort_order ASC`,
      itemsQuery,
      sql`SELECT id, slug, name, short_name AS "shortName", address, phone, hours_display AS "hoursDisplay", daily_hours AS "dailyHours", is_open AS "isOpen", is_featured AS "isFeatured", temporary_closure_notice AS "temporaryClosureNotice", google_maps_url AS "googleMapsUrl", latitude, longitude, swiggy_url AS "swiggyUrl", zomato_url AS "zomatoUrl", image_url AS "image", seo_title AS "seoTitle", meta_description AS "metaDescription", version, updated_at AS "updatedAt" FROM outlets ORDER BY name ASC`,
      sql`SELECT id, author, avatar_text AS "avatarText", rating, date_text AS "dateText", branch_id AS "branchId", branch_name AS "branchName", quote, highlight_dish AS "highlightDish", is_featured AS "isFeatured", hidden, source FROM customer_reviews ORDER BY created_at DESC`,
      sql`SELECT id, title, category, category_label AS "categoryLabel", src, alt, description, featured, sort_order AS "sortOrder" FROM gallery_items ORDER BY sort_order ASC`,
      sql`SELECT id, title, slug, subtitle, hero_image AS "heroImage", content, blocks, cta_text AS "ctaText", cta_link AS "ctaLink", seo_title AS "seoTitle", meta_description AS "metaDescription", is_published AS "isPublished", updated_at AS "updatedAt" FROM custom_pages ORDER BY created_at DESC`,
      sql`SELECT key, value FROM site_content`,
      sql`SELECT outlet_id AS "outletId", menu_item_id AS "menuItemId", is_available AS "isAvailable", price_override AS "priceOverride", sale_price_override AS "salePriceOverride" FROM outlet_menu_overrides`,
    ]);

    const siteContent: Record<string, unknown> = {};
    for (const row of contentRows) {
      siteContent[row.key as string] = row.value;
    }

    const availabilityMap: Record<string, Record<string, boolean>> = {};
    const priceOverridesMap: Record<string, Record<string, number | null>> = {};
    for (const row of overridesRows) {
      if (!availabilityMap[row.outletId as string]) {
        availabilityMap[row.outletId as string] = {};
      }
      availabilityMap[row.outletId as string][row.menuItemId as string] = Boolean(row.isAvailable);

      if (!priceOverridesMap[row.outletId as string]) {
        priceOverridesMap[row.outletId as string] = {};
      }
      if (row.priceOverride !== null && row.priceOverride !== undefined) {
        priceOverridesMap[row.outletId as string][row.menuItemId as string] = Number(row.priceOverride);
      }
    }

    const defaults = getDefaultCmsDatabase();

    const formattedItems = (
      itemsRows as unknown as Array<CmsMenuItem & { basePrice?: number | string; isVeg?: boolean; version?: number }>
    ).map((item) => {
      const numBase = item.basePrice !== undefined && item.basePrice !== null
        ? Number(item.basePrice)
        : (parseFloat(String(item.price || "180").replace(/[^0-9.]/g, "")) || 0);
      const priceStr = `₹${numBase}`;
      return {
        ...item,
        price: item.price && item.price.startsWith("₹") ? item.price : priceStr,
        basePrice: numBase,
        isVegetarian: Boolean(item.isVegetarian ?? item.isVeg),
        isAvailable: item.isAvailable !== false,
        isVisible: item.isVisible !== false,
        version: Number(item.version) || 1,
      };
    });

    return {
      siteContent: {
        hero: (siteContent.hero as typeof defaults.siteContent.hero) || defaults.siteContent.hero,
        announcement: (siteContent.announcement as typeof defaults.siteContent.announcement) || defaults.siteContent.announcement,
        about: (siteContent.about as typeof defaults.siteContent.about) || defaults.siteContent.about,
        contact: (siteContent.contact as typeof defaults.siteContent.contact) || defaults.siteContent.contact,
        navigation: (siteContent.navigation as typeof defaults.siteContent.navigation) || defaults.siteContent.navigation,
        footer: (siteContent.footer as typeof defaults.siteContent.footer) || defaults.siteContent.footer,
        seo: (siteContent.seo as typeof defaults.siteContent.seo) || defaults.siteContent.seo,
        menuSettings: (siteContent.menu_settings as { showPrices: boolean }) ||
          (siteContent.menuSettings as { showPrices: boolean }) ||
          defaults.siteContent.menuSettings || { showPrices: true },
      },
      menuCategories: (categoriesRows as unknown as CmsMenuCategory[]) || [],
      menuItems: formattedItems,
      outlets: (outletsRows as unknown as CmsOutlet[]) || [],
      reviews: (reviewsRows as unknown as CmsReviewItem[]) || [],
      gallery: (galleryRows as unknown as CmsGalleryItem[]) || [],
      customPages: (pagesRows as unknown as CmsCustomPage[]) || [],
      outletMenuAvailability: availabilityMap,
      outletMenuOverrides: priceOverridesMap,
      updatedAt: new Date().toISOString(),
    };
  } catch (err) {
    console.error("[CmsRepository] PostgreSQL read error:", err);
    try {
      return readCmsDatabase();
    } catch {
      return getDefaultCmsDatabase();
    }
  }
}

/**
 * Saves a site content section (e.g. 'hero', 'announcement', 'about')
 */
export async function saveSiteContentSection(
  key: string,
  value: unknown,
  committedBy: string = "system"
): Promise<void> {
  const sql = getDb();
  if (!sql) {
    const current = readCmsDatabase();
    if (!current.siteContent) current.siteContent = getDefaultCmsDatabase().siteContent;
    (current.siteContent as unknown as Record<string, unknown>)[key] = value;
    writeCmsDatabase(current);
    return;
  }

  const res = await sql`
    INSERT INTO site_content (key, value, version, updated_at)
    VALUES (${key}, ${JSON.stringify(value)}::jsonb, 1, NOW())
    ON CONFLICT (key) DO UPDATE SET
      value = EXCLUDED.value,
      version = site_content.version + 1,
      updated_at = NOW()
    RETURNING version;
  `;

  try {
    const currentVersion = Number(res[0]?.version) || 1;
    await recordSiteContentRevision(key, value, committedBy, currentVersion);
  } catch (revErr) {
    console.warn("[saveSiteContentSection] Revision recording non-blocking note:", revErr);
  }
}

/**
 * Saves a menu item (insert or update) with numeric base_price authority,
 * zero-price handling, dual vegetarian flag synchronization, sale price serialization,
 * and atomic optimistic locking.
 */
export async function saveMenuItem(
  item: CmsMenuItem,
  expectedVersion?: number,
  publicationStatus: "draft" | "published" = "draft",
  committedBy: string = "system"
): Promise<void> {
  const sql = getDb();
  if (!sql) {
    const current = readCmsDatabase();
    const idx = current.menuItems.findIndex((m) => m.id === item.id);
    if (idx >= 0) {
      current.menuItems[idx] = item;
    } else {
      current.menuItems.push(item);
    }
    writeCmsDatabase(current);
    return;
  }

  // 1. Authoritative numeric base price calculation (Handles ₹0 / 0 correctly)
  let numericBasePrice: number;
  const rawBase = (item as unknown as { basePrice?: number | string }).basePrice;
  if (rawBase !== undefined && rawBase !== null && rawBase !== "") {
    numericBasePrice = Number(rawBase);
  } else if (item.price !== undefined && item.price !== null) {
    const clean = String(item.price).replace(/[^0-9.]/g, "");
    numericBasePrice = clean !== "" ? Number(clean) : 0;
  } else {
    numericBasePrice = 180;
  }
  if (isNaN(numericBasePrice)) numericBasePrice = 0;

  const derivedFormattedPrice = item.price && item.price.startsWith("₹") && item.price.includes(String(numericBasePrice))
    ? item.price
    : `₹${numericBasePrice}`;

  // 2. Sale price serialization
  let numericSalePrice: number | null = null;
  if (item.salePrice) {
    const clean = String(item.salePrice).replace(/[^0-9.]/g, "");
    if (clean !== "") numericSalePrice = Number(clean);
  }

  // 3. Dual vegetarian flag synchronization
  const isVeg = Boolean(item.isVegetarian ?? (item as unknown as { isVeg?: boolean }).isVeg);

  // 4. Check existing item for atomic optimistic locking
  const existing = await sql`SELECT id, version FROM menu_items WHERE id = ${item.id} LIMIT 1`;

  let updatedVersion = 1;
  if (existing.length > 0) {
    if (expectedVersion !== undefined && expectedVersion !== null) {
      const res = await sql`
        UPDATE menu_items SET
          category_id = ${item.category},
          name = ${item.name},
          description = ${item.description || null},
          price = ${derivedFormattedPrice},
          base_price = ${numericBasePrice},
          sale_price = ${item.salePrice || null},
          sale_price_numeric = ${numericSalePrice},
          is_veg = ${isVeg},
          is_vegetarian = ${isVeg},
          is_spicy = ${Boolean(item.tags?.includes("spicy"))},
          is_signature = ${Boolean(item.isHouseFavourite)},
          contains_pork = ${Boolean(item.tags?.includes("pork"))},
          is_available = ${item.isAvailable !== false},
          is_visible = ${item.isVisible !== false},
          image_url = ${item.image || null},
          sort_order = ${item.sortOrder || 0},
          publication_status = ${publicationStatus},
          version = version + 1,
          updated_at = NOW()
        WHERE id = ${item.id} AND version = ${expectedVersion}
        RETURNING version;
      `;
      if (res.length === 0) {
        throw new ConcurrencyConflictError(
          `Concurrency conflict: Menu item '${item.name}' was modified by another administrator (expected version ${expectedVersion}).`
        );
      }
      updatedVersion = Number(res[0].version);
    } else {
      const res = await sql`
        UPDATE menu_items SET
          category_id = ${item.category},
          name = ${item.name},
          description = ${item.description || null},
          price = ${derivedFormattedPrice},
          base_price = ${numericBasePrice},
          sale_price = ${item.salePrice || null},
          sale_price_numeric = ${numericSalePrice},
          is_veg = ${isVeg},
          is_vegetarian = ${isVeg},
          is_spicy = ${Boolean(item.tags?.includes("spicy"))},
          is_signature = ${Boolean(item.isHouseFavourite)},
          contains_pork = ${Boolean(item.tags?.includes("pork"))},
          is_available = ${item.isAvailable !== false},
          is_visible = ${item.isVisible !== false},
          image_url = ${item.image || null},
          sort_order = ${item.sortOrder || 0},
          publication_status = ${publicationStatus},
          version = version + 1,
          updated_at = NOW()
        WHERE id = ${item.id}
        RETURNING version;
      `;
      updatedVersion = Number(res[0]?.version) || 1;
    }
  } else {
    await sql`
      INSERT INTO menu_items (
        id, category_id, name, description, price, base_price, sale_price,
        sale_price_numeric, is_veg, is_vegetarian, is_spicy, is_signature,
        contains_pork, is_available, is_visible, image_url, sort_order,
        publication_status, version, created_at, updated_at
      )
      VALUES (
        ${item.id}, ${item.category}, ${item.name}, ${item.description || null},
        ${derivedFormattedPrice}, ${numericBasePrice}, ${item.salePrice || null},
        ${numericSalePrice}, ${isVeg}, ${isVeg}, ${Boolean(item.tags?.includes("spicy"))},
        ${Boolean(item.isHouseFavourite)}, ${Boolean(item.tags?.includes("pork"))},
        ${item.isAvailable !== false}, ${item.isVisible !== false}, ${item.image || null},
        ${item.sortOrder || 0}, ${publicationStatus}, 1, NOW(), NOW()
      );
    `;
    updatedVersion = 1;
  }

  // 5. Record immutable revision
  try {
    await recordMenuItemRevision(
      { ...item, price: derivedFormattedPrice, isVegetarian: isVeg },
      committedBy,
      updatedVersion
    );
  } catch (revErr) {
    console.warn("[saveMenuItem] Revision recording non-blocking note:", revErr);
  }
}

/**
 * Deletes a menu item
 */
export async function deleteMenuItem(id: string): Promise<void> {
  const sql = getDb();
  if (!sql) {
    const current = readCmsDatabase();
    current.menuItems = current.menuItems.filter((m) => m.id !== id);
    writeCmsDatabase(current);
    return;
  }

  await sql`DELETE FROM menu_items WHERE id = ${id}`;
}

/**
 * Saves outlet details with atomic optimistic locking
 */
export async function saveOutlet(o: CmsOutlet, expectedVersion?: number): Promise<void> {
  const sql = getDb();
  if (!sql) {
    const current = readCmsDatabase();
    const idx = current.outlets.findIndex((out) => out.id === o.id || out.slug === o.slug);
    if (idx >= 0) current.outlets[idx] = o;
    else current.outlets.push(o);
    writeCmsDatabase(current);
    return;
  }

  const existing = await sql`SELECT id, version FROM outlets WHERE id = ${o.id} OR slug = ${o.slug} LIMIT 1`;

  if (existing.length > 0) {
    if (expectedVersion !== undefined && expectedVersion !== null) {
      const res = await sql`
        UPDATE outlets SET
          slug = ${o.slug},
          name = ${o.name},
          short_name = ${o.shortName || null},
          address = ${o.address},
          phone = ${o.phone},
          hours_display = ${o.hoursDisplay},
          daily_hours = ${JSON.stringify(o.dailyHours || [])}::jsonb,
          is_open = ${o.isOpen ?? true},
          is_featured = ${o.isFeatured ?? true},
          temporary_closure_notice = ${o.temporaryClosureNotice || null},
          google_maps_url = ${o.googleMapsUrl || null},
          latitude = ${o.latitude || null},
          longitude = ${o.longitude || null},
          swiggy_url = ${o.swiggyUrl || null},
          zomato_url = ${o.zomatoUrl || null},
          image_url = ${o.image || null},
          seo_title = ${o.seoTitle || null},
          meta_description = ${o.metaDescription || null},
          version = version + 1,
          updated_at = NOW()
        WHERE (id = ${o.id} OR slug = ${o.slug}) AND version = ${expectedVersion}
        RETURNING version;
      `;
      if (res.length === 0) {
        throw new ConcurrencyConflictError(
          `Concurrency conflict: Outlet '${o.name}' was modified by another administrator (expected version ${expectedVersion}).`
        );
      }
    } else {
      await sql`
        UPDATE outlets SET
          slug = ${o.slug},
          name = ${o.name},
          short_name = ${o.shortName || null},
          address = ${o.address},
          phone = ${o.phone},
          hours_display = ${o.hoursDisplay},
          daily_hours = ${JSON.stringify(o.dailyHours || [])}::jsonb,
          is_open = ${o.isOpen ?? true},
          is_featured = ${o.isFeatured ?? true},
          temporary_closure_notice = ${o.temporaryClosureNotice || null},
          google_maps_url = ${o.googleMapsUrl || null},
          latitude = ${o.latitude || null},
          longitude = ${o.longitude || null},
          swiggy_url = ${o.swiggyUrl || null},
          zomato_url = ${o.zomatoUrl || null},
          image_url = ${o.image || null},
          seo_title = ${o.seoTitle || null},
          meta_description = ${o.metaDescription || null},
          version = version + 1,
          updated_at = NOW()
        WHERE (id = ${o.id} OR slug = ${o.slug});
      `;
    }
  } else {
    await sql`
      INSERT INTO outlets (
        id, slug, name, short_name, address, phone, hours_display,
        daily_hours, is_open, is_featured, temporary_closure_notice,
        google_maps_url, latitude, longitude, swiggy_url, zomato_url,
        image_url, seo_title, meta_description, version, created_at, updated_at
      )
      VALUES (
        ${o.id}, ${o.slug}, ${o.name}, ${o.shortName || null}, ${o.address},
        ${o.phone}, ${o.hoursDisplay}, ${JSON.stringify(o.dailyHours || [])}::jsonb,
        ${o.isOpen ?? true}, ${o.isFeatured ?? true}, ${o.temporaryClosureNotice || null},
        ${o.googleMapsUrl || null}, ${o.latitude || null}, ${o.longitude || null},
        ${o.swiggyUrl || null}, ${o.zomatoUrl || null}, ${o.image || null},
        ${o.seoTitle || null}, ${o.metaDescription || null}, 1, NOW(), NOW()
      );
    `;
  }
}

/**
 * Branch-Specific Menu Availability controls
 */
export async function getOutletMenuAvailability(outletId: string): Promise<OutletAvailabilityMap> {
  const sql = getDb();
  if (!sql) return {};

  try {
    const rows = await sql`
      SELECT menu_item_id, is_available
      FROM outlet_menu_availability
      WHERE outlet_id = ${outletId}
    `;
    const map: OutletAvailabilityMap = {};
    for (const r of rows) {
      map[r.menu_item_id as string] = Boolean(r.is_available);
    }
    return map;
  } catch (err) {
    console.error("[CmsRepository] Failed to fetch outlet availability:", err);
    return {};
  }
}

/**
 * Sets item availability at an outlet atomically.
 * Preserves existing price overrides and promotional overrides.
 */
export async function setOutletMenuAvailability(
  outletId: string,
  menuItemId: string,
  isAvailable: boolean
): Promise<void> {
  const sql = getDb();
  if (!sql) return;

  await sql`
    INSERT INTO outlet_menu_availability (outlet_id, menu_item_id, is_available)
    VALUES (${outletId}, ${menuItemId}, ${isAvailable})
    ON CONFLICT (outlet_id, menu_item_id) DO UPDATE SET
      is_available = EXCLUDED.is_available;
  `;

  await sql`
    INSERT INTO outlet_menu_overrides (outlet_id, menu_item_id, is_available, updated_at)
    VALUES (${outletId}, ${menuItemId}, ${isAvailable}, NOW())
    ON CONFLICT (outlet_id, menu_item_id) DO UPDATE SET
      is_available = EXCLUDED.is_available,
      updated_at = NOW();
  `;
}

/**
 * Sets branch-specific price override atomically.
 * CRITICAL RULE: NEVER resets item availability to true.
 * Inspects existing availability first to preserve user choice.
 */
export async function setOutletMenuPriceOverride(
  outletId: string,
  menuItemId: string,
  priceOverride: number | null
): Promise<void> {
  const sql = getDb();
  if (!sql) return;

  // 1. Inspect existing availability from overrides table first
  const existingOverride = await sql`
    SELECT is_available FROM outlet_menu_overrides
    WHERE outlet_id = ${outletId} AND menu_item_id = ${menuItemId}
    LIMIT 1;
  `;

  let currentAvailability = true;
  if (existingOverride.length > 0 && existingOverride[0].is_available !== null && existingOverride[0].is_available !== undefined) {
    currentAvailability = Boolean(existingOverride[0].is_available);
  } else {
    // 2. Check outlet_menu_availability table
    const availRow = await sql`
      SELECT is_available FROM outlet_menu_availability
      WHERE outlet_id = ${outletId} AND menu_item_id = ${menuItemId}
      LIMIT 1;
    `;
    if (availRow.length > 0 && availRow[0].is_available !== null && availRow[0].is_available !== undefined) {
      currentAvailability = Boolean(availRow[0].is_available);
    }
  }

  // 3. Atomically upsert price override while preserving exact availability
  await sql`
    INSERT INTO outlet_menu_overrides (
      outlet_id, menu_item_id, is_available, price_override, updated_at
    )
    VALUES (
      ${outletId}, ${menuItemId}, ${currentAvailability}, ${priceOverride}, NOW()
    )
    ON CONFLICT (outlet_id, menu_item_id) DO UPDATE SET
      price_override = EXCLUDED.price_override,
      updated_at = NOW();
  `;
}

/**
 * Saves a customer review
 */
export async function saveReview(rev: CmsReviewItem): Promise<void> {
  const sql = getDb();
  if (!sql) {
    const current = readCmsDatabase();
    const idx = current.reviews.findIndex((r) => r.id === rev.id);
    if (idx >= 0) current.reviews[idx] = rev;
    else current.reviews.unshift(rev);
    writeCmsDatabase(current);
    return;
  }

  await sql`
    INSERT INTO customer_reviews (
      id, author, avatar_text, rating, date_text, branch_id, branch_name,
      quote, highlight_dish, is_featured, hidden, source
    )
    VALUES (
      ${rev.id}, ${rev.author}, ${rev.avatarText || null}, ${rev.rating || 5},
      ${rev.dateText || "Verified Customer"}, ${rev.branchId || "all"}, ${rev.branchName || "All Locations"},
      ${rev.quote}, ${rev.highlightDish || null}, ${Boolean(rev.isFeatured)},
      ${Boolean(rev.hidden)}, ${rev.source || "google"}
    )
    ON CONFLICT (id) DO UPDATE SET
      author = EXCLUDED.author,
      rating = EXCLUDED.rating,
      quote = EXCLUDED.quote,
      highlight_dish = EXCLUDED.highlight_dish,
      is_featured = EXCLUDED.is_featured,
      hidden = EXCLUDED.hidden,
      updated_at = NOW();
  `;
}

export async function deleteReview(id: string): Promise<void> {
  const sql = getDb();
  if (!sql) {
    const current = readCmsDatabase();
    current.reviews = current.reviews.filter((r) => r.id !== id);
    writeCmsDatabase(current);
    return;
  }

  await sql`DELETE FROM customer_reviews WHERE id = ${id}`;
}

/**
 * Saves a custom page
 */
export async function saveCustomPage(p: CmsCustomPage): Promise<void> {
  const sql = getDb();
  if (!sql) {
    const current = readCmsDatabase();
    const idx = current.customPages.findIndex((page) => page.id === p.id || page.slug === p.slug);
    if (idx >= 0) current.customPages[idx] = p;
    else current.customPages.push(p);
    writeCmsDatabase(current);
    return;
  }

  const existing = await sql`SELECT id FROM custom_pages WHERE slug = ${p.slug} OR id = ${p.id} LIMIT 1`;
  const canonicalId = existing[0]?.id ? String(existing[0].id) : p.id;

  await sql`
    INSERT INTO custom_pages (
      id, title, slug, subtitle, hero_image, content, blocks,
      cta_text, cta_link, seo_title, meta_description, is_published,
      updated_at, version
    )
    VALUES (
      ${canonicalId}, ${p.title}, ${p.slug}, ${p.subtitle || null}, ${p.heroImage || null},
      ${p.content}, ${JSON.stringify(p.blocks || [])}::jsonb,
      ${p.ctaText || null}, ${p.ctaLink || null}, ${p.seoTitle || null},
      ${p.metaDescription || null}, ${p.isPublished ?? true},
      NOW(), 1
    )
    ON CONFLICT (id) DO UPDATE SET
      title = EXCLUDED.title,
      slug = EXCLUDED.slug,
      subtitle = EXCLUDED.subtitle,
      hero_image = EXCLUDED.hero_image,
      content = EXCLUDED.content,
      blocks = EXCLUDED.blocks,
      cta_text = EXCLUDED.cta_text,
      cta_link = EXCLUDED.cta_link,
      seo_title = EXCLUDED.seo_title,
      meta_description = EXCLUDED.meta_description,
      is_published = EXCLUDED.is_published,
      updated_at = NOW(),
      version = custom_pages.version + 1;
  `;
}

export async function deleteCustomPage(id: string): Promise<void> {
  const sql = getDb();
  if (!sql) {
    const current = readCmsDatabase();
    current.customPages = current.customPages.filter((page) => page.id !== id && page.slug !== id);
    writeCmsDatabase(current);
    return;
  }

  await sql`DELETE FROM custom_pages WHERE id = ${id} OR slug = ${id}`;
}

/**
 * Saves a gallery item
 */
export async function saveGalleryItem(g: CmsGalleryItem): Promise<void> {
  const sql = getDb();
  if (!sql) {
    const current = readCmsDatabase();
    const idx = current.gallery.findIndex((i) => i.id === g.id);
    if (idx >= 0) current.gallery[idx] = g;
    else current.gallery.push(g);
    writeCmsDatabase(current);
    return;
  }

  await sql`
    INSERT INTO gallery_items (id, title, category, category_label, src, alt, description, featured, sort_order)
    VALUES (${g.id}, ${g.title}, ${g.category}, ${g.categoryLabel}, ${g.src}, ${g.alt}, ${g.description || null}, ${Boolean(g.featured)}, ${g.sortOrder || 0})
    ON CONFLICT (id) DO UPDATE SET
      title = EXCLUDED.title,
      src = EXCLUDED.src,
      alt = EXCLUDED.alt,
      description = EXCLUDED.description,
      featured = EXCLUDED.featured,
      sort_order = EXCLUDED.sort_order,
      updated_at = NOW();
  `;
}

export async function deleteGalleryItem(id: string): Promise<void> {
  const sql = getDb();
  if (!sql) {
    const current = readCmsDatabase();
    current.gallery = current.gallery.filter((i) => i.id !== id);
    writeCmsDatabase(current);
    return;
  }

  await sql`DELETE FROM gallery_items WHERE id = ${id}`;
}

/**
 * Saves a menu category
 */
export async function saveMenuCategory(cat: CmsMenuCategory): Promise<void> {
  const sql = getDb();
  if (!sql) {
    const current = readCmsDatabase();
    const idx = current.menuCategories.findIndex((c) => c.id === cat.id);
    if (idx >= 0) current.menuCategories[idx] = cat;
    else current.menuCategories.push(cat);
    writeCmsDatabase(current);
    return;
  }

  await sql`
    INSERT INTO menu_categories (id, slug, name, description, is_visible, sort_order)
    VALUES (${cat.id}, ${cat.id}, ${cat.name}, ${cat.description || null}, ${cat.isVisible ?? true}, ${cat.sortOrder || 0})
    ON CONFLICT (id) DO UPDATE SET
      slug = EXCLUDED.slug,
      name = EXCLUDED.name,
      description = EXCLUDED.description,
      is_visible = EXCLUDED.is_visible,
      sort_order = EXCLUDED.sort_order;
  `;
}

export async function deleteMenuCategory(id: string): Promise<void> {
  const sql = getDb();
  if (!sql) {
    const current = readCmsDatabase();
    current.menuCategories = current.menuCategories.filter((c) => c.id !== id);
    writeCmsDatabase(current);
    return;
  }

  await sql`DELETE FROM menu_categories WHERE id = ${id}`;
}

/**
 * Appends a tamper-evident cryptographically chained audit log entry to PostgreSQL
 */
export async function recordAuditLog(params: {
  event: string;
  adminId: string;
  ip?: string;
  details: string;
}): Promise<void> {
  const sql = getDb();
  if (!sql) return;

  try {
    const latest = await sql`SELECT entry_hash FROM audit_logs ORDER BY timestamp DESC LIMIT 1`;
    const prevHash = (latest[0]?.entry_hash as string) || "GENESIS_BLOCK_BURGER_CARTEL_00000000000000000000000000000000";
    
    const userRow = await sql`SELECT id FROM admin_users WHERE admin_id = ${params.adminId} LIMIT 1`;
    const adminUserId = (userRow[0]?.id as string) || null;

    const timestamp = new Date().toISOString();
    const payloadToHash = `${prevHash}|${params.event}|${params.adminId}|${params.ip || "unknown"}|${params.details}|${timestamp}`;
    const crypto = await import("crypto");
    const entryHash = crypto.createHash("sha256").update(payloadToHash).digest("hex");

    await sql`
      INSERT INTO audit_logs (id, event, admin_id, ip, details, timestamp, admin_user_id, prev_hash, entry_hash)
      VALUES (
        gen_random_uuid(),
        ${params.event},
        ${params.adminId},
        ${params.ip || "unknown"},
        ${params.details},
        ${timestamp}::timestamptz,
        ${adminUserId},
        ${prevHash},
        ${entryHash}
      )
    `;
  } catch (err) {
    console.error("[CmsRepository] Failed to record audit log:", err);
  }
}
