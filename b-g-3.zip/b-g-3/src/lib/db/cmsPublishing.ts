import crypto from "crypto";
import { getDb } from "./index.ts";
import type { CmsMenuItem } from "../cms/store.ts";

export interface ReleaseManifest {
  menuItems: Array<{
    id: string;
    revisionId: string;
    version: number;
    name: string;
  }>;
  siteContent: Array<{
    key: string;
    revisionId: string;
    version: number;
  }>;
}

export interface CmsReleaseRecord {
  id: string;
  releaseNumber: number;
  label: string;
  description: string;
  publishedBy: string;
  publishedAt: string;
  snapshotManifest: ReleaseManifest;
  isActive: boolean;
}

/**
 * Creates an immutable revision record for a menu item
 */
export async function recordMenuItemRevision(
  item: CmsMenuItem,
  committedBy: string,
  version?: number
): Promise<string> {
  const sql = getDb();
  if (!sql) return "";

  const latest = await sql`
    SELECT version FROM menu_item_revisions WHERE item_id = ${item.id} ORDER BY version DESC LIMIT 1
  `;
  const resolvedVersion = version && version > (Number(latest[0]?.version) || 0)
    ? version
    : (Number(latest[0]?.version) || 0) + 1;

  const revisionId = crypto.randomUUID();
  const numericBasePrice = (item as unknown as { basePrice?: number }).basePrice !== undefined &&
    (item as unknown as { basePrice?: number }).basePrice !== null
      ? Number((item as unknown as { basePrice?: number }).basePrice)
      : (parseFloat(String(item.price || "180").replace(/[^0-9.]/g, "")) || 0);

  await sql`
    INSERT INTO menu_item_revisions (
      revision_id, item_id, version, name, category_id, price, base_price,
      description, image_url, is_veg, is_popular, is_active, snapshot,
      committed_by, committed_at
    )
    VALUES (
      ${revisionId},
      ${item.id},
      ${resolvedVersion},
      ${item.name},
      ${item.category},
      ${item.price || `₹${numericBasePrice}`},
      ${numericBasePrice},
      ${item.description || null},
      ${item.image || null},
      ${Boolean(item.isVegetarian)},
      ${Boolean(item.isHouseFavourite)},
      ${item.isAvailable !== false},
      ${JSON.stringify(item)}::jsonb,
      ${committedBy},
      NOW()
    );
  `;

  return revisionId;
}

/**
 * Creates an immutable revision record for a site content section
 */
export async function recordSiteContentRevision(
  key: string,
  value: unknown,
  committedBy: string,
  version: number
): Promise<string> {
  const sql = getDb();
  if (!sql) return "";

  const revisionId = crypto.randomUUID();

  await sql`
    INSERT INTO site_content_revisions (
      revision_id, key, version, content_json, committed_by, committed_at
    )
    VALUES (
      ${revisionId},
      ${key},
      ${version},
      ${JSON.stringify(value)}::jsonb,
      ${committedBy},
      NOW()
    );
  `;

  return revisionId;
}

/**
 * Generates and publishes an explicit release containing approved revisions.
 * Atomically marks items published and updates the active release manifest.
 */
export async function publishReleaseManifest(params: {
  label: string;
  description?: string;
  publishedBy: string;
  approvedItemIds?: string[]; // If omitted or '*', publishes all approved/ready items
  approvedContentKeys?: string[];
}): Promise<CmsReleaseRecord> {
  const sql = getDb();
  if (!sql) {
    throw new Error("[Publishing] PostgreSQL connection required for releases.");
  }

  // 1. Determine next release number
  const latestRelease = await sql`
    SELECT release_number FROM cms_releases ORDER BY release_number DESC LIMIT 1
  `;
  const nextReleaseNumber = (Number(latestRelease[0]?.release_number) || 0) + 1;
  const releaseId = crypto.randomUUID();

  // 2. Fetch latest revisions for the approved menu items
  let itemRevisionsQuery;
  if (params.approvedItemIds && params.approvedItemIds.length > 0 && !params.approvedItemIds.includes("*")) {
    itemRevisionsQuery = sql`
      SELECT DISTINCT ON (item_id)
        revision_id, item_id, version, name
      FROM menu_item_revisions
      WHERE item_id = ANY(${params.approvedItemIds})
      ORDER BY item_id, version DESC, committed_at DESC
    `;
  } else {
    itemRevisionsQuery = sql`
      SELECT DISTINCT ON (item_id)
        revision_id, item_id, version, name
      FROM menu_item_revisions
      ORDER BY item_id, version DESC, committed_at DESC
    `;
  }
  const itemRevisions = await itemRevisionsQuery;

  // 3. Fetch latest revisions for site content
  let contentRevisionsQuery;
  if (params.approvedContentKeys && params.approvedContentKeys.length > 0 && !params.approvedContentKeys.includes("*")) {
    contentRevisionsQuery = sql`
      SELECT DISTINCT ON (key)
        revision_id, key, version
      FROM site_content_revisions
      WHERE key = ANY(${params.approvedContentKeys})
      ORDER BY key, version DESC, committed_at DESC
    `;
  } else {
    contentRevisionsQuery = sql`
      SELECT DISTINCT ON (key)
        revision_id, key, version
      FROM site_content_revisions
      ORDER BY key, version DESC, committed_at DESC
    `;
  }
  const contentRevisions = await contentRevisionsQuery;

  const manifest: ReleaseManifest = {
    menuItems: itemRevisions.map((r) => ({
      id: r.item_id as string,
      revisionId: r.revision_id as string,
      version: Number(r.version) || 1,
      name: r.name as string,
    })),
    siteContent: contentRevisions.map((r) => ({
      key: r.key as string,
      revisionId: r.revision_id as string,
      version: Number(r.version) || 1,
    })),
  };

  // 4. Deactivate previous active releases
  await sql`UPDATE cms_releases SET is_active = FALSE WHERE is_active = TRUE`;

  // 5. Insert new release record
  await sql`
    INSERT INTO cms_releases (
      id, release_number, label, description, published_by, published_at,
      snapshot_manifest, is_active
    )
    VALUES (
      ${releaseId},
      ${nextReleaseNumber},
      ${params.label || `Release v${nextReleaseNumber}`},
      ${params.description || "Production Release Publication"},
      ${params.publishedBy},
      NOW(),
      ${JSON.stringify(manifest)}::jsonb,
      TRUE
    );
  `;

  // 6. Record release item mappings in cms_release_items
  for (const item of manifest.menuItems) {
    await sql`
      INSERT INTO cms_release_items (
        id, release_id, entity_type, entity_id, revision_id, version, created_at
      )
      VALUES (
        gen_random_uuid(),
        ${releaseId},
        'menu_item',
        ${item.id},
        ${item.revisionId},
        ${item.version},
        NOW()
      );
    `;
  }

  for (const sc of manifest.siteContent) {
    await sql`
      INSERT INTO cms_release_items (
        id, release_id, entity_type, entity_id, revision_id, version, created_at
      )
      VALUES (
        gen_random_uuid(),
        ${releaseId},
        'site_content',
        ${sc.key},
        ${sc.revisionId},
        ${sc.version},
        NOW()
      );
    `;
  }

  // 7. Update menu_items: mark included items as 'published' and active
  const itemIds = manifest.menuItems.map((m) => m.id);
  if (itemIds.length > 0) {
    await sql`
      UPDATE menu_items
      SET publication_status = 'published', is_active = TRUE, updated_at = NOW()
      WHERE id = ANY(${itemIds});
    `;
  }

  return {
    id: releaseId,
    releaseNumber: nextReleaseNumber,
    label: params.label || `Release v${nextReleaseNumber}`,
    description: params.description || "Production Release Publication",
    publishedBy: params.publishedBy,
    publishedAt: new Date().toISOString(),
    snapshotManifest: manifest,
    isActive: true,
  };
}

/**
 * Rolls back to an earlier release manifest atomically
 */
export async function rollbackRelease(
  targetReleaseId: string,
  rolledBackBy: string
): Promise<{ success: boolean; release: CmsReleaseRecord }> {
  const sql = getDb();
  if (!sql) throw new Error("Database connection required.");

  const rows = await sql`
    SELECT id, release_number, label, description, published_by, published_at, snapshot_manifest, is_active
    FROM cms_releases
    WHERE id = ${targetReleaseId}
    LIMIT 1
  `;

  if (rows.length === 0) {
    throw new Error(`Target release '${targetReleaseId}' not found.`);
  }

  const targetRelease = rows[0];
  const manifest = targetRelease.snapshot_manifest as ReleaseManifest;

  // 1. Deactivate current active releases
  await sql`UPDATE cms_releases SET is_active = FALSE WHERE is_active = TRUE`;

  // 2. Set target release as active
  await sql`
    UPDATE cms_releases
    SET is_active = TRUE, published_by = ${rolledBackBy}, published_at = NOW()
    WHERE id = ${targetReleaseId}
  `;

  // 3. Revert menu items from their revision snapshots in the manifest
  if (manifest.menuItems && manifest.menuItems.length > 0) {
    for (const itemRef of manifest.menuItems) {
      const revRows = await sql`
        SELECT snapshot FROM menu_item_revisions WHERE revision_id = ${itemRef.revisionId} LIMIT 1
      `;
      if (revRows.length > 0) {
        const snap = revRows[0].snapshot as CmsMenuItem;
        const numericBasePrice = (snap as unknown as { basePrice?: number }).basePrice !== undefined &&
          (snap as unknown as { basePrice?: number }).basePrice !== null
            ? Number((snap as unknown as { basePrice?: number }).basePrice)
            : (parseFloat(String(snap.price || "180").replace(/[^0-9.]/g, "")) || 0);

        await sql`
          UPDATE menu_items SET
            name = ${snap.name},
            category_id = ${snap.category},
            price = ${snap.price || `₹${numericBasePrice}`},
            base_price = ${numericBasePrice},
            description = ${snap.description || null},
            image_url = ${snap.image || null},
            is_veg = ${Boolean(snap.isVegetarian)},
            is_vegetarian = ${Boolean(snap.isVegetarian)},
            is_available = ${snap.isAvailable !== false},
            publication_status = 'published',
            updated_at = NOW()
          WHERE id = ${snap.id};
        `;
      }
    }
  }

  // 4. Revert site content from revision snapshots
  if (manifest.siteContent && manifest.siteContent.length > 0) {
    for (const scRef of manifest.siteContent) {
      const scRows = await sql`
        SELECT content_json FROM site_content_revisions WHERE revision_id = ${scRef.revisionId} LIMIT 1
      `;
      if (scRows.length > 0) {
        const contentVal = scRows[0].content_json;
        await sql`
          UPDATE site_content SET
            value = ${JSON.stringify(contentVal)}::jsonb,
            version = version + 1,
            updated_at = NOW()
          WHERE key = ${scRef.key};
        `;
      }
    }
  }

  return {
    success: true,
    release: {
      id: String(targetRelease.id),
      releaseNumber: Number(targetRelease.release_number),
      label: String(targetRelease.label),
      description: String(targetRelease.description),
      publishedBy: rolledBackBy,
      publishedAt: new Date().toISOString(),
      snapshotManifest: manifest,
      isActive: true,
    },
  };
}

/**
 * Lists all past releases with active status
 */
export async function listReleases(): Promise<Array<{
  id: string;
  releaseNumber: number;
  label: string;
  description: string;
  publishedBy: string;
  publishedAt: string;
  isActive: boolean;
  itemCount: number;
}>> {
  const sql = getDb();
  if (!sql) return [];

  const rows = await sql`
    SELECT
      r.id,
      r.release_number AS "releaseNumber",
      r.label,
      r.description,
      r.published_by AS "publishedBy",
      r.published_at AS "publishedAt",
      r.is_active AS "isActive",
      COUNT(i.id) AS "itemCount"
    FROM cms_releases r
    LEFT JOIN cms_release_items i ON r.id = i.release_id
    GROUP BY r.id, r.release_number, r.label, r.description, r.published_by, r.published_at, r.is_active
    ORDER BY r.release_number DESC;
  `;

  return rows.map((r) => ({
    id: String(r.id),
    releaseNumber: Number(r.releaseNumber),
    label: String(r.label),
    description: String(r.description || ""),
    publishedBy: String(r.publishedBy || ""),
    publishedAt: r.publishedAt ? new Date(r.publishedAt as string).toISOString() : "",
    isActive: Boolean(r.isActive),
    itemCount: Number(r.itemCount) || 0,
  }));
}
