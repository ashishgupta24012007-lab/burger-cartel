import { getDb } from "./index.ts";
import type { CmsDatabaseSchema } from "../cms/store.ts";

/**
 * Persists full CMS snapshot into PostgreSQL with conflict handling
 */
export async function syncCmsToPostgres(data: CmsDatabaseSchema): Promise<void> {
  const sql = getDb();
  if (!sql) return;

  try {
    // 1. Sync Menu Categories
    if (data.menuCategories && data.menuCategories.length > 0) {
      for (const cat of data.menuCategories) {
        await sql`
          INSERT INTO menu_categories (id, slug, name, description, is_visible, sort_order)
          VALUES (${cat.id}, ${cat.id}, ${cat.name}, ${cat.description || null}, ${cat.isVisible ?? true}, ${cat.sortOrder || 0})
          ON CONFLICT (id) DO UPDATE SET
            name = EXCLUDED.name,
            slug = EXCLUDED.slug,
            description = EXCLUDED.description,
            is_visible = EXCLUDED.is_visible,
            sort_order = EXCLUDED.sort_order,
            updated_at = NOW();
        `;
      }
    }

    // 2. Sync Menu Items
    if (data.menuItems && data.menuItems.length > 0) {
      for (const item of data.menuItems) {
        const numericBasePrice = item.basePrice !== undefined
          ? Number(item.basePrice)
          : (parseFloat(String(item.price || "180").replace(/[^0-9.]/g, "")) || 180);

        await sql`
          INSERT INTO menu_items (
            id, category_id, name, description, price, base_price, sale_price,
            is_veg, is_spicy, is_signature, contains_pork, is_available, is_visible,
            image_url, sort_order
          )
          VALUES (
            ${item.id}, ${item.category}, ${item.name}, ${item.description || null},
            ${item.price || "₹180"}, ${numericBasePrice}, ${item.salePrice || null},
            ${Boolean(item.isVegetarian)}, ${Boolean(item.tags?.includes("spicy"))}, ${Boolean(item.isHouseFavourite)},
            ${Boolean(item.tags?.includes("pork"))}, ${item.isAvailable ?? true}, ${item.isVisible ?? true},
            ${item.image || null}, ${item.sortOrder || 0}
          )
          ON CONFLICT (id) DO UPDATE SET
            category_id = EXCLUDED.category_id,
            name = EXCLUDED.name,
            description = EXCLUDED.description,
            price = EXCLUDED.price,
            base_price = EXCLUDED.base_price,
            sale_price = EXCLUDED.sale_price,
            is_veg = EXCLUDED.is_veg,
            is_spicy = EXCLUDED.is_spicy,
            is_signature = EXCLUDED.is_signature,
            contains_pork = EXCLUDED.contains_pork,
            is_available = EXCLUDED.is_available,
            is_visible = EXCLUDED.is_visible,
            image_url = EXCLUDED.image_url,
            sort_order = EXCLUDED.sort_order,
            updated_at = NOW();
        `;
      }
    }

    // 3. Sync Outlets
    if (data.outlets && data.outlets.length > 0) {
      for (const o of data.outlets) {
        await sql`
          INSERT INTO outlets (
            id, slug, name, short_name, address, phone, hours_display,
            daily_hours, is_open, is_featured, temporary_closure_notice,
            google_maps_url, latitude, longitude, swiggy_url, zomato_url,
            image_url, seo_title, meta_description
          )
          VALUES (
            ${o.id}, ${o.slug}, ${o.name}, ${o.shortName || null}, ${o.address},
            ${o.phone}, ${o.hoursDisplay}, ${JSON.stringify(o.dailyHours || [])}::jsonb,
            ${o.isOpen ?? true}, ${o.isFeatured ?? true}, ${o.temporaryClosureNotice || null},
            ${o.googleMapsUrl || null}, ${o.latitude || null}, ${o.longitude || null},
            ${o.swiggyUrl || null}, ${o.zomatoUrl || null}, ${o.image || null},
            ${o.seoTitle || null}, ${o.metaDescription || null}
          )
          ON CONFLICT (id) DO UPDATE SET
            slug = EXCLUDED.slug,
            name = EXCLUDED.name,
            short_name = EXCLUDED.short_name,
            address = EXCLUDED.address,
            phone = EXCLUDED.phone,
            hours_display = EXCLUDED.hours_display,
            daily_hours = EXCLUDED.daily_hours,
            is_open = EXCLUDED.is_open,
            is_featured = EXCLUDED.is_featured,
            temporary_closure_notice = EXCLUDED.temporary_closure_notice,
            google_maps_url = EXCLUDED.google_maps_url,
            latitude = EXCLUDED.latitude,
            longitude = EXCLUDED.longitude,
            swiggy_url = EXCLUDED.swiggy_url,
            zomato_url = EXCLUDED.zomato_url,
            image_url = EXCLUDED.image_url,
            seo_title = EXCLUDED.seo_title,
            meta_description = EXCLUDED.meta_description,
            updated_at = NOW();
        `;
      }
    }

    // 4. Sync Site Content Sections
    if (data.siteContent) {
      for (const [key, val] of Object.entries(data.siteContent)) {
        await sql`
          INSERT INTO site_content (key, value, version, updated_at)
          VALUES (${key}, ${JSON.stringify(val)}::jsonb, 1, NOW())
          ON CONFLICT (key) DO UPDATE SET
            value = EXCLUDED.value,
            version = site_content.version + 1,
            updated_at = NOW();
        `;
      }
    }

    // 5. Sync Backups (if any)
    if (data.backups && data.backups.length > 0) {
      const latest = data.backups[0];
      await sql`
        INSERT INTO cms_backups (id, label, data_snippet, data, created_at)
        VALUES (${latest.id}, ${latest.label}, ${latest.dataSnippet}, ${JSON.stringify(latest.data)}::jsonb, ${latest.timestamp}::timestamptz)
        ON CONFLICT (id) DO NOTHING;
      `;
    }
  } catch (err) {
    console.error("[CmsSync] Error syncing CMS data to PostgreSQL:", err);
  }
}
