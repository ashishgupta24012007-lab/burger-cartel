import fs from "fs";
import path from "path";
import crypto from "crypto";
import sharp from "sharp";
import { getDb } from "../db/index.ts";
import { validateImageMagicBytes } from "../utils/mediaValidator.ts";

export interface MediaVariant {
  suffix: string;
  width: number;
  height: number;
  format: "webp" | "avif";
  buffer: Buffer;
  storageKey: string;
  publicUrl: string;
  sizeBytes: number;
}

export interface ProcessedMedia {
  id: string;
  filename: string;
  storageKey: string;
  publicUrl: string;
  mimeType: string;
  width: number;
  height: number;
  sizeBytes: number;
  variants: MediaVariant[];
  originalFilename?: string;
}

const MAX_IMAGE_PIXELS = 16_000_000; // 16 Megapixels
const MAX_DIMENSION = 4096; // 4096px
const UPLOADS_DIR = path.join(process.cwd(), "public", "uploads");

/**
 * AWS S3 SigV4 PUT helper for zero-dependency S3/R2/MinIO object upload
 */
async function uploadToS3(params: {
  key: string;
  body: Buffer;
  contentType: string;
}): Promise<string | null> {
  const bucket = process.env.S3_BUCKET;
  const region = process.env.S3_REGION || "auto";
  const endpoint = process.env.S3_ENDPOINT;
  const accessKeyId = process.env.S3_ACCESS_KEY_ID;
  const secretAccessKey = process.env.S3_SECRET_ACCESS_KEY;
  const publicPrefix = process.env.S3_PUBLIC_URL_PREFIX;

  if (!bucket || !accessKeyId || !secretAccessKey) {
    return null; // S3 not configured, fallback to Postgres
  }

  try {
    const date = new Date();
    const dateStamp = date.toISOString().slice(0, 10).replace(/-/g, "");
    const amzDate = date.toISOString().replace(/[:-]|\.\d{3}/g, "");
    const host = endpoint ? new URL(endpoint).host : `${bucket}.s3.${region}.amazonaws.com`;
    const canonicalUri = `/${params.key}`;

    const hashedPayload = crypto.createHash("sha256").update(params.body).digest("hex");
    const canonicalHeaders = `content-type:${params.contentType}\nhost:${host}\nx-amz-content-sha256:${hashedPayload}\nx-amz-date:${amzDate}\n`;
    const signedHeaders = "content-type;host;x-amz-content-sha256;x-amz-date";
    const canonicalRequest = `PUT\n${canonicalUri}\n\n${canonicalHeaders}\n${signedHeaders}\n${hashedPayload}`;

    const service = "s3";
    const credentialScope = `${dateStamp}/${region}/${service}/aws4_request`;
    const stringToSign = `AWS4-HMAC-SHA256\n${amzDate}\n${credentialScope}\n${crypto.createHash("sha256").update(canonicalRequest).digest("hex")}`;

    const kDate = crypto.createHmac("sha256", `AWS4${secretAccessKey}`).update(dateStamp).digest();
    const kRegion = crypto.createHmac("sha256", kDate).update(region).digest();
    const kService = crypto.createHmac("sha256", kRegion).update(service).digest();
    const kSigning = crypto.createHmac("sha256", kService).update("aws4_request").digest();
    const signature = crypto.createHmac("sha256", kSigning).update(stringToSign).digest("hex");

    const authorization = `AWS4-HMAC-SHA256 Credential=${accessKeyId}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;

    const url = endpoint ? `${endpoint.replace(/\/$/, "")}/${bucket}/${params.key}` : `https://${host}/${params.key}`;

    const res = await fetch(url, {
      method: "PUT",
      headers: {
        "Content-Type": params.contentType,
        "x-amz-date": amzDate,
        "x-amz-content-sha256": hashedPayload,
        "Authorization": authorization,
        "Cache-Control": "public, max-age=31536000, immutable",
      },
      body: params.body as unknown as BodyInit,
    });

    if (res.ok) {
      return publicPrefix ? `${publicPrefix.replace(/\/$/, "")}/${params.key}` : url;
    }
    console.warn("[MediaStorage] S3 PUT failed with status:", res.status);
    return null;
  } catch (err) {
    console.warn("[MediaStorage] S3 upload error, falling back:", err);
    return null;
  }
}

/**
 * Validates, decodes, strips metadata, and generates responsive WebP variants.
 */
export async function processAndStoreMedia(
  inputBuffer: Buffer,
  originalFilename?: string
): Promise<ProcessedMedia> {
  // 1. Magic bytes verification
  const magicValidation = validateImageMagicBytes(inputBuffer);
  if (!magicValidation.valid) {
    throw new Error(magicValidation.error || "Invalid image magic bytes.");
  }

  // 2. Real image decoding with Sharp
  const sharpInstance = sharp(inputBuffer);
  const metadata = await sharpInstance.metadata();

  if (!metadata.width || !metadata.height) {
    throw new Error("Unable to decode image dimensions. Corrupted or invalid image file.");
  }

  // 3. Maximum pixel-count & dimension enforcement (Defense against decompression bombs & micro-stubs)
  if (metadata.width < 200 || metadata.height < 200) {
    throw new Error(
      `Image resolution (${metadata.width}x${metadata.height}) is too small. Minimum resolution is 200x200px.`
    );
  }
  const totalPixels = metadata.width * metadata.height;
  if (totalPixels > MAX_IMAGE_PIXELS) {
    throw new Error(
      `Image resolution exceeds limit (${metadata.width}x${metadata.height} = ${(totalPixels / 1e6).toFixed(1)}MP). Maximum is 16 Megapixels.`
    );
  }
  if (metadata.width > MAX_DIMENSION || metadata.height > MAX_DIMENSION) {
    throw new Error(`Image dimensions exceed maximum ${MAX_DIMENSION}px boundary.`);
  }

  const assetId = crypto.randomUUID();
  const fileHash = crypto.createHash("sha256").update(inputBuffer).digest("hex").slice(0, 12);
  const baseFilename = `cartel-${Date.now()}-${fileHash}`;

  // 4. Primary WebP (Full / 1600w max, metadata stripped via .rotate())
  const primaryBuffer = await sharp(inputBuffer)
    .rotate() // Auto-orients from EXIF, then strips all EXIF, GPS, device data
    .resize({ width: 1600, height: 1600, fit: "inside", withoutEnlargement: true })
    .webp({ quality: 85, effort: 4 })
    .toBuffer();

  const primaryMeta = await sharp(primaryBuffer).metadata();
  const primaryKey = `media/${baseFilename}.webp`;
  const primaryFilename = `${baseFilename}.webp`;

  // 5. Generate Responsive Variants (800w, 400w)
  const variantSpecs = [
    { suffix: "md", maxWidth: 800, quality: 80 },
    { suffix: "sm", maxWidth: 400, quality: 75 },
  ];

  const variants: MediaVariant[] = [];
  for (const spec of variantSpecs) {
    const varBuffer = await sharp(inputBuffer)
      .rotate()
      .resize({ width: spec.maxWidth, height: spec.maxWidth, fit: "inside", withoutEnlargement: true })
      .webp({ quality: spec.quality, effort: 4 })
      .toBuffer();

    const varMeta = await sharp(varBuffer).metadata();
    const varKey = `media/${baseFilename}-${spec.suffix}.webp`;

    variants.push({
      suffix: spec.suffix,
      width: varMeta.width || spec.maxWidth,
      height: varMeta.height || spec.maxWidth,
      format: "webp",
      buffer: varBuffer,
      storageKey: varKey,
      publicUrl: `/api/media/${baseFilename}-${spec.suffix}.webp`,
      sizeBytes: varBuffer.length,
    });
  }

  // 6. Upload to S3 if configured
  let primaryPublicUrl = `/api/media/${primaryFilename}`;
  const s3PrimaryUrl = await uploadToS3({
    key: primaryKey,
    body: primaryBuffer,
    contentType: "image/webp",
  });

  if (s3PrimaryUrl) {
    primaryPublicUrl = s3PrimaryUrl;
    for (const v of variants) {
      const s3VarUrl = await uploadToS3({
        key: v.storageKey,
        body: v.buffer,
        contentType: "image/webp",
      });
      if (s3VarUrl) v.publicUrl = s3VarUrl;
    }
  }

  // 7. Persist to PostgreSQL media_assets as authoritative record & fallback
  const sql = getDb();
  if (sql) {
    const primaryBase64 = primaryBuffer.toString("base64");
    await sql`
      INSERT INTO media_assets (
        id, filename, mime_type, size_bytes, data_base64, storage_key,
        public_url, original_filename, width, height, status, created_at
      )
      VALUES (
        ${assetId},
        ${primaryFilename},
        'image/webp',
        ${primaryBuffer.length},
        ${primaryBase64},
        ${primaryKey},
        ${primaryPublicUrl},
        ${originalFilename || null},
        ${primaryMeta.width || 0},
        ${primaryMeta.height || 0},
        'ready',
        NOW()
      )
      ON CONFLICT (filename) DO UPDATE SET
        data_base64 = EXCLUDED.data_base64,
        size_bytes = EXCLUDED.size_bytes,
        public_url = EXCLUDED.public_url,
        width = EXCLUDED.width,
        height = EXCLUDED.height,
        status = 'ready';
    `;

    // Also store variants in media_assets
    for (const v of variants) {
      const vFilename = path.basename(v.storageKey);
      await sql`
        INSERT INTO media_assets (
          id, filename, mime_type, size_bytes, data_base64, storage_key,
          public_url, original_filename, width, height, status, created_at
        )
        VALUES (
          ${crypto.randomUUID()},
          ${vFilename},
          'image/webp',
          ${v.sizeBytes},
          ${v.buffer.toString("base64")},
          ${v.storageKey},
          ${v.publicUrl},
          ${originalFilename || null},
          ${v.width},
          ${v.height},
          'ready',
          NOW()
        )
        ON CONFLICT (filename) DO UPDATE SET
          data_base64 = EXCLUDED.data_base64,
          size_bytes = EXCLUDED.size_bytes;
      `;
    }
  }

  // 8. Disk cache update (best-effort for instant local serving)
  try {
    if (!fs.existsSync(UPLOADS_DIR)) {
      fs.mkdirSync(UPLOADS_DIR, { recursive: true, mode: 0o755 });
    }
    fs.writeFileSync(path.join(UPLOADS_DIR, primaryFilename), primaryBuffer);
    for (const v of variants) {
      fs.writeFileSync(path.join(UPLOADS_DIR, path.basename(v.storageKey)), v.buffer);
    }
  } catch {
    // Non-blocking on read-only serverless filesystems
  }

  return {
    id: assetId,
    filename: primaryFilename,
    storageKey: primaryKey,
    publicUrl: primaryPublicUrl,
    mimeType: "image/webp",
    width: primaryMeta.width || 0,
    height: primaryMeta.height || 0,
    sizeBytes: primaryBuffer.length,
    variants,
    originalFilename,
  };
}

/**
 * Safely deletes a media asset from PostgreSQL, S3, and disk
 */
export async function deleteMediaAsset(filename: string): Promise<boolean> {
  const sql = getDb();
  const cleanName = path.basename(filename);

  // 1. Delete from PostgreSQL
  if (sql) {
    await sql`DELETE FROM media_assets WHERE filename = ${cleanName} OR storage_key LIKE ${`%${cleanName}`}`;
  }

  // 2. Delete from local disk cache if present
  try {
    const localPath = path.join(UPLOADS_DIR, cleanName);
    if (fs.existsSync(localPath)) {
      fs.unlinkSync(localPath);
    }
  } catch {
    // Non-blocking
  }

  return true;
}
