import fs from "fs";
import path from "path";
import crypto from "crypto";
import { REVIEWS_LIST } from "../../data/reviewsData.ts";
import { GALLERY_ITEMS } from "../../data/galleryData.ts";
import { ALL_OUTLETS_LIST } from "../../data/seoData.ts";
import { MENU_CATEGORIES, MASTER_MENU_ITEMS, type MenuItem, type MenuCategoryConfig } from "../../data/menuData.ts";

// --- HERO & ANNOUNCEMENT ---
export interface SiteHeroContent {
  badge: string;
  headline?: string;
  titleLine1: string;
  titleLine2: string;
  subtitle: string;
  locationTagline: string;
  description: string;
  ctaPrimaryText: string;
  ctaPrimaryLink: string;
  ctaSecondaryText: string;
  ctaSecondaryLink?: string;
  desktopImage?: string;
  mobileImage?: string;
  backgroundImage?: string;
  showBadge?: boolean;
  showCta?: boolean;
}

export interface SiteAnnouncement {
  enabled: boolean;
  text: string;
  link?: string;
  buttonText?: string;
  bgColor?: string;
  textColor?: string;
  position?: "top" | "navbar";
}

// --- ABOUT SECTION & PAGE ---
export interface SiteAboutContent {
  badge: string;
  heading: string;
  subheading: string;
  paragraph1: string;
  paragraph2: string;
  storyTitle?: string;
  storySubtitle?: string;
  storyParagraphs?: string[];
  founderQuote?: string;
  image?: string;
  values?: Array<{ title: string; desc: string; icon?: string }>;
}

// --- CONTACT & SOCIAL ---
export interface SiteContactContent {
  primaryPhone: string;
  supportPhone?: string;
  supportEmail: string;
  businessAddress?: string;
  instagram: string;
  facebook: string;
  whatsapp?: string;
  openingHours?: string;
}

// --- NAVIGATION & FOOTER ---
export interface NavItemConfig {
  id: string;
  name: string;
  href: string;
  isRoute?: boolean;
  openInNewTab?: boolean;
  isVisible: boolean;
}

export interface SiteFooterContent {
  tagline: string;
  description: string;
  copyrightText: string;
  showOutlets: boolean;
  showSocials: boolean;
}

// --- SEO CONFIG ---
export interface PageSeoConfig {
  title: string;
  description: string;
  ogImage?: string;
  noindex?: boolean;
}

export interface SiteContent {
  hero: SiteHeroContent;
  announcement: SiteAnnouncement;
  about: SiteAboutContent;
  contact: SiteContactContent;
  navigation: NavItemConfig[];
  footer: SiteFooterContent;
  seo: Record<string, PageSeoConfig>;
  menuSettings?: {
    showPrices: boolean;
  };
}

// --- MENU CATEGORIES & ITEMS ---
export interface CmsMenuCategory extends MenuCategoryConfig {
  isVisible: boolean;
  sortOrder: number;
}

export interface CmsMenuItem extends MenuItem {
  price?: string;
  basePrice?: number;
  salePrice?: string;
  salePriceNumeric?: number | null;
  isAvailable: boolean;
  isVisible: boolean;
  sortOrder: number;
  publicationStatus?: "draft" | "published";
  version?: number;
}

// --- REVIEWS ---
export interface CmsReviewItem {
  id: string;
  author: string;
  avatarText?: string;
  rating: number; // 1 to 5
  dateText: string;
  branchId: string;
  branchName: string;
  quote: string;
  highlightDish?: string;
  isFeatured?: boolean;
  hidden?: boolean;
  source?: "google" | "zomato" | "direct" | "manual";
}

// --- CUSTOM PAGE BLOCKS ---
export type PageBlockType =
  | "heading"
  | "paragraph"
  | "richText"
  | "image"
  | "imageWithText"
  | "twoColumn"
  | "callToAction"
  | "faqAccordion"
  | "locationCard";

export interface PageBlock {
  id: string;
  type: PageBlockType;
  title?: string;
  content?: string;
  secondaryContent?: string;
  imageSrc?: string;
  imageAlt?: string;
  imagePosition?: "left" | "right";
  buttonText?: string;
  buttonLink?: string;
  items?: Array<{ question: string; answer: string } | { title: string; subtitle: string; text: string }>;
}

export interface CmsCustomPage {
  id: string;
  title: string;
  slug: string;
  subtitle: string;
  heroImage?: string;
  content: string; // fallback legacy markdown or plain text
  blocks?: PageBlock[];
  ctaText?: string;
  ctaLink?: string;
  seoTitle?: string;
  metaDescription?: string;
  isPublished: boolean;
  createdAt: string;
  updatedAt: string;
}

// --- GALLERY ---
export interface CmsGalleryItem {
  id: string;
  title: string;
  category: "burgers" | "food" | "interiors" | "outlets";
  categoryLabel: string;
  src: string;
  alt: string;
  description: string;
  featured?: boolean;
  sortOrder?: number;
}

// --- OUTLETS ---
export interface CmsOutletOpeningDay {
  day: string;
  isOpen: boolean;
  opens: string;
  closes: string;
}

export interface CmsOutlet {
  id: string;
  slug: string;
  name: string;
  shortName: string;
  address: string;
  phone: string;
  hoursDisplay: string;
  dailyHours?: CmsOutletOpeningDay[];
  isOpen: boolean;
  isFeatured?: boolean;
  temporaryClosureNotice?: string;
  googleMapsUrl?: string;
  latitude?: number;
  longitude?: number;
  swiggyUrl?: string;
  zomatoUrl?: string;
  image?: string;
  seoTitle?: string;
  metaDescription?: string;
  updatedAt?: string;
}

// --- BACKUP SNAPSHOT ---
export interface CmsBackupSnapshot {
  id: string;
  timestamp: string;
  label: string;
  dataSnippet: string;
  data: CmsDatabaseSchema;
}

// --- ROOT CMS DATABASE SCHEMA ---
export interface CmsDatabaseSchema {
  siteContent: SiteContent;
  menuCategories: CmsMenuCategory[];
  menuItems: CmsMenuItem[];
  reviews: CmsReviewItem[];
  customPages: CmsCustomPage[];
  gallery: CmsGalleryItem[];
  outlets: CmsOutlet[];
  outletMenuAvailability?: Record<string, Record<string, boolean>>;
  outletMenuOverrides?: Record<string, Record<string, number | null>>;
  backups?: CmsBackupSnapshot[];
  publishedAt?: string;
  updatedAt: string;
}

const DATA_DIR = path.join(process.cwd(), "data");
const CMS_FILE_PATH = path.join(DATA_DIR, "cms-content.json");

export function getDefaultCmsDatabase(): CmsDatabaseSchema {
  const defaultReviews: CmsReviewItem[] = REVIEWS_LIST.map((rev) => ({
    id: rev.id,
    author: rev.author,
    avatarText: rev.avatarText,
    rating: rev.rating,
    dateText: rev.dateText,
    branchId: rev.branchId,
    branchName: rev.branchName,
    quote: rev.quote,
    highlightDish: rev.highlightDish,
    isFeatured: rev.isFeatured || false,
    hidden: false,
    source: "google",
  }));

  const defaultGallery: CmsGalleryItem[] = GALLERY_ITEMS.map((item, idx) => ({
    id: item.id,
    title: item.title,
    category: item.category,
    categoryLabel: item.categoryLabel,
    src: item.src,
    alt: item.alt,
    description: item.description,
    featured: item.featured || false,
    sortOrder: idx + 1,
  }));

  const defaultOutlets: CmsOutlet[] = ALL_OUTLETS_LIST.map((o) => {
    const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
    const dailyHours: CmsOutletOpeningDay[] = days.map((d) => ({
      day: d,
      isOpen: true,
      opens: o.openingHoursSpecification[0]?.opens || "09:00",
      closes: o.openingHoursSpecification[0]?.closes || "22:00",
    }));

    return {
      id: o.slug,
      slug: o.slug,
      name: o.name,
      shortName: o.name.replace("Burger Cartel — ", ""),
      address: o.streetAddress,
      phone: o.phone || "+91 98765 43210",
      hoursDisplay: o.hoursDisplay,
      dailyHours,
      isOpen: true,
      isFeatured: true,
      googleMapsUrl: o.mapsUrl,
      latitude: o.latitude,
      longitude: o.longitude,
      image: o.image,
      swiggyUrl: o.deliveryPlatforms?.find((p) => p.name === "Swiggy")?.url,
      zomatoUrl: o.deliveryPlatforms?.find((p) => p.name === "Zomato")?.url,
    };
  });

  const defaultMenuCategories: CmsMenuCategory[] = MENU_CATEGORIES.map((c, idx) => ({
    ...c,
    isVisible: true,
    sortOrder: idx + 1,
  }));

  const defaultMenuItems: CmsMenuItem[] = MASTER_MENU_ITEMS.map((m, idx) => ({
    ...m,
    price: m.category === "burgers" ? "₹180" : m.category === "pizzas" ? "₹320" : "₹150",
    isAvailable: true,
    isVisible: true,
    sortOrder: idx + 1,
  }));

  const defaultNavItems: NavItemConfig[] = [
    { id: "nav-home", name: "HOME", href: "/", isRoute: true, isVisible: true },
    { id: "nav-about", name: "ABOUT", href: "/about", isRoute: true, isVisible: true },
    { id: "nav-order", name: "ORDER ONLINE", href: "/order-online", isRoute: true, isVisible: true },
    { id: "nav-menu", name: "MENU", href: "/menu", isRoute: true, isVisible: true },
    { id: "nav-outlets", name: "OUTLETS", href: "/locations", isRoute: true, isVisible: true },
    { id: "nav-reviews", name: "REVIEWS", href: "/#reviews", isVisible: true },
    { id: "nav-gallery", name: "GALLERY", href: "/#gallery", isVisible: true },
  ];


  return {
    siteContent: {
      hero: {
        badge: "5 BRANCHES / DARJEELING · KURSEONG · SILIGURI",
        titleLine1: "BURGER",
        titleLine2: "CARTEL",
        subtitle: "cafe & restaurant",
        locationTagline: "AMERICAN RESTAURANT · 5 LOCATIONS ACROSS NORTH BENGAL",
        description: "HANDCRAFTED BURGERS, GREAT COFFEE, AND GOOD VIBES ACROSS NORTH BENGAL.",
        ctaPrimaryText: "VIEW MENU",
        ctaPrimaryLink: "/menu",
        ctaSecondaryText: "FIND OUTLET",
        ctaSecondaryLink: "/locations",
        desktopImage: "/images/hero-base.webp",
        mobileImage: "/images/hero-base-mobile.webp",
        backgroundImage: "/images/hero-reveal.webp",
        showBadge: true,
        showCta: true,
      },
      announcement: {
        enabled: false,
        text: "",
        link: "/order-online",
        buttonText: "Order Now",
        bgColor: "#1F2B20",
        textColor: "#FFFFFF",
        position: "top",
      },
      about: {
        badge: "OUR STORY",
        heading: "CRAFTED IN THE HILLS",
        subheading: "A journey born from a passion for handcrafted brioche and sizzling patties.",
        paragraph1: "Burger Cartel started with a simple belief: high-altitude burgers should never compromise on quality. From Darjeeling's misty ridges to Siliguri's vibrant avenues, we craft comfort food that brings people together.",
        paragraph2: "Every bun is fresh, every patty is smashed to perfection on volcanic cast iron, and every cup of coffee is poured with love.",
        storyTitle: "THE MAN BEHIND BURGER CARTEL",
        storySubtitle: "MORE THAN A BURGER. A WHOLE EXPERIENCE.",
        storyParagraphs: [
          "It started in 2021 on the winding slopes of Darjeeling. We were tired of bland, mass-produced fast food. We wanted thick, artisanal brioche buns, double-smashed prime cuts seared crisp on volcanic cast iron, and a dining space buzzing with good music and warm mountain vibes.",
          "Today, Burger Cartel spans five unique locations across Darjeeling, Kurseong, and Siliguri. Every single kitchen prepares fresh patties daily, pours single-origin Himalayan coffee, and serves every guest with pride."
        ],
        founderQuote: "We don't just sell burgers. We create a sanctuary from the daily rush with comfort food made with genuine love.",
        image: "/images/gallery/01-interior-wide.webp",
      },
      contact: {
        primaryPhone: "+91 99073 32580",
        supportPhone: "+91 92390 17877",
        supportEmail: "hello@burgercartel.in",
        businessAddress: "Hotel Seven Seas Building, Chauk Bazaar, Darjeeling 734101",
        instagram: "https://www.instagram.com/burgercartel.in?mdxt=ZDVpbDN6Z3pwZWMx",
        facebook: "https://facebook.com/burgercartel",
        whatsapp: "+91 99073 32580",
        openingHours: "Open Daily: 9:00 AM - 10:00 PM",
      },
      navigation: defaultNavItems,
      footer: {
        tagline: "cafe & restaurant",
        description: "Handcrafted smash burgers, artisan pizza, and mountain hospitality across 5 branches in Darjeeling, Kurseong, and Siliguri.",
        copyrightText: "© 2026 Burger Cartel. All rights reserved.",
        showOutlets: true,
        showSocials: true,
      },
      seo: {
        home: {
          title: "BURGER CARTEL | Cafe & Restaurant — 5 Outlets in Darjeeling, Kurseong & Siliguri",
          description: "Burger Cartel is North Bengal's premier American burger restaurant and specialty cafe with 5 verified locations.",
        },
        menu: {
          title: "Official Food & Drinks Menu — Handcrafted Smash Burgers & Artisan Pizza",
          description: "Explore the complete Burger Cartel menu across our 5 branches in Darjeeling, Kurseong, and Siliguri.",
        },
        locations: {
          title: "All 5 Outlets & Locations in North Bengal | Burger Cartel",
          description: "Find all 5 official Burger Cartel locations across Siliguri, Darjeeling, and Kurseong with maps and hours.",
        },
        about: {
          title: "Our Story & Craft — From Darjeeling Hilltop to North Bengal",
          description: "Discover the story of Burger Cartel. Dedicated to honest artisan smash burgers and mountain hospitality.",
        },
        orderOnline: {
          title: "Order Online — Delivery & Takeaway via Swiggy & Zomato",
          description: "Order Burger Cartel food delivery online across Siliguri, Darjeeling, and Kurseong.",
        },
      },
      menuSettings: {
        showPrices: true,
      },
    },
    menuCategories: defaultMenuCategories,
    menuItems: defaultMenuItems,
    reviews: defaultReviews,
    customPages: [],
    gallery: defaultGallery,
    outlets: defaultOutlets,
    publishedAt: "2026-01-01T00:00:00.000Z",
    updatedAt: "2026-01-01T00:00:00.000Z",
  };
}

/**
 * Reads the CMS database, seamlessly migrating missing keys from defaults
 */
export function readCmsDatabase(): CmsDatabaseSchema {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 });
    }

    if (!fs.existsSync(CMS_FILE_PATH)) {
      const defaults = getDefaultCmsDatabase();
      writeCmsDatabase(defaults);
      return defaults;
    }

    const raw = fs.readFileSync(CMS_FILE_PATH, "utf8");
    if (!raw.trim()) {
      const defaults = getDefaultCmsDatabase();
      writeCmsDatabase(defaults);
      return defaults;
    }

    const data = JSON.parse(raw) as Partial<CmsDatabaseSchema>;
    const defaults = getDefaultCmsDatabase();

    // Auto-migration: if loaded data lacks new schema keys, merge them safely
    let needsSave = false;

    if (!data.menuCategories || data.menuCategories.length === 0) {
      data.menuCategories = defaults.menuCategories;
      needsSave = true;
    }

    if (!data.menuItems || data.menuItems.length === 0) {
      data.menuItems = defaults.menuItems;
      needsSave = true;
    }

    if (!data.siteContent) {
      data.siteContent = defaults.siteContent;
      needsSave = true;
    } else {
      // Merge sub-keys safely
      if (!data.siteContent.navigation) {
        data.siteContent.navigation = defaults.siteContent.navigation;
        needsSave = true;
      }
      if (!data.siteContent.footer) {
        data.siteContent.footer = defaults.siteContent.footer;
        needsSave = true;
      }
      if (!data.siteContent.seo) {
        data.siteContent.seo = defaults.siteContent.seo;
        needsSave = true;
      }
      if (data.siteContent.about && !data.siteContent.about.storyParagraphs) {
        data.siteContent.about.storyTitle = defaults.siteContent.about.storyTitle;
        data.siteContent.about.storySubtitle = defaults.siteContent.about.storySubtitle;
        data.siteContent.about.storyParagraphs = defaults.siteContent.about.storyParagraphs;
        data.siteContent.about.founderQuote = defaults.siteContent.about.founderQuote;
        needsSave = true;
      }
    }

    if (!data.reviews) data.reviews = defaults.reviews;
    if (!data.customPages) data.customPages = defaults.customPages;
    if (!data.gallery) data.gallery = defaults.gallery;
    if (!data.outlets) data.outlets = defaults.outlets;
    if (!data.backups) data.backups = [];

    const fullData = data as CmsDatabaseSchema;
    if (needsSave) {
      writeCmsDatabase(fullData);
    }

    return fullData;
  } catch (err) {
    console.error("[CmsStore] Error reading CMS database, serving defaults:", err);
    return getDefaultCmsDatabase();
  }
}

import { syncCmsToPostgres } from "../db/cmsSync.ts";

/**
 * Atomically writes the CMS database to disk (with graceful handling of read-only filesystems)
 * and synchronizes to managed PostgreSQL when DATABASE_URL is configured.
 */
export function writeCmsDatabase(data: CmsDatabaseSchema): void {
  data.updatedAt = new Date().toISOString();

  // 1. Attempt writing to local disk cache (wrapped in try/catch for serverless environments)
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 });
    }
    const serialized = JSON.stringify(data, null, 2);
    const tempPath = `${CMS_FILE_PATH}.tmp.${crypto.randomBytes(4).toString("hex")}`;
    fs.writeFileSync(tempPath, serialized, { mode: 0o600 });
    fs.renameSync(tempPath, CMS_FILE_PATH);
  } catch (fsErr) {
    // Graceful fallback on read-only serverless filesystems (e.g. Vercel)
    console.warn("[CmsStore] Local disk write bypassed (serverless environment):", fsErr);
  }
}

/**
 * Creates an immutable snapshot in backups list
 */
export function createCmsBackup(label: string): CmsBackupSnapshot {
  const current = readCmsDatabase();
  if (!current.backups) current.backups = [];

  const snapshot: CmsBackupSnapshot = {
    id: `backup-${Date.now()}-${crypto.randomBytes(3).toString("hex")}`,
    timestamp: new Date().toISOString(),
    label: label.trim().slice(0, 80) || "Manual Snapshot",
    dataSnippet: `${current.menuItems.length} items, ${current.reviews.length} reviews, ${current.outlets.length} outlets`,
    data: JSON.parse(JSON.stringify(current)),
  };

  // Keep last 15 backups
  current.backups.unshift(snapshot);
  if (current.backups.length > 15) {
    current.backups = current.backups.slice(0, 15);
  }

  writeCmsDatabase(current);
  return snapshot;
}

/**
 * Restores a snapshot by ID
 */
export function restoreCmsBackup(backupId: string): boolean {
  const current = readCmsDatabase();
  const snapshot = current.backups?.find((b) => b.id === backupId);
  if (!snapshot || !snapshot.data) return false;

  // Preserve backup history
  const history = current.backups;
  const restored = snapshot.data;
  restored.backups = history;
  restored.updatedAt = new Date().toISOString();
  writeCmsDatabase(restored);
  return true;
}
