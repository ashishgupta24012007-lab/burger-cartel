/**
 * Burger Cartel Production Environment & Security Bootstrap Validator
 * Enforces mandatory secrets and configurations to prevent silent local fallbacks
 * and ephemeral key degradation in production.
 */

export function validateProductionEnvironment(): void {
  const isProduction = process.env.NODE_ENV === "production";

  if (isProduction) {
    if (!process.env.DATABASE_URL) {
      throw new Error(
        "[BOOTSTRAP FATAL] DATABASE_URL is missing. Production environments strictly require managed PostgreSQL."
      );
    }

    const sessionSecret = process.env.SESSION_SECRET;
    if (!sessionSecret || sessionSecret.length < 32) {
      throw new Error(
        "[BOOTSTRAP FATAL] SESSION_SECRET must be configured with at least 32 characters in production."
      );
    }

    const adminStoreKey = process.env.ADMIN_STORE_KEY;
    if (!adminStoreKey || adminStoreKey.length < 32) {
      throw new Error(
        "[BOOTSTRAP FATAL] ADMIN_STORE_KEY must be configured with at least 32 characters in production."
      );
    }

    if (process.env.ALLOW_LOCAL_FALLBACK === "true") {
      throw new Error(
        "[BOOTSTRAP FATAL] ALLOW_LOCAL_FALLBACK is forbidden in production. Silent local storage fallbacks are disabled."
      );
    }
  }
}

// Run validation immediately on module load
try {
  validateProductionEnvironment();
} catch (err) {
  // If in production, log error immediately
  if (process.env.NODE_ENV === "production") {
    console.error((err as Error).message);
  }
}
