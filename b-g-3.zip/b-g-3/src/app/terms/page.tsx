import type { Metadata } from "next";
import Link from "next/link";
import { ChevronRight, ShieldCheck, Scale, AlertTriangle } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { SITE_URL, safeJsonLd } from "@/data/seoData";

export const metadata: Metadata = {
  title: "Terms of Use & Legal Disclaimer | Burger Cartel",
  description:
    "Terms of use, menu pricing disclaimer, allergen advisory, and third-party delivery terms for the official Burger Cartel restaurant website.",
  alternates: {
    canonical: "/terms",
  },
};

export default function TermsPage() {
  const breadcrumbJsonLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: "Home",
        item: SITE_URL,
      },
      {
        "@type": "ListItem",
        position: 2,
        name: "Terms of Use & Disclaimer",
        item: `${SITE_URL}/terms`,
      },
    ],
  };

  return (
    <div className="min-h-screen bg-[#F5F0E7] text-[#292925] flex flex-col font-sans selection:bg-[#1F2B20] selection:text-white">
      <Navbar />

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: safeJsonLd(breadcrumbJsonLd) }}
      />

      <main className="flex-1 max-w-4xl mx-auto w-full px-5 sm:px-8 md:px-12 pt-32 pb-20">
        {/* Breadcrumb Navigation */}
        <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-xs text-[#736F67] mb-8">
          <Link href="/" className="hover:text-[#1F2B20] transition-colors">
            Home
          </Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <span className="text-[#1F2B20] font-semibold">Terms &amp; Disclaimer</span>
        </nav>

        {/* Page Header */}
        <header className="border-b border-[#E8DED0] pb-8 mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#1F2B20]/10 border border-[#1F2B20]/20 text-[#1F2B20] text-xs font-semibold mb-3">
            <Scale className="w-3.5 h-3.5" />
            <span>Legal Notice &amp; Terms of Use</span>
          </div>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-black uppercase tracking-tight text-[#1F2B20] mb-3">
            Terms &amp; Legal Disclaimer
          </h1>
          <p className="text-xs sm:text-sm text-[#4A4843] leading-relaxed max-w-2xl">
            Please read these terms carefully before browsing our website. By accessing or using this website, you agree to the conditions and disclaimers detailed below.
          </p>
        </header>

        {/* Legal Clauses */}
        <div className="space-y-8 text-sm text-[#4A4843] leading-relaxed">
          {/* Section 1 */}
          <section className="bg-white border border-[#E8DED0] rounded-2xl p-6 sm:p-8 shadow-sm">
            <h2 className="text-base sm:text-lg font-black uppercase tracking-tight text-[#1F2B20] mb-3 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-[#B18B5B]" />
              <span>1. Informational &amp; Promotional Purpose</span>
            </h2>
            <p className="mb-3">
              This website is operated by Burger Cartel to provide restaurant location details, operating hours, dining menus, and promotional information about our culinary offerings across Darjeeling, Kurseong, and Siliguri.
            </p>
            <p>
              This website does not directly process commercial financial transactions, retail orders, or consumer credit card payments.
            </p>
          </section>

          {/* Section 2 */}
          <section className="bg-white border border-[#E8DED0] rounded-2xl p-6 sm:p-8 shadow-sm">
            <h2 className="text-base sm:text-lg font-black uppercase tracking-tight text-[#1F2B20] mb-3">
              2. Menu, Pricing &amp; Item Availability
            </h2>
            <p className="mb-3">
              All menu descriptions, dish images, and prices displayed on this website are indicative and published for customer convenience. Menu items, ingredients, preparation styles, and prices are subject to seasonal variation, daily market availability, and branch-level inventory without prior notice.
            </p>
            <p>
              Final prices, taxes, and availability are determined at the time an order is placed in person at our physical outlets or via our verified listings on third-party delivery platforms.
            </p>
          </section>

          {/* Section 3: Allergen Advisory (Essential Liability Shield) */}
          <section className="bg-[#FAF7F0] border border-[#D9CEBE] rounded-2xl p-6 sm:p-8 shadow-sm">
            <div className="flex items-center gap-2 text-[#9A3412] font-black uppercase tracking-wider text-xs mb-3">
              <AlertTriangle className="w-4 h-4" />
              <span>Important Food Allergy &amp; Dietary Advisory</span>
            </div>
            <h2 className="text-base sm:text-lg font-black uppercase tracking-tight text-[#1F2B20] mb-3">
              3. Food Allergen &amp; Cross-Contact Notice
            </h2>
            <p className="mb-3">
              Burger Cartel kitchens prepare freshly cooked food in active commercial environments. Our kitchens routinely handle common allergens, including <strong>wheat/gluten, dairy, eggs, soy, sesame seeds, and tree nuts</strong>, on shared surfaces, cast-iron flat-top grills, and deep fryers.
            </p>
            <p className="mb-3">
              While our kitchen staff takes reasonable care in preparation, cross-contact between ingredients may occur during peak hours. We cannot guarantee a 100% allergen-free preparation environment.
            </p>
            <p className="font-semibold text-[#1F2B20]">
              If you or any member of your dining party has a known food allergy, intolerance, or medical dietary restriction, you must inform our store team prior to placing your order.
            </p>
          </section>

          {/* Section 4: Third-Party Delivery */}
          <section className="bg-white border border-[#E8DED0] rounded-2xl p-6 sm:p-8 shadow-sm">
            <h2 className="text-base sm:text-lg font-black uppercase tracking-tight text-[#1F2B20] mb-3">
              4. Third-Party Ordering &amp; Delivery Services
            </h2>
            <p className="mb-3">
              Online food delivery links featured on this website redirect users to independent external platforms, primarily <strong>Swiggy</strong> and <strong>Zomato</strong>.
            </p>
            <ul className="list-disc list-inside space-y-2 mb-3">
              <li>
                Online delivery orders, delivery fees, live GPS tracking, delivery partner assignment, and payment processing are managed directly by the respective third-party platform.
              </li>
              <li>
                Burger Cartel is responsible for kitchen food preparation and packaging integrity until handover to the delivery courier.
              </li>
              <li>
                Transit delays, delivery partner conduct, platform payment disputes, or cancellation refunds must be addressed directly through the respective platform&apos;s customer support.
              </li>
            </ul>
          </section>

          {/* Section 5: Intellectual Property */}
          <section className="bg-white border border-[#E8DED0] rounded-2xl p-6 sm:p-8 shadow-sm">
            <h2 className="text-base sm:text-lg font-black uppercase tracking-tight text-[#1F2B20] mb-3">
              5. Intellectual Property
            </h2>
            <p>
              The Burger Cartel brand name, logo, graphic badges, typography, menu compilations, and original culinary photography on this website are protected by applicable intellectual property and copyright laws. Unauthorized reproduction, commercial distribution, automated scraping, or hotlinking of assets without express written consent is prohibited.
            </p>
          </section>

          {/* Section 6: Limitation of Liability */}
          <section className="bg-white border border-[#E8DED0] rounded-2xl p-6 sm:p-8 shadow-sm">
            <h2 className="text-base sm:text-lg font-black uppercase tracking-tight text-[#1F2B20] mb-3">
              6. Limitation of Liability
            </h2>
            <p className="mb-3">
              This website is provided on an &ldquo;as is&rdquo; and &ldquo;as available&rdquo; basis without warranties of any kind. To the fullest extent permitted under applicable law in India, Burger Cartel, its owners, and its staff shall not be liable for any direct, indirect, incidental, or consequential damages resulting from website downtime, inaccuracies in posted content, or reliance on information provided herein.
            </p>
            <p>
              Nothing in these terms limits or excludes any statutory consumer rights that cannot be disclaimed under the <em>Consumer Protection Act, 2019</em>.
            </p>
          </section>

          {/* Section 7: Governing Law */}
          <section className="bg-white border border-[#E8DED0] rounded-2xl p-6 sm:p-8 shadow-sm">
            <h2 className="text-base sm:text-lg font-black uppercase tracking-tight text-[#1F2B20] mb-3">
              7. Governing Law &amp; Jurisdiction
            </h2>
            <p>
              These terms and your use of this website are governed by the laws of India. Any legal dispute or claim arising in connection with the website shall be subject to the exclusive jurisdiction of the competent courts in West Bengal, India.
            </p>
          </section>
        </div>

        {/* Footer back link */}
        <div className="mt-12 pt-6 border-t border-[#E8DED0] flex items-center justify-between text-xs text-[#736F67]">
          <Link href="/" className="hover:text-[#1F2B20] font-semibold flex items-center gap-1 transition-colors">
            <span>&larr; Back to Home</span>
          </Link>
          <Link href="/privacy-policy" className="hover:text-[#1F2B20] transition-colors">
            View Privacy Policy &rarr;
          </Link>
        </div>
      </main>

      <Footer />
    </div>
  );
}
