import type { Metadata } from "next";
import { connection } from "next/server";
import { notFound } from "next/navigation";

import Link from "next/link";
import Image from "next/image";
import {
  MapPin,
  Clock,
  Phone,
  Navigation,
  ChevronRight,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  ShoppingBag,
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { getCmsData } from "@/lib/db/cmsRepository";
import {
  SITE_URL,
  OUTLETS_SEO_DATA,
  generateRestaurantSchema,
  generateBreadcrumbSchema,
  safeJsonLd,
} from "@/data/seoData";

export async function generateStaticParams() {
  try {
    const cms = await getCmsData();
    return (cms.outlets || [])
      .filter((o) => o.isOpen !== false)
      .map((o) => ({ slug: o.slug }));
  } catch {
    return [
      { slug: "panchanai" },
      { slug: "pradhan-nagar" },
      { slug: "darjeeling" },
      { slug: "kurseong" },
      { slug: "shivmandir" },
    ];
  }
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const cms = await getCmsData();
  const live = (cms.outlets || []).find((o) => o.slug === slug || o.id === slug);

  // If outlet does not exist in live database or is disabled, return 404 metadata
  if (!live || live.isOpen === false) {
    return {
      title: "Outlet Not Found | Burger Cartel",
      description: "The requested Burger Cartel outlet could not be found or has been discontinued.",
      robots: { index: false, follow: false },
    };
  }

  const staticOutlet = OUTLETS_SEO_DATA[slug as keyof typeof OUTLETS_SEO_DATA];
  const name = live.name;
  const phone = live.phone || staticOutlet?.phone || "";
  const streetAddress = live.address || staticOutlet?.streetAddress || "";
  const hoursDisplay = live.hoursDisplay || staticOutlet?.hoursDisplay || "11:00 AM – 11:00 PM Daily";
  const image = live.image || staticOutlet?.image || "/images/outlets/panchanai.webp";

  const title = live.seoTitle || `${name} — ${staticOutlet?.locality || live.shortName || "North Bengal"}, West Bengal`;
  const description =
    live.metaDescription ||
    (staticOutlet
      ? `${staticOutlet.description} Address: ${streetAddress}, ${staticOutlet.addressLocality}. Open ${hoursDisplay}.${phone ? ` Phone: ${phone}.` : ""}`
      : `Visit Burger Cartel at ${streetAddress}. Handcrafted smash burgers, artisan pizza, and coffee. Open ${hoursDisplay}.${phone ? ` Phone: ${phone}.` : ""}`);

  return {
    title,
    description,
    alternates: {
      canonical: `/locations/${live.slug}`,
    },
    openGraph: {
      title: `${name} | Burger Cartel`,
      description,
      url: `${SITE_URL}/locations/${live.slug}`,
      images: [
        {
          url: image,
          width: 1200,
          height: 800,
          alt: `${name} storefront and dining atmosphere`,
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title: `${name} | Burger Cartel`,
      description,
      images: [image],
    },
    robots: {
      index: true,
      follow: true,
    },
  };
}

export default async function OutletPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  await connection();
  const { slug } = await params;
  const cms = await getCmsData();
  const live = (cms.outlets || []).find((o) => o.slug === slug || o.id === slug);

  // Dynamic branch verification: do not resurrect deleted/closed outlets from static fallbacks
  if (!live || live.isOpen === false) {
    notFound();
  }

  const staticOutlet = OUTLETS_SEO_DATA[slug as keyof typeof OUTLETS_SEO_DATA];

  const name = live.name;
  const phone = live.phone || staticOutlet?.phone || "";
  const phoneRaw = phone ? phone.replace(/[^0-9+]/g, "") : (staticOutlet?.phoneRaw || "");
  const hoursDisplay = live.hoursDisplay || staticOutlet?.hoursDisplay || "11:00 AM – 11:00 PM Daily";
  const streetAddress = live.address || staticOutlet?.streetAddress || "";
  const mapsUrl = live.googleMapsUrl || staticOutlet?.mapsUrl || `https://maps.google.com/?q=${encodeURIComponent(name + " " + streetAddress)}`;
  const image = live.image || staticOutlet?.image || "/images/outlets/panchanai.webp";

  // Dynamically update delivery platform links if set in CMS
  const deliveryPlatforms: Array<{ name: string; url: string }> = [];
  if (live.swiggyUrl) {
    deliveryPlatforms.push({ name: "Swiggy", url: live.swiggyUrl });
  } else if (staticOutlet?.deliveryPlatforms) {
    const sw = staticOutlet.deliveryPlatforms.find((p) => p.name === "Swiggy");
    if (sw) deliveryPlatforms.push(sw);
  }
  if (live.zomatoUrl) {
    deliveryPlatforms.push({ name: "Zomato", url: live.zomatoUrl });
  } else if (staticOutlet?.deliveryPlatforms) {
    const zm = staticOutlet.deliveryPlatforms.find((p) => p.name === "Zomato");
    if (zm) deliveryPlatforms.push(zm);
  }

  const outlet: import("@/data/seoData").OutletSeoData = {
    slug: live.slug,
    name,
    officialName: live.name,
    tagline: staticOutlet?.tagline || "Handcrafted Burgers & Specialty Brews",
    description: live.metaDescription || staticOutlet?.description || `Burger Cartel outlet located at ${streetAddress}.`,
    region: staticOutlet?.region || "Siliguri",
    locality: staticOutlet?.locality || live.shortName || "North Bengal",
    streetAddress,
    addressLocality: staticOutlet?.addressLocality || "North Bengal",
    addressRegion: staticOutlet?.addressRegion || "West Bengal",
    postalCode: staticOutlet?.postalCode || "734001",
    addressCountry: staticOutlet?.addressCountry || "IN",
    phone,
    phoneRaw,
    hoursDisplay,
    openingHoursSpecification: staticOutlet?.openingHoursSpecification || [
      {
        dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
        opens: "11:00",
        closes: "23:00",
      },
    ],
    latitude: live.latitude || staticOutlet?.latitude || 26.7271,
    longitude: live.longitude || staticOutlet?.longitude || 88.3953,
    mapsUrl,
    priceRange: staticOutlet?.priceRange || "₹₹",
    servesCuisine: staticOutlet?.servesCuisine || ["American", "Burgers", "Pizza", "Cafe", "Fast Food"],
    features: staticOutlet?.features || ["Dine-in", "Takeaway", "Home Delivery", "Specialty Coffee"],
    nearbyLandmarks: staticOutlet?.nearbyLandmarks || [],
    directionsNote: staticOutlet?.directionsNote || "Easily accessible from major transit points.",
    image,
    ratingValue: staticOutlet?.ratingValue || 4.8,
    reviewCount: staticOutlet?.reviewCount || 120,
    deliveryPlatforms,
  };

  const restaurantSchema = generateRestaurantSchema(outlet);
  const breadcrumbSchema = generateBreadcrumbSchema([
    { name: "Home", url: "/" },
    { name: "Locations", url: "/locations" },
    { name: outlet.name.replace("Burger Cartel — ", ""), url: `/locations/${outlet.slug}` },
  ]);

  const otherOutlets = (cms.outlets || [])
    .filter((o) => o.slug !== live.slug && o.isOpen !== false)
    .map((o) => {
      const s = OUTLETS_SEO_DATA[o.slug as keyof typeof OUTLETS_SEO_DATA];
      return {
        slug: o.slug,
        name: o.name,
        officialName: o.name,
        image: o.image || s?.image || "/images/outlets/panchanai.webp",
        locality: s?.locality || o.shortName || "North Bengal",
        hoursDisplay: o.hoursDisplay || s?.hoursDisplay || "11:00 AM – 11:00 PM Daily",
      };
    });

  return (
    <div className="relative min-h-screen bg-[#F5F0E7] text-[#292925] selection:bg-[#1F2B20] selection:text-white">
      {/* Schema.org Structured Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: safeJsonLd(restaurantSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: safeJsonLd(breadcrumbSchema) }}
      />

      {/* Navigation Bar */}
      <div className="bg-black text-white">
        <Navbar activeRoute="locations" />
      </div>

      {/* Breadcrumb Header */}
      <nav
        aria-label="Breadcrumb"
        className="border-b border-[#E8DED0] bg-[#FAF7F0] px-5 sm:px-8 md:px-12 py-3.5"
      >
        <div className="max-w-6xl mx-auto flex items-center gap-2 text-xs text-[#736F67]">
          <Link href="/" className="hover:text-[#1F2B20] transition-colors">
            Home
          </Link>
          <ChevronRight className="w-3.5 h-3.5 text-[#B18B5B]" />
          <Link
            href="/locations"
            className="hover:text-[#1F2B20] transition-colors"
          >
            Locations
          </Link>
          <ChevronRight className="w-3.5 h-3.5 text-[#B18B5B]" />
          <span className="font-semibold text-[#1F2B20]">
            {outlet.name.replace("Burger Cartel — ", "")}
          </span>
        </div>
      </nav>

      {/* Main Outlet Showcase Section */}
      <main className="max-w-6xl mx-auto px-5 sm:px-8 md:px-12 py-10 sm:py-16 space-y-12 sm:space-y-16">
        {/* HERO CARD */}
        <section className="neu-cream-card rounded-3xl p-6 sm:p-10 border border-[#E8DED0] grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 space-y-5">
            <div className="flex flex-wrap items-center gap-2.5">
              <span className="px-3 py-1 rounded-full bg-[#1F2B20] text-white text-[10px] font-bold uppercase tracking-wider">
                {outlet.region}
              </span>
              <span className="px-3 py-1 rounded-full neu-cream-pill text-[10px] font-bold uppercase tracking-wider text-[#B18B5B]">
                {outlet.locality}
              </span>
              <span className="px-3 py-1 rounded-full bg-emerald-700/10 text-emerald-800 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                Open Daily
              </span>
            </div>

            <div>
              <h1 className="text-2xl sm:text-3xl md:text-4xl font-black text-[#1F2B20] uppercase tracking-tight">
                {outlet.name}
              </h1>
              <p className="text-sm sm:text-base text-[#B18B5B] font-semibold mt-1">
                {outlet.tagline}
              </p>
            </div>

            <p className="text-xs sm:text-sm text-[#55524B] leading-relaxed">
              {outlet.description}
            </p>

            {/* Quick Summary Highlights */}
            <div className="pt-2 border-t border-[#E8DED0] space-y-2 text-xs text-[#4A4843]">
              <div className="flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-[#B18B5B] shrink-0 mt-0.5" />
                <div>
                  <strong className="text-[#1F2B20]">Daily Hours: </strong>
                  <span>{outlet.hoursDisplay}</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#B18B5B] shrink-0 mt-0.5" />
                <div>
                  <strong className="text-[#1F2B20]">Address: </strong>
                  <span>{outlet.streetAddress}, {outlet.addressLocality}, {outlet.addressRegion} {outlet.postalCode}</span>
                </div>
              </div>

              {outlet.phone && (
                <div className="flex items-center gap-2.5">
                  <Phone className="w-4 h-4 text-[#B18B5B] shrink-0" />
                  <div>
                    <strong className="text-[#1F2B20]">Phone: </strong>
                    <a
                      href={`tel:${outlet.phoneRaw}`}
                      className="hover:text-[#B18B5B] underline transition-colors"
                    >
                      {outlet.phone}
                    </a>
                  </div>
                </div>
              )}
            </div>

            {/* CTA Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-3">
              <a
                href={outlet.mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-3 rounded-full bg-[#1F2B20] text-white text-xs font-bold uppercase tracking-wider flex items-center gap-2 hover:bg-[#B18B5B] hover:text-[#1F2B20] transition-colors shadow-sm"
              >
                <Navigation className="w-3.5 h-3.5" />
                Get Directions
              </a>

              {(outlet.deliveryPlatforms || []).map((platform) => (
                <a
                  key={platform.name}
                  href={platform.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-5 py-3 rounded-full neu-cream-pill text-xs font-bold uppercase tracking-wider text-[#1F2B20] hover:border-[#1F2B20] flex items-center gap-2 transition-all"
                >
                  <ShoppingBag className="w-3.5 h-3.5 text-[#B18B5B]" />
                  Order on {platform.name}
                </a>
              ))}
            </div>
          </div>

          {/* OUTLET HERO IMAGE */}
          <div className="lg:col-span-5">
            <div className="relative w-full aspect-[4/3] rounded-2xl overflow-hidden shadow-lg border border-[#E8DED0]">
              <Image
                src={outlet.image}
                alt={`${outlet.name} storefront and dining experience`}
                fill
                priority
                className="object-cover"
                sizes="(max-width: 1024px) 100vw, 40vw"
              />
            </div>
          </div>
        </section>

        {/* DETAILED INFORMATION GRID */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* FEATURES & AMENITIES */}
          <div className="neu-cream-card rounded-3xl p-6 sm:p-8 border border-[#E8DED0] space-y-4">
            <div className="flex items-center gap-2 text-[#B18B5B]">
              <Sparkles className="w-5 h-5" />
              <h2 className="text-sm font-bold uppercase tracking-wider text-[#1F2B20]">
                Branch Amenities & Features
              </h2>
            </div>
            <p className="text-xs text-[#55524B]">
              Every Burger Cartel outlet is designed to deliver a premier dining atmosphere with fresh culinary preparation:
            </p>
            <div className="grid grid-cols-2 gap-2.5 pt-2">
              {outlet.features.map((feature) => (
                <div
                  key={feature}
                  className="flex items-center gap-2 text-xs font-medium text-[#292925]"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </div>

          {/* HOURS OF OPERATION */}
          <div className="neu-cream-card rounded-3xl p-6 sm:p-8 border border-[#E8DED0] space-y-4">
            <div className="flex items-center gap-2 text-[#B18B5B]">
              <Clock className="w-5 h-5" />
              <h2 className="text-sm font-bold uppercase tracking-wider text-[#1F2B20]">
                Weekly Operating Schedule
              </h2>
            </div>
            <div className="space-y-2 pt-1 text-xs">
              {live.dailyHours && live.dailyHours.length > 0 ? (
                live.dailyHours.map((sched: { day?: string; hours?: string }) => (
                  <div
                    key={sched.day}
                    className="flex justify-between py-1.5 border-b border-[#E8DED0]/70 text-[#4A4843]"
                  >
                    <span className="font-semibold text-[#1F2B20]">{sched.day}</span>
                    <span>{sched.hours}</span>
                  </div>
                ))
              ) : (
                <div className="flex justify-between py-1.5 border-b border-[#E8DED0]/70 text-[#4A4843]">
                  <span className="font-semibold text-[#1F2B20]">Monday – Sunday</span>
                  <span>{outlet.hoursDisplay}</span>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* OTHER OUTLETS CROSS-LINKING SECTION */}
        {otherOutlets.length > 0 && (
          <section className="pt-8 border-t border-[#E8DED0]">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg sm:text-xl font-black text-[#1F2B20] uppercase tracking-tight">
                Other Burger Cartel Outlets in North Bengal
              </h2>
              <Link
                href="/locations"
                className="text-xs font-bold text-[#B18B5B] hover:text-[#1F2B20] flex items-center gap-1 transition-colors"
              >
                View All Outlets
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {otherOutlets.map((other) => (
                <Link
                  key={other.slug}
                  href={`/locations/${other.slug}`}
                  className="neu-cream-card rounded-2xl p-4 border border-[#E8DED0]/70 hover:shadow-md transition-all group flex flex-col justify-between"
                >
                  <div>
                    <div className="relative w-full h-28 rounded-xl overflow-hidden mb-3 bg-[#E8DED0]">
                      <Image
                        src={other.image}
                        alt={other.officialName}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                        sizes="(max-width: 640px) 100vw, 25vw"
                      />
                    </div>
                    <h3 className="font-bold text-xs text-[#1F2B20] uppercase tracking-tight group-hover:text-[#B18B5B] transition-colors">
                      {other.name.replace("Burger Cartel — ", "")}
                    </h3>
                    <p className="text-[11px] text-[#736F67] mt-0.5 line-clamp-1">
                      {other.locality}
                    </p>
                  </div>
                  <div className="mt-3 pt-2 border-t border-[#E8DED0] flex items-center justify-between text-[10px] text-[#B18B5B] font-bold uppercase tracking-wider">
                    <span>{other.hoursDisplay.split("(")[0].trim()}</span>
                    <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}
      </main>

      {/* Unified Brand Footer */}
      <Footer />
    </div>
  );
}
