import type { Metadata } from "next";
import { connection } from "next/server";

import Link from "next/link";
import Image from "next/image";
import {
  MapPin,
  Clock,
  Phone,
  Navigation,
  ExternalLink,
  ChevronRight,
  Sparkles,
  ArrowRight,
  ShieldCheck,
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { getCmsData } from "@/lib/db/cmsRepository";
import {
  SITE_URL,
  ALL_OUTLETS_LIST,
  generateBreadcrumbSchema,
  safeJsonLd,
} from "@/data/seoData";

export async function generateMetadata(): Promise<Metadata> {
  const cms = await getCmsData();
  const seo = cms.siteContent.seo?.locations;

  const count = (cms.outlets || []).filter((o) => o.isOpen !== false).length || 5;
  const title = seo?.title || `All ${count} Outlets & Locations in North Bengal`;
  const description =
    seo?.description ||
    `Find all ${count} official Burger Cartel locations across Siliguri (Panchanai, Pradhan Nagar, Shivmandir), Darjeeling (Chauk Bazaar), and Kurseong (Clock Tower). Verified physical addresses, daily operating hours, phone numbers, and directions.`;
  const ogImage = seo?.ogImage || "/images/og-image.png";

  return {
    title,
    description,
    alternates: {
      canonical: "/locations",
    },
    openGraph: {
      title: seo?.title || "Burger Cartel Outlets | Darjeeling, Kurseong & Siliguri",
      description,
      url: `${SITE_URL}/locations`,
      images: [
        {
          url: ogImage,
          width: 1200,
          height: 630,
          type: "image/png",
          alt: "Burger Cartel verified outlets across North Bengal",
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title: seo?.title || "Burger Cartel Outlets | Darjeeling, Kurseong & Siliguri",
      description,
      images: [ogImage],
    },
    robots: {
      index: !seo?.noindex,
      follow: !seo?.noindex,
    },
  };
}

interface OutletSource {
  slug: string;
  name?: string;
  phone?: string;
  phoneRaw?: string;
  hoursDisplay?: string;
  address?: string;
  streetAddress?: string;
  googleMapsUrl?: string;
  mapsUrl?: string;
  image?: string;
  latitude?: number;
  longitude?: number;
  isFeatured?: boolean;
  isOpen?: boolean;
  shortName?: string;
  metaDescription?: string;
}

export default async function LocationsPage() {
  await connection();
  const cms = await getCmsData();
  const cmsOutlets = cms.outlets || [];
  const activeOutlets = cmsOutlets.filter((o) => o.isOpen !== false);
  const sourceOutlets: OutletSource[] = activeOutlets.length > 0 ? activeOutlets : (ALL_OUTLETS_LIST as unknown as OutletSource[]);

  const mergedOutlets = sourceOutlets.map((liveOrStatic: OutletSource) => {
    const slug = liveOrStatic.slug;
    const staticOutlet = ALL_OUTLETS_LIST.find((s) => s.slug === slug);
    const live = cmsOutlets.find((o) => o.slug === slug);

    const name = live?.name || staticOutlet?.name || liveOrStatic.name || "Burger Cartel";
    const phone = live?.phone || staticOutlet?.phone || liveOrStatic.phone || "";
    const phoneRaw = phone ? phone.replace(/[^0-9+]/g, "") : (staticOutlet?.phoneRaw || "");
    const hoursDisplay = live?.hoursDisplay || staticOutlet?.hoursDisplay || liveOrStatic.hoursDisplay || "11:00 AM – 11:00 PM Daily";
    const streetAddress = live?.address || staticOutlet?.streetAddress || liveOrStatic.address || "";
    const mapsUrl = live?.googleMapsUrl || staticOutlet?.mapsUrl || `https://maps.google.com/?q=${encodeURIComponent(name + " " + streetAddress)}`;
    const image = live?.image || staticOutlet?.image || liveOrStatic.image || "/images/outlets/panchanai.webp";

    return {
      slug,
      name,
      officialName: name,
      locality: staticOutlet?.locality || live?.shortName || "North Bengal",
      region: staticOutlet?.region || "West Bengal",
      addressLocality: staticOutlet?.addressLocality || "North Bengal",
      addressRegion: staticOutlet?.addressRegion || "West Bengal",
      postalCode: staticOutlet?.postalCode || "734001",
      tagline: staticOutlet?.tagline || "Handcrafted Burgers & Specialty Brews",
      description: live?.metaDescription || staticOutlet?.description || `Burger Cartel outlet located at ${streetAddress}.`,
      features: staticOutlet?.features || ["Dine-in", "Takeaway", "Home Delivery", "Specialty Coffee"],
      phone,
      phoneRaw,
      hoursDisplay,
      streetAddress,
      mapsUrl,
      image,
      latitude: live?.latitude || staticOutlet?.latitude || 26.7271,
      longitude: live?.longitude || staticOutlet?.longitude || 88.3953,
      isFeatured: live?.isFeatured ?? (staticOutlet as unknown as { isFeatured?: boolean })?.isFeatured ?? true,
    };
  });

  const breadcrumbSchema = generateBreadcrumbSchema([
    { name: "Home", url: "/" },
    { name: "Locations", url: "/locations" },
  ]);

  const itemListSchema = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    name: "Burger Cartel Official Outlets",
    description:
      "Directory of all 5 verified Burger Cartel restaurants across North Bengal.",
    numberOfItems: mergedOutlets.length,
    itemListElement: mergedOutlets.map((outlet, index) => ({
      "@type": "ListItem",
      position: index + 1,
      item: {
        "@type": "Restaurant",
        name: outlet.officialName,
        url: `${SITE_URL}/locations/${outlet.slug}`,
        telephone: outlet.phone,
        address: {
          "@type": "PostalAddress",
          streetAddress: outlet.streetAddress,
          addressLocality: outlet.addressLocality,
          addressRegion: outlet.addressRegion,
          postalCode: outlet.postalCode,
          addressCountry: "IN",
        },
        geo: {
          "@type": "GeoCoordinates",
          latitude: outlet.latitude,
          longitude: outlet.longitude,
        },
      },
    })),
  };

  const siliguriOutlets = mergedOutlets.filter(
    (o) => o.region === "Siliguri"
  );
  const hillsOutlets = mergedOutlets.filter(
    (o) => o.region === "Darjeeling" || o.region === "Kurseong"
  );

  return (
    <div className="relative min-h-screen bg-[#F5F0E7] text-[#292925] selection:bg-[#1F2B20] selection:text-white">
      {/* Schema.org Structured Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: safeJsonLd(breadcrumbSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: safeJsonLd(itemListSchema) }}
      />

      {/* Navigation Bar */}
      <div className="bg-black text-white">
        <Navbar activeRoute="locations" />
      </div>

      {/* Breadcrumb Header */}
      <section className="border-b border-[#E8DED0] bg-[#FAF7F0] px-5 sm:px-8 md:px-12 py-3.5">
        <div className="max-w-6xl mx-auto flex items-center gap-2 text-xs text-[#736F67]">
          <Link href="/" className="hover:text-[#1F2B20] transition-colors">
            Home
          </Link>
          <ChevronRight className="w-3.5 h-3.5 text-[#B18B5B]" />
          <span className="font-semibold text-[#1F2B20]">Locations</span>
        </div>
      </section>

      {/* Page Hero Header */}
      <header className="py-12 sm:py-16 md:py-20 px-5 sm:px-8 md:px-12 text-center max-w-4xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full neu-cream-pill text-[11px] font-bold uppercase tracking-[0.2em] text-[#B18B5B] mb-4">
          <Sparkles className="w-3.5 h-3.5 text-[#B18B5B]" />
          5 Verified Locations
        </div>
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-black text-[#1F2B20] tracking-tight uppercase mb-4">
          OUR LOCATIONS
        </h1>
        <p className="text-base sm:text-lg text-[#55524B] leading-relaxed max-w-2xl mx-auto">
          From the misty ridge of Darjeeling and the heritage Clock Tower of Kurseong to the bustling student hubs and dining corridors of Siliguri.
        </p>
      </header>

      {/* Main Content Directory */}
      <main className="max-w-6xl mx-auto px-5 sm:px-8 md:px-12 pb-24 space-y-16">
        {/* SECTION 1: Siliguri Outlets */}
        <section>
          <div className="flex items-center justify-between border-b border-[#E8DED0] pb-4 mb-8">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-[#1F2B20] uppercase tracking-wide">
                Siliguri &amp; Foothills (3 Outlets)
              </h2>
              <p className="text-xs sm:text-sm text-[#736F67] mt-0.5">
                Convenient dining along major transit routes, university hubs, and city centers
              </p>
            </div>
            <span className="hidden sm:inline-block text-xs font-bold text-[#B18B5B] uppercase tracking-wider">
              Open Daily
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
            {siliguriOutlets.map((outlet) => (
              <article
                key={outlet.slug}
                className="neu-cream-card rounded-2xl sm:rounded-3xl p-6 sm:p-7 flex flex-col justify-between hover:shadow-lg transition-all border border-[#E8DED0]/70"
              >
                <div>
                  <div className="relative w-full h-44 rounded-xl overflow-hidden mb-5 bg-[#E8DED0]">
                    <Image
                      src={outlet.image}
                      alt={outlet.officialName}
                      fill
                      className="object-cover"
                      sizes="(max-width: 768px) 100vw, 33vw"
                    />
                    <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/75 backdrop-blur-sm text-white text-[10px] font-bold uppercase tracking-wider">
                      {outlet.locality}
                    </div>
                  </div>

                  <h3 className="text-lg sm:text-xl font-black text-[#1F2B20] uppercase tracking-tight mb-1">
                    {outlet.name}
                  </h3>
                  <p className="text-xs text-[#B18B5B] font-semibold mb-3">
                    {outlet.tagline}
                  </p>

                  <div className="space-y-2.5 text-xs text-[#55524B] mb-6">
                    <div className="flex items-start gap-2.5">
                      <Clock className="w-4 h-4 text-[#B18B5B] shrink-0 mt-0.5" />
                      <span className="font-medium text-[#1F2B20]">
                        {outlet.hoursDisplay}
                      </span>
                    </div>
                    <div className="flex items-start gap-2.5">
                      <MapPin className="w-4 h-4 text-[#B18B5B] shrink-0 mt-0.5" />
                      <span>{outlet.streetAddress}, {outlet.addressLocality}</span>
                    </div>
                    {outlet.phone && (
                      <div className="flex items-center gap-2.5">
                        <Phone className="w-4 h-4 text-[#B18B5B] shrink-0" />
                        <a
                          href={`tel:${outlet.phoneRaw}`}
                          className="hover:text-[#1F2B20] hover:underline font-medium"
                        >
                          {outlet.phone}
                        </a>
                      </div>
                    )}
                  </div>
                </div>

                <div className="pt-4 border-t border-[#E8DED0] space-y-2.5">
                  <Link
                    href={`/locations/${outlet.slug}`}
                    className="w-full py-2.5 px-4 rounded-xl neu-cream-pill text-xs font-bold text-[#1F2B20] flex items-center justify-center gap-2 hover:bg-[#FAF7F0] transition-colors"
                  >
                    View Details &amp; Menu
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                  <a
                    href={outlet.mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2 px-4 rounded-xl text-xs font-semibold text-[#736F67] hover:text-[#1F2B20] flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Navigation className="w-3.5 h-3.5 text-[#B18B5B]" />
                    Get Directions
                    <ExternalLink className="w-3 h-3 opacity-60" />
                  </a>
                </div>
              </article>
            ))}
          </div>
        </section>

        {/* SECTION 2: Darjeeling & Kurseong Hills Outlets */}
        <section>
          <div className="flex items-center justify-between border-b border-[#E8DED0] pb-4 mb-8">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-[#1F2B20] uppercase tracking-wide">
                Darjeeling &amp; Kurseong Hills (2 Outlets)
              </h2>
              <p className="text-xs sm:text-sm text-[#736F67] mt-0.5">
                Heritage hill stations, scenic Himalayan vistas, and cozy cafe vibes
              </p>
            </div>
            <span className="hidden sm:inline-block text-xs font-bold text-[#B18B5B] uppercase tracking-wider">
              Open Daily
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8 max-w-4xl mx-auto">
            {hillsOutlets.map((outlet) => (
              <article
                key={outlet.slug}
                className="neu-cream-card rounded-2xl sm:rounded-3xl p-6 sm:p-7 flex flex-col justify-between hover:shadow-lg transition-all border border-[#E8DED0]/70"
              >
                <div>
                  <div className="relative w-full h-48 rounded-xl overflow-hidden mb-5 bg-[#E8DED0]">
                    <Image
                      src={outlet.image}
                      alt={outlet.officialName}
                      fill
                      className="object-cover"
                      sizes="(max-width: 768px) 100vw, 50vw"
                    />
                    <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/75 backdrop-blur-sm text-white text-[10px] font-bold uppercase tracking-wider">
                      {outlet.locality}
                    </div>
                  </div>

                  <h3 className="text-lg sm:text-xl font-black text-[#1F2B20] uppercase tracking-tight mb-1">
                    {outlet.name}
                  </h3>
                  <p className="text-xs text-[#B18B5B] font-semibold mb-3">
                    {outlet.tagline}
                  </p>

                  <div className="space-y-2.5 text-xs text-[#55524B] mb-6">
                    <div className="flex items-start gap-2.5">
                      <Clock className="w-4 h-4 text-[#B18B5B] shrink-0 mt-0.5" />
                      <span className="font-medium text-[#1F2B20]">
                        {outlet.hoursDisplay}
                      </span>
                    </div>
                    <div className="flex items-start gap-2.5">
                      <MapPin className="w-4 h-4 text-[#B18B5B] shrink-0 mt-0.5" />
                      <span>{outlet.streetAddress}, {outlet.addressLocality}</span>
                    </div>
                    {outlet.phone && (
                      <div className="flex items-center gap-2.5">
                        <Phone className="w-4 h-4 text-[#B18B5B] shrink-0" />
                        <a
                          href={`tel:${outlet.phoneRaw}`}
                          className="hover:text-[#1F2B20] hover:underline font-medium"
                        >
                          {outlet.phone}
                        </a>
                      </div>
                    )}
                  </div>
                </div>

                <div className="pt-4 border-t border-[#E8DED0] space-y-2.5">
                  <Link
                    href={`/locations/${outlet.slug}`}
                    className="w-full py-2.5 px-4 rounded-xl neu-cream-pill text-xs font-bold text-[#1F2B20] flex items-center justify-center gap-2 hover:bg-[#FAF7F0] transition-colors"
                  >
                    View Details &amp; Menu
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                  <a
                    href={outlet.mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2 px-4 rounded-xl text-xs font-semibold text-[#736F67] hover:text-[#1F2B20] flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Navigation className="w-3.5 h-3.5 text-[#B18B5B]" />
                    Get Directions
                    <ExternalLink className="w-3 h-3 opacity-60" />
                  </a>
                </div>
              </article>
            ))}
          </div>
        </section>

        {/* SECTION 3: Verified Geographic Information & FAQs */}
        <section className="neu-cream-card rounded-3xl p-8 sm:p-10 border border-[#E8DED0]">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-9 h-9 rounded-full neu-cream-pill flex items-center justify-center text-[#B18B5B]">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-[#1F2B20] uppercase tracking-wide">
                Verified Regional Coverage &amp; Visitor FAQs
              </h2>
              <p className="text-xs text-[#736F67]">
                Accurate local dining guidance for North Bengal residents and travelers
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-[#55524B] leading-relaxed">
            <div className="p-4 rounded-2xl bg-[#FAF7F0]/80 border border-[#E8DED0]/60 space-y-2">
              <h3 className="font-bold text-[#1F2B20] text-sm">
                Where are Burger Cartel outlets physically located?
              </h3>
              <p>
                Burger Cartel has five official outlets located exclusively in West Bengal across the districts of Darjeeling and Siliguri:
                Darjeeling (Hotel Seven Seas Building, Chauk Bazaar), Kurseong (Top Floor Clock Tower), Siliguri Panchanai (Parijat Road, Salbari), Siliguri Pradhan Nagar (Nivedita Road), and Shivmandir (near North Bengal University).
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-[#FAF7F0]/80 border border-[#E8DED0]/60 space-y-2">
              <h3 className="font-bold text-[#1F2B20] text-sm">
                Do you have branches in Sikkim or Nepal?
              </h3>
              <p>
                No. Burger Cartel does not operate physical restaurant branches in Sikkim or Nepal. However, because our Siliguri, Panchanai, and Kurseong outlets are situated directly along the primary transit highways connecting Siliguri to Gangtok and eastern Nepal (Kakarbhitta), travelers frequently stop by for breakfast, smash burgers, and coffee on their journey.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-[#FAF7F0]/80 border border-[#E8DED0]/60 space-y-2">
              <h3 className="font-bold text-[#1F2B20] text-sm">
                Is parking available at your outlets?
              </h3>
              <p>
                Our Panchanai (Salbari / Parijat Road) outlet features a large, dedicated private parking facility for both cars and two-wheelers, making it the most convenient destination for highway travelers and families. The hill outlets (Darjeeling and Kurseong) are centrally located near town squares and transit points.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-[#FAF7F0]/80 border border-[#E8DED0]/60 space-y-2">
              <h3 className="font-bold text-[#1F2B20] text-sm">
                Can I order online for delivery?
              </h3>
              <p>
                Yes. Online delivery is available through Swiggy and Zomato across Siliguri, Darjeeling, and Kurseong according to platform radius and local operational hours. Visit our <Link href="/order-online" className="text-[#B18B5B] underline font-semibold">Order Online</Link> page for direct links.
              </p>
            </div>
          </div>
        </section>
      </main>

      {/* Unified Brand Footer */}
      <Footer />
    </div>
  );
}
