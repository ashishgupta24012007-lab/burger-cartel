"use client";

import React, { useEffect, useRef, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import {
  ArrowRight,
  Menu as MenuIcon,
  X as CloseIcon,
  ChefHat,
  Mountain,
  Heart,
  Globe,
  Sparkles,
} from "lucide-react";
import LocationModal from "@/components/LocationModal";
import MenuModal from "@/components/MenuModal";
import Footer from "@/components/Footer";
import { fetchCmsContentOnce } from "@/lib/client/cmsClient";

// Register GSAP ScrollTrigger plugin on client
if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger);
}

export default function AboutPage() {
  const [locationOpen, setLocationOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [aboutData, setAboutData] = useState({
    heading: "THE MAN BEHIND BURGER CARTEL",
    subheading: "A PASSION FOR GOOD FOOD, ROOTED IN DARJEELING",
    paragraph1: "Burger Cartel was founded by Kelvin Kwok, affectionately known as Kwai. Born and raised in Darjeeling, he has a special connection to the town he calls home.",
    paragraph2: "His passion for food took him beyond the hills to Le Cordon Bleu in London, where he honed his culinary craft with classic technique and international standards.",
    founderQuote: "Cooking isn't just about feeding people — it's about making them feel something they won't forget.",
  });

  useEffect(() => {
    let mounted = true;
    async function loadAbout() {
      const data = await fetchCmsContentOnce();
      if (!mounted || !data) return;
      if (data.siteContent?.about) {
        setAboutData((prev) => ({
          ...prev,
          heading: data.siteContent.about.heading || prev.heading,
          subheading: data.siteContent.about.subheading || prev.subheading,
          paragraph1: data.siteContent.about.paragraph1 || prev.paragraph1,
          paragraph2: data.siteContent.about.paragraph2 || prev.paragraph2,
          founderQuote: data.siteContent.about.founderQuote || prev.founderQuote,
        }));
      }
    }
    loadAbout();

    const handleCmsUpdate = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail?.siteContent?.about) {
        const ab = customEvent.detail.siteContent.about;
        setAboutData((prev) => ({
          ...prev,
          heading: ab.heading || prev.heading,
          subheading: ab.subheading || prev.subheading,
          paragraph1: ab.paragraph1 || prev.paragraph1,
          paragraph2: ab.paragraph2 || prev.paragraph2,
          founderQuote: ab.founderQuote || prev.founderQuote,
        }));
      }
    };

    window.addEventListener("cms:updated", handleCmsUpdate);
    return () => {
      mounted = false;
      window.removeEventListener("cms:updated", handleCmsUpdate);
    };
  }, []);

  const containerRef = useRef<HTMLDivElement>(null);
  const storytellingRef = useRef<HTMLElement>(null);
  const navRef = useRef<HTMLElement>(null);
  const portraitWrapperRef = useRef<HTMLDivElement>(null);
  const bgOverlayRef = useRef<HTMLDivElement>(null);

  // Chapter 1 Refs
  const chapter1Ref = useRef<HTMLDivElement>(null);
  const ch1HeadingLinesRef = useRef<(HTMLSpanElement | null)[]>([]);
  const ch1SubheadingRef = useRef<HTMLDivElement>(null);
  const ch1ParagraphsRef = useRef<(HTMLParagraphElement | null)[]>([]);
  const ch1HighlightsRef = useRef<HTMLDivElement>(null);
  const annotationsRef = useRef<(HTMLDivElement | null)[]>([]);

  // Chapter 2 Refs
  const chapter2Ref = useRef<HTMLDivElement>(null);
  const ch2LabelRef = useRef<HTMLSpanElement>(null);
  const ch2HeadingLinesRef = useRef<(HTMLSpanElement | null)[]>([]);
  const ch2SubheadingRef = useRef<HTMLDivElement>(null);
  const ch2ParagraphsRef = useRef<(HTMLParagraphElement | null)[]>([]);
  const ch2ClosingRef = useRef<HTMLDivElement>(null);

  // Cinematic 6-Phase Page-Entry & Scroll-Driven Storytelling Sequence
  useEffect(() => {
    // Respect user prefers-reduced-motion setting
    const prefersReducedMotion =
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    if (prefersReducedMotion) {
      if (bgOverlayRef.current) bgOverlayRef.current.style.display = "none";
      if (chapter2Ref.current) {
        chapter2Ref.current.style.opacity = "1";
        chapter2Ref.current.style.pointerEvents = "auto";
      }
      return;
    }

    const ctx = gsap.context(() => {
      // ========================================================
      // 1. INITIAL PAGE-ENTRY ANIMATION (Chapter 1 Entrance)
      // ========================================================
      const entranceTl = gsap.timeline({
        defaults: { ease: "power3.out" },
      });

      // PHASE 1 — Background Reveal
      if (bgOverlayRef.current) {
        entranceTl.to(bgOverlayRef.current, {
          opacity: 0,
          duration: 1.0,
          ease: "power2.inOut",
          onComplete: () => {
            if (bgOverlayRef.current) bgOverlayRef.current.style.display = "none";
          },
        });
      }

      // PHASE 2 — Navigation Entrance
      if (navRef.current) {
        entranceTl.fromTo(
          navRef.current,
          { opacity: 0, y: 16 },
          { opacity: 1, y: 0, duration: 0.75, ease: "power2.out" },
          "-=0.7"
        );
      }

      // PHASE 3 — Founder Portrait Rises From Below (80px up, scales 0.96 -> 1)
      if (portraitWrapperRef.current) {
        entranceTl.fromTo(
          portraitWrapperRef.current,
          { opacity: 0, y: 80, scale: 0.96 },
          { opacity: 1, y: 0, scale: 1, duration: 1.3, ease: "power3.out" },
          "-=0.6"
        );
      }

      // PHASE 4 — Chapter 1 Heading Reveals with Smooth Vertical Mask
      const ch1Lines = ch1HeadingLinesRef.current.filter(Boolean);
      if (ch1Lines.length > 0) {
        entranceTl.fromTo(
          ch1Lines,
          {
            yPercent: 110,
            opacity: 0,
          },
          {
            yPercent: 0,
            opacity: 1,
            duration: 0.85,
            stagger: 0.14,
            ease: "power3.out",
          },
          "-=0.9"
        );
      }

      // PHASE 5 — Chapter 1 Content Appears Progressively
      if (ch1SubheadingRef.current) {
        entranceTl.fromTo(
          ch1SubheadingRef.current,
          { opacity: 0, y: 14 },
          { opacity: 1, y: 0, duration: 0.6 },
          "-=0.6"
        );
      }

      const ch1Paras = ch1ParagraphsRef.current.filter(Boolean);
      if (ch1Paras.length > 0) {
        entranceTl.fromTo(
          ch1Paras,
          { opacity: 0, y: 14 },
          { opacity: 1, y: 0, duration: 0.6, stagger: 0.1 },
          "-=0.4"
        );
      }

      const annots = annotationsRef.current.filter(Boolean);
      if (annots.length > 0) {
        entranceTl.fromTo(
          annots,
          { opacity: 0, scale: 0.9 },
          { opacity: 1, scale: 1, duration: 0.65, stagger: 0.08, ease: "back.out(1.4)" },
          "-=0.4"
        );
      }

      if (ch1HighlightsRef.current) {
        const items = ch1HighlightsRef.current.querySelectorAll(".highlight-card");
        entranceTl.fromTo(
          items,
          { opacity: 0, y: 16 },
          { opacity: 1, y: 0, duration: 0.6, stagger: 0.08, ease: "power2.out" },
          "-=0.3"
        );
      }

      // ========================================================
      // 2. SCROLL-DRIVEN STORYTELLING: CHAPTER 1 -> CHAPTER 2
      // ========================================================
      const mm = gsap.matchMedia();

      // DESKTOP (>= 1024px): Pinned scrubbing transition
      // The founder portrait in the right column remains visually stationary throughout!
      mm.add("(min-width: 1024px)", () => {
        if (!storytellingRef.current || !chapter1Ref.current || !chapter2Ref.current) return;

        const scrollTl = gsap.timeline({
          scrollTrigger: {
            trigger: storytellingRef.current,
            start: "top 55px",
            end: "+=1200",
            pin: true,
            scrub: 0.8,
            anticipatePin: 1,
            invalidateOnRefresh: true,
          },
        });

        // 0. Hold Chapter 1 briefly so visitor has time to read it before scroll begins transition
        scrollTl.to({}, { duration: 0.2 });

        // 1. Fade out Chapter 1 heading and informational text
        scrollTl.to(chapter1Ref.current, {
          opacity: 0,
          y: -20,
          duration: 0.35,
          ease: "power2.inOut",
          pointerEvents: "none",
        });

        // 2. Keep founder portrait stationary; reveal Chapter 2 container
        scrollTl.to(
          chapter2Ref.current,
          { opacity: 1, y: 0, duration: 0.2, ease: "power2.inOut", pointerEvents: "auto" }
        );

        // 3. Reveal Chapter 2 Label ("CHAPTER 02 — THE VISION")
        if (ch2LabelRef.current) {
          scrollTl.fromTo(
            ch2LabelRef.current,
            { opacity: 0, x: -15 },
            { opacity: 1, x: 0, duration: 0.25, ease: "power2.out" },
            "-=0.1"
          );
        }

        // 4. Animate Chapter 2 Heading lines with smooth vertical masked reveal
        const ch2Lines = ch2HeadingLinesRef.current.filter(Boolean);
        if (ch2Lines.length > 0) {
          scrollTl.fromTo(
            ch2Lines,
            {
              yPercent: 110,
              opacity: 0,
            },
            {
              yPercent: 0,
              opacity: 1,
              duration: 0.45,
              stagger: 0.12,
              ease: "power3.out",
            },
            "-=0.08"
          );
        }

        // 5. Reveal tagline and paragraphs in smooth staggered sequence
        if (ch2SubheadingRef.current) {
          scrollTl.fromTo(
            ch2SubheadingRef.current,
            { opacity: 0, y: 12 },
            { opacity: 1, y: 0, duration: 0.25, ease: "power2.out" }
          );
        }

        const ch2Paras = ch2ParagraphsRef.current.filter(Boolean);
        if (ch2Paras.length > 0) {
          scrollTl.fromTo(
            ch2Paras,
            { opacity: 0, y: 14 },
            { opacity: 1, y: 0, duration: 0.35, stagger: 0.08, ease: "power2.out" },
            "-=0.1"
          );
        }

        // 6. Reveal closing statement last
        if (ch2ClosingRef.current) {
          scrollTl.fromTo(
            ch2ClosingRef.current,
            { opacity: 0, scale: 0.94, y: 10 },
            { opacity: 1, scale: 1, y: 0, duration: 0.3, ease: "back.out(1.5)" }
          );
        }

        // 7. Hold Chapter 2 fully visible for reading before unpinning
        scrollTl.to({}, { duration: 0.35 });
      });

      // MOBILE & TABLET (< 1024px): Seamless scroll sequence
      mm.add("(max-width: 1023px)", () => {
        if (!chapter2Ref.current) return;

        const mobileTl = gsap.timeline({
          scrollTrigger: {
            trigger: chapter2Ref.current,
            start: "top 78%",
            end: "top 35%",
            scrub: 0.8,
          },
        });

        mobileTl.fromTo(
          chapter2Ref.current,
          { opacity: 0, y: 25 },
          { opacity: 1, y: 0, duration: 0.5, pointerEvents: "auto" }
        );

        const ch2Lines = ch2HeadingLinesRef.current.filter(Boolean);
        if (ch2Lines.length > 0) {
          mobileTl.fromTo(
            ch2Lines,
            { yPercent: 110, opacity: 0 },
            {
              yPercent: 0,
              opacity: 1,
              duration: 0.5,
              stagger: 0.12,
              ease: "power3.out",
            }
          );
        }

        const ch2Paras = ch2ParagraphsRef.current.filter(Boolean);
        if (ch2Paras.length > 0) {
          mobileTl.fromTo(
            ch2Paras,
            { opacity: 0, y: 12 },
            { opacity: 1, y: 0, duration: 0.3, stagger: 0.06 }
          );
        }

        if (ch2ClosingRef.current) {
          mobileTl.fromTo(
            ch2ClosingRef.current,
            { opacity: 0, scale: 0.94 },
            { opacity: 1, scale: 1, duration: 0.25 }
          );
        }
      });
    }, containerRef);

    return () => ctx.revert();
  }, []);

  return (
    <div
      ref={containerRef}
      className="relative min-h-screen bg-[#F5F0E7] text-[#292925] overflow-x-hidden selection:bg-[#1F2B20] selection:text-white"
    >
      {/* Soft warm overlay for seamless entrance transition */}
      <div
        ref={bgOverlayRef}
        className="fixed inset-0 bg-[#FAF7F0]/60 z-50 pointer-events-none"
      />

      {/* TOP NAVIGATION BAR */}
      <header
        ref={navRef}
        className="sticky top-0 z-40 w-full bg-[#F5F0E7]/95 backdrop-blur-md border-b border-[#E8DED0]/60 transition-all"
      >
        <div className="max-w-7xl mx-auto px-5 sm:px-8 md:px-12 py-2.5 sm:py-3 flex items-center justify-between">
          {/* Left Brand Wordmark / Logo */}
          <Link
            href="/"
            className="flex items-center gap-2.5 sm:gap-3 group select-none"
          >
            <div className="relative w-11 h-11 sm:w-13 sm:h-13 rounded-full overflow-hidden shrink-0 bg-white p-1 shadow-xs border border-[#E8DED0]">
              <Image
                src="/images/logo.png"
                alt="BURGER CARTEL Logo"
                width={52}
                height={52}
                className="w-full h-full object-contain"
                priority
              />
            </div>
            <div className="flex flex-col leading-tight">
              <span className="font-sans font-black text-sm sm:text-base tracking-[0.14em] text-[#1F2B20] uppercase">
                BURGER CARTEL
              </span>
              <span className="font-sans text-[8px] sm:text-[9px] font-bold tracking-[0.24em] text-[#B18B5B] uppercase mt-0.5">
                EST. DARJEELING
              </span>
            </div>
          </Link>

          {/* Center Navigation Links: HOME | ABOUT | ORDER ONLINE | MENU | OUTLETS | GALLERY | CONTACT */}
          <nav className="hidden md:flex items-center gap-6 lg:gap-8 text-xs font-bold tracking-[0.2em] uppercase text-[#4A4843]">
            <Link
              href="/"
              className="hover:text-[#1F2B20] transition-colors py-1"
            >
              HOME
            </Link>

            {/* Active ABOUT Link with Warm Caramel Underline */}
            <div className="relative py-1 text-[#1F2B20]">
              <span>ABOUT</span>
              <span className="absolute bottom-[-3px] left-0 right-0 h-[2px] bg-[#B18B5B] rounded-full" />
            </div>

            <Link
              href="/order-online"
              className="hover:text-[#1F2B20] transition-colors py-1"
            >
              ORDER ONLINE
            </Link>

            <Link
              href="/menu"
              className="hover:text-[#1F2B20] transition-colors py-1 cursor-pointer"
            >
              MENU
            </Link>

            <button
              type="button"
              onClick={() => setLocationOpen(true)}
              className="hover:text-[#1F2B20] transition-colors py-1 cursor-pointer"
            >
              OUTLETS
            </button>

            <Link
              href="/#gallery"
              className="hover:text-[#1F2B20] transition-colors py-1"
            >
              GALLERY
            </Link>

            <button
              type="button"
              onClick={() => setLocationOpen(true)}
              className="hover:text-[#1F2B20] transition-colors py-1 cursor-pointer"
            >
              CONTACT
            </button>
          </nav>

          {/* Right Action: Forest Green "VISIT A BRANCH →" Pill Button */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setLocationOpen(true)}
              className="group px-5 sm:px-6 py-2 sm:py-2.5 rounded-full bg-[#1F2B20] hover:bg-[#2a3c2b] text-white text-xs font-bold tracking-[0.16em] uppercase flex items-center gap-2 shadow-md hover:shadow-lg transition-all cursor-pointer select-none"
            >
              <span>VISIT A BRANCH</span>
              <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
            </button>

            {/* Mobile Menu Hamburger */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-[#1F2B20] md:hidden transition-colors"
              aria-label="Toggle navigation"
            >
              {mobileMenuOpen ? (
                <CloseIcon className="w-5 h-5" />
              ) : (
                <MenuIcon className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-[#E8DED0] bg-[#FAF7F0] px-6 py-5 flex flex-col gap-3.5 animate-in fade-in slide-in-from-top-2">
            <Link
              href="/"
              onClick={() => setMobileMenuOpen(false)}
              className="text-xs font-bold tracking-[0.2em] uppercase text-[#4A4843] hover:text-[#1F2B20] py-1"
            >
              HOME
            </Link>
            <div className="text-xs font-black tracking-[0.2em] uppercase text-[#1F2B20] py-1 flex items-center justify-between">
              <span>ABOUT</span>
              <span className="w-2 h-2 rounded-full bg-[#B18B5B]" />
            </div>
            <Link
              href="/order-online"
              onClick={() => setMobileMenuOpen(false)}
              className="text-xs font-bold tracking-[0.2em] uppercase text-[#4A4843] hover:text-[#1F2B20] py-1"
            >
              ORDER ONLINE
            </Link>
            <Link
              href="/menu"
              onClick={() => setMobileMenuOpen(false)}
              className="text-left text-xs font-bold tracking-[0.2em] uppercase text-[#4A4843] hover:text-[#1F2B20] py-1"
            >
              MENU
            </Link>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                setLocationOpen(true);
              }}
              className="text-left text-xs font-bold tracking-[0.2em] uppercase text-[#4A4843] hover:text-[#1F2B20] py-1"
            >
              OUTLETS (5 BRANCHES)
            </button>
            <Link
              href="/#gallery"
              onClick={() => setMobileMenuOpen(false)}
              className="text-xs font-bold tracking-[0.2em] uppercase text-[#4A4843] hover:text-[#1F2B20] py-1"
            >
              GALLERY
            </Link>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                setLocationOpen(true);
              }}
              className="text-left text-xs font-bold tracking-[0.2em] uppercase text-[#4A4843] hover:text-[#1F2B20] py-1"
            >
              CONTACT
            </button>
            <Link
              href="/order-online"
              onClick={() => setMobileMenuOpen(false)}
              className="w-full mt-2 py-3 rounded-full bg-[#1F2B20] text-white text-xs font-bold uppercase tracking-widest text-center block"
            >
              ORDER ONLINE ↗
            </Link>
          </div>
        )}
      </header>

      {/* MAIN CONTENT STAGE: SCROLL-DRIVEN STORYTELLING SECTION */}
      <section
        ref={storytellingRef}
        className="relative max-w-7xl mx-auto px-5 sm:px-8 md:px-12 pt-4 sm:pt-6 md:pt-8 pb-10 sm:pb-14 flex flex-col justify-center min-h-[calc(100vh-65px)]"
      >
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-center">
          
          {/* LEFT COLUMN: CHAPTER 1 & CHAPTER 2 STORYTELLING PANELS */}
          <div className="lg:col-span-7 relative min-h-[500px] sm:min-h-[540px] flex flex-col justify-center">
            
            {/* ========================================================
               CHAPTER 1: THE FOUNDER (Spacious, Clean, High-End Editorial)
               ======================================================== */}
            <div
              ref={chapter1Ref}
              className="chapter-1 w-full flex flex-col justify-center transition-all duration-300"
            >
              {/* Small uppercase label: OUR FOUNDER */}
              <span className="text-xs font-bold tracking-[0.28em] text-[#B18B5B] uppercase block mb-2">
                OUR FOUNDER
              </span>

              {/* Main Display Headline (Clean Editorial Reveal) */}
              <h1 className="font-sans font-black text-3xl sm:text-4xl md:text-[3.2rem] lg:text-[3.5rem] xl:text-[3.8rem] tracking-[-0.035em] leading-[0.92] uppercase select-none mb-3 sm:mb-4">
                <span className="block overflow-hidden pb-1">
                  <span
                    ref={(el) => {
                      ch1HeadingLinesRef.current[0] = el;
                    }}
                    className="block text-[#1F2B20]"
                  >
                    {aboutData.heading}
                  </span>
                </span>
              </h1>

              {/* Subheading / Tagline */}
              <div ref={ch1SubheadingRef} className="mb-3.5 sm:mb-4">
                <p className="font-sans text-xs sm:text-[13px] font-bold tracking-[0.24em] text-[#4A4843] uppercase leading-relaxed">
                  {aboutData.subheading}
                </p>
              </div>

              {/* Chapter 1 Story Paragraphs (Spacious, Clean, Highly Legible) */}
              <div className="space-y-3 sm:space-y-3.5 max-w-xl text-[13.5px] sm:text-[14px] md:text-[14.5px] text-[#4A4843] leading-[1.65] font-normal">
                <p
                  ref={(el) => {
                    ch1ParagraphsRef.current[0] = el;
                  }}
                >
                  {aboutData.paragraph1}
                </p>
                <p
                  ref={(el) => {
                    ch1ParagraphsRef.current[1] = el;
                  }}
                >
                  {aboutData.paragraph2}
                </p>
                <p
                  ref={(el) => {
                    ch1ParagraphsRef.current[2] = el;
                  }}
                >
                  In 2020, during the COVID-19 pandemic, Kwai returned to
                  Darjeeling and started Burger Cartel as a small home-based cloud
                  kitchen.
                </p>
                <p
                  ref={(el) => {
                    ch1ParagraphsRef.current[3] = el;
                  }}
                >
                  The idea soon grew beyond his initial setup. He turned a space on
                  the first floor of Hotel Seven Seas into Burger Cartel&apos;s
                  first physical café, bringing handcrafted burgers, Neapolitan
                  sourdough pizzas, and a fresh food experience to his hometown.
                </p>
              </div>

              {/* Founder Quote */}
              {aboutData.founderQuote && (
                <div className="mt-4 p-4 rounded-xl border-l-2 border-[#B18B5B] bg-[#E8DED0]/30 italic text-sm text-[#1F2B20]">
                  &ldquo;{aboutData.founderQuote}&rdquo;
                  <span className="block not-italic text-xs font-bold uppercase tracking-wider text-[#B18B5B] mt-1.5">
                    — Kelvin Kwok (Kwai), Founder
                  </span>
                </div>
              )}

              {/* Three Bottom Highlights */}
              <div
                ref={ch1HighlightsRef}
                className="mt-5 sm:mt-6 pt-4 border-t border-[#E8DED0] flex flex-wrap items-center gap-4 sm:gap-6"
              >
                {/* Highlight 1: Chef Hat */}
                <div className="highlight-card flex items-center gap-2.5">
                  <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full neu-cream-disc flex items-center justify-center shrink-0">
                    <ChefHat className="w-4 h-4 text-[#B18B5B]" />
                  </div>
                  <div>
                    <span className="block text-[9.5px] sm:text-[10px] font-bold tracking-[0.18em] text-[#1F2B20] uppercase leading-tight">
                      GLOBALLY
                    </span>
                    <span className="block text-[9.5px] sm:text-[10px] font-bold tracking-[0.18em] text-[#1F2B20] uppercase leading-tight">
                      TRAINED CHEF
                    </span>
                  </div>
                </div>

                <div className="hidden sm:block w-[1px] h-6 bg-[#E8DED0]" />

                {/* Highlight 2: Mountain */}
                <div className="highlight-card flex items-center gap-2.5">
                  <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full neu-cream-disc flex items-center justify-center shrink-0">
                    <Mountain className="w-4 h-4 text-[#B18B5B]" />
                  </div>
                  <div>
                    <span className="block text-[9.5px] sm:text-[10px] font-bold tracking-[0.18em] text-[#1F2B20] uppercase leading-tight">
                      BORN &amp; RAISED
                    </span>
                    <span className="block text-[9.5px] sm:text-[10px] font-bold tracking-[0.18em] text-[#1F2B20] uppercase leading-tight">
                      IN DARJEELING
                    </span>
                  </div>
                </div>

                <div className="hidden sm:block w-[1px] h-6 bg-[#E8DED0]" />

                {/* Highlight 3: Heart */}
                <div className="highlight-card flex items-center gap-2.5">
                  <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full neu-cream-disc flex items-center justify-center shrink-0">
                    <Heart className="w-4 h-4 text-[#B18B5B]" />
                  </div>
                  <div>
                    <span className="block text-[9.5px] sm:text-[10px] font-bold tracking-[0.18em] text-[#1F2B20] uppercase leading-tight">
                      A PASSIONATE
                    </span>
                    <span className="block text-[9.5px] sm:text-[10px] font-bold tracking-[0.18em] text-[#1F2B20] uppercase leading-tight">
                      FOOD ENTREPRENEUR
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* ========================================================
               CHAPTER 2: THE VISION (Smooth Scroll-Driven Reveal)
               ======================================================== */}
            <div
              ref={chapter2Ref}
              className="chapter-2 w-full lg:absolute lg:inset-0 flex flex-col justify-center opacity-0 pointer-events-none mt-10 lg:mt-0 transition-all duration-300"
            >
              {/* Small uppercase label: CHAPTER 02 — THE VISION */}
              <span
                ref={ch2LabelRef}
                className="text-xs font-bold tracking-[0.28em] text-[#B18B5B] uppercase block mb-2"
              >
                CHAPTER 02 — THE VISION
              </span>

              {/* Main Heading */}
              <h2 className="font-sans font-black text-3xl sm:text-4xl md:text-[3rem] lg:text-[3.3rem] xl:text-[3.6rem] tracking-[-0.035em] leading-[0.92] uppercase select-none mb-3 sm:mb-4">
                <span className="block overflow-hidden pb-1">
                  <span
                    ref={(el) => {
                      ch2HeadingLinesRef.current[0] = el;
                    }}
                    className="block text-[#1F2B20]"
                  >
                    MORE THAN A BURGER.
                  </span>
                </span>
                <span className="block overflow-hidden pb-1">
                  <span
                    ref={(el) => {
                      ch2HeadingLinesRef.current[1] = el;
                    }}
                    className="block text-[#B18B5B]"
                  >
                    A WHOLE EXPERIENCE.
                  </span>
                </span>
              </h2>

              {/* Supporting Tagline: BOLD FLAVOURS. UNCOMMON CHARACTER. */}
              <div ref={ch2SubheadingRef} className="mb-3.5 sm:mb-4">
                <p className="font-sans text-xs sm:text-[13px] font-bold tracking-[0.24em] text-[#4A4843] uppercase leading-relaxed">
                  BOLD FLAVOURS. UNCOMMON CHARACTER.
                </p>
              </div>

              {/* Chapter 2 Story Paragraphs (Spacious, Clean, Highly Legible) */}
              <div className="space-y-3 sm:space-y-3.5 max-w-xl text-[13.5px] sm:text-[14px] md:text-[14.5px] text-[#4A4843] leading-[1.65] font-normal">
                <p
                  ref={(el) => {
                    ch2ParagraphsRef.current[0] = el;
                  }}
                >
                  For Kwai, great food is about more than what is on the plate.
                  It is about bringing people together, exploring flavours, and
                  creating moments worth remembering.
                </p>
                <p
                  ref={(el) => {
                    ch2ParagraphsRef.current[1] = el;
                  }}
                >
                  That spirit lives in Burger Cartel&apos;s bold personality,
                  handcrafted burgers, and wood-fired pizzas. Every detail
                  reflects a love for good food served with character.
                </p>
                <p
                  ref={(el) => {
                    ch2ParagraphsRef.current[2] = el;
                  }}
                >
                  Inspired by the playful world of a cartel, the brand brings
                  its own attitude to the table—unconventional, full of flavour,
                  and never ordinary.
                </p>
                <p
                  ref={(el) => {
                    ch2ParagraphsRef.current[3] = el;
                  }}
                >
                  What makes it special is the feeling it aims to create: a
                  place to catch up with friends, share a meal, try something
                  different, and turn an ordinary outing into a memorable
                  experience.
                </p>
              </div>

              {/* Closing Statement (Revealed Last) */}
              <div
                ref={ch2ClosingRef}
                className="mt-5 sm:mt-6 pt-4 border-t border-[#E8DED0]"
              >
                <div className="inline-flex items-center gap-2.5 px-4 py-2.5 rounded-full neu-cream-disc shadow-xs">
                  <Sparkles className="w-4 h-4 text-[#B18B5B] shrink-0" />
                  <span className="text-[10px] sm:text-[11px] font-black tracking-[0.2em] text-[#1F2B20] uppercase">
                    BOLD FLAVOURS · UNCOMMON CHARACTER · GOOD TIMES.
                  </span>
                </div>
              </div>
            </div>

          </div>

          {/* RIGHT COLUMN: ORIGINAL FOUNDER PORTRAIT (Visually Stationary Throughout) */}
          <div
            ref={portraitWrapperRef}
            className="lg:col-span-5 relative flex items-center justify-center py-2 select-none"
          >
            {/* Outer Neumorphic Organic Backplate Frame */}
            <div className="relative w-full max-w-[280px] sm:max-w-[310px] lg:max-w-[335px] h-[430px] sm:h-[460px] lg:h-[480px]">
              
              {/* Backplate Organic Shadow Glow Layer */}
              <div className="absolute -inset-3.5 sm:-inset-4 rounded-tr-[120px] rounded-tl-[70px] rounded-bl-[50px] rounded-br-[90px] neu-cream-backplate pointer-events-none" />

              {/* Portrait Capsule Container */}
              <div className="relative w-full h-full rounded-t-[150px] rounded-b-[32px] overflow-hidden border-[3px] border-[#FAF7F0] shadow-xl group transition-transform duration-500 hover:scale-[1.015] bg-[#FAF7F0]">
                {/* Real Founder Photograph of Kelvin Kwok (Kwai) */}
                <Image
                  src="/images/founder.png"
                  alt="Kelvin Kwok (Kwai) — Founder of Burger Cartel"
                  fill
                  sizes="(max-width: 768px) 100vw, 320px"
                  className="object-cover object-top grayscale contrast-[106%] brightness-[102%]"
                  priority
                />

                {/* Subtle soft vignette near lower edge for editorial depth */}
                <div className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-[#FAF7F0]/85 via-[#FAF7F0]/20 to-transparent pointer-events-none" />
              </div>

              {/* EDITORIAL ANNOTATION 1 (Top Left): "Kelvin Kwok (Kwai)" + Curved Arrow */}
              <div
                ref={(el) => {
                  annotationsRef.current[0] = el;
                }}
                className="absolute -top-5 -left-5 sm:-top-6 sm:-left-7 z-20 flex flex-col items-end pointer-events-none"
              >
                <div className="font-handwriting text-base sm:text-lg font-bold text-[#292925] leading-tight text-right rotate-[-4deg]">
                  <span>Kelvin Kwok</span>
                  <br />
                  <span className="text-sm sm:text-base text-[#B18B5B]">(Kwai)</span>
                </div>
                {/* Curved SVG Arrow swooping toward shoulder */}
                <svg
                  className="w-9 h-8 text-[#292925]/75 -mt-0.5 mr-1"
                  viewBox="0 0 60 50"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M 12 6 C 30 10, 48 24, 46 44" />
                  <path d="M 40 40 L 46 44 L 52 38" />
                </svg>
              </div>

              {/* EDITORIAL ANNOTATION 2 (Middle Left): Globe Icon + "Global Experience" + Arrow */}
              <div
                ref={(el) => {
                  annotationsRef.current[1] = el;
                }}
                className="absolute top-[48%] -translate-y-1/2 -left-6 sm:-left-8 z-20 flex flex-col items-center pointer-events-none"
              >
                <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-full neu-cream-disc flex items-center justify-center text-[#B18B5B] shadow-xs mb-0.5">
                  <Globe className="w-3 h-3 text-[#B18B5B]" />
                </div>
                <span className="font-handwriting text-xs sm:text-sm font-bold text-[#292925] whitespace-nowrap rotate-[-6deg] text-center leading-tight">
                  Global
                  <br />
                  Experience
                </span>
                {/* Curved Arrow pointing to founder */}
                <svg
                  className="w-8 h-6 text-[#292925]/75 mt-0.5 ml-2"
                  viewBox="0 0 50 40"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M 8 10 C 20 12, 34 20, 42 32" />
                  <path d="M 36 32 L 42 32 L 42 26" />
                </svg>
              </div>

              {/* EDITORIAL ANNOTATION 3 (Top Right): Mountain Sketch + "From Darjeeling" */}
              <div
                ref={(el) => {
                  annotationsRef.current[2] = el;
                }}
                className="absolute -top-3 -right-5 sm:-top-4 sm:-right-7 z-20 flex flex-col items-center pointer-events-none"
              >
                {/* Handcrafted minimalist 3-peak mountain line drawing */}
                <svg
                  className="w-7 h-4 text-[#B18B5B]"
                  viewBox="0 0 50 35"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M 4 30 L 18 10 L 30 24 L 38 14 L 46 30 Z" />
                  <path d="M 18 10 L 22 17" />
                  <path d="M 38 14 L 41 20" />
                </svg>
                <span className="font-handwriting text-xs sm:text-sm font-bold text-[#292925] mt-0.5 rotate-[4deg] text-center leading-tight">
                  From
                  <br />
                  Darjeeling
                </span>
              </div>

              {/* EDITORIAL ANNOTATION 4 (Middle Right): Curved Arrow + "Back to Hometown" */}
              <div
                ref={(el) => {
                  annotationsRef.current[3] = el;
                }}
                className="absolute top-[56%] -right-6 sm:-right-8 z-20 flex flex-col items-start pointer-events-none"
              >
                <svg
                  className="w-8 h-6 text-[#292925]/75 mb-0.5"
                  viewBox="0 0 50 40"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M 42 10 C 28 12, 14 20, 8 32" />
                  <path d="M 6 25 L 8 32 L 15 31" />
                </svg>
                <span className="font-handwriting text-xs sm:text-sm font-bold text-[#292925] whitespace-nowrap rotate-[3deg] leading-tight">
                  Back to
                  <br />
                  Hometown
                </span>
              </div>

              {/* EDITORIAL ANNOTATION 5 (Bottom Right): Handcrafted Artisan Burger Sketch */}
              <div
                ref={(el) => {
                  annotationsRef.current[4] = el;
                }}
                className="absolute -bottom-3 -right-5 sm:-bottom-4 sm:-right-6 z-20 w-16 sm:w-18 aspect-square pointer-events-none opacity-90 drop-shadow-xs"
              >
                <Image
                  src="/images/burger-sketch-transparent.png"
                  alt="Handcrafted Burger Sketch"
                  width={72}
                  height={72}
                  className="w-full h-full object-contain"
                />
              </div>

            </div>
          </div>

        </div>
      </section>

      {/* FOOTER */}
      <Footer onOpenLocation={() => setLocationOpen(true)} />

      {/* Interactive Modals */}
      <LocationModal
        isOpen={locationOpen}
        onClose={() => setLocationOpen(false)}
      />

      <MenuModal
        isOpen={menuOpen}
        onClose={() => setMenuOpen(false)}
      />
    </div>
  );
}
