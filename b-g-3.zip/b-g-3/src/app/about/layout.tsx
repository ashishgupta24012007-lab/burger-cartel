import type { Metadata } from "next";
import { SITE_URL, generateBreadcrumbSchema, safeJsonLd } from "@/data/seoData";
import { getCmsData } from "@/lib/db/cmsRepository";

export async function generateMetadata(): Promise<Metadata> {
  const cms = await getCmsData();
  const seo = cms.siteContent.seo?.about;

  const title = seo?.title || "Our Story & Craft — From Darjeeling Hilltop to North Bengal";
  const description =
    seo?.description ||
    "Discover the story of Burger Cartel. Born in the misty hills of Darjeeling, expanding to Kurseong and Siliguri. Dedicated to honest artisan smash burgers, freshly baked buns, and mountain hospitality.";
  const ogImage = seo?.ogImage || "/images/og-image.png";

  return {
    title,
    description,
    alternates: {
      canonical: "/about",
    },
    openGraph: {
      title,
      description,
      url: `${SITE_URL}/about`,
      images: [
        {
          url: ogImage,
          width: 1200,
          height: 630,
          type: "image/png",
          alt: "Burger Cartel outlet ambient evening atmosphere",
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [ogImage],
    },
    robots: {
      index: !seo?.noindex,
      follow: !seo?.noindex,
    },
  };
}

export default function AboutLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const breadcrumbSchema = generateBreadcrumbSchema([
    { name: "Home", url: "/" },
    { name: "About Us", url: "/about" },
  ]);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: safeJsonLd(breadcrumbSchema) }}
      />
      {children}
    </>
  );
}
