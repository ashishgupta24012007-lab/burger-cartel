import { NextRequest, NextResponse } from "next/server";
import { getAdminSession, assertSameOrigin, NO_CACHE_HEADERS } from "@/lib/auth/session";
import { verifyRbacPermission } from "@/lib/auth/rbac";
import { processAndStoreMedia } from "@/lib/storage/mediaStorage";
import { recordAuditLog } from "@/lib/db/cmsRepository";

const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB maximum upload limit

export async function POST(req: NextRequest) {
  try {
    // 1. Authentication Enforcement
    const session = await getAdminSession();
    if (!session.authenticated || !session.admin) {
      return NextResponse.json(
        { success: false, error: "Unauthorized. Administrator session required." },
        { status: 401, headers: NO_CACHE_HEADERS }
      );
    }

    // 2. CSRF and Origin Protection
    if (!assertSameOrigin(req)) {
      return NextResponse.json(
        { success: false, error: "Cross-origin request rejected." },
        { status: 403, headers: NO_CACHE_HEADERS }
      );
    }

    // 3. Central Server-Side RBAC Enforcement
    const rbac = await verifyRbacPermission(session.admin, "ADD_GALLERY_ITEM");
    if (!rbac.authorized) {
      return NextResponse.json(
        { success: false, error: rbac.error || "Forbidden: You lack permission 'media:upload' to upload assets." },
        { status: 403, headers: NO_CACHE_HEADERS }
      );
    }

    // 4. Parse Multipart Form Data
    const formData = await req.formData();
    const file = formData.get("file");

    if (!file || typeof file === "string" || !(file instanceof Blob)) {
      return NextResponse.json(
        { success: false, error: "No file uploaded. Form field 'file' is required." },
        { status: 400, headers: NO_CACHE_HEADERS }
      );
    }

    // 5. Enforce Maximum File Size
    if (file.size > MAX_FILE_SIZE) {
      return NextResponse.json(
        { success: false, error: `File exceeds ${MAX_FILE_SIZE / (1024 * 1024)}MB size limit.` },
        { status: 413, headers: NO_CACHE_HEADERS }
      );
    }

    if (file.size === 0) {
      return NextResponse.json(
        { success: false, error: "Uploaded file is empty." },
        { status: 400, headers: NO_CACHE_HEADERS }
      );
    }

    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    const originalFilename = (file as unknown as { name?: string }).name || "upload.jpg";

    // 6. Process Image with Sharp & Persistent Storage (Magic Bytes, Decoding, 16MP Limit, EXIF Strip, Responsive WebP)
    const processed = await processAndStoreMedia(buffer, originalFilename);

    // 7. Chained Audit Logging in PostgreSQL
    const clientIp = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || req.headers.get("x-real-ip") || "127.0.0.1";
    await recordAuditLog({
      event: "MEDIA_UPLOADED",
      adminId: session.admin.adminId,
      ip: clientIp,
      details: `Uploaded and optimized media: ${processed.filename} (${(processed.sizeBytes / 1024).toFixed(1)} KB, ${processed.width}x${processed.height} WebP, ${processed.variants.length} responsive variants).`,
    });

    return NextResponse.json(
      {
        success: true,
        message: "Media asset processed and stored successfully.",
        url: processed.publicUrl,
        filename: processed.filename,
        storageKey: processed.storageKey,
        width: processed.width,
        height: processed.height,
        size: processed.sizeBytes,
        mimeType: processed.mimeType,
        variants: processed.variants.map((v) => ({
          suffix: v.suffix,
          url: v.publicUrl,
          width: v.width,
          height: v.height,
        })),
      },
      { headers: NO_CACHE_HEADERS }
    );
  } catch (err: unknown) {
    const errorMsg = (err as Error).message || "Internal server error processing file upload.";
    console.error("[MediaUpload Error]:", err);
    const statusCode = errorMsg.includes("limit") || errorMsg.includes("dimension") || errorMsg.includes("bytes") || errorMsg.includes("Corrupted")
      ? 415
      : 500;

    return NextResponse.json(
      { success: false, error: errorMsg },
      { status: statusCode, headers: NO_CACHE_HEADERS }
    );
  }
}
