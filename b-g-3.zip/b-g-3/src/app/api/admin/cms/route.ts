import { NextRequest, NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import crypto from "crypto";
import { getAdminSession, assertSameOrigin, NO_CACHE_HEADERS } from "@/lib/auth/session";
import { assertAuthorizedForOutlet } from "@/lib/auth/branchAuth";
import { verifyRbacPermission } from "@/lib/auth/rbac";
import {
  writeCmsDatabase,
  getDefaultCmsDatabase,
  CmsReviewItem,
  CmsCustomPage,
  CmsMenuItem,
  CmsMenuCategory,
  CmsGalleryItem,
} from "@/lib/cms/store";
import { mutateAuthDatabase } from "@/lib/auth/store";
import { isSafeUrl } from "@/lib/utils/urlSanitizer";
import {
  getCmsData,
  setOutletMenuAvailability,
  setOutletMenuPriceOverride,
  saveSiteContentSection,
  saveMenuItem,
  deleteMenuItem,
  saveMenuCategory,
  deleteMenuCategory,
  saveOutlet,
  saveReview,
  deleteReview,
  saveCustomPage,
  deleteCustomPage,
  saveGalleryItem,
  deleteGalleryItem,
  recordAuditLog,
  ConcurrencyConflictError,
} from "@/lib/db/cmsRepository";
import {
  createDatabaseSnapshot,
  listDatabaseSnapshots,
  restoreDatabaseSnapshot,
  resetDatabaseToDefaults,
} from "@/lib/db/cmsBackupRepository";
import {
  publishReleaseManifest,
  rollbackRelease,
  listReleases,
} from "@/lib/db/cmsPublishing";

export async function GET() {
  const session = await getAdminSession();
  if (!session.authenticated || !session.admin) {
    return NextResponse.json(
      { success: false, error: "Unauthorized." },
      { status: 401, headers: NO_CACHE_HEADERS }
    );
  }

  const cms = await getCmsData();
  return NextResponse.json(
    {
      success: true,
      data: cms,
    },
    { headers: NO_CACHE_HEADERS }
  );
}

export async function POST(req: NextRequest) {
  try {
    // 1. Authentication check
    const session = await getAdminSession();
    if (!session.authenticated || !session.admin) {
      return NextResponse.json(
        { success: false, error: "Unauthorized. Please log in." },
        { status: 401, headers: NO_CACHE_HEADERS }
      );
    }

    // 2. CSRF Defense
    if (!assertSameOrigin(req)) {
      return NextResponse.json(
        { success: false, error: "Cross-origin request rejected." },
        { status: 403, headers: NO_CACHE_HEADERS }
      );
    }

    const body = await req.json();
    const { action, payload } = body;

    if (!action || typeof action !== "string") {
      return NextResponse.json(
        { success: false, error: "Missing or invalid action parameter." },
        { status: 400, headers: NO_CACHE_HEADERS }
      );
    }

    // 3. Central Server-Side RBAC Enforcement (Least Privilege Action Matrix)
    const targetOutlet = payload?.outletId || payload?.slug || undefined;
    const rbac = await verifyRbacPermission(session.admin, action, { outletId: targetOutlet });
    if (!rbac.authorized) {
      return NextResponse.json(
        { success: false, error: rbac.error || `Forbidden: Lacking permission for action '${action}'.` },
        { status: rbac.status || 403, headers: NO_CACHE_HEADERS }
      );
    }

    const cms = await getCmsData();
    let auditMessage = "";

    switch (action) {
      // 1. UPDATE ENTIRE SITE CONTENT
      case "UPDATE_SITE_CONTENT": {
        if (!payload || typeof payload !== "object") {
          return NextResponse.json(
            { success: false, error: "Invalid content payload." },
            { status: 400, headers: NO_CACHE_HEADERS }
          );
        }

        if (payload.hero) {
          if (payload.hero.ctaPrimaryLink && !isSafeUrl(payload.hero.ctaPrimaryLink)) {
            return NextResponse.json(
              { success: false, error: "Invalid Primary CTA Link. Must be a safe relative path (/...) or https:// URL." },
              { status: 400, headers: NO_CACHE_HEADERS }
            );
          }
          if (payload.hero.ctaSecondaryLink && !isSafeUrl(payload.hero.ctaSecondaryLink)) {
            return NextResponse.json(
              { success: false, error: "Invalid Secondary CTA Link. Must be a safe relative path (/...) or https:// URL." },
              { status: 400, headers: NO_CACHE_HEADERS }
            );
          }
          const isTwoLineUpdate = Boolean(payload.hero.titleLine1 || payload.hero.titleLine2);
          const resolvedHeadline = isTwoLineUpdate
            ? (payload.hero.headline || "")
            : (payload.hero.headline !== undefined ? payload.hero.headline : (cms.siteContent.hero.headline || ""));

          cms.siteContent.hero = {
            ...cms.siteContent.hero,
            ...payload.hero,
            headline: resolvedHeadline,
            titleLine1: isTwoLineUpdate ? (payload.hero.titleLine1 || "") : (payload.hero.headline ? "" : (cms.siteContent.hero.titleLine1 || "")),
            titleLine2: isTwoLineUpdate ? (payload.hero.titleLine2 || "") : (payload.hero.headline ? "" : (cms.siteContent.hero.titleLine2 || "")),
          };
        }
        if (payload.announcement) cms.siteContent.announcement = { ...cms.siteContent.announcement, ...payload.announcement };
        if (payload.about) cms.siteContent.about = { ...cms.siteContent.about, ...payload.about };
        if (payload.contact) cms.siteContent.contact = { ...cms.siteContent.contact, ...payload.contact };
        if (payload.navigation && Array.isArray(payload.navigation)) cms.siteContent.navigation = payload.navigation;
        if (payload.footer) cms.siteContent.footer = { ...cms.siteContent.footer, ...payload.footer };
        if (payload.seo) cms.siteContent.seo = { ...cms.siteContent.seo, ...payload.seo };
        if (payload.menuSettings) {
          cms.siteContent.menuSettings = {
            showPrices: payload.menuSettings.showPrices !== false,
          };
        }

        // Direct PostgreSQL Persistence
        for (const [k, v] of Object.entries(cms.siteContent)) {
          await saveSiteContentSection(k, v);
        }
        if (payload.menuSettings) {
          await saveSiteContentSection("menu_settings", cms.siteContent.menuSettings);
        }

        auditMessage = "Updated website layout, hero, and editorial content.";
        break;
      }

      // 2. HERO SECTION DEDICATED CONTROLS
      case "UPDATE_HERO": {
        if (!payload || typeof payload !== "object") {
          return NextResponse.json(
            { success: false, error: "Invalid hero payload." },
            { status: 400, headers: NO_CACHE_HEADERS }
          );
        }
        if (payload.ctaPrimaryLink && !isSafeUrl(payload.ctaPrimaryLink)) {
          return NextResponse.json(
            { success: false, error: "Invalid Primary CTA Link." },
            { status: 400, headers: NO_CACHE_HEADERS }
          );
        }
        const isTwoLineUpdate = Boolean(payload.titleLine1 || payload.titleLine2);
        const resolvedHeadline = isTwoLineUpdate
          ? (payload.headline || "")
          : (payload.headline !== undefined ? payload.headline : (cms.siteContent.hero.headline || ""));

        cms.siteContent.hero = {
          ...cms.siteContent.hero,
          ...payload,
          headline: resolvedHeadline,
          titleLine1: isTwoLineUpdate ? (payload.titleLine1 || "") : (payload.headline ? "" : (cms.siteContent.hero.titleLine1 || "")),
          titleLine2: isTwoLineUpdate ? (payload.titleLine2 || "") : (payload.headline ? "" : (cms.siteContent.hero.titleLine2 || "")),
        };
        await saveSiteContentSection("hero", cms.siteContent.hero);
        auditMessage = "Updated Homepage Hero section settings.";
        break;
      }

      // 3. ANNOUNCEMENT BANNER
      case "UPDATE_ANNOUNCEMENT": {
        if (!payload || typeof payload !== "object") {
          return NextResponse.json(
            { success: false, error: "Invalid announcement payload." },
            { status: 400, headers: NO_CACHE_HEADERS }
          );
        }
        cms.siteContent.announcement = { ...cms.siteContent.announcement, ...payload };
        await saveSiteContentSection("announcement", cms.siteContent.announcement);
        auditMessage = `Updated announcement banner: ${cms.siteContent.announcement.enabled ? "Active" : "Disabled"}.`;
        break;
      }

      // 4. ABOUT PAGE & SECTION
      case "UPDATE_ABOUT": {
        if (!payload || typeof payload !== "object") {
          return NextResponse.json(
            { success: false, error: "Invalid about payload." },
            { status: 400, headers: NO_CACHE_HEADERS }
          );
        }
        cms.siteContent.about = { ...cms.siteContent.about, ...payload };
        await saveSiteContentSection("about", cms.siteContent.about);
        auditMessage = "Updated About Us story, heading, and founder notes.";
        break;
      }

      // 5. CONTACT & SOCIALS
      case "UPDATE_CONTACT": {
        if (!payload || typeof payload !== "object") {
          return NextResponse.json(
            { success: false, error: "Invalid contact payload." },
            { status: 400, headers: NO_CACHE_HEADERS }
          );
        }
        cms.siteContent.contact = { ...cms.siteContent.contact, ...payload };
        await saveSiteContentSection("contact", cms.siteContent.contact);
        auditMessage = "Updated central contact details and social links.";
        break;
      }

      // 6. NAVIGATION & FOOTER
      case "UPDATE_NAVIGATION": {
        if (!Array.isArray(payload)) {
          return NextResponse.json(
            { success: false, error: "Navigation payload must be an array of links." },
            { status: 400, headers: NO_CACHE_HEADERS }
          );
        }
        cms.siteContent.navigation = payload;
        await saveSiteContentSection("navigation", cms.siteContent.navigation);
        auditMessage = "Updated website navigation link structure.";
        break;
      }

      case "UPDATE_FOOTER": {
        if (!payload || typeof payload !== "object") {
          return NextResponse.json(
            { success: false, error: "Invalid footer payload." },
            { status: 400, headers: NO_CACHE_HEADERS }
          );
        }
        cms.siteContent.footer = { ...cms.siteContent.footer, ...payload };
        await saveSiteContentSection("footer", cms.siteContent.footer);
        auditMessage = "Updated footer taglines, descriptions, and copyright.";
        break;
      }

      // 7. MENU CATEGORIES MANAGEMENT
      case "SAVE_MENU_CATEGORY":
      case "UPDATE_CATEGORY": {
        const { id, name, shortName, subtitle, description, isVisible, sortOrder } = payload || {};
        if (!name || typeof name !== "string") {
          return NextResponse.json(
            { success: false, error: "Category name is required." },
            { status: 400, headers: NO_CACHE_HEADERS }
          );
        }

        const categoryId = id || name.toLowerCase().replace(/[^a-z0-9]+/g, "-");
        const existingIdx = (cms.menuCategories || []).findIndex((c) => c.id === categoryId);

        const categoryObj: CmsMenuCategory = {
          id: categoryId,
          name: String(name).trim().toUpperCase(),
          shortName: String(shortName || name).trim(),
          subtitle: String(subtitle || "Menu Selection").trim(),
          description: String(description || "").trim(),
          isVisible: isVisible !== false,
          sortOrder: Number(sortOrder) || (existingIdx !== -1 ? cms.menuCategories[existingIdx].sortOrder : cms.menuCategories.length + 1),
        };

        if (existingIdx !== -1) {
          cms.menuCategories[existingIdx] = categoryObj;
          auditMessage = `Updated menu category '${categoryObj.name}'.`;
        } else {
          cms.menuCategories.push(categoryObj);
          auditMessage = `Created new menu category '${categoryObj.name}'.`;
        }
        await saveMenuCategory(categoryObj);
        break;
      }

      case "DELETE_MENU_CATEGORY": {
        const { id } = payload || {};
        // Safety check: check if items belong to category
        const itemCount = (cms.menuItems || []).filter((m) => m.category === id).length;
        if (itemCount > 0) {
          return NextResponse.json(
            { success: false, error: `Cannot delete category with ${itemCount} assigned items. Reassign items first.` },
            { status: 400, headers: NO_CACHE_HEADERS }
          );
        }

        cms.menuCategories = (cms.menuCategories || []).filter((c) => c.id !== id);
        await deleteMenuCategory(id);
        auditMessage = `Deleted menu category '${id}'.`;
        break;
      }

      // 8. MENU ITEMS MANAGEMENT
      case "SAVE_MENU_ITEM":
      case "UPDATE_MENU_ITEM": {
        const {
          id,
          name,
          category,
          subcategory,
          description,
          price,
          basePrice,
          salePrice,
          image,
          isVegetarian,
          isHouseFavourite,
          isAvailable,
          isVisible,
          sortOrder,
          variants,
          tags,
        } = payload || {};

        if (!name || !category) {
          return NextResponse.json(
            { success: false, error: "Food item name and category are required." },
            { status: 400, headers: NO_CACHE_HEADERS }
          );
        }

        const itemId = id || `item-${Date.now()}-${crypto.randomBytes(3).toString("hex")}`;
        const existingIdx = (cms.menuItems || []).findIndex((m) => m.id === itemId);

        const itemObj: CmsMenuItem = {
          id: itemId,
          name: String(name).trim(),
          category: String(category).trim(),
          subcategory: subcategory ? String(subcategory).trim() : undefined,
          description: String(description || "").trim(),
          price: price ? String(price).trim() : "₹180",
          salePrice: salePrice ? String(salePrice).trim() : undefined,
          basePrice: basePrice !== undefined ? Number(basePrice) : (price ? parseFloat(String(price).replace(/[^0-9.]/g, "")) : undefined),
          image: image ? String(image).trim() : "/images/menu/burgers/the-classic-fresh.webp",
          isVegetarian: Boolean(isVegetarian),
          isHouseFavourite: Boolean(isHouseFavourite),
          isAvailable: isAvailable !== false,
          isVisible: isVisible !== false,
          sortOrder: Number(sortOrder) || (existingIdx !== -1 ? cms.menuItems[existingIdx].sortOrder : cms.menuItems.length + 1),
          variants: Array.isArray(variants) ? variants : undefined,
          tags: Array.isArray(tags) ? tags : undefined,
        };

        if (existingIdx !== -1) {
          cms.menuItems[existingIdx] = itemObj;
          auditMessage = `Updated menu item '${itemObj.name}'.`;
        } else {
          cms.menuItems.push(itemObj);
          auditMessage = `Created new menu item '${itemObj.name}'.`;
        }
        const expectedVersion = payload?.expectedVersion !== undefined
          ? Number(payload.expectedVersion)
          : (payload?.version !== undefined ? Number(payload.version) : undefined);

        const isEditor = session.admin.role === "editor";
        const publicationStatus: "draft" | "published" = payload?.publicationStatus
          ? (payload.publicationStatus as "draft" | "published")
          : (payload?.isDraft || isEditor ? "draft" : "published");

        await saveMenuItem(itemObj, expectedVersion, publicationStatus, session.admin.adminId);
        break;
      }

      case "DELETE_MENU_ITEM": {
        const { id } = payload || {};
        cms.menuItems = (cms.menuItems || []).filter((m) => m.id !== id);
        await deleteMenuItem(id);
        auditMessage = `Deleted menu item '${id}'.`;
        break;
      }

      case "UPDATE_MENU_SETTINGS": {
        const { showPrices } = payload || {};
        const isShow = showPrices !== false;
        if (!cms.siteContent) {
          cms.siteContent = getDefaultCmsDatabase().siteContent;
        }
        cms.siteContent.menuSettings = { showPrices: isShow };
        await saveSiteContentSection("menu_settings", { showPrices: isShow });
        await saveSiteContentSection("menuSettings", { showPrices: isShow });
        auditMessage = `Updated menu settings: display prices is ${isShow ? "ON" : "OFF"}.`;
        break;
      }

      // 9. REVIEWS MANAGEMENT
      case "ADD_REVIEW": {
        const { author, rating, branchId, branchName, quote, highlightDish, source } = payload || {};
        if (!author || !quote) {
          return NextResponse.json(
            { success: false, error: "Author and review text are required." },
            { status: 400, headers: NO_CACHE_HEADERS }
          );
        }

        const newReview: CmsReviewItem = {
          id: `review-${Date.now()}-${crypto.randomBytes(3).toString("hex")}`,
          author: String(author).trim().slice(0, 64),
          avatarText: String(author).trim().slice(0, 2).toUpperCase(),
          rating: Number(rating) || 5,
          dateText: "Recently added",
          branchId: String(branchId || "all"),
          branchName: String(branchName || "Burger Cartel"),
          quote: String(quote).trim().slice(0, 1000),
          highlightDish: highlightDish ? String(highlightDish).trim().slice(0, 64) : undefined,
          isFeatured: true,
          hidden: false,
          source: source || "direct",
        };

        cms.reviews.unshift(newReview);
        await saveReview(newReview);
        auditMessage = `Added review by '${newReview.author}'.`;
        break;
      }

      case "UPDATE_REVIEW": {
        const { id, author, rating, branchId, branchName, quote, highlightDish, isFeatured, hidden, source } = payload || {};
        const review = cms.reviews.find((r) => r.id === id);
        if (!review) {
          return NextResponse.json(
            { success: false, error: "Review not found." },
            { status: 404, headers: NO_CACHE_HEADERS }
          );
        }
        if (author) review.author = String(author).trim().slice(0, 64);
        if (rating) review.rating = Number(rating);
        if (branchId) review.branchId = String(branchId);
        if (branchName) review.branchName = String(branchName);
        if (quote) review.quote = String(quote).trim().slice(0, 1000);
        if (highlightDish !== undefined) review.highlightDish = highlightDish ? String(highlightDish).trim() : undefined;
        if (isFeatured !== undefined) review.isFeatured = Boolean(isFeatured);
        if (hidden !== undefined) review.hidden = Boolean(hidden);
        if (source) review.source = source;

        await saveReview(review);
        auditMessage = `Updated review '${review.id}' by ${review.author}.`;
        break;
      }

      case "TOGGLE_REVIEW_VISIBILITY": {
        const { id } = payload || {};
        const review = cms.reviews.find((r) => r.id === id);
        if (!review) {
          return NextResponse.json(
            { success: false, error: "Review not found." },
            { status: 404, headers: NO_CACHE_HEADERS }
          );
        }
        review.hidden = !review.hidden;
        await saveReview(review);
        auditMessage = `${review.hidden ? "Hid" : "Published"} review '${review.id}'.`;
        break;
      }

      case "DELETE_REVIEW": {
        const { id } = payload || {};
        cms.reviews = cms.reviews.filter((r) => r.id !== id);
        await deleteReview(id);
        auditMessage = `Deleted review '${id}'.`;
        break;
      }

      // 10. CUSTOM PAGES WITH BLOCKS
      case "SAVE_CUSTOM_PAGE": {
        const { id, title, slug, subtitle, heroImage, content, blocks, ctaText, ctaLink, seoTitle, metaDescription, isPublished } = payload || {};
        if (!title || !slug) {
          return NextResponse.json(
            { success: false, error: "Page title and URL slug are required." },
            { status: 400, headers: NO_CACHE_HEADERS }
          );
        }

        const cleanSlug = String(slug)
          .toLowerCase()
          .replace(/[^a-z0-9-_]/g, "")
          .trim();

        if (!cleanSlug) {
          return NextResponse.json(
            { success: false, error: "Invalid URL slug format." },
            { status: 400, headers: NO_CACHE_HEADERS }
          );
        }

        const now = new Date().toISOString();
        const existingIdx = cms.customPages.findIndex((p) => p.id === id || p.slug === cleanSlug);

        const canonicalPageId = (id || (existingIdx !== -1 ? cms.customPages[existingIdx].id : null)) ||
          `page-${Date.now()}-${crypto.randomBytes(3).toString("hex")}`;

        const pageObj: CmsCustomPage = {
          id: canonicalPageId,
          title: String(title).trim().slice(0, 120),
          slug: cleanSlug,
          subtitle: String(subtitle || "").trim().slice(0, 200),
          heroImage: heroImage ? String(heroImage).trim() : "/images/gallery/01-interior-wide.webp",
          content: String(content || "").trim(),
          blocks: Array.isArray(blocks) ? blocks : undefined,
          ctaText: ctaText ? String(ctaText).trim().slice(0, 60) : undefined,
          ctaLink: ctaLink ? String(ctaLink).trim().slice(0, 255) : undefined,
          seoTitle: seoTitle ? String(seoTitle).trim().slice(0, 100) : undefined,
          metaDescription: metaDescription ? String(metaDescription).trim().slice(0, 200) : undefined,
          isPublished: isPublished !== false,
          createdAt: existingIdx !== -1 ? cms.customPages[existingIdx].createdAt : now,
          updatedAt: now,
        };

        if (existingIdx !== -1) {
          cms.customPages[existingIdx] = pageObj;
          auditMessage = `Updated custom page '/p/${cleanSlug}'.`;
        } else {
          cms.customPages.unshift(pageObj);
          auditMessage = `Created custom page '/p/${cleanSlug}'.`;
        }
        await saveCustomPage(pageObj);
        break;
      }

      case "DELETE_CUSTOM_PAGE": {
        const { id } = payload || {};
        cms.customPages = cms.customPages.filter((p) => p.id !== id && p.slug !== id);
        await deleteCustomPage(id);
        auditMessage = `Deleted custom page '${id}'.`;
        break;
      }

      // 11. GALLERY & MEDIA MANAGER
      case "ADD_GALLERY_ITEM": {
        const { title, category, categoryLabel, src, alt, description, featured } = payload || {};
        if (!src || !title) {
          return NextResponse.json(
            { success: false, error: "Image file and title are required." },
            { status: 400, headers: NO_CACHE_HEADERS }
          );
        }

        const newItem: CmsGalleryItem = {
          id: payload?.id ? String(payload.id).trim() : `img-${Date.now()}-${crypto.randomBytes(3).toString("hex")}`,
          title: String(title).trim(),
          category: category || "food",
          categoryLabel: categoryLabel || (category === "burgers" ? "Burgers" : "Food & Drinks"),
          src: String(src).trim(),
          alt: String(alt || title).trim(),
          description: String(description || "").trim(),
          featured: Boolean(featured),
          sortOrder: (cms.gallery || []).length + 1,
        };

        cms.gallery.unshift(newItem);
        await saveGalleryItem(newItem);
        auditMessage = `Added media asset '${newItem.title}' to Gallery.`;
        break;
      }

      case "UPDATE_GALLERY_ITEM": {
        const { id, src, title, category, description, alt, featured, sortOrder } = payload || {};
        const item = cms.gallery.find((g) => g.id === id);
        if (!item) {
          return NextResponse.json(
            { success: false, error: "Gallery item not found." },
            { status: 404, headers: NO_CACHE_HEADERS }
          );
        }
        if (src) item.src = String(src).trim();
        if (title) item.title = String(title).trim();
        if (category) item.category = category;
        if (description !== undefined) item.description = String(description).trim();
        if (alt !== undefined) item.alt = String(alt).trim();
        if (featured !== undefined) item.featured = Boolean(featured);
        if (sortOrder !== undefined) item.sortOrder = Number(sortOrder);

        await saveGalleryItem(item);
        auditMessage = `Updated media asset '${item.title}'.`;
        break;
      }

      case "DELETE_GALLERY_ITEM": {
        const { id, force } = payload || {};
        const item = cms.gallery.find((g) => g.id === id);
        if (!item) {
          return NextResponse.json(
            { success: false, error: "Image item not found." },
            { status: 404, headers: NO_CACHE_HEADERS }
          );
        }

        // Usage safety inspection
        if (!force) {
          const usedInMenu = (cms.menuItems || []).some((m) => m.image === item.src);
          const usedInHero = cms.siteContent.hero.desktopImage === item.src || cms.siteContent.hero.mobileImage === item.src;
          if (usedInMenu || usedInHero) {
            return NextResponse.json(
              {
                success: false,
                isUsed: true,
                error: `This image is currently in use (${usedInMenu ? "in Menu Items" : ""}${usedInHero ? " in Homepage Hero" : ""}). Replace usage or pass force: true to delete anyway.`,
              },
              { status: 409, headers: NO_CACHE_HEADERS }
            );
          }
        }

        cms.gallery = cms.gallery.filter((g) => g.id !== id);
        await deleteGalleryItem(id);
        auditMessage = `Deleted gallery asset '${item.title}'.`;
        break;
      }

      // 12. BRANCH & OUTLET MANAGEMENT
      case "UPDATE_OUTLET": {
        const { slug, name, address, phone, hoursDisplay, dailyHours, isOpen, isFeatured, temporaryClosureNotice, googleMapsUrl, swiggyUrl, zomatoUrl, image, seoTitle, metaDescription } = payload || {};
        
        // Branch-Level Authorization Enforcement
        const isAuthorized = await assertAuthorizedForOutlet(session.admin.id, String(slug));
        if (!isAuthorized) {
          return NextResponse.json(
            { success: false, error: `Forbidden: Administrator is not authorized to manage outlet '${slug}'.` },
            { status: 403, headers: NO_CACHE_HEADERS }
          );
        }

        const outlet = cms.outlets.find((o) => o.slug === slug);
        if (!outlet) {
          return NextResponse.json(
            { success: false, error: "Outlet not found." },
            { status: 404, headers: NO_CACHE_HEADERS }
          );
        }

        // Optimistic Concurrency Control: atomic database conditional versioning
        const expectedVersion = payload?.expectedVersion !== undefined
          ? Number(payload.expectedVersion)
          : (payload?.version !== undefined ? Number(payload.version) : undefined);

        if (name) outlet.name = String(name).trim();
        if (address) outlet.address = String(address).trim();
        if (phone !== undefined) outlet.phone = String(phone).trim();
        if (hoursDisplay) outlet.hoursDisplay = String(hoursDisplay).trim();
        if (dailyHours && Array.isArray(dailyHours)) outlet.dailyHours = dailyHours;
        if (isOpen !== undefined) outlet.isOpen = Boolean(isOpen);
        if (isFeatured !== undefined) outlet.isFeatured = Boolean(isFeatured);
        if (temporaryClosureNotice !== undefined) outlet.temporaryClosureNotice = temporaryClosureNotice ? String(temporaryClosureNotice).trim() : undefined;
        if (googleMapsUrl !== undefined) outlet.googleMapsUrl = googleMapsUrl ? String(googleMapsUrl).trim() : undefined;
        if (swiggyUrl !== undefined) outlet.swiggyUrl = swiggyUrl ? String(swiggyUrl).trim() : undefined;
        if (zomatoUrl !== undefined) outlet.zomatoUrl = zomatoUrl ? String(zomatoUrl).trim() : undefined;
        if (image !== undefined) outlet.image = image ? String(image).trim() : undefined;
        if (seoTitle !== undefined) outlet.seoTitle = seoTitle ? String(seoTitle).trim() : undefined;
        if (metaDescription !== undefined) outlet.metaDescription = metaDescription ? String(metaDescription).trim() : undefined;

        await saveOutlet(outlet, expectedVersion);
        auditMessage = `Updated outlet management for '${outlet.name}'.`;
        break;
      }

      case "TOGGLE_OUTLET_ITEM_AVAILABILITY":
      case "SET_OUTLET_ITEM_AVAILABILITY": {
        const { outletId, menuItemId, isAvailable } = payload || {};
        if (!outletId || !menuItemId) {
          return NextResponse.json(
            { success: false, error: "outletId and menuItemId are required." },
            { status: 400, headers: NO_CACHE_HEADERS }
          );
        }

        // Branch-Level Authorization Enforcement
        const isAuthorized = await assertAuthorizedForOutlet(session.admin.id, String(outletId));
        if (!isAuthorized) {
          return NextResponse.json(
            { success: false, error: `Forbidden: Administrator is not authorized to manage outlet '${outletId}'.` },
            { status: 403, headers: NO_CACHE_HEADERS }
          );
        }

        await setOutletMenuAvailability(String(outletId), String(menuItemId), Boolean(isAvailable));

        if (!cms.outletMenuAvailability) {
          cms.outletMenuAvailability = {};
        }
        if (!cms.outletMenuAvailability[String(outletId)]) {
          cms.outletMenuAvailability[String(outletId)] = {};
        }
        cms.outletMenuAvailability[String(outletId)][String(menuItemId)] = Boolean(isAvailable);

        auditMessage = `Updated availability for item '${menuItemId}' at outlet '${outletId}' to ${isAvailable ? "AVAILABLE" : "UNAVAILABLE"}.`;
        break;
      }

      case "SET_OUTLET_ITEM_PRICE_OVERRIDE":
      case "SET_OUTLET_MENU_PRICE_OVERRIDE": {
        const { outletId, menuItemId, priceOverride } = payload || {};
        if (!outletId || !menuItemId) {
          return NextResponse.json(
            { success: false, error: "outletId and menuItemId are required." },
            { status: 400, headers: NO_CACHE_HEADERS }
          );
        }

        // Branch-Level Authorization Enforcement
        const isAuthorized = await assertAuthorizedForOutlet(session.admin.id, String(outletId));
        if (!isAuthorized) {
          return NextResponse.json(
            { success: false, error: `Forbidden: Administrator is not authorized to manage outlet '${outletId}'.` },
            { status: 403, headers: NO_CACHE_HEADERS }
          );
        }

        const numericPrice = priceOverride !== null && priceOverride !== undefined && !isNaN(Number(priceOverride))
          ? Number(priceOverride)
          : null;

        await setOutletMenuPriceOverride(String(outletId), String(menuItemId), numericPrice);

        if (!cms.outletMenuOverrides) {
          cms.outletMenuOverrides = {};
        }
        if (!cms.outletMenuOverrides[String(outletId)]) {
          cms.outletMenuOverrides[String(outletId)] = {};
        }
        cms.outletMenuOverrides[String(outletId)][String(menuItemId)] = numericPrice;

        auditMessage = `Set branch price override for item '${menuItemId}' at outlet '${outletId}' to ${numericPrice !== null ? `₹${numericPrice}` : "default"}.`;
        break;
      }

      // 13. SEO PER-PAGE MANAGEMENT
      case "UPDATE_PAGE_SEO":
      case "UPDATE_SEO": {
        const { pageKey, title, description, ogImage, noindex } = payload || {};
        if (!pageKey) {
          return NextResponse.json(
            { success: false, error: "pageKey is required (e.g., 'home', 'menu')." },
            { status: 400, headers: NO_CACHE_HEADERS }
          );
        }
        if (!cms.siteContent.seo) cms.siteContent.seo = {};
        cms.siteContent.seo[pageKey] = {
          title: String(title || "").trim(),
          description: String(description || "").trim(),
          ogImage: ogImage ? String(ogImage).trim() : undefined,
          noindex: Boolean(noindex),
        };
        await saveSiteContentSection("seo", cms.siteContent.seo);
        auditMessage = `Updated SEO settings for page '${pageKey}'.`;
        break;
      }

      // 14. POSTGRESQL BACKUP & DISASTER RECOVERY
      case "CREATE_BACKUP": {
        const label = payload?.label || `Manual Snapshot ${new Date().toLocaleDateString()}`;
        const snapshot = await createDatabaseSnapshot(label, session.admin.adminId);
        auditMessage = `Created verified PostgreSQL backup snapshot: '${label}' (${snapshot.checksumSha256.slice(0, 8)}).`;
        return NextResponse.json({
          success: true,
          message: auditMessage,
          snapshot,
        }, { headers: NO_CACHE_HEADERS });
      }

      case "RESTORE_BACKUP": {
        const { backupId } = payload || {};
        if (!backupId) {
          return NextResponse.json(
            { success: false, error: "backupId is required." },
            { status: 400, headers: NO_CACHE_HEADERS }
          );
        }
        const result = await restoreDatabaseSnapshot(String(backupId), session.admin.adminId);
        if (!result.success) {
          return NextResponse.json(
            { success: false, error: result.message || "Backup restoration failed." },
            { status: 400, headers: NO_CACHE_HEADERS }
          );
        }
        auditMessage = `Restored live PostgreSQL database from snapshot '${backupId}'.`;
        break;
      }

      case "RESET_DEFAULTS": {
        const result = await resetDatabaseToDefaults(session.admin.adminId);
        auditMessage = `Reset live database to verified defaults with emergency rollback point '${result.recoverySnapshotId}'.`;
        return NextResponse.json({
          success: true,
          message: auditMessage,
          emergencyBackupId: result.recoverySnapshotId,
        }, { headers: NO_CACHE_HEADERS });
      }

      case "LIST_BACKUPS": {
        const backups = await listDatabaseSnapshots();
        return NextResponse.json({
          success: true,
          backups,
        }, { headers: NO_CACHE_HEADERS });
      }

      // 15. CONTENT PUBLISHING & RELEASES
      case "PUBLISH_ALL":
      case "PUBLISH_RELEASE": {
        const release = await publishReleaseManifest({
          label: payload?.label || `Release ${new Date().toLocaleDateString()}`,
          description: payload?.description || "Published via CMS control",
          publishedBy: session.admin.adminId,
          approvedItemIds: payload?.approvedItemIds,
          approvedContentKeys: payload?.approvedContentKeys,
        });
        cms.publishedAt = release.publishedAt;
        auditMessage = `Published Release v${release.releaseNumber} ('${release.label}') containing ${release.snapshotManifest.menuItems.length} menu items and ${release.snapshotManifest.siteContent.length} content sections.`;
        return NextResponse.json({
          success: true,
          message: auditMessage,
          release,
        }, { headers: NO_CACHE_HEADERS });
      }

      case "ROLLBACK_RELEASE": {
        const { releaseId } = payload || {};
        if (!releaseId) {
          return NextResponse.json(
            { success: false, error: "releaseId is required for rollback." },
            { status: 400, headers: NO_CACHE_HEADERS }
          );
        }
        const rolledBack = await rollbackRelease(String(releaseId), session.admin.adminId);
        auditMessage = `Rolled back to release '${rolledBack.release.label}'.`;
        return NextResponse.json({
          success: true,
          message: auditMessage,
          release: rolledBack.release,
        }, { headers: NO_CACHE_HEADERS });
      }

      case "LIST_RELEASES": {
        const releases = await listReleases();
        return NextResponse.json({
          success: true,
          releases,
        }, { headers: NO_CACHE_HEADERS });
      }

      default:
        return NextResponse.json(
          { success: false, error: `Unrecognized action: ${action}` },
          { status: 400, headers: NO_CACHE_HEADERS }
        );
    }

    // Persist changes to local cache/mirror
    writeCmsDatabase(cms);

    // Record cryptographically chained audit log in PostgreSQL
    const clientIp = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || req.headers.get("x-real-ip") || "127.0.0.1";
    await recordAuditLog({
      event: "CMS_CONTENT_MODIFIED",
      adminId: session.admin!.adminId,
      ip: clientIp,
      details: auditMessage,
    });

    // Record audit log entry in encrypted legacy store
    await mutateAuthDatabase((authDb) => {
      authDb.auditLogs.push({
        id: crypto.randomUUID(),
        event: "CMS_CONTENT_MODIFIED",
        adminId: session.admin!.adminId,
        timestamp: new Date().toISOString(),
        details: auditMessage,
      });
    });

    // Invalidate Next.js static and dynamic route caches across all public pages
    try {
      revalidatePath("/", "layout");
      revalidatePath("/menu");
      revalidatePath("/about");
      revalidatePath("/locations");
      revalidatePath("/locations/[slug]", "page");
      for (const o of cms.outlets || []) {
        revalidatePath(`/locations/${o.slug}`);
      }
      revalidatePath("/order-online");
      revalidatePath("/p/[slug]", "page");
    } catch (revErr) {
      console.warn("[Admin CMS] Cache revalidation warning:", revErr);
    }

    return NextResponse.json({
      success: true,
      message: auditMessage,
      data: cms,
    }, { headers: NO_CACHE_HEADERS });
  } catch (err: unknown) {
    if (err instanceof ConcurrencyConflictError) {
      return NextResponse.json(
        { success: false, conflict: true, error: err.message },
        { status: 409, headers: NO_CACHE_HEADERS }
      );
    }
    console.error("[Admin CMS Error]:", err);
    return NextResponse.json(
      { success: false, error: "Failed to process CMS operation." },
      { status: 500, headers: NO_CACHE_HEADERS }
    );
  }
}
