import { NextRequest, NextResponse } from "next/server";
import { clearAdminSession, assertSameOrigin, NO_CACHE_HEADERS } from "@/lib/auth/session";

export async function POST(req: NextRequest) {
  // CSRF Defense
  if (!assertSameOrigin(req)) {
    return NextResponse.json(
      { success: false, error: "Cross-origin request rejected." },
      { status: 403, headers: NO_CACHE_HEADERS }
    );
  }

  await clearAdminSession();
  return NextResponse.json(
    {
      success: true,
      message: "Logged out successfully.",
    },
    { headers: NO_CACHE_HEADERS }
  );
}
