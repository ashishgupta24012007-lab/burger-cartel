import { NextRequest, NextResponse } from "next/server";
import {
  authenticateAdmin,
  createAdminSession,
} from "@/lib/auth/security";
import {
  getClientIp,
  getUserAgent,
  setAdminSessionCookie,
  assertSameOrigin,
  NO_CACHE_HEADERS,
} from "@/lib/auth/session";

export async function POST(req: NextRequest) {
  try {
    // 1. Enforce Content-Type
    const contentType = req.headers.get("content-type") || "";
    if (!contentType.includes("application/json")) {
      return NextResponse.json(
        { success: false, error: "Invalid Content-Type. application/json required." },
        { status: 415, headers: NO_CACHE_HEADERS }
      );
    }

    // 2. CSRF Defense: verify request origin matches host
    if (!assertSameOrigin(req)) {
      return NextResponse.json(
        { success: false, error: "Cross-origin request rejected." },
        { status: 403, headers: NO_CACHE_HEADERS }
      );
    }

    const body = await req.json();
    const { adminId, password } = body;

    // Strict type and boundary checks to prevent DoS or type-juggling attacks
    if (
      !adminId ||
      typeof adminId !== "string" ||
      adminId.trim().length < 3 ||
      adminId.trim().length > 64 ||
      !password ||
      typeof password !== "string" ||
      password.length < 8 ||
      password.length > 128
    ) {
      return NextResponse.json(
        { success: false, error: "Invalid credentials format or length." },
        { status: 400, headers: NO_CACHE_HEADERS }
      );
    }

    const clientIp = await getClientIp();
    const result = await authenticateAdmin(adminId.trim(), password, clientIp);

    if (!result.success || !result.admin) {
      const isLocked = result.error?.includes("locked");
      return NextResponse.json(
        { success: false, error: result.error || "Authentication failed." },
        { status: isLocked ? 429 : 401, headers: NO_CACHE_HEADERS }
      );
    }

    // Generate session
    const userAgent = await getUserAgent();
    const { signedToken, expiresAt } = await createAdminSession(
      result.admin.adminId,
      clientIp,
      userAgent
    );

    await setAdminSessionCookie(signedToken, expiresAt);

    return NextResponse.json(
      {
        success: true,
        message: "Authentication successful.",
        adminId: result.admin.adminId,
        mustChangePassword: result.admin.mustChangePassword || false,
      },
      { headers: NO_CACHE_HEADERS }
    );
  } catch (err: unknown) {
    console.error("[Login Error]:", err);
    const message =
      process.env.NODE_ENV === "production"
        ? "An unexpected server error occurred."
        : (err instanceof Error ? err.message : "Internal server error");
    return NextResponse.json(
      { success: false, error: message },
      { status: 500, headers: NO_CACHE_HEADERS }
    );
  }
}
