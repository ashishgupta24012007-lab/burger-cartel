import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import {
  isInitialSetupNeeded,
  hashPassword,
  createAdminSession,
  checkRateLimit,
  recordFailedAttempt,
  resetRateLimit,
} from "@/lib/auth/security";
import {
  mutateAuthDatabase,
  AdminRecord,
} from "@/lib/auth/store";
import {
  getClientIp,
  getUserAgent,
  setAdminSessionCookie,
  assertSameOrigin,
  NO_CACHE_HEADERS,
} from "@/lib/auth/session";
import { getDb } from "@/lib/db";

function constantTimeCompare(a: string, b: string): boolean {
  const bufA = Buffer.from(a, "utf8");
  const bufB = Buffer.from(b, "utf8");
  if (bufA.length !== bufB.length) {
    crypto.timingSafeEqual(bufA, bufA);
    return false;
  }
  return crypto.timingSafeEqual(bufA, bufB);
}

export async function POST(req: NextRequest) {
  try {
    // 1. Enforce Content-Type
    const contentType = req.headers.get("content-type") || "";
    if (!contentType.includes("application/json")) {
      return NextResponse.json(
        { success: false, error: "Invalid Content-Type. application/json required." },
        { status: 415, headers: NO_CACHE_HEADERS }
      );
    }

    // 2. CSRF Defense
    if (!assertSameOrigin(req)) {
      return NextResponse.json(
        { success: false, error: "Cross-origin request rejected." },
        { status: 403, headers: NO_CACHE_HEADERS }
      );
    }

    // 3. Security check: only allow if NO admin currently exists
    const setupNeeded = await isInitialSetupNeeded();
    if (!setupNeeded) {
      return NextResponse.json(
        {
          success: false,
          error: "Administrator account already exists. One-time setup is disabled.",
        },
        { status: 403, headers: NO_CACHE_HEADERS }
      );
    }

    const body = await req.json();
    const { adminId, password, confirmPassword, setupToken } = body;
    const clientIp = await getClientIp();
    const rateKey = `setup:${clientIp}`;

    // Rate Limiting: Lock IP after 5 failed setup attempts
    const rateLimit = await checkRateLimit(rateKey);
    if (!rateLimit.allowed) {
      const lockMinutes = rateLimit.lockedUntil
        ? Math.ceil((new Date(rateLimit.lockedUntil).getTime() - Date.now()) / 60000)
        : 15;
      return NextResponse.json(
        {
          success: false,
          error: `Too many failed setup attempts. Access locked for ${lockMinutes} minutes.`,
        },
        { status: 429, headers: NO_CACHE_HEADERS }
      );
    }

    // Guard against public registration in production:
    // If ADMIN_SETUP_TOKEN is configured, verify it with timingSafeEqual.
    // If not configured, in production only allow localhost (127.0.0.1 / ::1).
    const configuredSetupToken = process.env.ADMIN_SETUP_TOKEN;
    if (configuredSetupToken) {
      const providedToken = (req.headers.get("x-setup-token") || setupToken || "") as string;
      if (!providedToken || typeof providedToken !== "string" || !constantTimeCompare(providedToken, configuredSetupToken)) {
        await recordFailedAttempt(rateKey);
        return NextResponse.json(
          { success: false, error: "Invalid or missing administrator setup token." },
          { status: 403, headers: NO_CACHE_HEADERS }
        );
      }
    } else if (process.env.NODE_ENV === "production") {
      const isLoopback = clientIp === "127.0.0.1" || clientIp === "::1" || clientIp === "localhost";
      if (!isLoopback) {
        await recordFailedAttempt(rateKey);
        return NextResponse.json(
          {
            success: false,
            error: "Public administrator registration is prohibited. Configure ADMIN_SETUP_TOKEN or set INITIAL_ADMIN_ID in deployment environment.",
          },
          { status: 403, headers: NO_CACHE_HEADERS }
        );
      }
    }

    if (
      !adminId ||
      typeof adminId !== "string" ||
      adminId.trim().length < 3 ||
      adminId.trim().length > 64
    ) {
      await recordFailedAttempt(rateKey);
      return NextResponse.json(
        { success: false, error: "Admin ID must be between 3 and 64 characters." },
        { status: 400, headers: NO_CACHE_HEADERS }
      );
    }

    if (
      !password ||
      typeof password !== "string" ||
      password.length < 8 ||
      password.length > 128
    ) {
      await recordFailedAttempt(rateKey);
      return NextResponse.json(
        {
          success: false,
          error: "Password must be between 8 and 128 characters long.",
        },
        { status: 400, headers: NO_CACHE_HEADERS }
      );
    }

    if (password !== confirmPassword) {
      await recordFailedAttempt(rateKey);
      return NextResponse.json(
        { success: false, error: "Passwords do not match." },
        { status: 400, headers: NO_CACHE_HEADERS }
      );
    }

    const cleanAdminId = adminId.trim();
    const { hash, salt } = await hashPassword(password);
    const now = new Date().toISOString();

    const newAdmin: AdminRecord = {
      id: crypto.randomUUID(),
      adminId: cleanAdminId,
      passwordHash: hash,
      salt,
      createdAt: now,
      updatedAt: now,
      mustChangePassword: false,
    };

    // 6. Update PostgreSQL Authoritative Store
    const sql = getDb();
    if (sql) {
      const existing = await sql`SELECT COUNT(*) as count FROM admin_users`;
      if (Number(existing[0]?.count || 0) > 0) {
        return NextResponse.json(
          { success: false, error: "Administrator account already exists." },
          { status: 403, headers: NO_CACHE_HEADERS }
        );
      }
      await sql`
        INSERT INTO admin_users (
          id, admin_id, password_hash, salt, role, role_id,
          must_change_password, failed_login_attempts, created_at, updated_at
        ) VALUES (
          gen_random_uuid(),
          ${cleanAdminId},
          ${hash},
          ${salt},
          'superadmin',
          'superadmin',
          FALSE,
          0,
          NOW(),
          NOW()
        )
      `;
    }

    // Atomic mutate local mirror to avoid race condition under concurrent setup requests
    const created = await mutateAuthDatabase((db) => {
      if (db.admins.length > 0 && !sql) {
        return false;
      }
      db.admins.push(newAdmin);
      db.config.bootstrapCompleted = true;
      db.config.bootstrapDate = now;
      db.auditLogs.push({
        id: crypto.randomUUID(),
        event: "ADMIN_INITIAL_SETUP_SUCCESS",
        adminId: cleanAdminId,
        timestamp: now,
        ip: clientIp,
        details: "Initial administrator account created via secure setup.",
      });
      return true;
    });

    if (!created && !sql) {
      return NextResponse.json(
        { success: false, error: "Administrator account already exists." },
        { status: 403, headers: NO_CACHE_HEADERS }
      );
    }

    // Create session & log in immediately
    const userAgent = await getUserAgent();
    const { signedToken, expiresAt } = await createAdminSession(
      cleanAdminId,
      clientIp,
      userAgent
    );

    await setAdminSessionCookie(signedToken, expiresAt);

    await resetRateLimit(rateKey);

    return NextResponse.json(
      {
        success: true,
        message: "Administrator account created successfully.",
        adminId: cleanAdminId,
      },
      { headers: NO_CACHE_HEADERS }
    );
  } catch (err: unknown) {
    console.error("[Setup Error]:", err);
    const message =
      process.env.NODE_ENV === "production"
        ? "An unexpected server error occurred."
        : (err instanceof Error ? err.message : "Internal server error");
    return NextResponse.json(
      { success: false, error: message },
      { status: 500, headers: NO_CACHE_HEADERS }
    );
  }
}
