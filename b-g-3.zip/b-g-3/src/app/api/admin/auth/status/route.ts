import { NextResponse } from "next/server";
import { isInitialSetupNeeded } from "@/lib/auth/security";
import { getAdminSession, NO_CACHE_HEADERS } from "@/lib/auth/session";

export async function GET() {
  const session = await getAdminSession();
  const setupNeeded = await isInitialSetupNeeded();

  return NextResponse.json(
    {
      authenticated: session.authenticated,
      adminId: session.admin?.adminId || null,
      role: session.admin?.role || null,
      roleId: session.admin?.roleId || null,
      permissions: session.admin?.permissions || [],
      assignedOutletId: session.admin?.assignedOutletId || null,
      mustChangePassword: session.admin?.mustChangePassword || false,
      initialSetupNeeded: setupNeeded,
    },
    {
      headers: NO_CACHE_HEADERS,
    }
  );
}
