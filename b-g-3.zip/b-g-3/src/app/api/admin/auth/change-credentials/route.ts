import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import {
  getAdminSession,
  getClientIp,
  getUserAgent,
  setAdminSessionCookie,
  assertSameOrigin,
  NO_CACHE_HEADERS,
} from "@/lib/auth/session";
import {
  verifyPassword,
  hashPassword,
  checkRateLimit,
  recordFailedAttempt,
  resetRateLimit,
  revokeAllAdminSessions,
  createAdminSession,
} from "@/lib/auth/security";
import { readAuthDatabase, writeAuthDatabase } from "@/lib/auth/store";
import { getDb } from "@/lib/db";

export async function POST(req: NextRequest) {
  try {
    const session = await getAdminSession();
    if (!session.authenticated || !session.admin) {
      return NextResponse.json(
        { success: false, error: "Unauthorized. Please log in." },
        { status: 401, headers: NO_CACHE_HEADERS }
      );
    }

    // CSRF Defense
    if (!assertSameOrigin(req)) {
      return NextResponse.json(
        { success: false, error: "Cross-origin request rejected." },
        { status: 403, headers: NO_CACHE_HEADERS }
      );
    }

    // Rate limit check on credential modifications
    const rateKey = `cred_change:${session.admin.adminId.toLowerCase()}`;
    const rateCheck = await checkRateLimit(rateKey);
    if (!rateCheck.allowed) {
      return NextResponse.json(
        { success: false, error: "Too many failed attempts. Modification locked temporarily." },
        { status: 429, headers: NO_CACHE_HEADERS }
      );
    }

    // Enforce Content-Type
    const contentType = req.headers.get("content-type") || "";
    if (!contentType.includes("application/json")) {
      return NextResponse.json(
        { success: false, error: "Invalid Content-Type. application/json required." },
        { status: 415, headers: NO_CACHE_HEADERS }
      );
    }

    const body = await req.json();
    const { currentPassword, newAdminId, newPassword, confirmNewPassword } = body;

    if (!currentPassword || typeof currentPassword !== "string") {
      return NextResponse.json(
        { success: false, error: "Current password is required to verify identity." },
        { status: 400, headers: NO_CACHE_HEADERS }
      );
    }

    const db = readAuthDatabase();
    const adminIndex = db.admins.findIndex((a) => a.id === session.admin!.id);
    if (adminIndex === -1) {
      return NextResponse.json(
        { success: false, error: "Admin record not found." },
        { status: 404, headers: NO_CACHE_HEADERS }
      );
    }

    const currentAdmin = db.admins[adminIndex];
    const isCurrentValid = await verifyPassword(
      currentPassword,
      currentAdmin.passwordHash,
      currentAdmin.salt
    );

    if (!isCurrentValid) {
      await recordFailedAttempt(rateKey);
      return NextResponse.json(
        { success: false, error: "Current password does not match." },
        { status: 400, headers: NO_CACHE_HEADERS }
      );
    }

    // Reset rate limit on successful currentPassword validation
    await resetRateLimit(rateKey);

    const now = new Date().toISOString();
    let updatedAdminId = currentAdmin.adminId;
    let passwordChanged = false;

    // Optional update Admin ID
    if (newAdminId && typeof newAdminId === "string" && newAdminId.trim() !== currentAdmin.adminId) {
      const cleanId = newAdminId.trim();
      if (cleanId.length < 3 || cleanId.length > 64) {
        return NextResponse.json(
          { success: false, error: "New Admin ID must be between 3 and 64 characters." },
          { status: 400, headers: NO_CACHE_HEADERS }
        );
      }
      // Check if duplicate
      const exists = db.admins.some(
        (a) => a.id !== currentAdmin.id && a.adminId.toLowerCase() === cleanId.toLowerCase()
      );
      if (exists) {
        return NextResponse.json(
          { success: false, error: "That Admin ID is already taken." },
          { status: 400, headers: NO_CACHE_HEADERS }
        );
      }
      updatedAdminId = cleanId;
      currentAdmin.adminId = cleanId;
    }

    // Optional update Password
    if (newPassword && typeof newPassword === "string") {
      if (newPassword.length < 8 || newPassword.length > 128) {
        return NextResponse.json(
          { success: false, error: "New password must be between 8 and 128 characters long." },
          { status: 400, headers: NO_CACHE_HEADERS }
        );
      }
      if (newPassword !== confirmNewPassword) {
        return NextResponse.json(
          { success: false, error: "New passwords do not match." },
          { status: 400, headers: NO_CACHE_HEADERS }
        );
      }
      const { hash, salt } = await hashPassword(newPassword);
      currentAdmin.passwordHash = hash;
      currentAdmin.salt = salt;
      passwordChanged = true;
    }

    currentAdmin.mustChangePassword = false;
    currentAdmin.updatedAt = now;
    db.admins[adminIndex] = currentAdmin;

    const clientIp = await getClientIp();
    db.auditLogs.push({
      id: crypto.randomUUID(),
      event: "CREDENTIALS_UPDATED",
      adminId: updatedAdminId,
      timestamp: now,
      ip: clientIp,
      details: passwordChanged ? "Password and credentials updated." : "Admin ID updated.",
    });

    writeAuthDatabase(db);

    // Update PostgreSQL Authoritative Store
    const sql = getDb();
    if (sql) {
      if (passwordChanged) {
        await sql`
          UPDATE admin_users
          SET 
            admin_id = ${updatedAdminId},
            password_hash = ${currentAdmin.passwordHash},
            salt = ${currentAdmin.salt},
            must_change_password = FALSE,
            failed_login_attempts = 0,
            locked_until = NULL,
            updated_at = NOW()
          WHERE LOWER(admin_id) = LOWER(${session.admin.adminId})
        `;
      } else {
        await sql`
          UPDATE admin_users
          SET 
            admin_id = ${updatedAdminId},
            must_change_password = FALSE,
            updated_at = NOW()
          WHERE LOWER(admin_id) = LOWER(${session.admin.adminId})
        `;
      }
    }

    // If password was changed, revoke all old sessions and issue a fresh session
    if (passwordChanged) {
      await revokeAllAdminSessions(currentAdmin.adminId);
      const userAgent = await getUserAgent();
      const { signedToken, expiresAt } = await createAdminSession(
        updatedAdminId,
        clientIp,
        userAgent
      );
      await setAdminSessionCookie(signedToken, expiresAt);
    }

    return NextResponse.json(
      {
        success: true,
        message: "Security credentials updated successfully.",
        adminId: updatedAdminId,
      },
      { headers: NO_CACHE_HEADERS }
    );
  } catch (err: unknown) {
    console.error("[ChangeCredentials Error]:", err);
    const message =
      process.env.NODE_ENV === "production"
        ? "An unexpected server error occurred."
        : (err instanceof Error ? err.message : "Internal server error");
    return NextResponse.json(
      { success: false, error: message },
      { status: 500, headers: NO_CACHE_HEADERS }
    );
  }
}
