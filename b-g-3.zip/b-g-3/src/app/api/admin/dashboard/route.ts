import { NextResponse } from "next/server";
import { getAdminSession, NO_CACHE_HEADERS } from "@/lib/auth/session";
import { getDb } from "@/lib/db";
import { getCmsData } from "@/lib/db/cmsRepository";
import { ALL_OUTLETS_LIST } from "@/data/seoData";

export async function GET() {
  const session = await getAdminSession();
  if (!session.authenticated || !session.admin) {
    return NextResponse.json(
      { success: false, error: "Unauthorized." },
      { status: 401, headers: NO_CACHE_HEADERS }
    );
  }

  const sql = getDb();
  let recentLogs: Array<{ event: string; adminId?: string; details?: string; timestamp: string }> = [];
  let activeSessionsCount = 1;

  if (sql) {
    try {
      const logRows = await sql`
        SELECT event, admin_id AS "adminId", details, timestamp
        FROM audit_logs
        ORDER BY timestamp DESC
        LIMIT 10
      `;
      recentLogs = logRows.map((r) => ({
        event: String(r.event),
        adminId: r.adminId ? String(r.adminId) : undefined,
        details: r.details ? String(r.details) : undefined,
        timestamp: new Date(r.timestamp as string).toISOString(),
      }));

      const sessionRows = await sql`
        SELECT COUNT(*) as count 
        FROM admin_sessions 
        WHERE expires_at > NOW()
      `;
      activeSessionsCount = Number(sessionRows[0]?.count || 1);
    } catch {
      // Fallback gracefully
    }
  }

  const cms = await getCmsData().catch(() => null);
  const liveOutlets = cms?.outlets && cms.outlets.length > 0
    ? cms.outlets.map((o) => ({
        name: o.name,
        slug: o.slug,
        hours: o.hoursDisplay,
        phone: o.phone || "Not listed",
      }))
    : ALL_OUTLETS_LIST.map((o) => ({
        name: o.name,
        slug: o.slug,
        hours: o.hoursDisplay,
        phone: o.phone || "Not listed",
      }));

  return NextResponse.json(
    {
      success: true,
      admin: {
        adminId: session.admin.adminId,
        role: session.admin.role,
        roleId: session.admin.roleId,
        permissions: session.admin.permissions || [],
        createdAt: session.admin.createdAt,
        updatedAt: session.admin.updatedAt,
        mustChangePassword: session.admin.mustChangePassword || false,
      },
      system: {
        storageType: sql ? "PostgreSQL Authoritative Persistence Layer" : "Local Persistent Encrypted Store",
        status: "Operational & Encrypted",
        activeSessionsCount,
        phoneAuthReady: true,
        phoneAuthEnabled: false,
      },
      outlets: liveOutlets,
      recentLogs,
    },
    { headers: NO_CACHE_HEADERS }
  );
}
