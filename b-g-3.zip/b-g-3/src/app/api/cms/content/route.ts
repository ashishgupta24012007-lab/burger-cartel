import { NextRequest, NextResponse } from "next/server";
import { getCmsData } from "@/lib/db/cmsRepository";

export async function GET(req: NextRequest) {
  try {
    // Check if an authorized preview token is supplied (for admin preview mode)
    const isPreview = req.nextUrl.searchParams.get("preview") === "true";
    
    // In production public calls, getCmsData queries strictly published rows
    const cms = await getCmsData({ publishedOnly: !isPreview });

    // Filter and sort menu categories for public site
    const publicCategories = (cms.menuCategories || [])
      .filter((c) => c.isVisible !== false)
      .sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));

    // Filter and sort menu items for public site — strictly reject draft/unpublished items
    const publicMenuItems = (cms.menuItems || [])
      .filter((m) => m.isVisible !== false && (isPreview || m.publicationStatus === "published"))
      .sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));

    // Filter out hidden reviews for public site
    const publicReviews = (cms.reviews || []).filter((r) => !r.hidden);

    // Filter out unpublished custom pages
    const publicCustomPages = (cms.customPages || []).filter((p) => p.isPublished);

    // Sort gallery items
    const publicGallery = (cms.gallery || []).sort(
      (a, b) => (a.sortOrder || 0) - (b.sortOrder || 0)
    );

    return NextResponse.json(
      {
        success: true,
        siteContent: cms.siteContent,
        menuCategories: publicCategories,
        menuItems: publicMenuItems,
        reviews: publicReviews,
        customPages: publicCustomPages,
        gallery: publicGallery,
        outlets: cms.outlets || [],
        outletMenuAvailability: cms.outletMenuAvailability || {},
        outletMenuOverrides: cms.outletMenuOverrides || {},
        publishedAt: cms.publishedAt || cms.updatedAt,
        updatedAt: cms.updatedAt,
      },
      {
        headers: {
          "Cache-Control": "no-cache, no-store, must-revalidate, max-age=0",
          Pragma: "no-cache",
        },
      }
    );
  } catch (err: unknown) {
    if (err && typeof err === "object" && "digest" in err && String((err as { digest?: string }).digest).startsWith("NEXT_")) {
      throw err;
    }
    console.error("[CMS Content Error]:", err);
    return NextResponse.json(
      { success: false, error: "Failed to load content." },
      { status: 500 }
    );
  }
}
