import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import { getDb } from "@/lib/db";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ filename: string }> }
) {
  try {
    const { filename } = await params;

    // Sanitize filename to prevent directory traversal
    const cleanFilename = path.basename(filename);
    if (!cleanFilename || cleanFilename !== filename) {
      return new NextResponse("Invalid filename", { status: 400 });
    }

    // 1. Check local disk first if present
    const localPath = path.join(process.cwd(), "public", "uploads", cleanFilename);
    if (fs.existsSync(localPath)) {
      const buffer = fs.readFileSync(localPath);
      const ext = path.extname(cleanFilename).toLowerCase();
      const mimeTypes: Record<string, string> = {
        ".webp": "image/webp",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".avif": "image/avif",
      };
      const contentType = mimeTypes[ext] || "application/octet-stream";

      return new NextResponse(buffer, {
        headers: {
          "Content-Type": contentType,
          "Cache-Control": "public, max-age=31536000, immutable",
          "X-Content-Type-Options": "nosniff",
        },
      });
    }

    // 2. Fetch from PostgreSQL managed storage
    const sql = getDb();
    if (sql) {
      const rows = await sql`
        SELECT mime_type, data_base64, public_url
        FROM media_assets
        WHERE filename = ${cleanFilename}
        LIMIT 1
      `;

      if (rows.length > 0) {
        const { mime_type, data_base64, public_url } = rows[0];

        // If hosted on external CDN/S3 bucket, redirect directly
        if (public_url && typeof public_url === "string" && public_url.startsWith("https://")) {
          return NextResponse.redirect(public_url, {
            status: 307,
            headers: {
              "Cache-Control": "public, max-age=31536000, immutable",
            },
          });
        }

        if (data_base64) {
          const buffer = Buffer.from(data_base64 as string, "base64");
          return new NextResponse(buffer, {
            headers: {
              "Content-Type": (mime_type as string) || "image/webp",
              "Cache-Control": "public, max-age=31536000, immutable",
              "X-Content-Type-Options": "nosniff",
            },
          });
        }
      }
    }

    return new NextResponse("Asset not found", { status: 404 });
  } catch (err) {
    console.error("[Media Serve Error]:", err);
    return new NextResponse("Server error", { status: 500 });
  }
}
