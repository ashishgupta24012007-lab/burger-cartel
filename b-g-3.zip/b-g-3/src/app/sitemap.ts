import type { MetadataRoute } from "next";
import { SITE_URL } from "@/data/seoData";
import { getCmsData } from "@/lib/db/cmsRepository";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const lastModified = new Date();

  // Core brand & commercial pages
  const coreRoutes: MetadataRoute.Sitemap = [
    {
      url: `${SITE_URL}/`,
      lastModified,
      changeFrequency: "daily",
      priority: 1.0,
    },
    {
      url: `${SITE_URL}/menu`,
      lastModified,
      changeFrequency: "weekly",
      priority: 0.9,
    },
    {
      url: `${SITE_URL}/locations`,
      lastModified,
      changeFrequency: "weekly",
      priority: 0.9,
    },
    {
      url: `${SITE_URL}/order-online`,
      lastModified,
      changeFrequency: "weekly",
      priority: 0.85,
    },
    {
      url: `${SITE_URL}/about`,
      lastModified,
      changeFrequency: "monthly",
      priority: 0.7,
    },
    {
      url: `${SITE_URL}/terms`,
      lastModified,
      changeFrequency: "monthly",
      priority: 0.4,
    },
    {
      url: `${SITE_URL}/privacy-policy`,
      lastModified,
      changeFrequency: "monthly",
      priority: 0.4,
    },
  ];

  let locationRoutes: MetadataRoute.Sitemap = [];
  let customPageRoutes: MetadataRoute.Sitemap = [];

  try {
    const cms = await getCmsData();

    // Dynamically list all live active outlets from PostgreSQL
    locationRoutes = (cms.outlets || [])
      .filter((outlet) => outlet.isOpen !== false)
      .map((outlet) => ({
        url: `${SITE_URL}/locations/${outlet.slug}`,
        lastModified: new Date(outlet.updatedAt || lastModified),
        changeFrequency: "weekly" as const,
        priority: 0.85,
      }));

    // Dynamic published CMS custom pages (e.g. /p/[slug])
    customPageRoutes = (cms.customPages || [])
      .filter((page) => page.isPublished)
      .map((page) => ({
        url: `${SITE_URL}/p/${page.slug}`,
        lastModified: new Date(page.updatedAt || lastModified),
        changeFrequency: "weekly" as const,
        priority: 0.75,
      }));
  } catch (err) {
    console.warn("[Sitemap] Failed to fetch dynamic database routes:", err);
  }

  return [...coreRoutes, ...locationRoutes, ...customPageRoutes];
}
