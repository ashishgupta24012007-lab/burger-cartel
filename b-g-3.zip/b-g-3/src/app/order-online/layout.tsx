import type { Metadata } from "next";
import { SITE_URL, generateBreadcrumbSchema, safeJsonLd } from "@/data/seoData";
import { getCmsData } from "@/lib/db/cmsRepository";

export async function generateMetadata(): Promise<Metadata> {
  const cms = await getCmsData();
  const seo = cms.siteContent.seo?.["order-online"] || cms.siteContent.seo?.orderOnline;

  const title = seo?.title || "Order Online — Delivery & Takeaway via Swiggy & Zomato";
  const description =
    seo?.description ||
    "Order Burger Cartel food delivery online across Siliguri, Darjeeling, and Kurseong. Direct Swiggy and Zomato links for all verified branches.";
  const ogImage = seo?.ogImage || "/images/og-image.png";

  return {
    title,
    description,
    alternates: {
      canonical: "/order-online",
    },
    openGraph: {
      title,
      description,
      url: `${SITE_URL}/order-online`,
      images: [
        {
          url: ogImage,
          width: 1200,
          height: 630,
          type: "image/png",
          alt: "Burger Cartel loaded cheesy fries and artisan smash burgers",
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [ogImage],
    },
    robots: {
      index: !seo?.noindex,
      follow: !seo?.noindex,
    },
  };
}

export default function OrderOnlineLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const breadcrumbSchema = generateBreadcrumbSchema([
    { name: "Home", url: "/" },
    { name: "Order Online", url: "/order-online" },
  ]);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: safeJsonLd(breadcrumbSchema) }}
      />
      {children}
    </>
  );
}
