"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import {
  ArrowRight,
  ArrowLeft,
  MapPin,
  ExternalLink,
  Menu as MenuIcon,
  X as CloseIcon,
  Search,
  CheckCircle2,
  Info,
} from "lucide-react";
import LocationModal from "@/components/LocationModal";
import MenuModal from "@/components/MenuModal";
import Footer from "@/components/Footer";
import { fetchCmsContent, onCmsUpdate } from "@/lib/client/cmsClient";
import type { CmsOutlet, CmsDatabaseSchema } from "@/lib/cms/store";

interface PlatformLink {
  platform: "swiggy" | "zomato";
  url: string;
  isDirect: boolean;
  label: string;
  note: string;
}

interface OrderBranch {
  id: string;
  name: string;
  city: "Siliguri" | "Darjeeling" | "Kurseong";
  locality: string;
  address: string;
  links: PlatformLink[];
}

const BRANCHES: OrderBranch[] = [
  // SILIGURI OUTLETS
  {
    id: "pradhan-nagar",
    name: "Burger Cartel — Pradhan Nagar",
    city: "Siliguri",
    locality: "Pradhan Nagar / Ward 2",
    address: "345/10/1/A Premises, Nivedita Road, Pradhan Nagar, Siliguri.",
    links: [
      {
        platform: "swiggy",
        url: "https://www.swiggy.com/city/siliguri/burger-cartel-janta-nagar-rest1069787",
        isDirect: true,
        label: "ORDER ON SWIGGY",
        note: "Direct Restaurant Menu",
      },
      {
        platform: "zomato",
        url: "https://www.zomato.com/siliguri/burger-cartel-pradhan-nagar/order",
        isDirect: true,
        label: "ORDER ON ZOMATO",
        note: "Direct Restaurant Menu",
      },
    ],
  },
  {
    id: "sukna-janta-nagar",
    name: "Burger Cartel — Sukna / Janta Nagar",
    city: "Siliguri",
    locality: "Methibari / Salbari",
    address: "Shop No. 02, Ground Floor, Methibari, Janta Nagar, Siliguri.",
    links: [
      {
        platform: "swiggy",
        url: "https://www.swiggy.com/city/siliguri/burger-cartel-sukna-janta-nagar-rest869349",
        isDirect: true,
        label: "ORDER ON SWIGGY",
        note: "Direct Restaurant Menu",
      },
      {
        platform: "zomato",
        url: "https://www.zomato.com/siliguri/delivery?dish=burger",
        isDirect: false,
        label: "SEARCH ON ZOMATO",
        note: "Area Delivery Search",
      },
    ],
  },
  {
    id: "patiram-jote-shivmandir",
    name: "Burger Cartel — Patiram Jote / Shiv Mandir",
    city: "Siliguri",
    locality: "Near NBU / Shiv Mandir",
    address: "1st Floor, Atharokhai, Bara Mohansingh, near Shiv Mandir, Patiram Jote, Siliguri.",
    links: [
      {
        platform: "zomato",
        url: "https://www.zomato.com/hi/siliguri/burger-cartel-patiram-jote/order",
        isDirect: true,
        label: "ORDER ON ZOMATO",
        note: "Direct Restaurant Menu",
      },
      {
        platform: "swiggy",
        url: "https://www.swiggy.com/city/siliguri/restaurants",
        isDirect: false,
        label: "SEARCH ON SWIGGY",
        note: "Siliguri Platform Search",
      },
    ],
  },

  // DARJEELING OUTLET
  {
    id: "darjeeling-chauk-bazaar",
    name: "Burger Cartel Café & Restaurant — Darjeeling",
    city: "Darjeeling",
    locality: "Hotel Seven Seas / Chauk Bazaar",
    address: "Hotel Seven Seas building, 17 N. B. Singh Road, Darjeeling.",
    links: [
      {
        platform: "swiggy",
        url: "https://www.swiggy.com/city/darjeeling/central-darjeeling-restaurants/snacks-cuisine-restaurants",
        isDirect: false,
        label: "VIEW SWIGGY LISTING",
        note: "Darjeeling Category Listing",
      },
      {
        platform: "zomato",
        url: "https://www.zomato.com/darjeeling/delivery/dish-burger",
        isDirect: false,
        label: "SEARCH ZOMATO DARJEELING",
        note: "Darjeeling Delivery Search",
      },
    ],
  },

  // KURSEONG OUTLET
  {
    id: "kurseong",
    name: "Burger Cartel — Kurseong",
    city: "Kurseong",
    locality: "Municipal Complex / Motor Stand",
    address: "Stall C-1, Municipal Complex, Motor Stand, Kurseong.",
    links: [
      {
        platform: "zomato",
        url: "https://www.zomato.com/cs/kurseong/burger-cartel-kurseong-locality-kurseong/order",
        isDirect: true,
        label: "ORDER ON ZOMATO",
        note: "Direct Restaurant Menu",
      },
      {
        platform: "swiggy",
        url: "https://www.swiggy.com/city/siliguri/restaurants",
        isDirect: false,
        label: "SEARCH ON SWIGGY",
        note: "Regional Platform Search",
      },
    ],
  },
];

function mergeBranches(defaults: OrderBranch[], cmsOutlets: CmsOutlet[]): OrderBranch[] {
  if (!cmsOutlets || cmsOutlets.length === 0) return defaults;
  return defaults.map((branch) => {
    const live = cmsOutlets.find(
      (o) =>
        o.slug === branch.id ||
        (branch.id === "sukna-janta-nagar" && o.slug === "panchanai") ||
        (branch.id === "patiram-jote-shivmandir" && o.slug === "shivmandir") ||
        (branch.id === "darjeeling-chauk-bazaar" && o.slug === "darjeeling") ||
        o.id === branch.id
    );
    if (!live) return branch;

    const updatedLinks = [...branch.links];
    if (live.swiggyUrl) {
      const sIdx = updatedLinks.findIndex((l) => l.platform === "swiggy");
      if (sIdx >= 0) {
        updatedLinks[sIdx] = {
          ...updatedLinks[sIdx],
          url: live.swiggyUrl,
          isDirect: true,
          label: "ORDER ON SWIGGY",
          note: "Direct Restaurant Menu",
        };
      } else {
        updatedLinks.push({
          platform: "swiggy",
          url: live.swiggyUrl,
          isDirect: true,
          label: "ORDER ON SWIGGY",
          note: "Direct Restaurant Menu",
        });
      }
    }
    if (live.zomatoUrl) {
      const zIdx = updatedLinks.findIndex((l) => l.platform === "zomato");
      if (zIdx >= 0) {
        updatedLinks[zIdx] = {
          ...updatedLinks[zIdx],
          url: live.zomatoUrl,
          isDirect: true,
          label: "ORDER ON ZOMATO",
          note: "Direct Restaurant Menu",
        };
      } else {
        updatedLinks.push({
          platform: "zomato",
          url: live.zomatoUrl,
          isDirect: true,
          label: "ORDER ON ZOMATO",
          note: "Direct Restaurant Menu",
        });
      }
    }

    return {
      ...branch,
      name: live.name || branch.name,
      address: live.address || branch.address,
      links: updatedLinks,
    };
  });
}

export default function OrderOnlinePage() {
  const [selectedCity, setSelectedCity] = useState<string>("ALL");
  const [locationOpen, setLocationOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [branches, setBranches] = useState<OrderBranch[]>(BRANCHES);

  useEffect(() => {
    let mounted = true;
    fetchCmsContent()
      .then((data) => {
        if (mounted && data?.outlets && data.outlets.length > 0) {
          setBranches(mergeBranches(BRANCHES, data.outlets));
        }
      })
      .catch((err) => console.error("[OrderOnline] CMS load error:", err));

    const unsubscribe = onCmsUpdate((data: CmsOutlet[] | CmsDatabaseSchema) => {
      const outlets = "outlets" in data ? data.outlets : data;
      if (mounted && outlets && Array.isArray(outlets) && outlets.length > 0) {
        setBranches(mergeBranches(BRANCHES, outlets));
      }
    });

    return () => {
      mounted = false;
      unsubscribe();
    };
  }, []);

  const filteredBranches =
    selectedCity === "ALL"
      ? branches
      : branches.filter((b) => b.city.toUpperCase() === selectedCity);

  return (
    <div className="relative min-h-screen bg-[#F5F0E7] text-[#292925] overflow-x-hidden selection:bg-[#1F2B20] selection:text-white">
      {/* TOP NAVIGATION BAR */}
      <header className="sticky top-0 z-40 w-full bg-[#F5F0E7]/92 backdrop-blur-md border-b border-[#E8DED0]/60 transition-all">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 md:px-12 py-3.5 sm:py-4.5 flex items-center justify-between">
          {/* Left Brand Wordmark / Logo */}
          <Link
            href="/"
            className="flex items-center gap-2.5 sm:gap-3 group select-none"
          >
            <div className="relative w-11 h-11 sm:w-13 sm:h-13 rounded-full overflow-hidden shrink-0 bg-white p-1 shadow-xs border border-[#E8DED0]">
              <Image
                src="/images/logo.png"
                alt="BURGER CARTEL Logo"
                width={52}
                height={52}
                className="w-full h-full object-contain"
                priority
              />
            </div>
            <div className="flex flex-col leading-tight">
              <span className="font-sans font-black text-sm sm:text-base tracking-[0.14em] text-[#1F2B20] uppercase">
                BURGER CARTEL
              </span>
              <span className="font-sans text-[8px] sm:text-[9px] font-bold tracking-[0.24em] text-[#B18B5B] uppercase mt-0.5">
                ORDER ONLINE
              </span>
            </div>
          </Link>

          {/* Center Navigation Links: HOME | ABOUT | ORDER ONLINE | MENU | OUTLETS | GALLERY | CONTACT */}
          <nav className="hidden md:flex items-center gap-6 lg:gap-8 text-xs font-bold tracking-[0.2em] uppercase text-[#4A4843]">
            <Link
              href="/"
              className="hover:text-[#1F2B20] transition-colors py-1"
            >
              HOME
            </Link>

            <Link
              href="/about"
              className="hover:text-[#1F2B20] transition-colors py-1"
            >
              ABOUT
            </Link>

            {/* Active ORDER ONLINE Link with Warm Caramel Underline */}
            <div className="relative py-1 text-[#1F2B20]">
              <span>ORDER ONLINE</span>
              <span className="absolute bottom-[-3px] left-0 right-0 h-[2px] bg-[#B18B5B] rounded-full" />
            </div>

            <Link
              href="/menu"
              className="hover:text-[#1F2B20] transition-colors py-1 cursor-pointer"
            >
              MENU
            </Link>

            <button
              type="button"
              onClick={() => setLocationOpen(true)}
              className="hover:text-[#1F2B20] transition-colors py-1 cursor-pointer"
            >
              OUTLETS
            </button>

            <Link
              href="/#gallery"
              className="hover:text-[#1F2B20] transition-colors py-1"
            >
              GALLERY
            </Link>

            <button
              type="button"
              onClick={() => setLocationOpen(true)}
              className="hover:text-[#1F2B20] transition-colors py-1 cursor-pointer"
            >
              CONTACT
            </button>
          </nav>

          {/* Right Action: Forest Green "VISIT A BRANCH →" Pill Button */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setLocationOpen(true)}
              className="group px-5 sm:px-6 py-2.5 sm:py-3 rounded-full bg-[#1F2B20] hover:bg-[#2a3c2b] text-white text-xs font-bold tracking-[0.16em] uppercase flex items-center gap-2 shadow-md hover:shadow-lg transition-all cursor-pointer select-none"
            >
              <span>VISIT A BRANCH</span>
              <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
            </button>

            {/* Mobile Menu Hamburger */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-[#1F2B20] md:hidden transition-colors"
              aria-label="Toggle navigation"
            >
              {mobileMenuOpen ? (
                <CloseIcon className="w-5 h-5" />
              ) : (
                <MenuIcon className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-[#E8DED0] bg-[#FAF7F0] px-6 py-5 flex flex-col gap-3.5 animate-in fade-in slide-in-from-top-2">
            <Link
              href="/"
              onClick={() => setMobileMenuOpen(false)}
              className="text-xs font-bold tracking-[0.2em] uppercase text-[#4A4843] hover:text-[#1F2B20] py-1"
            >
              HOME
            </Link>
            <Link
              href="/about"
              onClick={() => setMobileMenuOpen(false)}
              className="text-xs font-bold tracking-[0.2em] uppercase text-[#4A4843] hover:text-[#1F2B20] py-1"
            >
              ABOUT
            </Link>
            <div className="text-xs font-black tracking-[0.2em] uppercase text-[#1F2B20] py-1 flex items-center justify-between">
              <span>ORDER ONLINE</span>
              <span className="w-2 h-2 rounded-full bg-[#B18B5B]" />
            </div>
            <Link
              href="/menu"
              onClick={() => setMobileMenuOpen(false)}
              className="text-left text-xs font-bold tracking-[0.2em] uppercase text-[#4A4843] hover:text-[#1F2B20] py-1"
            >
              MENU
            </Link>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                setLocationOpen(true);
              }}
              className="text-left text-xs font-bold tracking-[0.2em] uppercase text-[#4A4843] hover:text-[#1F2B20] py-1"
            >
              OUTLETS (5 BRANCHES)
            </button>
            <Link
              href="/#gallery"
              onClick={() => setMobileMenuOpen(false)}
              className="text-xs font-bold tracking-[0.2em] uppercase text-[#4A4843] hover:text-[#1F2B20] py-1"
            >
              GALLERY
            </Link>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                setLocationOpen(true);
              }}
              className="text-left text-xs font-bold tracking-[0.2em] uppercase text-[#4A4843] hover:text-[#1F2B20] py-1"
            >
              CONTACT
            </button>
            <Link
              href="/menu"
              onClick={() => setMobileMenuOpen(false)}
              className="w-full mt-2 py-3 rounded-full bg-[#1F2B20] text-white text-xs font-bold uppercase tracking-widest text-center block"
            >
              EXPLORE MENU ↗
            </Link>
          </div>
        )}
      </header>

      {/* MAIN CONTAINER */}
      <main className="max-w-6xl mx-auto px-5 sm:px-8 md:px-12 pt-8 sm:pt-12 md:pt-14 pb-20 sm:pb-24">
        {/* PAGE INTRODUCTION */}
        <div className="mb-10 sm:mb-14 text-center max-w-2xl mx-auto">
          {/* Small label: BURGER CARTEL · ORDER ONLINE */}
          <span className="text-[10px] sm:text-xs font-bold tracking-[0.3em] text-[#B18B5B] uppercase block mb-2.5">
            BURGER CARTEL · ORDER ONLINE
          </span>

          {/* Main heading: FIND YOUR NEAREST CARTEL. */}
          <h1 className="font-sans font-black text-4xl sm:text-5xl md:text-6xl tracking-[-0.03em] leading-[0.92] uppercase text-[#1F2B20] mb-3.5">
            FIND YOUR NEAREST CARTEL.
          </h1>

          {/* Supporting copy */}
          <p className="text-xs sm:text-sm text-[#4A4843] leading-relaxed max-w-xl mx-auto">
            Choose a branch and order online through your preferred platform.
            Availability and delivery areas may vary by location.
          </p>

          {/* City Filter Tabs (Neumorphic Pill Chips - Fully Responsive & Wrapped) */}
          <div className="mt-6 sm:mt-7 flex flex-wrap items-center justify-center gap-2 sm:gap-2.5 max-w-xl mx-auto px-2">
            {[
              { id: "ALL", label: "ALL OUTLETS", count: 5 },
              { id: "SILIGURI", label: "SILIGURI", count: 3 },
              { id: "DARJEELING", label: "DARJEELING", count: 1 },
              { id: "KURSEONG", label: "KURSEONG", count: 1 },
            ].map((tab) => {
              const active = selectedCity === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setSelectedCity(tab.id)}
                  className={`inline-flex items-center gap-1.5 px-3.5 sm:px-4 py-2 sm:py-2.5 rounded-full text-xs font-bold tracking-[0.1em] uppercase transition-all duration-200 cursor-pointer ${
                    active
                      ? "bg-[#1F2B20] text-white shadow-md scale-102"
                      : "neu-cream-pill text-[#4A4843] hover:text-[#1F2B20] hover:bg-white/80"
                  }`}
                >
                  <span>{tab.label}</span>
                  <span
                    className={`text-[10px] font-mono px-1.5 py-0.5 rounded-full ${
                      active
                        ? "bg-white/20 text-white"
                        : "bg-[#E8DED0]/70 text-[#736F67]"
                    }`}
                  >
                    {tab.count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* BRANCH CARDS GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-7">
          {filteredBranches.map((branch) => (
            <div
              key={branch.id}
              className="neu-cream-card rounded-2xl p-6 sm:p-7 flex flex-col justify-between transition-all duration-300 hover:-translate-y-1 hover:shadow-xl bg-[#FAF7F0]"
            >
              {/* Card Header: City Tag + Branch Name + Address */}
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className="px-2.5 py-1 rounded-full text-[9px] sm:text-[10px] font-bold tracking-[0.18em] uppercase bg-[#E8DED0]/70 text-[#1F2B20] border border-[#E8DED0]">
                    {branch.city} · {branch.locality}
                  </span>
                </div>

                <h3 className="font-sans font-black text-xl sm:text-2xl tracking-tight text-[#1F2B20] uppercase leading-tight mb-2.5">
                  {branch.name}
                </h3>

                <div className="flex items-start gap-2 text-xs text-[#736F67] mb-6 leading-relaxed">
                  <MapPin className="w-3.5 h-3.5 text-[#B18B5B] shrink-0 mt-0.5" />
                  <span>{branch.address}</span>
                </div>
              </div>

              {/* Ordering Platform Buttons */}
              <div className="space-y-3 pt-5 border-t border-[#E8DED0]">
                {branch.links.map((link, idx) => {
                  const isSwiggy = link.platform === "swiggy";
                  return (
                    <a
                      key={idx}
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`group w-full p-3 sm:p-3.5 rounded-xl border flex items-center justify-between transition-all duration-200 cursor-pointer ${
                        isSwiggy
                          ? "bg-white hover:bg-orange-50/70 border-orange-200/80 hover:border-orange-400 text-[#292925] shadow-xs hover:shadow-md"
                          : "bg-white hover:bg-rose-50/70 border-rose-200/80 hover:border-rose-400 text-[#292925] shadow-xs hover:shadow-md"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        {/* Platform Brand Badge */}
                        <div
                          className={`w-8 h-8 rounded-lg flex items-center justify-center font-black text-xs text-white shrink-0 shadow-xs ${
                            isSwiggy ? "bg-[#FC8019]" : "bg-[#E23744]"
                          }`}
                        >
                          {isSwiggy ? "S" : "Z"}
                        </div>

                        <div className="text-left">
                          <span className="block text-[11px] sm:text-xs font-black tracking-wider text-[#1F2B20] group-hover:text-black">
                            {link.label}
                          </span>
                          <span className="block text-[9px] font-semibold text-[#8C877D] uppercase tracking-wide">
                            {link.note}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 text-[10px] font-bold text-[#8C877D] group-hover:text-[#1F2B20] shrink-0">
                        {link.isDirect ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Search className="w-3.5 h-3.5 text-amber-600" />
                        )}
                        <ExternalLink className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                      </div>
                    </a>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* BOTTOM MICROCOPY & NAVIGATION */}
        <div className="mt-14 sm:mt-16 text-center space-y-4 pt-10 border-t border-[#E8DED0]">
          <div className="inline-flex items-center gap-2 text-xs text-[#736F67]">
            <Info className="w-3.5 h-3.5 text-[#B18B5B]" />
            <p>
              Delivery availability depends on your location and the ordering platform.
            </p>
          </div>

          <div>
            <Link
              href="/"
              className="inline-flex items-center gap-2 text-xs font-bold tracking-[0.2em] uppercase text-[#1F2B20] hover:text-[#B18B5B] transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>BACK TO HOME</span>
            </Link>
          </div>
        </div>
      </main>

      {/* FOOTER */}
      <Footer onOpenLocation={() => setLocationOpen(true)} />

      {/* Interactive Modals */}
      <LocationModal
        isOpen={locationOpen}
        onClose={() => setLocationOpen(false)}
      />

      <MenuModal
        isOpen={menuOpen}
        onClose={() => setMenuOpen(false)}
      />
    </div>
  );
}
