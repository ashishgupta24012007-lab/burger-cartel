import type { Metadata } from "next";
import Link from "next/link";
import { ChevronRight, ShieldCheck, Lock, CheckCircle2 } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { SITE_URL, safeJsonLd } from "@/data/seoData";

export const metadata: Metadata = {
  title: "Privacy Policy | Burger Cartel",
  description:
    "Privacy and data protection disclosure for the official Burger Cartel restaurant website.",
  alternates: {
    canonical: "/privacy-policy",
  },
};

export default function PrivacyPolicyPage() {
  const breadcrumbJsonLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: "Home",
        item: SITE_URL,
      },
      {
        "@type": "ListItem",
        position: 2,
        name: "Privacy Policy",
        item: `${SITE_URL}/privacy-policy`,
      },
    ],
  };

  return (
    <div className="min-h-screen bg-[#F5F0E7] text-[#292925] flex flex-col font-sans selection:bg-[#1F2B20] selection:text-white">
      <Navbar />

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: safeJsonLd(breadcrumbJsonLd) }}
      />

      <main className="flex-1 max-w-4xl mx-auto w-full px-5 sm:px-8 md:px-12 pt-32 pb-20">
        {/* Breadcrumb Navigation */}
        <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-xs text-[#736F67] mb-8">
          <Link href="/" className="hover:text-[#1F2B20] transition-colors">
            Home
          </Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <span className="text-[#1F2B20] font-semibold">Privacy Policy</span>
        </nav>

        {/* Page Header */}
        <header className="border-b border-[#E8DED0] pb-8 mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#1F2B20]/10 border border-[#1F2B20]/20 text-[#1F2B20] text-xs font-semibold mb-3">
            <Lock className="w-3.5 h-3.5" />
            <span>Data Protection Notice</span>
          </div>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-black uppercase tracking-tight text-[#1F2B20] mb-3">
            Privacy Policy
          </h1>
          <p className="text-xs sm:text-sm text-[#4A4843] leading-relaxed max-w-2xl">
            Burger Cartel is committed to respecting your privacy. This policy describes how our promotional website operates and discloses data practices in accordance with applicable law in India, including the Digital Personal Data Protection Act, 2023.
          </p>
        </header>

        {/* Privacy Content */}
        <div className="space-y-8 text-sm text-[#4A4843] leading-relaxed">
          {/* Section 1: Data Collection Truth */}
          <section className="bg-white border border-[#E8DED0] rounded-2xl p-6 sm:p-8 shadow-sm">
            <h2 className="text-base sm:text-lg font-black uppercase tracking-tight text-[#1F2B20] mb-3 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-[#B18B5B]" />
              <span>1. Zero Customer Data Collection</span>
            </h2>
            <p className="mb-3">
              This website is an informational showcase for Burger Cartel restaurant locations, hours, and menus.
            </p>
            <div className="space-y-2">
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#1F2B20] shrink-0 mt-0.5" />
                <span><strong>No Account Registration:</strong> We do not offer customer accounts or store public login credentials on this website.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#1F2B20] shrink-0 mt-0.5" />
                <span><strong>No Online Payments:</strong> We do not ask for or collect credit card, debit card, bank account, or UPI details.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#1F2B20] shrink-0 mt-0.5" />
                <span><strong>No Advertising Trackers:</strong> We do not run third-party advertising tracking pixels or commercial marketing profiling scripts.</span>
              </div>
            </div>
          </section>

          {/* Section 2: Cookies */}
          <section className="bg-white border border-[#E8DED0] rounded-2xl p-6 sm:p-8 shadow-sm">
            <h2 className="text-base sm:text-lg font-black uppercase tracking-tight text-[#1F2B20] mb-3">
              2. Cookies &amp; Local Storage
            </h2>
            <p className="mb-3">
              We do not issue tracking cookies, targeting cookies, or advertising cookies to visitors of this website.
            </p>
            <p>
              The only cookie utilized by this application is a strictly necessary, encrypted HTTP-only session cookie reserved solely for authorized restaurant administrative staff accessing the private content management system. Public website visitors receive no tracking cookies.
            </p>
          </section>

          {/* Section 3: Technical Server Logs */}
          <section className="bg-white border border-[#E8DED0] rounded-2xl p-6 sm:p-8 shadow-sm">
            <h2 className="text-base sm:text-lg font-black uppercase tracking-tight text-[#1F2B20] mb-3">
              3. Technical Server Logs &amp; Security
            </h2>
            <p className="mb-3">
              Like virtually all web servers, our hosting environment temporarily logs standard technical network requests (such as incoming IP address, browser User-Agent, requested page URL, and access timestamp).
            </p>
            <p>
              These logs are used strictly for security monitoring, preventing denial-of-service (DoS) attacks, detecting unauthorized server intrusion attempts, and ensuring server uptime and performance. Technical logs are not combined with any personally identifying profile.
            </p>
          </section>

          {/* Section 4: External Services */}
          <section className="bg-white border border-[#E8DED0] rounded-2xl p-6 sm:p-8 shadow-sm">
            <h2 className="text-base sm:text-lg font-black uppercase tracking-tight text-[#1F2B20] mb-3">
              4. External Links (Swiggy, Zomato &amp; Google Maps)
            </h2>
            <p className="mb-3">
              Our website provides links to external third-party services, including <strong>Swiggy</strong>, <strong>Zomato</strong>, and <strong>Google Maps</strong>.
            </p>
            <p>
              When you click on these links, you leave our website and are subject to the respective third party&apos;s privacy policies and terms of service. We do not control and are not responsible for the data practices of external platforms.
            </p>
          </section>

          {/* Section 5: Inquiries & Policy Updates */}
          <section className="bg-white border border-[#E8DED0] rounded-2xl p-6 sm:p-8 shadow-sm">
            <h2 className="text-base sm:text-lg font-black uppercase tracking-tight text-[#1F2B20] mb-3">
              5. Inquiries &amp; Updates
            </h2>
            <p className="mb-3">
              We may update this Privacy Policy from time to time to reflect changes in our operational or legal requirements. Any modifications will be posted directly on this page with an updated effective date.
            </p>
            <p>
              If you have any questions regarding this Privacy Policy or our website practices, you may contact our restaurant management team at any of our physical outlets in Darjeeling, Kurseong, or Siliguri.
            </p>
          </section>
        </div>

        {/* Footer back link */}
        <div className="mt-12 pt-6 border-t border-[#E8DED0] flex items-center justify-between text-xs text-[#736F67]">
          <Link href="/" className="hover:text-[#1F2B20] font-semibold flex items-center gap-1 transition-colors">
            <span>&larr; Back to Home</span>
          </Link>
          <Link href="/terms" className="hover:text-[#1F2B20] transition-colors">
            View Terms of Use &rarr;
          </Link>
        </div>
      </main>

      <Footer />
    </div>
  );
}
