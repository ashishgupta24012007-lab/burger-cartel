import type { Metadata } from "next";
import { connection } from "next/server";
import { notFound } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { ArrowRight, ChevronRight, Home as HomeIcon } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { readCmsDatabase } from "@/lib/cms/store";
import { getCmsData } from "@/lib/db/cmsRepository";
import { sanitizeUrl } from "@/lib/utils/urlSanitizer";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export function generateStaticParams() {
  const cms = readCmsDatabase();
  const pages = cms.customPages.filter((p) => p.isPublished);
  if (pages.length === 0) {
    return [{ slug: "_preview" }];
  }
  return pages.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  await connection();
  const { slug } = await params;
  const cms = await getCmsData();
  const page = cms.customPages.find(
    (p) => p.slug.toLowerCase() === slug.toLowerCase() && p.isPublished
  );

  if (!page) {
    notFound();
  }

  return {
    title: `${page.title} | Burger Cartel`,
    description: page.subtitle || `Explore ${page.title} at Burger Cartel North Bengal.`,
    openGraph: {
      title: `${page.title} | Burger Cartel`,
      description: page.subtitle || `Explore ${page.title} at Burger Cartel North Bengal.`,
      images: [
        {
          url: page.heroImage || "/images/og-image.png",
          width: 1200,
          height: 630,
          type: "image/png",
          alt: page.title,
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title: `${page.title} | Burger Cartel`,
      description: page.subtitle || `Explore ${page.title} at Burger Cartel North Bengal.`,
      images: [page.heroImage || "/images/og-image.png"],
    },
  };
}

export default async function CustomDynamicPage({ params }: PageProps) {
  await connection();
  const { slug } = await params;
  const cms = await getCmsData();
  const page = cms.customPages.find(
    (p) => p.slug.toLowerCase() === slug.toLowerCase() && p.isPublished
  );

  if (!page) {
    notFound();
  }

  // Parse paragraphs from multi-line text
  const paragraphs = page.content.split(/\n\s*\n/).filter((p) => p.trim().length > 0);

  return (
    <div className="min-h-screen bg-[#F5F0E7] text-[#292925] flex flex-col justify-between selection:bg-[#1F2B20] selection:text-white">
      {/* 1. Header Navigation */}
      <div className="relative z-30 bg-black text-white">
        <Navbar />
      </div>

      <main className="flex-1 pb-20">
        {/* 2. Hero Header Banner */}
        <section className="relative bg-black text-white py-14 sm:py-20 px-6 sm:px-10 border-b border-[#222222]">
          <div className="max-w-4xl mx-auto text-center">
            {/* Breadcrumb */}
            <div className="inline-flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.2em] text-[#B18B5B] mb-5">
              <Link href="/" className="hover:text-white transition-colors flex items-center gap-1">
                <HomeIcon className="w-3.5 h-3.5" />
                <span>Home</span>
              </Link>
              <ChevronRight className="w-3.5 h-3.5 text-zinc-600" />
              <span className="text-zinc-400">Pages</span>
              <ChevronRight className="w-3.5 h-3.5 text-zinc-600" />
              <span className="text-white">{page.title}</span>
            </div>

            <h1 className="font-sans font-black text-3xl sm:text-5xl md:text-6xl uppercase tracking-tight text-white mb-4 leading-tight">
              {page.title}
            </h1>

            {page.subtitle && (
              <p className="text-sm sm:text-base md:text-lg text-zinc-300 max-w-2xl mx-auto leading-relaxed font-medium">
                {page.subtitle}
              </p>
            )}
          </div>
        </section>

        {/* 3. Main Content Container */}
        <div className="max-w-4xl mx-auto px-6 sm:px-10 mt-10 sm:mt-14">
          {/* Optional Hero Image */}
          {page.heroImage && (
            <div className="relative w-full h-64 sm:h-96 rounded-3xl overflow-hidden neu-cream-card mb-12 shadow-md">
              <Image
                src={page.heroImage}
                alt={page.title}
                fill
                className="object-cover"
                sizes="(max-width: 768px) 100vw, 900px"
              />
            </div>
          )}

          {/* Body Content Article */}
          <article className="neu-cream-card rounded-3xl p-8 sm:p-12 md:p-14">
            <div className="space-y-6 text-[#292925] leading-relaxed text-sm sm:text-base md:text-lg">
              {paragraphs.map((p, idx) => {
                if (p.startsWith("- ") || p.startsWith("• ")) {
                  const items = p.split("\n").filter(Boolean);
                  return (
                    <ul key={idx} className="list-disc pl-6 space-y-2 text-[#4A4843]">
                      {items.map((item, itemIdx) => (
                        <li key={itemIdx}>{item.replace(/^[-•]\s*/, "")}</li>
                      ))}
                    </ul>
                  );
                }

                if (p.length < 80 && !p.endsWith(".")) {
                  return (
                    <h2 key={idx} className="font-sans font-black text-xl sm:text-2xl uppercase tracking-tight text-[#1F2B20] pt-4 first:pt-0">
                      {p}
                    </h2>
                  );
                }

                return (
                  <p key={idx} className="text-[#3A3833]">
                    {p}
                  </p>
                );
              })}
            </div>

            {/* Optional Call to Action */}
            {page.ctaText && page.ctaLink && (
              <div className="mt-12 pt-8 border-t border-[#E8DED0] flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#B18B5B] block mb-1">
                    NEXT STEPS
                  </span>
                  <p className="font-bold text-[#1F2B20] text-sm">
                    Ready to take action or have questions?
                  </p>
                </div>
                <a
                  href={sanitizeUrl(page.ctaLink)}
                  rel="noopener noreferrer"
                  className="px-8 py-3.5 rounded-full bg-[#1F2B20] hover:bg-black text-white text-xs font-bold uppercase tracking-[0.2em] inline-flex items-center gap-2 shadow-md transition-all shrink-0"
                >
                  <span>{page.ctaText}</span>
                  <ArrowRight className="w-4 h-4" />
                </a>
              </div>
            )}
          </article>
        </div>
      </main>

      {/* 4. Footer */}
      <Footer />
    </div>
  );
}
