import type { Metadata } from "next";
import { Inter, Great_Vibes, Caveat } from "next/font/google";
import "./globals.css";
import AnnouncementBanner from "@/components/AnnouncementBanner";
import {
  SITE_URL,
  generateOrganizationSchema,
  generateWebSiteSchema,
  safeJsonLd,
} from "@/data/seoData";
import { getCmsData } from "@/lib/db/cmsRepository";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const greatVibes = Great_Vibes({
  variable: "--font-script",
  weight: "400",
  subsets: ["latin"],
  display: "swap",
});

const caveat = Caveat({
  variable: "--font-caveat",
  weight: ["500", "600", "700"],
  subsets: ["latin"],
  display: "swap",
});

export async function generateMetadata(): Promise<Metadata> {
  let siteTitle = "BURGER CARTEL | Cafe & Restaurant — 5 Outlets in Darjeeling, Kurseong & Siliguri";
  let siteDesc = "Burger Cartel is North Bengal's premier American burger restaurant and specialty cafe. Handcrafted smash burgers, wood-fired artisan pizza, and single-origin coffee across 5 verified locations in Darjeeling, Kurseong, and Siliguri.";
  let ogImage = "/images/og-image.png";
  let noIndex = false;

  try {
    const cms = await getCmsData();
    const seo = cms.siteContent.seo?.home || cms.siteContent.seo?.global;
    if (seo?.title) siteTitle = seo.title;
    if (seo?.description) siteDesc = seo.description;
    if (seo?.ogImage) ogImage = seo.ogImage;
    if (seo?.noindex) noIndex = true;
  } catch {
    // Keep defaults during prerender
  }

  return {
    metadataBase: new URL(SITE_URL),
    title: {
      default: siteTitle,
      template: "%s | Burger Cartel",
    },
    description: siteDesc,
    applicationName: "Burger Cartel",
    authors: [{ name: "Burger Cartel" }],
    generator: "Next.js",
    keywords: [
      "Burger Cartel",
      "burgers Siliguri",
      "burgers Darjeeling",
      "burgers Kurseong",
      "best burgers in North Bengal",
      "smash burger Siliguri",
      "wood fired pizza Darjeeling",
      "Panchanai cafe",
      "Pradhan Nagar restaurant",
      "Shivmandir burger",
    ],
    creator: "Burger Cartel",
    publisher: "Burger Cartel",
    formatDetection: {
      email: false,
      address: true,
      telephone: true,
    },
    alternates: {
      canonical: "/",
    },
    icons: {
      icon: "/images/logo.png",
      apple: "/images/logo.png",
    },
    openGraph: {
      type: "website",
      locale: "en_IN",
      url: SITE_URL,
      siteName: "Burger Cartel",
      title: siteTitle,
      description: siteDesc,
      images: [
        {
          url: ogImage,
          width: 1200,
          height: 630,
          type: "image/png",
          alt: "Burger Cartel — Handcrafted Smash Burgers, Pizza & Cafe across North Bengal",
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title: siteTitle,
      description: siteDesc,
      images: [ogImage],
    },
    robots: {
      index: !noIndex,
      follow: !noIndex,
      googleBot: {
        index: !noIndex,
        follow: !noIndex,
        "max-video-preview": -1,
        "max-image-preview": "large",
        "max-snippet": -1,
      },
    },
  };
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const orgSchema = generateOrganizationSchema();
  const webSiteSchema = generateWebSiteSchema();

  return (
    <html
      lang="en"
      className={`${inter.variable} ${greatVibes.variable} ${caveat.variable} h-full antialiased`}
    >
      <head>
        {/* Preload critical mobile hero LCP image for low-bandwidth mobile networks */}
        <link
          rel="preload"
          as="image"
          href="/images/hero-base-mobile.webp"
          type="image/webp"
          media="(orientation: portrait), (max-width: 768px)"
          fetchPriority="high"
        />
        {/* Schema.org Organization Structured Data */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: safeJsonLd(orgSchema) }}
        />
        {/* Schema.org WebSite Structured Data */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: safeJsonLd(webSiteSchema) }}
        />
        {/* Offline & Weak-Connection Service Worker */}
        <script
          dangerouslySetInnerHTML={{
            __html: `
              if ('serviceWorker' in navigator && !window.location.pathname.startsWith('/admin-panel')) {
                window.addEventListener('load', function() {
                  navigator.serviceWorker.register('/sw.js').catch(function() {});
                });
              }
            `,
          }}
        />
      </head>
      <body className="min-h-full bg-black text-white font-sans antialiased overflow-x-hidden selection:bg-white selection:text-black">
        <AnnouncementBanner />
        {children}
      </body>
    </html>
  );
}
