import type { Metadata } from "next";
import Link from "next/link";
import { Home, UtensilsCrossed, MapPin, Compass } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "404 - Page Not Found | Burger Cartel",
  description: "The page you are looking for does not exist or has been moved. Explore our fresh gourmet smash burgers, artisan croissants, and North Bengal outlets.",
};

export default function NotFound() {
  return (
    <div className="min-h-screen bg-[#F5F0E7] text-[#292925] flex flex-col font-sans selection:bg-[#1F2B20] selection:text-white">
      {/* 1. Header Navigation */}
      <div className="relative z-30 bg-black text-white">
        <Navbar />
      </div>

      {/* 2. Main 404 Experience */}
      <main className="flex-1 flex items-center justify-center px-6 py-20 sm:py-28">
        <div className="max-w-xl w-full text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#1F2B20]/10 border border-[#1F2B20]/20 text-[#1F2B20] text-xs font-bold uppercase tracking-[0.2em] mb-6">
            <Compass className="w-3.5 h-3.5 text-[#B18B5B]" />
            <span>ERROR 404 · NOT FOUND</span>
          </div>

          {/* Large Stylized 404 */}
          <div className="relative my-2 select-none">
            <span className="font-sans font-black text-7xl sm:text-9xl tracking-tighter text-[#1F2B20]/10 block">
              404
            </span>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="font-sans font-black text-4xl sm:text-6xl uppercase tracking-tight text-[#1F2B20]">
                OFF THE MENU
              </span>
            </div>
          </div>

          {/* Subtitle Message */}
          <p className="text-sm sm:text-base text-[#4A4843] max-w-md mx-auto leading-relaxed mt-4 mb-8 font-medium">
            Looks like this page got eaten, moved, or never existed in the first place. Don&apos;t worry — our kitchen is still hot and firing up fresh orders.
          </p>

          {/* Quick Action Navigation Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 sm:gap-4">
            <Link
              href="/"
              className="w-full sm:w-auto px-7 py-3.5 rounded-full bg-[#1F2B20] hover:bg-black text-white text-xs font-bold uppercase tracking-[0.2em] inline-flex items-center justify-center gap-2 shadow-md hover:shadow-lg transition-all"
            >
              <Home className="w-4 h-4" />
              <span>Back to Home</span>
            </Link>

            <Link
              href="/menu"
              className="w-full sm:w-auto px-7 py-3.5 rounded-full bg-white hover:bg-zinc-50 border border-[#D9CEBF] text-[#1F2B20] text-xs font-bold uppercase tracking-[0.2em] inline-flex items-center justify-center gap-2 shadow-sm hover:shadow transition-all"
            >
              <UtensilsCrossed className="w-4 h-4 text-[#B18B5B]" />
              <span>Explore Menu</span>
            </Link>

            <Link
              href="/locations"
              className="w-full sm:w-auto px-7 py-3.5 rounded-full bg-transparent hover:bg-[#E8DED0]/60 text-[#1F2B20] text-xs font-bold uppercase tracking-[0.2em] inline-flex items-center justify-center gap-2 transition-all"
            >
              <MapPin className="w-4 h-4 text-[#B18B5B]" />
              <span>Find Outlets</span>
            </Link>
          </div>
        </div>
      </main>

      {/* 3. Footer */}
      <Footer />
    </div>
  );
}
