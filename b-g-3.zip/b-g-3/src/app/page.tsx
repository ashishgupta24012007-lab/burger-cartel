"use client";

import React, { useState, useRef } from "react";
import Link from "next/link";
import dynamic from "next/dynamic";
import Navbar from "@/components/Navbar";
import CenteredHero from "@/components/CenteredHero";
import EditorialBar from "@/components/EditorialBar";
import HeroRevealBackground from "@/components/HeroRevealBackground";
import SmoothScroll from "@/components/SmoothScroll";
import GallerySection from "@/components/GallerySection";
import ReviewsSection from "@/components/ReviewsSection";
import BranchActivitySection from "@/components/BranchActivitySection";
import Footer from "@/components/Footer";
import { ArrowRight } from "lucide-react";
import { safeJsonLd } from "@/data/seoData";

// Dynamically load heavy interactive modals only when requested by user
const LocationModal = dynamic(() => import("@/components/LocationModal"), {
  ssr: false,
});
const MenuModal = dynamic(() => import("@/components/MenuModal"), {
  ssr: false,
});

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [locationOpen, setLocationOpen] = useState(false);
  const heroRef = useRef<HTMLElement>(null);

  return (
    <div className="relative min-h-screen bg-[#F5F0E7] text-[#292925] selection:bg-[#1F2B20] selection:text-white overflow-x-hidden">
      {/* Schema.org BreadcrumbList */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: safeJsonLd({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              {
                "@type": "ListItem",
                position: 1,
                name: "Home",
                item: "https://burgercartel.in",
              },
            ],
          }),
        }}
      />
      {/* Smooth Lenis Scrolling */}
      <SmoothScroll />

      {/* 1. HERO SECTION STAGE (Spotlight Character Reveal Layer + Navigation + Hero Tagline) */}
      <section
        ref={heroRef}
        className="relative min-h-[100dvh] bg-black text-white flex flex-col justify-between overflow-hidden cursor-default"
      >
        {/* Cursor-Following Spotlight Character Reveal Layer (pointer-events: none) */}
        <HeroRevealBackground heroRef={heroRef} />

        {/* Top Navigation Bar with 1px divider (#222222) */}
        <div className="relative z-20 w-full">
          <Navbar
            onOpenMenu={() => setMenuOpen(true)}
            onOpenLocation={() => setLocationOpen(true)}
          />
        </div>

        {/* Centered Hero Section */}
        <main className="relative z-20 flex-1 w-full flex items-center justify-center py-6 sm:py-10">
          <CenteredHero
            onOpenLocation={() => setLocationOpen(true)}
          />
        </main>

        {/* Bottom Editorial Bar with 1px top border (#222222) */}
        <div className="relative z-20 w-full">
          <EditorialBar onOpenLocation={() => setLocationOpen(true)} />
        </div>
      </section>

      {/* 2. NEWLY REDESIGNED PREMIUM GALLERY SECTION (Directly below Hero) */}
      <GallerySection />

      {/* 3. PREMIUM CUSTOMER REVIEWS SECTION (Directly below Gallery) */}
      <ReviewsSection onOpenLocation={() => setLocationOpen(true)} />

      {/* 4. POPULAR TIMES & FIVE-BRANCH ACTIVITY GRAPHS (Directly below Reviews) */}
      <BranchActivitySection onOpenLocation={() => setLocationOpen(true)} />

      {/* 5. COMPACT ORDER ONLINE PROMOTIONAL SECTION */}
      <section className="relative z-10 py-16 sm:py-20 px-5 sm:px-8 md:px-12 bg-[#F5F0E7] text-[#292925] border-t border-[#E8DED0]">
        <div className="max-w-5xl mx-auto p-8 sm:p-12 neu-cream-card rounded-3xl flex flex-col md:flex-row items-center justify-between gap-8 sm:gap-10">
          <div className="max-w-xl text-center md:text-left">
            <span className="text-[10px] sm:text-xs font-bold tracking-[0.28em] text-[#B18B5B] uppercase block mb-2">
              ORDER ONLINE
            </span>
            <h2 className="font-sans font-black text-3xl sm:text-4xl md:text-5xl uppercase tracking-tight text-[#1F2B20] leading-[0.95] mb-3">
              YOUR BURGER. YOUR BRANCH. YOUR CHOICE.
            </h2>
            <p className="text-xs sm:text-sm text-[#4A4843] leading-relaxed">
              Find your nearest Burger Cartel and order through Swiggy or Zomato.
            </p>
          </div>

          <div className="shrink-0">
            <Link
              href="/order-online"
              className="group inline-flex items-center gap-2.5 px-7 sm:px-8 py-3.5 sm:py-4 rounded-full bg-[#1F2B20] hover:bg-[#283829] text-white text-xs sm:text-sm font-bold tracking-[0.16em] uppercase shadow-lg hover:shadow-xl transition-all cursor-pointer select-none"
            >
              <span>ORDER ONLINE</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <Footer onOpenLocation={() => setLocationOpen(true)} />

      {/* Interactive Modals (deferred until triggered) */}
      {menuOpen && (
        <MenuModal
          isOpen={menuOpen}
          onClose={() => setMenuOpen(false)}
        />
      )}

      {locationOpen && (
        <LocationModal
          isOpen={locationOpen}
          onClose={() => setLocationOpen(false)}
        />
      )}
    </div>
  );
}
