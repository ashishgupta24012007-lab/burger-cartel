"use client";

import React, { useState, useMemo, useRef, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import {
  Search,
  X,
  Info,
  Sparkles,
  Leaf,
  MapPin,
  ArrowRight,
  Menu as MenuIcon,
  X as CloseIcon,
  UtensilsCrossed,
} from "lucide-react";
import LocationModal from "@/components/LocationModal";
import Footer from "@/components/Footer";
import { fetchCmsContent } from "@/lib/client/cmsClient";
import {
  MENU_CATEGORIES,
  MASTER_MENU_ITEMS,
  PIZZA_CUSTOM_ADDONS,
  CROISSANT_BURGER_OPTIONS,
  BREAKFAST_ADDONS,
  MenuItem,
} from "@/data/menuData";

export default function MenuPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState<"all" | "veg" | "non-veg" | "favorites">("all");
  const [locationOpen, setLocationOpen] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string>("burgers");
  const [selectedBranchId, setSelectedBranchId] = useState<string>(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      return params.get("branch") || params.get("outlet") || "all";
    }
    return "all";
  });

  const [categories, setCategories] = useState(MENU_CATEGORIES);
  const [allItems, setAllItems] = useState<(MenuItem & { price?: string; isAvailable?: boolean; description?: string; image?: string })[]>(MASTER_MENU_ITEMS);
  const [outletAvailability, setOutletAvailability] = useState<Record<string, Record<string, boolean>>>({});
  const [outletOverrides, setOutletOverrides] = useState<Record<string, Record<string, number | null>>>({});
  const [showPrices, setShowPrices] = useState(true);

  // Load latest live CMS menu data
  useEffect(() => {
    let mounted = true;

    const loadData = async (forceFresh = false) => {
      const data = await fetchCmsContent({ forceFresh });
      if (!mounted || !data) return;

      if (Array.isArray(data.menuCategories)) {
        setCategories(data.menuCategories);
      }
      if (Array.isArray(data.menuItems)) {
        setAllItems(data.menuItems);
      }
      if (data.outletMenuAvailability) {
        setOutletAvailability(data.outletMenuAvailability);
      }
      if (data.outletMenuOverrides) {
        setOutletOverrides(data.outletMenuOverrides);
      }
      if (data.siteContent?.menuSettings?.showPrices !== undefined) {
        setShowPrices(Boolean(data.siteContent.menuSettings.showPrices));
      }
    };

    loadData();

    // Listen for live CMS updates dispatched from admin panel or cross-tab sync
    const handleCmsUpdate = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail) {
        const d = customEvent.detail;
        if (Array.isArray(d.menuCategories)) setCategories(d.menuCategories);
        if (Array.isArray(d.menuItems)) setAllItems(d.menuItems);
        if (d.outletMenuAvailability) setOutletAvailability(d.outletMenuAvailability);
        if (d.outletMenuOverrides) setOutletOverrides(d.outletMenuOverrides);
        if (d.siteContent?.menuSettings?.showPrices !== undefined) {
          setShowPrices(Boolean(d.siteContent.menuSettings.showPrices));
        }
      }
    };

    window.addEventListener("cms:updated", handleCmsUpdate);
    return () => {
      mounted = false;
      window.removeEventListener("cms:updated", handleCmsUpdate);
    };
  }, []);

  const navContainerRef = useRef<HTMLDivElement>(null);
  const isManualScrollRef = useRef<boolean>(false);

  // Compute effective pricing & availability based on active branch selection
  const effectiveItems = useMemo(() => {
    return allItems.map((item) => {
      const branchAvail =
        selectedBranchId !== "all" && outletAvailability[selectedBranchId]
          ? outletAvailability[selectedBranchId][item.id]
          : undefined;

      const branchPrice =
        selectedBranchId !== "all" && outletOverrides[selectedBranchId]
          ? outletOverrides[selectedBranchId][item.id]
          : undefined;

      return {
        ...item,
        isAvailable: branchAvail !== undefined ? Boolean(branchAvail) : (item.isAvailable !== false),
        price: branchPrice != null ? `₹${branchPrice}` : item.price,
      };
    });
  }, [allItems, selectedBranchId, outletAvailability, outletOverrides]);

  // Filter items based on search query & dietary preferences
  const filteredItems = useMemo(() => {
    let items = effectiveItems;

    if (filterType === "veg") {
      items = items.filter((item) => item.isVegetarian);
    } else if (filterType === "non-veg") {
      items = items.filter((item) => !item.isVegetarian);
    } else if (filterType === "favorites") {
      items = items.filter((item) => item.isHouseFavourite);
    }

    if (!searchQuery.trim()) {
      return items;
    }

    const q = searchQuery.toLowerCase().trim();
    return items.filter(
      (item) =>
        item.name.toLowerCase().includes(q) ||
        (item.description && item.description.toLowerCase().includes(q)) ||
        (item.category && item.category.toLowerCase().includes(q)) ||
        (item.subcategory && item.subcategory.toLowerCase().includes(q)) ||
        (item.tags && item.tags.some((t) => t.toLowerCase().includes(q))) ||
        (item.variants && item.variants.some((v) => v.toLowerCase().includes(q)))
    );
  }, [effectiveItems, searchQuery, filterType]);

  // Group items by category for long scrolling
  const itemsByCategory = useMemo(() => {
    const map: Record<string, (MenuItem & { price?: string; isAvailable?: boolean; description?: string; image?: string })[]> = {};
    for (const cat of categories) {
      map[cat.id] = [];
    }
    for (const item of filteredItems) {
      if (map[item.category]) {
        map[item.category].push(item);
      }
    }
    return map;
  }, [categories, filteredItems]);

  // 1. DYNAMIC SCROLL-SPY: Track which category section is currently on screen
  useEffect(() => {
    const handleScroll = () => {
      if (isManualScrollRef.current) return;

      // Check if user scrolled near the bottom of the page
      const isAtBottom =
        window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 90;

      if (isAtBottom) {
        const visibleCats = categories.filter(
          (c) => (itemsByCategory[c.id]?.length || 0) > 0
        );
        if (visibleCats.length > 0) {
          setActiveCategory(visibleCats[visibleCats.length - 1].id);
          return;
        }
      }

      // Find the active section based on top offset (accounting for sticky headers ~140px)
      const scrollThreshold = 180;
      let currentActive = activeCategory;

      for (const cat of categories) {
        // Only track categories that have visible items
        if ((itemsByCategory[cat.id]?.length || 0) === 0 && (searchQuery || filterType !== "all")) {
          continue;
        }
        const el = document.getElementById(cat.id);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= scrollThreshold) {
            currentActive = cat.id;
          }
        }
      }

      setActiveCategory(currentActive);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    // Run once on mount / items update
    handleScroll();

    return () => window.removeEventListener("scroll", handleScroll);
  }, [categories, itemsByCategory, searchQuery, filterType, activeCategory]);

  // 2. AUTO-SCROLL CATEGORY BAR: Keep active pill centered in horizontal strip
  useEffect(() => {
    if (navContainerRef.current) {
      const activeBtn = navContainerRef.current.querySelector(
        `[data-category-id="${activeCategory}"]`
      ) as HTMLElement | null;

      if (activeBtn) {
        const container = navContainerRef.current;
        const btnLeft = activeBtn.offsetLeft;
        const btnWidth = activeBtn.offsetWidth;
        const containerWidth = container.offsetWidth;
        const targetScroll = btnLeft - containerWidth / 2 + btnWidth / 2;

        container.scrollTo({
          left: Math.max(0, targetScroll),
          behavior: "smooth",
        });
      }
    }
  }, [activeCategory]);

  const scrollToCategory = (id: string) => {
    setActiveCategory(id);
    isManualScrollRef.current = true;
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
      setTimeout(() => {
        isManualScrollRef.current = false;
      }, 700);
    } else {
      isManualScrollRef.current = false;
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F0E7] text-[#292925] font-sans antialiased selection:bg-[#1F2B20] selection:text-[#FAF7F0]">
      {/* 1. TOP NAVIGATION BAR (Exact Match to Warm Cream Neumorphic Header) */}
      <header className="sticky top-0 z-40 w-full bg-[#F5F0E7]/95 backdrop-blur-md border-b border-[#E8DED0] transition-all">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 md:px-12 py-4 flex items-center justify-between">
          {/* Left Brand: Logo + BURGER CARTEL */}
          <Link href="/" className="flex items-center gap-3 group select-none">
            <div className="relative w-11 h-11 sm:w-13 sm:h-13 rounded-full overflow-hidden shrink-0 bg-white p-1 shadow-xs border border-[#E8DED0]">
              <Image
                src="/images/logo.png"
                alt="BURGER CARTEL Logo"
                width={52}
                height={52}
                className="w-full h-full object-contain"
                priority
              />
            </div>
            <div className="flex flex-col leading-tight">
              <span className="font-sans font-black text-sm sm:text-base tracking-[0.14em] text-[#1F2B20] uppercase">
                BURGER CARTEL
              </span>
              <span className="font-sans text-[8px] sm:text-[9px] font-bold tracking-[0.24em] text-[#B18B5B] uppercase mt-0.5">
                EST. DARJEELING
              </span>
            </div>
          </Link>

          {/* Desktop Center Navigation */}
          <nav className="hidden md:flex items-center gap-6 lg:gap-8 text-xs font-bold tracking-[0.2em] uppercase text-[#4A4843]">
            <Link href="/" className="hover:text-[#1F2B20] transition-colors py-1">
              HOME
            </Link>
            <Link href="/about" className="hover:text-[#1F2B20] transition-colors py-1">
              ABOUT
            </Link>
            <Link href="/order-online" className="hover:text-[#1F2B20] transition-colors py-1">
              ORDER ONLINE
            </Link>

            {/* Active MENU indicator */}
            <div className="relative py-1 text-[#1F2B20]">
              <span>MENU</span>
              <span className="absolute bottom-[-3px] left-0 right-0 h-[2px] bg-[#B18B5B] rounded-full" />
            </div>

            <button
              type="button"
              onClick={() => setLocationOpen(true)}
              className="hover:text-[#1F2B20] transition-colors py-1 cursor-pointer"
            >
              OUTLETS
            </button>
            <Link href="/#gallery" className="hover:text-[#1F2B20] transition-colors py-1">
              GALLERY
            </Link>
            <button
              type="button"
              onClick={() => setLocationOpen(true)}
              className="hover:text-[#1F2B20] transition-colors py-1 cursor-pointer"
            >
              CONTACT
            </button>
          </nav>

          {/* Right Action: Forest Green "VISIT A BRANCH →" Pill Button */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setLocationOpen(true)}
              className="hidden sm:inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#1F2B20] text-[#FAF7F0] text-xs font-bold tracking-[0.16em] uppercase hover:bg-[#2c3d2e] transition-all duration-300 shadow-sm cursor-pointer"
            >
              <span>VISIT A BRANCH</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            {/* Mobile Hamburger Button */}
            <button
              type="button"
              onClick={() => setMobileNavOpen(!mobileNavOpen)}
              className="md:hidden p-2 rounded-xl neu-cream-disc text-[#1F2B20] cursor-pointer"
              aria-label="Toggle navigation"
            >
              {mobileNavOpen ? <CloseIcon className="w-5 h-5" /> : <MenuIcon className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Slide-down Navigation Panel */}
        {mobileNavOpen && (
          <div className="md:hidden bg-[#FAF7F0] border-b border-[#E8DED0] px-6 py-6 flex flex-col gap-4 text-xs font-bold tracking-[0.2em] uppercase text-[#4A4843] shadow-lg animate-fadeIn">
            <Link href="/" onClick={() => setMobileNavOpen(false)} className="py-2 hover:text-[#1F2B20]">
              HOME
            </Link>
            <Link href="/about" onClick={() => setMobileNavOpen(false)} className="py-2 hover:text-[#1F2B20]">
              ABOUT
            </Link>
            <Link href="/order-online" onClick={() => setMobileNavOpen(false)} className="py-2 hover:text-[#1F2B20]">
              ORDER ONLINE
            </Link>
            <div className="py-2 text-[#1F2B20] font-black flex items-center justify-between">
              <span>MENU</span>
              <span className="w-2 h-2 rounded-full bg-[#B18B5B]" />
            </div>
            <button
              type="button"
              onClick={() => {
                setMobileNavOpen(false);
                setLocationOpen(true);
              }}
              className="text-left py-2 hover:text-[#1F2B20]"
            >
              OUTLETS & CONTACT
            </button>
            <Link href="/#gallery" onClick={() => setMobileNavOpen(false)} className="py-2 hover:text-[#1F2B20]">
              GALLERY
            </Link>
            <div className="pt-3 border-t border-[#E8DED0]">
              <button
                type="button"
                onClick={() => {
                  setMobileNavOpen(false);
                  setLocationOpen(true);
                }}
                className="w-full flex items-center justify-center gap-2 px-5 py-3 rounded-full bg-[#1F2B20] text-[#FAF7F0] text-xs font-bold tracking-widest uppercase cursor-pointer"
              >
                <span>VISIT A BRANCH</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </header>

      {/* 2. MENU INTRODUCTION HERO SECTION */}
      <section className="relative pt-12 sm:pt-16 pb-8 sm:pb-12 px-5 sm:px-8 md:px-12 overflow-hidden">
        <div className="max-w-6xl mx-auto text-center">
          {/* Small Uppercase Label */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full neu-cream-disc text-[11px] sm:text-xs font-bold tracking-[0.24em] text-[#B18B5B] uppercase mb-5 select-none shadow-xs">
            <UtensilsCrossed className="w-3.5 h-3.5 text-[#B18B5B]" />
            <span>BURGER CARTEL · CAFE &amp; RESTAURANT</span>
          </div>

          {/* Main Display Headline (Bebas / Oswald Style Bold Condensed) */}
          <h1 className="font-sans font-black text-4xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-[5.2rem] tracking-tight text-[#1F2B20] uppercase leading-[0.95] mb-5">
            GOOD FOOD. NO BORING BITES.
          </h1>

          {/* Script Subheading Accent */}
          <div className="mb-6">
            <span className="font-handwriting text-2xl sm:text-3xl md:text-4xl text-[#B18B5B] block font-normal">
              handcrafted breads · scratch sauces · uncommon character
            </span>
          </div>

          {/* Supporting Text */}
          <p className="max-w-2xl mx-auto text-sm sm:text-base text-[#4A4843] leading-relaxed font-normal mb-8">
            Welcome to Burger Cartel. We care about food quality and taste. Our breads are handmade, and our sauces are made from scratch. Settle in with a fizzy drink or your favourite milkshake and explore our selection of burgers, pizzas, sandwiches, and more.
          </p>

          {/* CRITICAL PRICING DISCLAIMER BANNER (No prices anywhere on the menu) */}
          <div className="max-w-2xl mx-auto p-4 sm:p-5 rounded-2xl neu-cream-inset border border-[#E8DED0] flex items-center gap-3.5 text-left mb-6 shadow-xs">
            <div className="w-9 h-9 rounded-full neu-cream-disc flex items-center justify-center shrink-0 text-[#B18B5B]">
              <Info className="w-4 h-4" />
            </div>
            <p className="text-xs sm:text-[13px] text-[#4A4843] leading-relaxed font-medium">
              <strong className="text-[#1F2B20] font-bold">Universal Cartel Menu:</strong> Menu items and availability may vary by branch. Please check with your selected outlet in Darjeeling, Siliguri, or Kurseong for current prices and daily specials.
            </p>
          </div>

          {/* Outlet Selection Filter */}
          <div className="max-w-2xl mx-auto flex items-center justify-center gap-2 mb-6">
            <span className="text-xs font-bold uppercase tracking-wider text-[#736F67]">Filter by Outlet:</span>
            <select
              value={selectedBranchId}
              onChange={(e) => setSelectedBranchId(e.target.value)}
              aria-label="Filter menu by outlet"
              className="neu-cream-pill px-3.5 py-1.5 text-xs font-bold uppercase tracking-wider text-[#1F2B20] bg-[#FAF7F0] border border-[#E8DED0] outline-none rounded-full cursor-pointer hover:border-[#B18B5B] transition-colors"
            >
              <option value="all">All Outlets</option>
              <option value="darjeeling">Darjeeling (Chauk Bazaar)</option>
              <option value="kurseong">Kurseong (Clock Tower)</option>
              <option value="panchanai">Panchanai (Salbari)</option>
              <option value="pradhan-nagar">Pradhan Nagar</option>
              <option value="shivmandir">Shivmandir</option>
            </select>
          </div>

          {/* 3. INTERACTIVE DISH SEARCH & QUICK FILTERS */}
          <div className="max-w-2xl mx-auto flex flex-col sm:flex-row items-center gap-3">
            {/* Search Input Box */}
            <div className="relative w-full flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#736F67]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search dishes (e.g. Gangnam Spice, Margherita, Kimbap)..."
                className="w-full pl-11 pr-10 py-3 sm:py-3.5 rounded-full neu-cream-inset text-xs sm:text-sm text-[#1F2B20] placeholder-[#736F67] focus:outline-none focus:ring-2 focus:ring-[#B18B5B]/40 font-medium"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#736F67] hover:text-[#1F2B20] p-1 cursor-pointer"
                  aria-label="Clear search"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Quick Dietary Filters */}
            <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto shrink-0 justify-center">
              <button
                type="button"
                onClick={() => setFilterType("all")}
                className={`px-4 py-2.5 sm:py-3 rounded-full text-xs font-bold tracking-wider uppercase transition-all cursor-pointer ${
                  filterType === "all"
                    ? "bg-[#1F2B20] text-[#FAF7F0] shadow-sm"
                    : "neu-cream-pill text-[#4A4843] hover:text-[#1F2B20]"
                }`}
              >
                ALL
              </button>
              <button
                type="button"
                onClick={() => setFilterType("veg")}
                className={`flex items-center gap-1.5 px-4 py-2.5 sm:py-3 rounded-full text-xs font-bold tracking-wider uppercase transition-all cursor-pointer ${
                  filterType === "veg"
                    ? "bg-emerald-800 text-white shadow-sm"
                    : "neu-cream-pill text-[#4A4843] hover:text-emerald-800"
                }`}
              >
                <Leaf className="w-3.5 h-3.5 text-emerald-600" />
                <span>VEG</span>
              </button>
              <button
                type="button"
                onClick={() => setFilterType("non-veg")}
                className={`flex items-center gap-1.5 px-4 py-2.5 sm:py-3 rounded-full text-xs font-bold tracking-wider uppercase transition-all cursor-pointer ${
                  filterType === "non-veg"
                    ? "bg-rose-900 text-white shadow-sm"
                    : "neu-cream-pill text-[#4A4843] hover:text-rose-900"
                }`}
              >
                <span className="w-2.5 h-2.5 rounded-full bg-rose-600 border border-rose-800 shrink-0 inline-block" />
                <span>NON-VEG</span>
              </button>
              <button
                type="button"
                onClick={() => setFilterType("favorites")}
                className={`flex items-center gap-1.5 px-4 py-2.5 sm:py-3 rounded-full text-xs font-bold tracking-wider uppercase transition-all cursor-pointer ${
                  filterType === "favorites"
                    ? "bg-[#B18B5B] text-white shadow-sm"
                    : "neu-cream-pill text-[#4A4843] hover:text-[#B18B5B]"
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-[#B18B5B]" />
                <span>FAVES</span>
              </button>
            </div>
          </div>

          {/* Active Search / Filter Status Summary */}
          {(searchQuery || filterType !== "all") && (
            <div className="mt-4 flex items-center justify-center gap-3 text-xs text-[#736F67]">
              <span>
                Found <strong className="text-[#1F2B20]">{filteredItems.length}</strong> matching dishes
              </span>
              {(searchQuery || filterType !== "all") && (
                <button
                  type="button"
                  onClick={() => {
                    setSearchQuery("");
                    setFilterType("all");
                  }}
                  className="text-[#B18B5B] underline hover:text-[#1F2B20] font-bold cursor-pointer"
                >
                  Reset filters
                </button>
              )}
            </div>
          )}
        </div>
      </section>

      {/* 4. STICKY CATEGORY NAVIGATION (Compact Horizontal Strip with dynamic scroll spy) */}
      <nav className="sticky top-[73px] z-30 w-full bg-[#FAF7F0]/95 backdrop-blur-md border-y border-[#E8DED0] shadow-xs">
        <div
          ref={navContainerRef}
          className="max-w-7xl mx-auto px-4 sm:px-8 py-2.5 overflow-x-auto scrollbar-none flex items-center gap-2 sm:gap-2.5 scroll-smooth"
        >
          {categories.map((cat) => {
            const count = itemsByCategory[cat.id]?.length || 0;
            const isActive = activeCategory === cat.id;

            return (
              <button
                key={cat.id}
                data-category-id={cat.id}
                type="button"
                onClick={() => scrollToCategory(cat.id)}
                className={`shrink-0 px-3.5 sm:px-4 py-1.5 sm:py-2 rounded-full text-[11px] sm:text-xs font-bold tracking-wider uppercase transition-all duration-200 cursor-pointer select-none flex items-center gap-1.5 ${
                  isActive
                    ? "bg-[#1F2B20] text-[#FAF7F0] shadow-sm scale-105"
                    : "neu-cream-pill text-[#4A4843] hover:text-[#1F2B20]"
                }`}
              >
                <span>{cat.shortName || cat.name}</span>
                {count > 0 && (
                  <span
                    className={`text-[9px] px-1.5 py-0.2 rounded-full ${
                      isActive ? "bg-white/20 text-white" : "bg-[#E8DED0] text-[#4A4843]"
                    }`}
                  >
                    {count}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </nav>

      {/* 5. MAIN LONG-SCROLLING MENU CONTAINER */}
      <main className="max-w-7xl mx-auto px-5 sm:px-8 md:px-12 py-12 sm:py-16 flex flex-col gap-20 sm:gap-24">
        {/* Empty Search Results Message */}
        {filteredItems.length === 0 && (
          <div className="text-center py-20 neu-cream-card rounded-3xl p-8 max-w-xl mx-auto">
            <UtensilsCrossed className="w-12 h-12 text-[#B18B5B] mx-auto mb-4" />
            <h3 className="text-xl font-bold uppercase tracking-wide text-[#1F2B20] mb-2">
              NO DISHES FOUND
            </h3>
            <p className="text-sm text-[#4A4843] mb-6">
              We couldn&apos;t find any menu items matching &ldquo;{searchQuery}&rdquo;. Try searching for &ldquo;burger&rdquo;, &ldquo;pizza&rdquo;, or &ldquo;korean&rdquo;.
            </p>
            <button
              type="button"
              onClick={() => {
                setSearchQuery("");
                setFilterType("all");
              }}
              className="px-6 py-2.5 rounded-full bg-[#1F2B20] text-[#FAF7F0] text-xs font-bold tracking-widest uppercase hover:bg-[#2c3d2e] transition-colors cursor-pointer"
            >
              SHOW ALL MENU ITEMS
            </button>
          </div>
        )}

        {/* Iterate over all categories in strict order */}
        {categories.map((cat) => {
          const items = itemsByCategory[cat.id] || [];
          if (items.length === 0 && (searchQuery || filterType !== "all")) {
            return null; // hide empty categories during filtered searches
          }

          return (
            <section
              key={cat.id}
              id={cat.id}
              className="scroll-mt-36 flex flex-col gap-8 transition-opacity duration-300"
            >
              {/* Category Header */}
              <div className="border-b border-[#E8DED0] pb-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
                <div>
                  <span className="text-[10px] sm:text-xs font-bold tracking-[0.25em] text-[#B18B5B] uppercase block mb-1.5">
                    {cat.subtitle}
                  </span>
                  <h2 className="text-3xl sm:text-4xl md:text-5xl font-black uppercase tracking-tight text-[#1F2B20]">
                    {cat.name}
                  </h2>
                </div>
                <p className="text-xs sm:text-sm text-[#4A4843] max-w-md leading-relaxed font-normal">
                  {cat.description}
                </p>
              </div>

              {/* Items Grid (2 columns on tablet, 3 on large desktop) */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
                {items.map((item) => (
                  <article
                    key={item.id}
                    className="neu-cream-card rounded-2xl sm:rounded-3xl p-5 sm:p-6 flex flex-col justify-between hover:-translate-y-1 transition-all duration-300 group"
                  >
                    <div>
                      {/* Realistic Dish Photograph Frame */}
                      <div className="relative w-full aspect-[4/3] rounded-xl sm:rounded-2xl overflow-hidden neu-cream-inset mb-5 bg-[#E8DED0]">
                        <Image
                          src={item.image}
                          alt={`${item.name} at Burger Cartel`}
                          fill
                          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                          className={`object-cover group-hover:scale-105 transition-transform duration-500 ${
                            item.isAvailable === false ? "grayscale contrast-125 opacity-70" : ""
                          }`}
                          loading="lazy"
                        />

                        {/* Top Overlay Badges */}
                        <div className="absolute top-3 left-3 flex flex-wrap items-center gap-2">
                          {item.isVegetarian ? (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-800/95 backdrop-blur-xs text-white text-[10px] font-bold tracking-wider uppercase shadow-xs">
                              <Leaf className="w-3 h-3 text-emerald-300" />
                              <span>VEG</span>
                            </span>
                          ) : item.category !== "beverages" ? (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-900/90 backdrop-blur-xs text-rose-100 text-[10px] font-bold tracking-wider uppercase shadow-xs">
                              <span className="w-2 h-2 rounded-full bg-rose-400 shrink-0" />
                              <span>NON-VEG</span>
                            </span>
                          ) : null}
                          {item.isHouseFavourite && (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#1F2B20]/90 backdrop-blur-xs text-[#FAF7F0] text-[10px] font-bold tracking-wider uppercase shadow-xs">
                              <Sparkles className="w-3 h-3 text-[#B18B5B]" />
                              <span>FAVOURITE</span>
                            </span>
                          )}
                        </div>

                        {/* Sold Out Banner */}
                        {item.isAvailable === false && (
                          <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px] flex items-center justify-center p-3 text-center">
                            <span className="px-3 py-1 rounded-full bg-amber-400 text-black text-[10px] font-black uppercase tracking-wider shadow-lg">
                              SOLD OUT FOR TODAY
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Dish Title & Price */}
                      <div className="mb-2">
                        <div className="flex items-start justify-between gap-2">
                          <h3 className="font-sans font-black text-xl sm:text-2xl text-[#1F2B20] uppercase tracking-tight leading-snug">
                            {item.name}
                          </h3>
                          {showPrices && item.price && (
                            <span className="text-xs sm:text-sm font-black text-[#B18B5B] font-mono shrink-0 pt-1">
                              {item.price}
                            </span>
                          )}
                        </div>
                        {item.subcategory && (
                          <span className="text-[10px] font-bold uppercase tracking-wider text-[#B18B5B] block mt-0.5">
                            {item.subcategory}
                          </span>
                        )}
                      </div>

                      {/* Concise Ingredient / Recipe Description */}
                      <p className="text-xs sm:text-[13px] text-[#4A4843] leading-relaxed font-normal mb-4">
                        {item.description}
                      </p>
                    </div>

                    {/* Bottom Variants / Notes (NO PRICES ANYWHERE) */}
                    {item.variants && item.variants.length > 0 && (
                      <div className="pt-3 border-t border-[#E8DED0]/70 flex flex-wrap items-center gap-1.5 mt-auto">
                        <span className="text-[9px] font-bold uppercase tracking-wider text-[#736F67] mr-1">
                          Options:
                        </span>
                        {item.variants.map((v) => (
                          <span
                            key={v}
                            className="px-2.5 py-1 rounded-full bg-[#FAF7F0] text-[10px] font-medium text-[#1F2B20] border border-[#E8DED0]"
                          >
                            {v}
                          </span>
                        ))}
                      </div>
                    )}
                  </article>
                ))}
              </div>

              {/* SPECIAL SUBSECTION: Under PIZZAS -> "MAKE IT YOUR OWN" */}
              {cat.id === "pizzas" && (
                <div className="mt-6 p-6 sm:p-8 rounded-3xl neu-cream-card border border-[#E8DED0]">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-5">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-[0.24em] text-[#B18B5B] block mb-1">
                        CUSTOMISE YOUR CRUST
                      </span>
                      <h3 className="text-2xl sm:text-3xl font-black uppercase text-[#1F2B20] tracking-tight">
                        MAKE IT YOUR OWN
                      </h3>
                    </div>
                    <p className="text-xs sm:text-[13px] text-[#4A4843] max-w-md">
                      Selected pizzas can be customized with fresh artisanal add-ons. Subject to branch availability.
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2.5">
                    {PIZZA_CUSTOM_ADDONS.map((addon) => (
                      <span
                        key={addon}
                        className="px-4 py-2 rounded-full neu-cream-pill text-xs font-semibold text-[#1F2B20] border border-white/60 shadow-xs"
                      >
                        + {addon}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* SPECIAL SUBSECTION: Under CROISSANTS -> "MAKE IT A CROISSANT BURGER" */}
              {cat.id === "croissants" && (
                <div className="mt-6 p-6 sm:p-8 rounded-3xl neu-cream-card border border-[#E8DED0]">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-5">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-[0.24em] text-[#B18B5B] block mb-1">
                        SIGNATURE ADAPTATION
                      </span>
                      <h3 className="text-2xl sm:text-3xl font-black uppercase text-[#1F2B20] tracking-tight">
                        MAKE IT A CROISSANT BURGER
                      </h3>
                    </div>
                    <p className="text-xs sm:text-[13px] text-[#4A4843] max-w-md">
                      Adapt any of our bold burger recipes onto freshly baked, flaky all-butter croissant pastry.
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2.5">
                    {CROISSANT_BURGER_OPTIONS.map((opt) => (
                      <span
                        key={opt}
                        className="px-4 py-2 rounded-full neu-cream-pill text-xs font-bold text-[#1F2B20] border border-white/60 shadow-xs"
                      >
                        {opt}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* SPECIAL SUBSECTION: Under BREAKFAST -> "BREAKFAST ADD-ONS" */}
              {cat.id === "breakfast" && (
                <div className="mt-6 p-6 sm:p-8 rounded-3xl neu-cream-card border border-[#E8DED0]">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-5">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-[0.24em] text-[#B18B5B] block mb-1">
                        MORNING SIDES
                      </span>
                      <h3 className="text-2xl sm:text-3xl font-black uppercase text-[#1F2B20] tracking-tight">
                        BREAKFAST ADD-ONS
                      </h3>
                    </div>
                    <p className="text-xs sm:text-[13px] text-[#4A4843] max-w-md">
                      Customize your morning plate with extra breakfast favorites.
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2.5">
                    {BREAKFAST_ADDONS.map((addon) => (
                      <span
                        key={addon}
                        className="px-4 py-2 rounded-full neu-cream-pill text-xs font-semibold text-[#1F2B20] border border-white/60 shadow-xs"
                      >
                        + {addon}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </section>
          );
        })}
      </main>

      {/* 6. COMPACT CLOSING SECTION */}
      <section className="py-20 px-5 sm:px-8 md:px-12 bg-[#FAF7F0] border-t border-[#E8DED0]">
        <div className="max-w-4xl mx-auto text-center">
          <span className="text-[10px] sm:text-xs font-bold tracking-[0.25em] text-[#B18B5B] uppercase block mb-3">
            BURGER CARTEL · GOOD TIMES
          </span>
          <h2 className="font-sans font-black text-3xl sm:text-4xl md:text-5xl text-[#1F2B20] uppercase tracking-tight mb-4">
            GOOD FOOD. GOOD COMPANY. YOUR KIND OF PLACE.
          </h2>
          <p className="text-sm sm:text-base text-[#4A4843] max-w-xl mx-auto leading-relaxed mb-8">
            Explore our menu, discover a new favourite, and visit your nearest Burger Cartel across Darjeeling, Kurseong, Salbari, Pradhan Nagar, and Shivmandir.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4">
            <button
              type="button"
              onClick={() => setLocationOpen(true)}
              className="px-8 py-3.5 rounded-full bg-[#1F2B20] text-[#FAF7F0] text-xs font-bold tracking-[0.18em] uppercase hover:bg-[#2c3d2e] transition-all duration-300 shadow-sm cursor-pointer flex items-center gap-2"
            >
              <MapPin className="w-4 h-4 text-[#B18B5B]" />
              <span>FIND OUR 5 BRANCHES</span>
            </button>

            <Link
              href="/order-online"
              className="px-8 py-3.5 rounded-full neu-cream-pill text-xs font-bold tracking-[0.18em] uppercase text-[#1F2B20] hover:text-[#B18B5B] transition-colors border border-white/70 shadow-sm flex items-center gap-2"
            >
              <span>ORDER ONLINE</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* 7. WEBSITE FOOTER */}
      <Footer onOpenLocation={() => setLocationOpen(true)} />

      {/* MODALS */}
      <LocationModal isOpen={locationOpen} onClose={() => setLocationOpen(false)} />
    </div>
  );
}
