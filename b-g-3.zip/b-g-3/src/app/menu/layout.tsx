import type { Metadata } from "next";
import { SITE_URL, generateBreadcrumbSchema, safeJsonLd } from "@/data/seoData";
import { getCmsData } from "@/lib/db/cmsRepository";

export async function generateMetadata(): Promise<Metadata> {
  const cms = await getCmsData();
  const seo = cms.siteContent.seo?.menu;

  const title = seo?.title || "Official Food & Drinks Menu — Handcrafted Smash Burgers & Artisan Pizza";
  const description =
    seo?.description ||
    "Explore the complete Burger Cartel menu across our 5 branches in Darjeeling, Kurseong, and Siliguri. Smashed chicken burgers, gourmet patties, wood-fired artisan pizza, thick shakes, and specialty brews.";
  const ogImage = seo?.ogImage || "/images/og-image.png";

  return {
    title,
    description,
    alternates: {
      canonical: "/menu",
    },
    openGraph: {
      title,
      description,
      url: `${SITE_URL}/menu`,
      images: [
        {
          url: ogImage,
          width: 1200,
          height: 630,
          type: "image/png",
          alt: "Burger Cartel signature smash burger and artisan fries",
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [ogImage],
    },
    robots: {
      index: !seo?.noindex,
      follow: !seo?.noindex,
    },
  };
}

export default function MenuLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const breadcrumbSchema = generateBreadcrumbSchema([
    { name: "Home", url: "/" },
    { name: "Menu", url: "/menu" },
  ]);

  const menuSchema = {
    "@context": "https://schema.org",
    "@type": "Menu",
    "@id": `${SITE_URL}/menu#menu`,
    name: "Burger Cartel Master Menu",
    description:
      "Handcrafted American smash burgers, wood-fired pizzas, sides, and craft beverages.",
    inLanguage: "en-IN",
    offers: {
      "@type": "AggregateOffer",
      priceCurrency: "INR",
      lowPrice: "180",
      highPrice: "650",
    },
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: safeJsonLd(breadcrumbSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: safeJsonLd(menuSchema) }}
      />
      {children}
    </>
  );
}
