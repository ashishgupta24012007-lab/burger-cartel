"use client";

import React, { useState, useEffect, useCallback, useMemo, useRef } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  Lock,
  User,
  KeyRound,
  AlertCircle,
  Eye,
  EyeOff,
  LogOut,
  Sparkles,
  History,
  Building2,
  Star,
  Image as ImageIcon,
  Plus,
  Trash2,
  Edit3,
  ExternalLink,
  Search,
  Check,
  X,
  Menu as MenuIcon,
  ShieldCheck,
  Archive,
  RefreshCw,
  Download,
  Copy,
  Save,
  Megaphone,
  LayoutDashboard,
  UtensilsCrossed,
  Clock,
  Upload,
} from "lucide-react";
import AdminSidebar, { AdminTab } from "@/components/admin/AdminSidebar";
import LivePreviewModal from "@/components/admin/LivePreviewModal";
import MenuManagerTab from "@/components/admin/MenuManagerTab";
import { broadcastCmsUpdate, invalidateCmsClientCache } from "@/lib/client/cmsClient";
import {
  CmsDatabaseSchema,
  CmsReviewItem,
  CmsCustomPage,
  CmsGalleryItem,
  CmsOutlet,
  CmsMenuItem,
  CmsMenuCategory,
  CmsBackupSnapshot,
  SiteContent,
} from "@/lib/cms/store";

interface DashboardData {
  admin: {
    adminId: string;
    createdAt: string;
    updatedAt: string;
    mustChangePassword: boolean;
  };
  system: {
    storageType: string;
    status: string;
    activeSessionsCount: number;
    phoneAuthReady: boolean;
    phoneAuthEnabled: boolean;
  };
  outlets: Array<{
    name: string;
    slug: string;
    hours: string;
    phone: string;
  }>;
  recentLogs: Array<{
    id: string;
    event: string;
    adminId?: string;
    timestamp: string;
    ip?: string;
    details?: string;
  }>;
}

export default function AdminPanelPage() {
  const [loading, setLoading] = useState(true);
  const [authenticated, setAuthenticated] = useState(false);
  const [initialSetupNeeded, setInitialSetupNeeded] = useState(false);
  const [currentAdminId, setCurrentAdminId] = useState("");
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [cmsData, setCmsData] = useState<CmsDatabaseSchema | null>(null);
  const [activeTab, setActiveTab] = useState<AdminTab>("overview");
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [previewPath, setPreviewPath] = useState("/");

  // Notification toast state
  const [toast, setToast] = useState<{ message: string; type: "success" | "error" } | null>(null);
  const showToast = useCallback((message: string, type: "success" | "error" = "success") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  }, []);

  // Login form state
  const [loginId, setLoginId] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState("");
  const [loginLoading, setLoginLoading] = useState(false);

  // Setup form state
  const [setupId, setSetupId] = useState("admin");
  const [setupPassword, setSetupPassword] = useState("");
  const [setupConfirm, setSetupConfirm] = useState("");
  const [setupError, setSetupError] = useState("");
  const [setupLoading, setSetupLoading] = useState(false);

  // Change credentials state
  const [currentPassword, setCurrentPassword] = useState("");
  const [newAdminId, setNewAdminId] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [credMessage, setCredMessage] = useState<{ text: string; type: "success" | "error" } | null>(null);
  const [credLoading, setCredLoading] = useState(false);

  // Content Editor forms state
  const [contentForm, setContentForm] = useState<SiteContent | null>(null);
  const [contentSaving, setContentSaving] = useState(false);

  // Reviews Manager state
  const [reviewSearch, setReviewSearch] = useState("");
  const [reviewBranchFilter, setReviewBranchFilter] = useState("all");
  const [showAddReviewModal, setShowAddReviewModal] = useState(false);
  const [editingReview, setEditingReview] = useState<CmsReviewItem | null>(null);
  const [reviewAuthor, setReviewAuthor] = useState("");
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewBranchId, setReviewBranchId] = useState("all");
  const [reviewBranchName, setReviewBranchName] = useState("All Locations");
  const [reviewQuote, setReviewQuote] = useState("");
  const [reviewHighlightDish, setReviewHighlightDish] = useState("");
  const [reviewSaving, setReviewSaving] = useState(false);

  // Custom Pages state
  const [showPageModal, setShowPageModal] = useState(false);
  const [editingPage, setEditingPage] = useState<CmsCustomPage | null>(null);
  const [pageTitle, setPageTitle] = useState("");
  const [pageSlug, setPageSlug] = useState("");
  const [pageSubtitle, setPageSubtitle] = useState("");
  const [pageHeroImage, setPageHeroImage] = useState("/images/gallery/01-interior-wide.webp");
  const [pageContent, setPageContent] = useState("");
  const [pageCtaText, setPageCtaText] = useState("");
  const [pageCtaLink, setPageCtaLink] = useState("");
  const [pageIsPublished, setPageIsPublished] = useState(true);
  const [pageSaving, setPageSaving] = useState(false);

  // Gallery state
  const [showImageModal, setShowImageModal] = useState(false);
  const [editingImage, setEditingImage] = useState<CmsGalleryItem | null>(null);
  const [imageSrc, setImageSrc] = useState("");
  const [imageTitle, setImageTitle] = useState("");
  const [imageCategory, setImageCategory] = useState<"burgers" | "food" | "interiors" | "outlets">("food");
  const [imageDescription, setImageDescription] = useState("");
  const [imageAlt, setImageAlt] = useState("");
  const [imageFeatured, setImageFeatured] = useState(false);
  const [imageSaving, setImageSaving] = useState(false);

  // Outlets editor state
  const [selectedOutletSlug, setSelectedOutletSlug] = useState<string>("panchanai");
  const [outletSaving, setOutletSaving] = useState(false);
  const [outletDraft, setOutletDraft] = useState<CmsOutlet | null>(null);

  // Backup state
  const [backupLabel, setBackupLabel] = useState("");
  const [backupCreating, setBackupCreating] = useState(false);
  const [restoringId, setRestoringId] = useState<string | null>(null);

  // Logs state
  const [logSearch, setLogSearch] = useState("");

  // Nav Links editor state
  const [newNavLabel, setNewNavLabel] = useState("");
  const [newNavHref, setNewNavHref] = useState("");
  const [editingNavId, setEditingNavId] = useState<string | null>(null);
  const [navEditName, setNavEditName] = useState("");
  const [navEditHref, setNavEditHref] = useState("");
  const [navSaving, setNavSaving] = useState(false);

  // Device file upload states and refs
  const galleryFileInputRef = useRef<HTMLInputElement>(null);
  const [galleryUploading, setGalleryUploading] = useState(false);

  const pageFileInputRef = useRef<HTMLInputElement>(null);
  const [pageUploading, setPageUploading] = useState(false);

  const heroDesktopFileInputRef = useRef<HTMLInputElement>(null);
  const heroMobileFileInputRef = useRef<HTMLInputElement>(null);
  const [heroUploading, setHeroUploading] = useState<"desktop" | "mobile" | null>(null);

  // Generic upload helper for device files
  const uploadDeviceImage = async (file: File): Promise<string | null> => {
    if (file.size > 5 * 1024 * 1024) {
      showToast("File size exceeds 5MB limit.", "error");
      return null;
    }
    try {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch("/api/admin/media/upload", {
        method: "POST",
        body: formData,
      });
      const json = await res.json();
      if (res.ok && json.success && json.url) {
        showToast("Image uploaded successfully from device!", "success");
        return json.url;
      } else {
        showToast(json.error || "Failed to upload image.", "error");
        return null;
      }
    } catch (err) {
      console.error("Upload error:", err);
      showToast("Network error uploading image.", "error");
      return null;
    }
  };

  // Fetch all CMS data
  const fetchCmsData = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/cms");
      if (res.ok) {
        const json = await res.json();
        if (json.success && json.data) {
          setCmsData(json.data);
          setContentForm(json.data.siteContent);
        }
      }
    } catch (err) {
      console.error("Failed to load CMS data:", err);
    }
  }, []);

  const fetchDashboardData = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/dashboard");
      if (res.ok) {
        const data = await res.json();
        setDashboardData(data);
      }
    } catch (err) {
      console.error("Failed to load dashboard data:", err);
    }
  }, []);

  useEffect(() => {
    let mounted = true;
    const loadSessionAndData = async () => {
      try {
        const res = await fetch("/api/admin/auth/status");
        const data = await res.json();
        if (!mounted) return;

        setAuthenticated(data.authenticated);
        setInitialSetupNeeded(data.initialSetupNeeded);
        if (data.adminId) setCurrentAdminId(data.adminId);

        if (data.authenticated) {
          const [dashRes, cmsRes] = await Promise.all([
            fetch("/api/admin/dashboard"),
            fetch("/api/admin/cms"),
          ]);
          if (!mounted) return;
          if (dashRes.ok) {
            const dashJson = await dashRes.json();
            setDashboardData(dashJson);
          }
          if (cmsRes.ok) {
            const cmsJson = await cmsRes.json();
            if (cmsJson.data) {
              setCmsData(cmsJson.data);
              setContentForm(cmsJson.data.siteContent);
            }
          }
        }
      } catch (err) {
        console.error("Failed to check auth status:", err);
      } finally {
        if (mounted) setLoading(false);
      }
    };

    loadSessionAndData();
    return () => {
      mounted = false;
    };
  }, []);

  // Handle Login
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    setLoginLoading(true);

    try {
      const res = await fetch("/api/admin/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminId: loginId, password: loginPassword }),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        setLoginError(data.error || "Login failed. Please verify your credentials.");
        return;
      }

      setAuthenticated(true);
      setCurrentAdminId(data.adminId);
      setLoginPassword("");
      await fetchDashboardData();
      await fetchCmsData();
      showToast("Logged in successfully! Welcome to Burger Cartel CMS.");
    } catch {
      setLoginError("Network error. Please try again.");
    } finally {
      setLoginLoading(false);
    }
  };

  // Handle Initial Setup
  const handleInitialSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    setSetupError("");
    setSetupLoading(true);

    try {
      const res = await fetch("/api/admin/auth/setup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          adminId: setupId,
          password: setupPassword,
          confirmPassword: setupConfirm,
        }),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        setSetupError(data.error || "Setup failed. Check inputs.");
        return;
      }

      setInitialSetupNeeded(false);
      setAuthenticated(true);
      setCurrentAdminId(data.adminId);
      await fetchDashboardData();
      await fetchCmsData();
      showToast("Administrator account created successfully!");
    } catch {
      setSetupError("Network error. Please try again.");
    } finally {
      setSetupLoading(false);
    }
  };

  // Handle Logout
  const handleLogout = async () => {
    try {
      await fetch("/api/admin/auth/logout", { method: "POST" });
      setAuthenticated(false);
      setCurrentAdminId("");
      setDashboardData(null);
      setCmsData(null);
      showToast("Logged out securely.");
    } catch (err) {
      console.error("Logout failed:", err);
    }
  };

  // Handle Credential Modification
  const handleChangeCredentials = async (e: React.FormEvent) => {
    e.preventDefault();
    setCredMessage(null);
    setCredLoading(true);

    try {
      const res = await fetch("/api/admin/auth/change-credentials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          currentPassword,
          newAdminId: newAdminId || undefined,
          newPassword: newPassword || undefined,
          confirmNewPassword: confirmNewPassword || undefined,
        }),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        setCredMessage({ text: data.error || "Failed to update credentials.", type: "error" });
        return;
      }

      setCredMessage({ text: "Credentials updated successfully!", type: "success" });
      setCurrentPassword("");
      setNewPassword("");
      setConfirmNewPassword("");
      if (newAdminId) setCurrentAdminId(newAdminId);
      await fetchDashboardData();
    } catch {
      setCredMessage({ text: "Network error. Please try again.", type: "error" });
    } finally {
      setCredLoading(false);
    }
  };

  // Generic CMS Action Dispatcher
  const dispatchCmsAction = async (action: string, payload: unknown, successMsg?: string): Promise<boolean> => {
    try {
      const res = await fetch("/api/admin/cms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, payload }),
      });

      const json = await res.json();
      if (res.ok && json.success) {
        invalidateCmsClientCache();
        if (json.data) {
          setCmsData(json.data);
          setContentForm(json.data.siteContent);
          broadcastCmsUpdate(json.data);
        } else {
          await fetchCmsData();
        }
        if (successMsg) showToast(successMsg);
        return true;
      } else {
        showToast(json.error || "Action failed.", "error");
        return false;
      }
    } catch (err) {
      console.error("Action error:", err);
      showToast("Network error executing action.", "error");
      return false;
    }
  };

  // Menu Handlers for MenuManagerTab
  const handleSaveMenuItem = async (item: Partial<CmsMenuItem>): Promise<boolean> => {
    return await dispatchCmsAction("SAVE_MENU_ITEM", item, `Saved "${item.name}"`);
  };

  const handleDeleteMenuItem = async (id: string): Promise<boolean> => {
    return await dispatchCmsAction("DELETE_MENU_ITEM", { id }, "Menu item deleted");
  };

  const handleSaveMenuCategory = async (category: Partial<CmsMenuCategory>): Promise<boolean> => {
    return await dispatchCmsAction("SAVE_MENU_CATEGORY", category, `Saved category "${category.name}"`);
  };

  const handleDeleteMenuCategory = async (id: string): Promise<boolean> => {
    return await dispatchCmsAction("DELETE_MENU_CATEGORY", { id }, "Category deleted");
  };

  const handleUpdateMenuSettings = async (settings: { showPrices: boolean }): Promise<boolean> => {
    return await dispatchCmsAction("UPDATE_MENU_SETTINGS", settings, `Menu prices turned ${settings.showPrices ? "ON" : "OFF"}`);
  };

  const handleToggleOutletAvailability = async (
    outletId: string,
    menuItemId: string,
    isAvailable: boolean
  ): Promise<boolean> => {
    return await dispatchCmsAction(
      "TOGGLE_OUTLET_ITEM_AVAILABILITY",
      { outletId, menuItemId, isAvailable },
      "Branch item availability updated"
    );
  };

  // Save Whole Site Content (Hero, Announcement, About, Contact, Footer, SEO)
  const handleSaveContent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!contentForm) return;
    setContentSaving(true);
    const formToSave = {
      ...contentForm,
      hero: {
        ...contentForm.hero,
        headline: "",
      },
    };
    await dispatchCmsAction("UPDATE_SITE_CONTENT", formToSave, "Website content updated live!");
    setContentSaving(false);
  };

  // Outlets Handlers
  const currentOutlet = useMemo(() => {
    return (cmsData?.outlets || []).find((o) => o.slug === selectedOutletSlug) || cmsData?.outlets?.[0] || null;
  }, [cmsData?.outlets, selectedOutletSlug]);

  const [prevOutlet, setPrevOutlet] = useState<CmsOutlet | null>(null);
  if (currentOutlet && currentOutlet !== prevOutlet) {
    setPrevOutlet(currentOutlet);
    setOutletDraft({ ...currentOutlet });
  }

  const isOutletDirty = useMemo(() => {
    if (!outletDraft || !currentOutlet) return false;
    return (
      outletDraft.name !== currentOutlet.name ||
      (outletDraft.phone || "") !== (currentOutlet.phone || "") ||
      (outletDraft.hoursDisplay || "") !== (currentOutlet.hoursDisplay || "") ||
      (outletDraft.address || "") !== (currentOutlet.address || "") ||
      Boolean(outletDraft.isOpen) !== Boolean(currentOutlet.isOpen) ||
      (outletDraft.temporaryClosureNotice || "") !== (currentOutlet.temporaryClosureNotice || "") ||
      (outletDraft.googleMapsUrl || "") !== (currentOutlet.googleMapsUrl || "") ||
      (outletDraft.swiggyUrl || "") !== (currentOutlet.swiggyUrl || "") ||
      (outletDraft.zomatoUrl || "") !== (currentOutlet.zomatoUrl || "")
    );
  }, [outletDraft, currentOutlet]);

  const handleSaveOutletDraft = async () => {
    if (!outletDraft || !currentOutlet) return;
    if (!outletDraft.name.trim()) {
      showToast("Outlet name cannot be empty.", "error");
      return;
    }
    if (!outletDraft.address.trim()) {
      showToast("Outlet address cannot be empty.", "error");
      return;
    }

    setOutletSaving(true);
    await dispatchCmsAction(
      "UPDATE_OUTLET",
      {
        slug: currentOutlet.slug,
        expectedUpdatedAt: currentOutlet.updatedAt,
        name: outletDraft.name.trim(),
        phone: outletDraft.phone?.trim() || "",
        hoursDisplay: outletDraft.hoursDisplay?.trim() || "",
        isOpen: Boolean(outletDraft.isOpen),
        address: outletDraft.address.trim(),
        temporaryClosureNotice: outletDraft.temporaryClosureNotice?.trim() || "",
        googleMapsUrl: outletDraft.googleMapsUrl?.trim() || "",
        swiggyUrl: outletDraft.swiggyUrl?.trim() || "",
        zomatoUrl: outletDraft.zomatoUrl?.trim() || "",
      },
      `Saved changes for "${outletDraft.name}"`
    );
    setOutletSaving(false);
  };

  const handleCancelOutletDraft = () => {
    if (currentOutlet) {
      setOutletDraft({ ...currentOutlet });
      showToast("Changes discarded", "success");
    }
  };

  const handleSelectOutlet = (slug: string) => {
    if (isOutletDirty && !confirm("You have unsaved changes to this outlet. Discard changes and switch?")) {
      return;
    }
    setSelectedOutletSlug(slug);
  };

  // Reviews Handlers
  const handleToggleReviewVisibility = async (review: CmsReviewItem) => {
    await dispatchCmsAction(
      "TOGGLE_REVIEW_VISIBILITY",
      { id: review.id },
      review.hidden ? `Review by ${review.author} is now visible.` : `Review by ${review.author} hidden.`
    );
  };

  const handleDeleteReview = async (review: CmsReviewItem) => {
    if (!confirm(`Permanently delete review by "${review.author}"?`)) return;
    await dispatchCmsAction("DELETE_REVIEW", { id: review.id }, "Review deleted");
  };

  const handleSaveReviewModal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewAuthor.trim() || !reviewQuote.trim()) {
      showToast("Author and Quote are required.", "error");
      return;
    }
    setReviewSaving(true);
    const action = editingReview ? "UPDATE_REVIEW" : "ADD_REVIEW";
    const ok = await dispatchCmsAction(
      action,
      {
        id: editingReview?.id,
        author: reviewAuthor.trim(),
        rating: reviewRating,
        branchId: reviewBranchId,
        branchName: reviewBranchName,
        quote: reviewQuote.trim(),
        highlightDish: reviewHighlightDish.trim() || undefined,
      },
      editingReview ? "Review updated!" : "New review published!"
    );
    if (ok) {
      setShowAddReviewModal(false);
      setEditingReview(null);
      setReviewAuthor("");
      setReviewQuote("");
      setReviewHighlightDish("");
    }
    setReviewSaving(false);
  };

  const openEditReviewModal = (rev: CmsReviewItem) => {
    setEditingReview(rev);
    setReviewAuthor(rev.author);
    setReviewRating(rev.rating);
    setReviewBranchId(rev.branchId);
    setReviewBranchName(rev.branchName);
    setReviewQuote(rev.quote);
    setReviewHighlightDish(rev.highlightDish || "");
    setShowAddReviewModal(true);
  };

  // Custom Pages Handlers
  const handlePageTitleChange = (val: string) => {
    setPageTitle(val);
    if (!editingPage) {
      const generated = val
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-|-$/g, "");
      setPageSlug(generated);
    }
  };

  const handleSavePageModal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pageTitle.trim() || !pageSlug.trim() || !pageContent.trim()) {
      showToast("Page Title, URL Slug, and Content are required.", "error");
      return;
    }
    setPageSaving(true);
    const ok = await dispatchCmsAction(
      "SAVE_CUSTOM_PAGE",
      {
        id: editingPage?.id,
        title: pageTitle.trim(),
        slug: pageSlug.trim(),
        subtitle: pageSubtitle.trim(),
        heroImage: pageHeroImage.trim() || undefined,
        content: pageContent.trim(),
        ctaText: pageCtaText.trim() || undefined,
        ctaLink: pageCtaLink.trim() || undefined,
        isPublished: pageIsPublished,
      },
      `Page '${pageTitle}' published at /p/${pageSlug}`
    );
    if (ok) {
      setShowPageModal(false);
      setEditingPage(null);
      setPageTitle("");
      setPageSlug("");
      setPageSubtitle("");
      setPageContent("");
      setPageCtaText("");
      setPageCtaLink("");
    }
    setPageSaving(false);
  };

  const openEditPageModal = (p: CmsCustomPage) => {
    setEditingPage(p);
    setPageTitle(p.title);
    setPageSlug(p.slug);
    setPageSubtitle(p.subtitle);
    setPageHeroImage(p.heroImage || "/images/gallery/01-interior-wide.webp");
    setPageContent(p.content);
    setPageCtaText(p.ctaText || "");
    setPageCtaLink(p.ctaLink || "");
    setPageIsPublished(p.isPublished);
    setShowPageModal(true);
  };

  const handleDeletePage = async (page: CmsCustomPage) => {
    if (!confirm(`Delete custom page "${page.title}" (/p/${page.slug})?`)) return;
    await dispatchCmsAction("DELETE_CUSTOM_PAGE", { id: page.id }, `Page /p/${page.slug} deleted`);
  };

  // Gallery Handlers
  const handleSaveImageModal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!imageSrc.trim() || !imageTitle.trim()) {
      showToast("Image URL and Title are required.", "error");
      return;
    }
    setImageSaving(true);
    const action = editingImage ? "UPDATE_GALLERY_ITEM" : "ADD_GALLERY_ITEM";
    const ok = await dispatchCmsAction(
      action,
      {
        id: editingImage?.id,
        src: imageSrc.trim(),
        title: imageTitle.trim(),
        category: imageCategory,
        description: imageDescription.trim(),
        alt: imageAlt.trim() || imageTitle.trim(),
        featured: imageFeatured,
      },
      editingImage ? "Image updated" : "Image added to gallery"
    );
    if (ok) {
      setShowImageModal(false);
      setEditingImage(null);
      setImageSrc("");
      setImageTitle("");
      setImageDescription("");
      setImageAlt("");
    }
    setImageSaving(false);
  };

  const openEditImageModal = (item: CmsGalleryItem) => {
    setEditingImage(item);
    setImageSrc(item.src);
    setImageTitle(item.title);
    setImageCategory(item.category);
    setImageDescription(item.description);
    setImageAlt(item.alt);
    setImageFeatured(Boolean(item.featured));
    setShowImageModal(true);
  };

  const handleDeleteImage = async (item: CmsGalleryItem) => {
    if (!confirm(`Delete image "${item.title}"?`)) return;
    await dispatchCmsAction("DELETE_GALLERY_ITEM", { id: item.id }, "Image removed from gallery");
  };

  // Backup & Restore Handlers
  const handleCreateBackup = async (e: React.FormEvent) => {
    e.preventDefault();
    setBackupCreating(true);
    await dispatchCmsAction("CREATE_BACKUP", { label: backupLabel || "Manual Admin Snapshot" }, "Backup snapshot created!");
    setBackupLabel("");
    setBackupCreating(false);
  };

  const handleRestoreBackup = async (snapshot: CmsBackupSnapshot) => {
    if (!confirm(`RESTORE SNAPSHOT "${snapshot.label}" from ${new Date(snapshot.timestamp).toLocaleString()}?\n\nThis will replace all live menu items, outlets, and texts with this snapshot's state.`)) {
      return;
    }
    setRestoringId(snapshot.id);
    await dispatchCmsAction("RESTORE_BACKUP", { backupId: snapshot.id }, `Restored database to snapshot '${snapshot.label}'`);
    setRestoringId(null);
  };

  const handleDownloadBackup = (snapshot: CmsBackupSnapshot) => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(snapshot.data, null, 2));
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `burger-cartel-backup-${snapshot.id}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Navigation Links Handlers
  const handleAddNavLink = () => {
    if (!newNavLabel.trim() || !newNavHref.trim() || !contentForm) return;
    const updated = [
      ...(contentForm.navigation || []),
      {
        id: `nav-${Date.now()}`,
        name: newNavLabel.trim(),
        href: newNavHref.trim(),
        isVisible: true,
      },
    ];
    setContentForm({ ...contentForm, navigation: updated });
    setNewNavLabel("");
    setNewNavHref("");
    showToast("Added link to draft. Click 'Save Navigation' to publish.");
  };

  const handleDeleteNavLink = (id: string) => {
    if (!contentForm) return;
    const updated = (contentForm.navigation || []).filter((n) => n.id !== id);
    setContentForm({ ...contentForm, navigation: updated });
  };

  const handleStartEditNavLink = (link: { id: string; name: string; href: string }) => {
    setEditingNavId(link.id);
    setNavEditName(link.name);
    setNavEditHref(link.href);
  };

  const handleSaveEditNavLink = (id: string) => {
    if (!contentForm || !navEditName.trim() || !navEditHref.trim()) return;
    const updated = (contentForm.navigation || []).map((n) =>
      n.id === id ? { ...n, name: navEditName.trim(), href: navEditHref.trim() } : n
    );
    setContentForm({ ...contentForm, navigation: updated });
    setEditingNavId(null);
    showToast("Updated link draft. Click 'Save Navigation' to publish.");
  };

  const handleCancelEditNavLink = () => {
    setEditingNavId(null);
  };

  const handleSaveNavigationOnly = async () => {
    if (!contentForm) return;
    setNavSaving(true);
    await dispatchCmsAction("UPDATE_NAVIGATION", contentForm.navigation || [], "Navigation links saved & published!");
    setNavSaving(false);
  };

  const handleSaveAnnouncementOnly = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!contentForm) return;
    setContentSaving(true);
    await dispatchCmsAction("UPDATE_ANNOUNCEMENT", contentForm.announcement, "Announcement banner saved & updated live!");
    setContentSaving(false);
  };

  // Filtered reviews
  const filteredReviews = (cmsData?.reviews || []).filter((r) => {
    const matchesBranch = reviewBranchFilter === "all" || r.branchId === reviewBranchFilter;
    const matchesSearch =
      !reviewSearch.trim() ||
      r.author.toLowerCase().includes(reviewSearch.toLowerCase()) ||
      r.quote.toLowerCase().includes(reviewSearch.toLowerCase()) ||
      (r.highlightDish && r.highlightDish.toLowerCase().includes(reviewSearch.toLowerCase()));
    return matchesBranch && matchesSearch;
  });

  // Filtered logs
  const filteredLogs = (dashboardData?.recentLogs || []).filter((l) => {
    if (!logSearch.trim()) return true;
    const q = logSearch.toLowerCase();
    return (
      l.event.toLowerCase().includes(q) ||
      (l.adminId && l.adminId.toLowerCase().includes(q)) ||
      (l.details && l.details.toLowerCase().includes(q))
    );
  });

  // Top open preview helper
  const openPreview = (path: string = "/") => {
    setPreviewPath(path);
    setIsPreviewOpen(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0D0D0C] text-white flex flex-col items-center justify-center p-4">
        <div className="w-10 h-10 border-2 border-[#B18B5B] border-t-transparent rounded-full animate-spin mb-4" />
        <p className="text-xs uppercase tracking-[0.2em] text-[#B18B5B] font-bold">
          Verifying Burger Cartel CMS...
        </p>
      </div>
    );
  }

  // UN-AUTHENTICATED: LOGIN OR INITIAL SETUP
  if (!authenticated) {
    return (
      <div className="min-h-screen bg-[#0A0A09] text-white flex flex-col justify-between p-4 sm:p-8 font-sans">
        <header className="max-w-5xl mx-auto w-full flex items-center justify-between py-4 border-b border-zinc-800/80">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-zinc-900 border border-zinc-700/80 flex items-center justify-center overflow-hidden">
              <Image
                src="/images/logo.webp"
                alt="Burger Cartel Logo"
                width={28}
                height={28}
                className="object-contain"
              />
            </div>
            <div>
              <span className="font-black text-sm tracking-widest uppercase text-white block">BURGER CARTEL</span>
              <span className="text-[10px] text-zinc-400 tracking-wider uppercase block">Website Admin &amp; CMS</span>
            </div>
          </div>
          <Link
            href="/"
            className="text-xs font-bold text-zinc-400 hover:text-white flex items-center gap-1.5 transition-colors"
          >
            <span>Live Site</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </Link>
        </header>

        <main className="max-w-md mx-auto w-full my-auto py-10">
          <div className="bg-[#141413] border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-500 via-[#B18B5B] to-amber-500" />

            {initialSetupNeeded ? (
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold tracking-wider uppercase mb-4">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>One-Time Initial Setup</span>
                </div>
                <h1 className="text-2xl font-black uppercase tracking-tight text-white mb-2">Create Admin Account</h1>
                <p className="text-xs text-zinc-400 leading-relaxed mb-6">
                  Set up your master administrator ID and password to access the website management dashboard.
                </p>

                {setupError && (
                  <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2 mb-4">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{setupError}</span>
                  </div>
                )}

                <form onSubmit={handleInitialSetup} className="space-y-4">
                  <div>
                    <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                      Admin ID
                    </label>
                    <input
                      type="text"
                      value={setupId}
                      onChange={(e) => setSetupId(e.target.value)}
                      required
                      className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                      Password
                    </label>
                    <input
                      type="password"
                      value={setupPassword}
                      onChange={(e) => setSetupPassword(e.target.value)}
                      required
                      placeholder="Min 8 characters"
                      className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                      Confirm Password
                    </label>
                    <input
                      type="password"
                      value={setupConfirm}
                      onChange={(e) => setSetupConfirm(e.target.value)}
                      required
                      className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={setupLoading}
                    className="w-full py-3.5 rounded-xl bg-[#B18B5B] hover:bg-[#9a784d] text-white font-bold text-xs uppercase tracking-widest transition-all mt-2 disabled:opacity-50"
                  >
                    {setupLoading ? "Creating Account..." : "Create Master Admin"}
                  </button>
                </form>
              </div>
            ) : (
              <div>
                <div className="w-12 h-12 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center mb-4 text-[#B18B5B]">
                  <Lock className="w-5 h-5" />
                </div>
                <h1 className="text-2xl font-black uppercase tracking-tight text-white mb-2">Admin Sign In</h1>
                <p className="text-xs text-zinc-400 leading-relaxed mb-6">
                  Sign in with your master credentials to manage the Burger Cartel website.
                </p>

                {loginError && (
                  <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2 mb-4">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{loginError}</span>
                  </div>
                )}

                <form onSubmit={handleLogin} className="space-y-4">
                  <div>
                    <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                      Admin ID
                    </label>
                    <input
                      type="text"
                      value={loginId}
                      onChange={(e) => setLoginId(e.target.value)}
                      required
                      placeholder="e.g. BC-ADMIN-SETUP-01"
                      className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                      Password
                    </label>
                    <div className="relative">
                      <input
                        type={showPassword ? "text" : "password"}
                        value={loginPassword}
                        onChange={(e) => setLoginPassword(e.target.value)}
                        required
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B] pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                  <button
                    type="submit"
                    disabled={loginLoading}
                    className="w-full py-3.5 rounded-xl bg-[#B18B5B] hover:bg-[#9a784d] text-white font-bold text-xs uppercase tracking-widest transition-all mt-2 disabled:opacity-50"
                  >
                    {loginLoading ? "Authenticating..." : "Sign In to Admin Panel"}
                  </button>
                </form>
              </div>
            )}
          </div>
        </main>

        <footer className="max-w-5xl mx-auto w-full text-center py-4 text-[11px] text-zinc-600">
          Burger Cartel · Protected Administrator Portal · AES-256-GCM Vault
        </footer>
      </div>
    );
  }

  // COUNTS FOR SIDEBAR
  const counts = {
    menuItems: cmsData?.menuItems?.length || 0,
    reviews: (cmsData?.reviews || []).filter((r) => !r.hidden).length,
    outlets: cmsData?.outlets?.length || 0,
    pages: cmsData?.customPages?.length || 0,
    gallery: cmsData?.gallery?.length || 0,
  };

  // AUTHENTICATED: FULL NO-CODE CMS & ADMIN CONTROL PANEL
  return (
    <div className="min-h-screen bg-[#0D0D0C] text-white flex flex-col font-sans selection:bg-[#B18B5B] selection:text-black">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 animate-bounce">
          <div
            className={`px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-3 text-xs font-bold ${
              toast.type === "success" ? "bg-[#B18B5B] text-white" : "bg-rose-500 text-white"
            }`}
          >
            {toast.type === "success" ? <Check className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
            <span>{toast.message}</span>
          </div>
        </div>
      )}

      {/* Navigation Sidebar - Fixed on desktop (w-72), slide-over drawer on mobile */}
      <AdminSidebar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        counts={counts}
        isMobileOpen={isMobileSidebarOpen}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
      />

      {/* Main Content Area - Offset by sidebar width (w-72 = 288px) on desktop */}
      <div className="lg:pl-72 flex flex-col flex-1 min-w-0 min-h-screen">
        {/* Top Header Bar */}
        <header className="sticky top-0 z-30 bg-[#141413]/95 backdrop-blur-md border-b border-zinc-800 px-4 sm:px-8 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-3 sm:gap-4">
            {/* Mobile Menu Hamburger (hidden on lg where sidebar is docked) */}
            <button
              type="button"
              onClick={() => setIsMobileSidebarOpen(true)}
              className="lg:hidden p-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white"
              aria-label="Open Navigation"
            >
              <MenuIcon className="w-5 h-5" />
            </button>

            {/* Mobile Brand Badge (shown only below lg) */}
            <div className="flex items-center gap-2 lg:hidden">
              <div className="w-8 h-8 rounded-xl bg-zinc-900 border border-zinc-700/80 flex items-center justify-center overflow-hidden">
                <Image
                  src="/images/logo.webp"
                  alt="Burger Cartel Logo"
                  width={24}
                  height={24}
                  className="object-contain"
                />
              </div>
              <span className="font-black text-xs tracking-wider uppercase text-white">BURGER CARTEL</span>
            </div>

            {/* Desktop Breadcrumb Navigation */}
            <div className="hidden lg:flex items-center gap-2 text-xs">
              <span className="font-bold text-zinc-500 uppercase tracking-wider">CMS Management</span>
              <span className="text-zinc-700">/</span>
              <span className="font-bold text-[#B18B5B] uppercase tracking-wider capitalize">
                {activeTab.replace(/([A-Z])/g, " $1")}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {/* Live Preview Button */}
            <button
              type="button"
              onClick={() => openPreview(activeTab === "menu" ? "/menu" : "/")}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#B18B5B]/15 hover:bg-[#B18B5B]/25 border border-[#B18B5B]/30 text-xs font-bold text-[#B18B5B] transition-colors cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Live Preview</span>
            </button>

            <Link
              href="/"
              target="_blank"
              className="hidden lg:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/80 text-xs font-bold text-zinc-300 transition-colors"
            >
              <span>Live Site</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </Link>

            <div className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-300">
              <User className="w-3.5 h-3.5 text-[#B18B5B]" />
              <span className="font-mono text-[11px] font-bold">{currentAdminId}</span>
            </div>

            <button
              onClick={handleLogout}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-400 text-xs font-bold transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Sign Out</span>
            </button>
          </div>
        </header>

        {/* Tab Content Panel */}
        <main className="flex-1 w-full max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-6 min-w-0">
          {/* TAB 1: DASHBOARD OVERVIEW */}
          {activeTab === "overview" && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-[#141413] border border-zinc-800 rounded-3xl p-6 sm:p-8">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
                  <div>
                    <h1 className="text-2xl font-black uppercase tracking-tight text-white">Dashboard Overview</h1>
                    <p className="text-xs text-zinc-400 mt-1">
                      Welcome back, <span className="text-[#B18B5B] font-bold">{currentAdminId}</span>. All website
                      sections and dishes are live.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => openPreview("/")}
                      className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/80 text-xs font-bold text-white transition-colors"
                    >
                      <Eye className="w-4 h-4 text-[#B18B5B]" />
                      <span>Preview Homepage</span>
                    </button>
                    <button
                      onClick={() => setActiveTab("menu")}
                      className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#B18B5B] hover:bg-[#9a784d] text-white text-xs font-bold transition-colors"
                    >
                      <UtensilsCrossed className="w-4 h-4" />
                      <span>Manage Menu</span>
                    </button>
                  </div>
                </div>

                {/* Metrics Grid */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                  <div
                    onClick={() => setActiveTab("menu")}
                    className="p-5 rounded-2xl bg-zinc-900/80 border border-zinc-800/80 hover:border-[#B18B5B]/50 transition-all cursor-pointer group"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400">Menu Items</span>
                      <UtensilsCrossed className="w-4 h-4 text-[#B18B5B] group-hover:scale-110 transition-transform" />
                    </div>
                    <div className="text-3xl font-black text-white">{counts.menuItems}</div>
                    <span className="text-[10px] text-zinc-500 mt-1 block">Across 14 categories</span>
                  </div>

                  <div
                    onClick={() => setActiveTab("outlets")}
                    className="p-5 rounded-2xl bg-zinc-900/80 border border-zinc-800/80 hover:border-emerald-500/50 transition-all cursor-pointer group"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400">Active Outlets</span>
                      <Building2 className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
                    </div>
                    <div className="text-3xl font-black text-white">{counts.outlets}</div>
                    <span className="text-[10px] text-zinc-500 mt-1 block">Darjeeling, Kurseong &amp; Siliguri</span>
                  </div>

                  <div
                    onClick={() => setActiveTab("reviews")}
                    className="p-5 rounded-2xl bg-zinc-900/80 border border-zinc-800/80 hover:border-amber-400/50 transition-all cursor-pointer group"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400">Verified Reviews</span>
                      <Star className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
                    </div>
                    <div className="text-3xl font-black text-white">{counts.reviews}</div>
                    <span className="text-[10px] text-zinc-500 mt-1 block">Live customer testimonials</span>
                  </div>

                  <div
                    onClick={() => setActiveTab("gallery")}
                    className="p-5 rounded-2xl bg-zinc-900/80 border border-zinc-800/80 hover:border-purple-400/50 transition-all cursor-pointer group"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400">Media Assets</span>
                      <ImageIcon className="w-4 h-4 text-purple-400 group-hover:scale-110 transition-transform" />
                    </div>
                    <div className="text-3xl font-black text-white">{counts.gallery}</div>
                    <span className="text-[10px] text-zinc-500 mt-1 block">High-res WebP photography</span>
                  </div>
                </div>

                {/* Quick Action Shortcuts */}
                <h2 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-3">Quick CMS Shortcuts</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-8">
                  {[
                    { label: "Edit Hero", tab: "homepage", icon: LayoutDashboard },
                    { label: "Update Prices", tab: "menu", icon: UtensilsCrossed },
                    { label: "Branch Hours", tab: "outlets", icon: Clock },
                    { label: "Banner Alert", tab: "announcement", icon: Megaphone },
                    { label: "Create Backup", tab: "backup", icon: Archive },
                    { label: "Change Password", tab: "security", icon: KeyRound },
                  ].map((sc) => {
                    const Icon = sc.icon;
                    return (
                      <button
                        key={sc.label}
                        type="button"
                        onClick={() => setActiveTab(sc.tab as AdminTab)}
                        className="p-3 rounded-xl bg-zinc-900/60 hover:bg-zinc-800 border border-zinc-800/80 text-left transition-all flex flex-col gap-2 group"
                      >
                        <Icon className="w-4 h-4 text-[#B18B5B] group-hover:scale-110 transition-transform" />
                        <span className="text-xs font-bold text-zinc-300 group-hover:text-white">{sc.label}</span>
                      </button>
                    );
                  })}
                </div>

                {/* System Health Card */}
                <div className="p-5 rounded-2xl bg-zinc-950 border border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
                      <ShieldCheck className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-white block">System Security &amp; Vault Operational</span>
                      <span className="text-[11px] text-zinc-400">
                        Storage: <span className="text-zinc-200 font-mono">Encrypted JSON Store</span> · Session Guard:{" "}
                        <span className="text-emerald-400 font-bold">Active</span>
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveTab("backup")}
                    className="px-3.5 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/80 text-xs font-bold text-zinc-300 transition-colors"
                  >
                    View Snapshots
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: HOMEPAGE HERO EDITOR */}
          {activeTab === "homepage" && contentForm && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-[#141413] border border-zinc-800 rounded-3xl p-6 sm:p-8">
                <div className="flex items-center justify-between gap-4 mb-6">
                  <div>
                    <h1 className="text-2xl font-black uppercase tracking-tight text-white">Homepage Hero Editor</h1>
                    <p className="text-xs text-zinc-400 mt-1">
                      Customise the hero typography, call-to-actions, and background photography displayed on the public
                      homepage.
                    </p>
                  </div>
                  <button
                    onClick={() => openPreview("/")}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-700 text-xs font-bold text-zinc-300 hover:text-white"
                  >
                    <Eye className="w-3.5 h-3.5 text-[#B18B5B]" />
                    <span>Preview Hero</span>
                  </button>
                </div>

                <form onSubmit={handleSaveContent} className="space-y-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Badge Text
                      </label>
                      <input
                        type="text"
                        value={contentForm.hero.badge || ""}
                        onChange={(e) =>
                          setContentForm({
                            ...contentForm,
                            hero: { ...contentForm.hero, badge: e.target.value },
                          })
                        }
                        placeholder="e.g. EST. 2024 · NORTH BENGAL"
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Location Tagline
                      </label>
                      <input
                        type="text"
                        value={contentForm.hero.locationTagline || ""}
                        onChange={(e) =>
                          setContentForm({
                            ...contentForm,
                            hero: { ...contentForm.hero, locationTagline: e.target.value },
                          })
                        }
                        placeholder="e.g. DARJEELING · KURSEONG · SILIGURI"
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Headline Line 1
                      </label>
                      <input
                        type="text"
                        value={contentForm.hero.titleLine1 || ""}
                        onChange={(e) =>
                          setContentForm({
                            ...contentForm,
                            hero: { ...contentForm.hero, titleLine1: e.target.value, headline: "" },
                          })
                        }
                        required
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Headline Line 2
                      </label>
                      <input
                        type="text"
                        value={contentForm.hero.titleLine2 || ""}
                        onChange={(e) =>
                          setContentForm({
                            ...contentForm,
                            hero: { ...contentForm.hero, titleLine2: e.target.value, headline: "" },
                          })
                        }
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                      Hero Subtitle / Description
                    </label>
                    <textarea
                      rows={3}
                      value={contentForm.hero.subtitle || ""}
                      onChange={(e) =>
                        setContentForm({
                          ...contentForm,
                          hero: { ...contentForm.hero, subtitle: e.target.value },
                        })
                      }
                      className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B] leading-relaxed"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Primary CTA Button Text
                      </label>
                      <input
                        type="text"
                        value={contentForm.hero.ctaPrimaryText || ""}
                        onChange={(e) =>
                          setContentForm({
                            ...contentForm,
                            hero: { ...contentForm.hero, ctaPrimaryText: e.target.value },
                          })
                        }
                        placeholder="e.g. Explore Menu"
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Primary CTA Button Link
                      </label>
                      <input
                        type="text"
                        value={contentForm.hero.ctaPrimaryLink || ""}
                        onChange={(e) =>
                          setContentForm({
                            ...contentForm,
                            hero: { ...contentForm.hero, ctaPrimaryLink: e.target.value },
                          })
                        }
                        placeholder="/menu"
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Secondary CTA Button Text
                      </label>
                      <input
                        type="text"
                        value={contentForm.hero.ctaSecondaryText || ""}
                        onChange={(e) =>
                          setContentForm({
                            ...contentForm,
                            hero: { ...contentForm.hero, ctaSecondaryText: e.target.value },
                          })
                        }
                        placeholder="e.g. Find Outlets"
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Secondary CTA Button Link
                      </label>
                      <input
                        type="text"
                        value={contentForm.hero.ctaSecondaryLink || ""}
                        onChange={(e) =>
                          setContentForm({
                            ...contentForm,
                            hero: { ...contentForm.hero, ctaSecondaryLink: e.target.value },
                          })
                        }
                        placeholder="/locations"
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-3 border-t border-zinc-800">
                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Desktop Background Image
                      </label>
                      <div className="flex flex-col sm:flex-row gap-2">
                        <input
                          type="text"
                          value={contentForm.hero.desktopImage || ""}
                          onChange={(e) =>
                            setContentForm({
                              ...contentForm,
                              hero: { ...contentForm.hero, desktopImage: e.target.value },
                            })
                          }
                          placeholder="/images/hero-desktop.webp"
                          className="flex-1 px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-xs focus:outline-none focus:border-[#B18B5B]"
                        />
                        <input
                          type="file"
                          ref={heroDesktopFileInputRef}
                          accept="image/png,image/jpeg,image/webp,image/gif"
                          className="hidden"
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (!file) return;
                            setHeroUploading("desktop");
                            const url = await uploadDeviceImage(file);
                            if (url) {
                              setContentForm({
                                ...contentForm,
                                hero: { ...contentForm.hero, desktopImage: url },
                              });
                            }
                            setHeroUploading(null);
                            if (heroDesktopFileInputRef.current) heroDesktopFileInputRef.current.value = "";
                          }}
                        />
                        <button
                          type="button"
                          onClick={() => heroDesktopFileInputRef.current?.click()}
                          disabled={heroUploading === "desktop"}
                          className="px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold transition-all border border-zinc-700 flex items-center justify-center gap-1.5 shrink-0 cursor-pointer"
                        >
                          <Upload className="w-3.5 h-3.5 text-[#B18B5B]" />
                          <span>{heroUploading === "desktop" ? "Uploading..." : "Select from device"}</span>
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Mobile Background Image
                      </label>
                      <div className="flex flex-col sm:flex-row gap-2">
                        <input
                          type="text"
                          value={contentForm.hero.mobileImage || ""}
                          onChange={(e) =>
                            setContentForm({
                              ...contentForm,
                              hero: { ...contentForm.hero, mobileImage: e.target.value },
                            })
                          }
                          placeholder="/images/hero-base-mobile.webp"
                          className="flex-1 px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-xs focus:outline-none focus:border-[#B18B5B]"
                        />
                        <input
                          type="file"
                          ref={heroMobileFileInputRef}
                          accept="image/png,image/jpeg,image/webp,image/gif"
                          className="hidden"
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (!file) return;
                            setHeroUploading("mobile");
                            const url = await uploadDeviceImage(file);
                            if (url) {
                              setContentForm({
                                ...contentForm,
                                hero: { ...contentForm.hero, mobileImage: url },
                              });
                            }
                            setHeroUploading(null);
                            if (heroMobileFileInputRef.current) heroMobileFileInputRef.current.value = "";
                          }}
                        />
                        <button
                          type="button"
                          onClick={() => heroMobileFileInputRef.current?.click()}
                          disabled={heroUploading === "mobile"}
                          className="px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold transition-all border border-zinc-700 flex items-center justify-center gap-1.5 shrink-0 cursor-pointer"
                        >
                          <Upload className="w-3.5 h-3.5 text-[#B18B5B]" />
                          <span>{heroUploading === "mobile" ? "Uploading..." : "Select from device"}</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 flex items-center justify-end gap-3">
                    <button
                      type="submit"
                      disabled={contentSaving}
                      className="px-6 py-3 rounded-xl bg-[#B18B5B] hover:bg-[#9a784d] text-white font-bold text-xs uppercase tracking-wider transition-all disabled:opacity-50 flex items-center gap-2"
                    >
                      <Save className="w-4 h-4" />
                      <span>{contentSaving ? "Saving..." : "Save Homepage Hero"}</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* TAB 3: MENU MANAGEMENT (MENU MANAGER TAB COMPONENT) */}
          {activeTab === "menu" && (
            <div className="animate-fadeIn">
              <MenuManagerTab
                menuItems={cmsData?.menuItems || []}
                menuCategories={cmsData?.menuCategories || []}
                galleryItems={cmsData?.gallery || []}
                outlets={cmsData?.outlets || []}
                outletMenuAvailability={cmsData?.outletMenuAvailability || {}}
                menuSettings={cmsData?.siteContent?.menuSettings || { showPrices: true }}
                onSaveItem={handleSaveMenuItem}
                onDeleteItem={handleDeleteMenuItem}
                onSaveCategory={handleSaveMenuCategory}
                onDeleteCategory={handleDeleteMenuCategory}
                onToggleOutletAvailability={handleToggleOutletAvailability}
                onUpdateMenuSettings={handleUpdateMenuSettings}
                showToast={showToast}
              />
            </div>
          )}

          {/* TAB 4: BRANCH OUTLETS EDITOR */}
          {activeTab === "outlets" && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-[#141413] border border-zinc-800 rounded-3xl p-6 sm:p-8">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                  <div>
                    <h1 className="text-2xl font-black uppercase tracking-tight text-white">Branch Outlets Management</h1>
                    <p className="text-xs text-zinc-400 mt-1">
                      Update operating hours, phone numbers, addresses, Google Maps links, and temporary closure alerts
                      across all 5 outlets.
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2.5">
                    {isOutletDirty && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-[11px] font-bold text-amber-300 animate-pulse">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                        <span>Unsaved Changes</span>
                      </span>
                    )}
                    {outletSaving && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#B18B5B]/10 border border-[#B18B5B]/30 text-xs font-bold text-[#B18B5B]">
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Saving...</span>
                      </span>
                    )}
                    {isOutletDirty && (
                      <button
                        type="button"
                        onClick={handleCancelOutletDraft}
                        disabled={outletSaving}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-zinc-900 border border-zinc-700 hover:border-zinc-500 text-xs font-bold text-zinc-300 hover:text-white transition-all cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5 text-zinc-400" />
                        <span>Discard</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={handleSaveOutletDraft}
                      disabled={!isOutletDirty || outletSaving}
                      className={`inline-flex items-center gap-2 px-5 py-2 rounded-xl text-xs font-bold transition-all shadow-md ${
                        isOutletDirty && !outletSaving
                          ? "bg-[#B18B5B] hover:bg-[#c49b67] text-white cursor-pointer active:scale-95"
                          : "bg-zinc-800 text-zinc-500 border border-zinc-700/50 cursor-not-allowed opacity-60"
                      }`}
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>{outletSaving ? "Saving..." : "Save Changes"}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => openPreview(`/locations/${selectedOutletSlug}`)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-xs font-bold text-zinc-300 hover:text-white transition-all"
                    >
                      <Eye className="w-3.5 h-3.5 text-[#B18B5B]" />
                      <span>Preview</span>
                    </button>
                  </div>
                </div>

                {/* Outlet Selector Pills */}
                <div className="flex flex-wrap gap-2 mb-8 p-1.5 bg-zinc-950 rounded-2xl border border-zinc-800">
                  {(cmsData?.outlets || []).map((o) => (
                    <button
                      key={o.slug}
                      type="button"
                      onClick={() => handleSelectOutlet(o.slug)}
                      className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                        selectedOutletSlug === o.slug
                          ? "bg-[#B18B5B] text-white shadow-md"
                          : "text-zinc-400 hover:text-white hover:bg-zinc-900"
                      }`}
                    >
                      <Building2 className="w-3.5 h-3.5" />
                      <span>{o.name}</span>
                      {!o.isOpen && (
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 font-bold uppercase">
                          Closed
                        </span>
                      )}
                    </button>
                  ))}
                </div>

                {/* Selected Outlet Editor Card */}
                {outletDraft && (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <div>
                        <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                          Outlet Name
                        </label>
                        <input
                          type="text"
                          value={outletDraft.name || ""}
                          onChange={(e) => setOutletDraft(prev => prev ? ({ ...prev, name: e.target.value }) : null)}
                          className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                        />
                      </div>

                      <div>
                        <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                          Phone Number
                        </label>
                        <input
                          type="text"
                          value={outletDraft.phone || ""}
                          onChange={(e) => setOutletDraft(prev => prev ? ({ ...prev, phone: e.target.value }) : null)}
                          placeholder="+91 98000 00000"
                          className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <div>
                        <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                          Display Hours Text
                        </label>
                        <input
                          type="text"
                          value={outletDraft.hoursDisplay || ""}
                          onChange={(e) => setOutletDraft(prev => prev ? ({ ...prev, hoursDisplay: e.target.value }) : null)}
                          placeholder="e.g. 11:00 AM – 10:30 PM (All Days)"
                          className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                        />
                      </div>

                      <div>
                        <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                          Operational Status
                        </label>
                        <button
                          type="button"
                          onClick={() => setOutletDraft(prev => prev ? ({ ...prev, isOpen: !prev.isOpen }) : null)}
                          className={`w-full px-4 py-3 rounded-xl border text-sm font-bold flex items-center justify-between transition-colors ${
                            outletDraft.isOpen
                              ? "bg-emerald-500/15 border-emerald-500/30 text-emerald-400"
                              : "bg-rose-500/15 border-rose-500/30 text-rose-400"
                          }`}
                        >
                          <span>{outletDraft.isOpen ? "Outlet Open & Serving" : "Outlet Marked as Closed"}</span>
                          <span className="text-xs uppercase underline">Click to Toggle</span>
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Physical Address
                      </label>
                      <input
                        type="text"
                        value={outletDraft.address || ""}
                        onChange={(e) => setOutletDraft(prev => prev ? ({ ...prev, address: e.target.value }) : null)}
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5 flex items-center justify-between">
                        <span>Temporary Closure / Special Notice (Optional)</span>
                        <span className="text-[10px] text-zinc-500 normal-case">
                          Leave blank for normal operations
                        </span>
                      </label>
                      <input
                        type="text"
                        value={outletDraft.temporaryClosureNotice || ""}
                        onChange={(e) => setOutletDraft(prev => prev ? ({ ...prev, temporaryClosureNotice: e.target.value }) : null)}
                        placeholder="e.g. Closed Tuesday for kitchen maintenance"
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-amber-400"
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-5 pt-3 border-t border-zinc-800">
                      <div>
                        <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                          Google Maps URL
                        </label>
                        <input
                          type="text"
                          value={outletDraft.googleMapsUrl || ""}
                          onChange={(e) => setOutletDraft(prev => prev ? ({ ...prev, googleMapsUrl: e.target.value }) : null)}
                          placeholder="https://maps.google.com/..."
                          className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                        />
                      </div>

                      <div>
                        <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                          Swiggy Delivery Link
                        </label>
                        <input
                          type="text"
                          value={outletDraft.swiggyUrl || ""}
                          onChange={(e) => setOutletDraft(prev => prev ? ({ ...prev, swiggyUrl: e.target.value }) : null)}
                          placeholder="https://swiggy.com/..."
                          className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                        />
                      </div>

                      <div>
                        <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                          Zomato Delivery Link
                        </label>
                        <input
                          type="text"
                          value={outletDraft.zomatoUrl || ""}
                          onChange={(e) => setOutletDraft(prev => prev ? ({ ...prev, zomatoUrl: e.target.value }) : null)}
                          placeholder="https://zomato.com/..."
                          className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                        />
                      </div>
                    </div>

                    {/* Bottom Save bar for long scroll */}
                    {isOutletDirty && (
                      <div className="flex items-center justify-between p-4 rounded-2xl bg-zinc-950 border border-amber-500/30">
                        <div className="flex items-center gap-2 text-xs text-amber-300 font-bold">
                          <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                          <span>You have unsaved changes to {outletDraft.name}.</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <button
                            type="button"
                            onClick={handleCancelOutletDraft}
                            disabled={outletSaving}
                            className="px-4 py-2 rounded-xl text-xs font-bold text-zinc-400 hover:text-white"
                          >
                            Discard
                          </button>
                          <button
                            type="button"
                            onClick={handleSaveOutletDraft}
                            disabled={outletSaving}
                            className="px-5 py-2 rounded-xl bg-[#B18B5B] hover:bg-[#c49b67] text-white text-xs font-bold transition-all shadow-md flex items-center gap-2 cursor-pointer"
                          >
                            <Save className="w-3.5 h-3.5" />
                            <span>{outletSaving ? "Saving..." : "Save Changes"}</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 5: CUSTOMER REVIEWS */}
          {activeTab === "reviews" && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-[#141413] border border-zinc-800 rounded-3xl p-6 sm:p-8">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                  <div>
                    <h1 className="text-2xl font-black uppercase tracking-tight text-white">Customer Reviews</h1>
                    <p className="text-xs text-zinc-400 mt-1">
                      Manage verified customer feedback displayed on the homepage testimonials slider.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setEditingReview(null);
                      setReviewAuthor("");
                      setReviewRating(5);
                      setReviewQuote("");
                      setReviewHighlightDish("");
                      setShowAddReviewModal(true);
                    }}
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#B18B5B] hover:bg-[#9a784d] text-white text-xs font-bold transition-all"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add New Review</span>
                  </button>
                </div>

                {/* Filter and Search Bar */}
                <div className="flex flex-col sm:flex-row gap-3 mb-6">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500" />
                    <input
                      type="text"
                      value={reviewSearch}
                      onChange={(e) => setReviewSearch(e.target.value)}
                      placeholder="Search by customer name, quote, or dish..."
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-white text-xs focus:outline-none focus:border-[#B18B5B]"
                    />
                  </div>
                  <select
                    value={reviewBranchFilter}
                    onChange={(e) => setReviewBranchFilter(e.target.value)}
                    className="px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-white text-xs focus:outline-none focus:border-[#B18B5B]"
                  >
                    <option value="all">All Outlets</option>
                    <option value="panchanai">Panchanai</option>
                    <option value="darjeeling">Darjeeling</option>
                    <option value="pradhannagar">Pradhan Nagar</option>
                    <option value="kurseong">Kurseong</option>
                    <option value="shivmandir">Shivmandir</option>
                  </select>
                </div>

                {/* Reviews List */}
                <div className="space-y-3">
                  {filteredReviews.length === 0 ? (
                    <div className="text-center py-12 text-zinc-500 text-xs">No reviews match your filters.</div>
                  ) : (
                    filteredReviews.map((rev) => (
                      <div
                        key={rev.id}
                        className={`p-5 rounded-2xl border transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                          rev.hidden
                            ? "bg-zinc-950/40 border-zinc-800/50 opacity-60"
                            : "bg-zinc-900/60 border-zinc-800/80 hover:border-zinc-700"
                        }`}
                      >
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-1.5">
                            <span className="font-bold text-sm text-white">{rev.author}</span>
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-400 font-mono">
                              {rev.branchName}
                            </span>
                            <div className="flex items-center text-amber-400">
                              {Array.from({ length: rev.rating }).map((_, i) => (
                                <Star key={i} className="w-3 h-3 fill-amber-400" />
                              ))}
                            </div>
                            {rev.hidden && (
                              <span className="text-[9px] px-2 py-0.5 rounded bg-zinc-800 text-zinc-400 font-bold uppercase">
                                Hidden
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-zinc-300 italic mb-2 leading-relaxed">
                            &ldquo;{rev.quote}&rdquo;
                          </p>
                          {rev.highlightDish && (
                            <span className="inline-flex items-center gap-1 text-[10px] text-[#B18B5B] font-bold">
                              <span>Recommended:</span>
                              <span className="text-zinc-300">{rev.highlightDish}</span>
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-2 self-end md:self-center shrink-0">
                          <button
                            type="button"
                            onClick={() => handleToggleReviewVisibility(rev)}
                            className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-bold text-zinc-300 transition-colors"
                          >
                            {rev.hidden ? "Publish" : "Hide"}
                          </button>
                          <button
                            type="button"
                            onClick={() => openEditReviewModal(rev)}
                            className="p-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-colors"
                            aria-label="Edit review"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteReview(rev)}
                            className="p-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition-colors"
                            aria-label="Delete review"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: MEDIA & GALLERY */}
          {activeTab === "gallery" && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-[#141413] border border-zinc-800 rounded-3xl p-6 sm:p-8">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                  <div>
                    <h1 className="text-2xl font-black uppercase tracking-tight text-white">Media &amp; Gallery</h1>
                    <p className="text-xs text-zinc-400 mt-1">
                      Manage visual assets, dishes, and interior photography across the website.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setEditingImage(null);
                      setImageSrc("");
                      setImageTitle("");
                      setImageDescription("");
                      setImageAlt("");
                      setImageFeatured(false);
                      setShowImageModal(true);
                    }}
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#B18B5B] hover:bg-[#9a784d] text-white text-xs font-bold transition-all"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add New Image</span>
                  </button>
                </div>

                {/* Gallery Grid */}
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {(cmsData?.gallery || []).map((img) => (
                    <div
                      key={img.id}
                      className="group relative rounded-2xl overflow-hidden bg-zinc-900 border border-zinc-800 flex flex-col"
                    >
                      <div className="relative aspect-video w-full bg-black overflow-hidden">
                        <Image
                          src={img.src}
                          alt={img.alt || img.title}
                          fill
                          className="object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <span className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-md text-[9px] font-bold text-white uppercase tracking-wider">
                          {img.category}
                        </span>
                      </div>
                      <div className="p-3.5 flex-1 flex flex-col justify-between">
                        <div>
                          <span className="font-bold text-xs text-white block truncate mb-1">{img.title}</span>
                          <span className="text-[10px] text-zinc-400 line-clamp-2">{img.description}</span>
                        </div>
                        <div className="flex items-center justify-between pt-3 mt-3 border-t border-zinc-800/80">
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(img.src);
                              showToast("Image URL copied to clipboard!");
                            }}
                            className="text-[10px] font-bold text-zinc-400 hover:text-white flex items-center gap-1"
                          >
                            <Copy className="w-3 h-3" />
                            <span>Copy URL</span>
                          </button>
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => openEditImageModal(img)}
                              className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white"
                            >
                              <Edit3 className="w-3 h-3" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteImage(img)}
                              className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 7: ABOUT OUR STORY */}
          {activeTab === "about" && contentForm && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-[#141413] border border-zinc-800 rounded-3xl p-6 sm:p-8">
                <div className="flex items-center justify-between gap-4 mb-6">
                  <div>
                    <h1 className="text-2xl font-black uppercase tracking-tight text-white">About Our Story Editor</h1>
                    <p className="text-xs text-zinc-400 mt-1">
                      Edit the narrative, heritage, and values displayed on the public About page (/about).
                    </p>
                  </div>
                  <button
                    onClick={() => openPreview("/about")}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-700 text-xs font-bold text-zinc-300 hover:text-white"
                  >
                    <Eye className="w-3.5 h-3.5 text-[#B18B5B]" />
                    <span>Preview About Page</span>
                  </button>
                </div>

                <form onSubmit={handleSaveContent} className="space-y-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Badge Text
                      </label>
                      <input
                        type="text"
                        value={contentForm.about.badge || ""}
                        onChange={(e) =>
                          setContentForm({
                            ...contentForm,
                            about: { ...contentForm.about, badge: e.target.value },
                          })
                        }
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Section Heading
                      </label>
                      <input
                        type="text"
                        value={contentForm.about.heading || ""}
                        onChange={(e) =>
                          setContentForm({
                            ...contentForm,
                            about: { ...contentForm.about, heading: e.target.value },
                          })
                        }
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                      Subheading
                    </label>
                    <input
                      type="text"
                      value={contentForm.about.subheading || ""}
                      onChange={(e) =>
                        setContentForm({
                          ...contentForm,
                          about: { ...contentForm.about, subheading: e.target.value },
                        })
                      }
                      className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                      Story Paragraph 1
                    </label>
                    <textarea
                      rows={4}
                      value={contentForm.about.paragraph1 || ""}
                      onChange={(e) =>
                        setContentForm({
                          ...contentForm,
                          about: { ...contentForm.about, paragraph1: e.target.value },
                        })
                      }
                      className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B] leading-relaxed"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                      Story Paragraph 2
                    </label>
                    <textarea
                      rows={4}
                      value={contentForm.about.paragraph2 || ""}
                      onChange={(e) =>
                        setContentForm({
                          ...contentForm,
                          about: { ...contentForm.about, paragraph2: e.target.value },
                        })
                      }
                      className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B] leading-relaxed"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                      Founder Quote / Signature Note
                    </label>
                    <input
                      type="text"
                      value={contentForm.about.founderQuote || ""}
                      onChange={(e) =>
                        setContentForm({
                          ...contentForm,
                          about: { ...contentForm.about, founderQuote: e.target.value },
                        })
                      }
                      placeholder="e.g. Crafted with passion, served with pride."
                      className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                    />
                  </div>

                  <div className="pt-4 flex items-center justify-end">
                    <button
                      type="submit"
                      disabled={contentSaving}
                      className="px-6 py-3 rounded-xl bg-[#B18B5B] hover:bg-[#9a784d] text-white font-bold text-xs uppercase tracking-wider transition-all disabled:opacity-50 flex items-center gap-2"
                    >
                      <Save className="w-4 h-4" />
                      <span>{contentSaving ? "Saving..." : "Save About Story"}</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* TAB 8: CUSTOM PAGES BUILDER */}
          {activeTab === "customPages" && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-[#141413] border border-zinc-800 rounded-3xl p-6 sm:p-8">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                  <div>
                    <h1 className="text-2xl font-black uppercase tracking-tight text-white">Custom Pages Builder</h1>
                    <p className="text-xs text-zinc-400 mt-1">
                      Create and publish custom landing pages with custom URLs like /p/your-slug without code.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setEditingPage(null);
                      setPageTitle("");
                      setPageSlug("");
                      setPageSubtitle("");
                      setPageHeroImage("/images/gallery/01-interior-wide.webp");
                      setPageContent("");
                      setPageCtaText("");
                      setPageCtaLink("");
                      setPageIsPublished(true);
                      setShowPageModal(true);
                    }}
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#B18B5B] hover:bg-[#9a784d] text-white text-xs font-bold transition-all"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Create New Page</span>
                  </button>
                </div>

                <div className="space-y-3">
                  {(cmsData?.customPages || []).length === 0 ? (
                    <div className="text-center py-12 text-zinc-500 text-xs">
                      No custom pages created yet. Click &ldquo;Create New Page&rdquo; to add one.
                    </div>
                  ) : (
                    (cmsData?.customPages || []).map((page) => (
                      <div
                        key={page.id}
                        className="p-5 rounded-2xl bg-zinc-900/60 border border-zinc-800/80 hover:border-zinc-700 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
                      >
                        <div>
                          <div className="flex items-center gap-3 mb-1">
                            <span className="font-bold text-sm text-white">{page.title}</span>
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-zinc-800 text-[#B18B5B] font-mono">
                              /p/{page.slug}
                            </span>
                            {!page.isPublished && (
                              <span className="text-[9px] px-2 py-0.5 rounded bg-zinc-800 text-zinc-400 font-bold uppercase">
                                Draft / Unpublished
                              </span>
                            )}
                          </div>
                          <span className="text-xs text-zinc-400 line-clamp-1">{page.subtitle || page.content}</span>
                        </div>

                        <div className="flex items-center gap-2 self-end md:self-center shrink-0">
                          <Link
                            href={`/p/${page.slug}`}
                            target="_blank"
                            className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-bold text-zinc-300 transition-colors flex items-center gap-1"
                          >
                            <span>View</span>
                            <ExternalLink className="w-3 h-3" />
                          </Link>
                          <button
                            type="button"
                            onClick={() => openEditPageModal(page)}
                            className="p-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeletePage(page)}
                            className="p-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 9: CONTACT & SOCIALS */}
          {activeTab === "contact" && contentForm && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-[#141413] border border-zinc-800 rounded-3xl p-6 sm:p-8">
                <div className="flex items-center justify-between gap-4 mb-6">
                  <div>
                    <h1 className="text-2xl font-black uppercase tracking-tight text-white">Contact &amp; Socials</h1>
                    <p className="text-xs text-zinc-400 mt-1">
                      Manage official phone numbers, WhatsApp, email, and social media handles.
                    </p>
                  </div>
                  <button
                    onClick={() => openPreview("/order-online")}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-700 text-xs font-bold text-zinc-300 hover:text-white"
                  >
                    <Eye className="w-3.5 h-3.5 text-[#B18B5B]" />
                    <span>Preview Live</span>
                  </button>
                </div>

                <form onSubmit={handleSaveContent} className="space-y-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Primary Phone Number
                      </label>
                      <input
                        type="text"
                        value={contentForm.contact.primaryPhone || ""}
                        onChange={(e) =>
                          setContentForm({
                            ...contentForm,
                            contact: { ...contentForm.contact, primaryPhone: e.target.value },
                          })
                        }
                        placeholder="+91 98000 00000"
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        WhatsApp Number
                      </label>
                      <input
                        type="text"
                        value={contentForm.contact.whatsapp || ""}
                        onChange={(e) =>
                          setContentForm({
                            ...contentForm,
                            contact: { ...contentForm.contact, whatsapp: e.target.value },
                          })
                        }
                        placeholder="+91 98000 00000"
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Support Email
                      </label>
                      <input
                        type="email"
                        value={contentForm.contact.supportEmail || ""}
                        onChange={(e) =>
                          setContentForm({
                            ...contentForm,
                            contact: { ...contentForm.contact, supportEmail: e.target.value },
                          })
                        }
                        placeholder="hello@burgercartel.in"
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Instagram Profile Link
                      </label>
                      <input
                        type="text"
                        value={contentForm.contact.instagram || ""}
                        onChange={(e) =>
                          setContentForm({
                            ...contentForm,
                            contact: { ...contentForm.contact, instagram: e.target.value },
                          })
                        }
                        placeholder="https://instagram.com/burgercartel.in"
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Facebook Page Link
                      </label>
                      <input
                        type="text"
                        value={contentForm.contact.facebook || ""}
                        onChange={(e) =>
                          setContentForm({
                            ...contentForm,
                            contact: { ...contentForm.contact, facebook: e.target.value },
                          })
                        }
                        placeholder="https://facebook.com/burgercartel.in"
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Headquarters Business Address
                      </label>
                      <input
                        type="text"
                        value={contentForm.contact.businessAddress || ""}
                        onChange={(e) =>
                          setContentForm({
                            ...contentForm,
                            contact: { ...contentForm.contact, businessAddress: e.target.value },
                          })
                        }
                        placeholder="Panchanai, Near Sukna Army Camp, Siliguri, WB 734009"
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>
                  </div>

                  <div className="pt-4 flex items-center justify-end">
                    <button
                      type="submit"
                      disabled={contentSaving}
                      className="px-6 py-3 rounded-xl bg-[#B18B5B] hover:bg-[#9a784d] text-white font-bold text-xs uppercase tracking-wider transition-all disabled:opacity-50 flex items-center gap-2"
                    >
                      <Save className="w-4 h-4" />
                      <span>{contentSaving ? "Saving..." : "Save Contact Info"}</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* TAB 10: NAVIGATION & FOOTER */}
          {activeTab === "navigation" && contentForm && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-[#141413] border border-zinc-800 rounded-3xl p-6 sm:p-8">
                <div className="flex items-center justify-between gap-4 mb-6">
                  <div>
                    <h1 className="text-2xl font-black uppercase tracking-tight text-white">Navigation &amp; Footer</h1>
                    <p className="text-xs text-zinc-400 mt-1">
                      Configure top header links, footer copyright, and brand taglines.
                    </p>
                  </div>
                  <button
                    onClick={() => openPreview("/")}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-700 text-xs font-bold text-zinc-300 hover:text-white"
                  >
                    <Eye className="w-3.5 h-3.5 text-[#B18B5B]" />
                    <span>Preview Site</span>
                  </button>
                </div>

                {/* Navbar Links List */}
                <div className="mb-8">
                  <div className="flex items-center justify-between gap-4 mb-3">
                    <h2 className="text-xs font-bold uppercase tracking-wider text-zinc-400">Top Navigation Links</h2>
                    <button
                      type="button"
                      onClick={handleSaveNavigationOnly}
                      disabled={navSaving}
                      className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#B18B5B] hover:bg-[#977348] text-white text-xs font-bold uppercase tracking-wider transition-all disabled:opacity-50 cursor-pointer shadow-sm"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>{navSaving ? "Saving..." : "Save Navigation Links"}</span>
                    </button>
                  </div>
                  <div className="space-y-2 mb-4">
                    {(contentForm.navigation || []).map((link, idx) => (
                      <div
                        key={link.id}
                        className="p-3.5 rounded-xl bg-zinc-900/80 border border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                      >
                        {editingNavId === link.id ? (
                          <div className="flex-1 flex flex-col sm:flex-row items-center gap-2">
                            <input
                              type="text"
                              value={navEditName}
                              onChange={(e) => setNavEditName(e.target.value)}
                              placeholder="Link Label"
                              className="flex-1 px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-700 text-white text-xs focus:outline-none focus:border-[#B18B5B]"
                            />
                            <input
                              type="text"
                              value={navEditHref}
                              onChange={(e) => setNavEditHref(e.target.value)}
                              placeholder="Link URL"
                              className="flex-1 px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-700 text-white text-xs font-mono focus:outline-none focus:border-[#B18B5B]"
                            />
                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => handleSaveEditNavLink(link.id)}
                                className="p-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 cursor-pointer"
                                title="Apply changes"
                              >
                                <Check className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={handleCancelEditNavLink}
                                className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-400 cursor-pointer"
                                title="Cancel"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        ) : (
                          <>
                            <div className="flex items-center gap-3">
                              <span className="text-xs font-mono text-zinc-500">{idx + 1}.</span>
                              <span className="font-bold text-xs text-white">{link.name}</span>
                              <span className="text-[11px] font-mono text-[#B18B5B]">{link.href}</span>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => handleStartEditNavLink(link)}
                                className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white cursor-pointer"
                                title="Edit link"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDeleteNavLink(link.id)}
                                className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 cursor-pointer"
                                title="Delete link"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </>
                        )}
                      </div>
                    ))}
                  </div>

                  {/* Add Nav Link Row */}
                  <div className="flex flex-col sm:flex-row gap-2">
                    <input
                      type="text"
                      value={newNavLabel}
                      onChange={(e) => setNewNavLabel(e.target.value)}
                      placeholder="Link Label (e.g. Catering)"
                      className="flex-1 px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-white text-xs focus:outline-none focus:border-[#B18B5B]"
                    />
                    <input
                      type="text"
                      value={newNavHref}
                      onChange={(e) => setNewNavHref(e.target.value)}
                      placeholder="Destination URL (e.g. /catering)"
                      className="flex-1 px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-white text-xs focus:outline-none focus:border-[#B18B5B]"
                    />
                    <button
                      type="button"
                      onClick={handleAddNavLink}
                      className="px-4 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold transition-colors"
                    >
                      Add Link
                    </button>
                  </div>
                </div>

                {/* Footer Settings */}
                <form onSubmit={handleSaveContent} className="space-y-5 pt-6 border-t border-zinc-800">
                  <h2 className="text-xs font-bold uppercase tracking-wider text-zinc-400">Footer Content &amp; Tagline</h2>

                  <div>
                    <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                      Footer Tagline
                    </label>
                    <input
                      type="text"
                      value={contentForm.footer.tagline || ""}
                      onChange={(e) =>
                        setContentForm({
                          ...contentForm,
                          footer: { ...contentForm.footer, tagline: e.target.value },
                        })
                      }
                      className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                      Footer Description
                    </label>
                    <textarea
                      rows={2}
                      value={contentForm.footer.description || ""}
                      onChange={(e) =>
                        setContentForm({
                          ...contentForm,
                          footer: { ...contentForm.footer, description: e.target.value },
                        })
                      }
                      className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                      Copyright Notice
                    </label>
                    <input
                      type="text"
                      value={contentForm.footer.copyrightText || ""}
                      onChange={(e) =>
                        setContentForm({
                          ...contentForm,
                          footer: { ...contentForm.footer, copyrightText: e.target.value },
                        })
                      }
                      className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                    />
                  </div>

                  <div className="pt-4 flex items-center justify-end">
                    <button
                      type="submit"
                      disabled={contentSaving}
                      className="px-6 py-3 rounded-xl bg-[#B18B5B] hover:bg-[#9a784d] text-white font-bold text-xs uppercase tracking-wider transition-all disabled:opacity-50 flex items-center gap-2"
                    >
                      <Save className="w-4 h-4" />
                      <span>{contentSaving ? "Saving..." : "Save Navigation & Footer"}</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* TAB 11: ANNOUNCEMENT BANNER */}
          {activeTab === "announcement" && contentForm && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-[#141413] border border-zinc-800 rounded-3xl p-6 sm:p-8">
                <div className="flex items-center justify-between gap-4 mb-6">
                  <div>
                    <h1 className="text-2xl font-black uppercase tracking-tight text-white">Announcement Banner</h1>
                    <p className="text-xs text-zinc-400 mt-1">
                      Display special offers, temporary holiday notices, or new item drops at the very top of every
                      page.
                    </p>
                  </div>
                </div>

                {/* Banner Live Preview Simulation */}
                {contentForm.announcement.enabled && contentForm.announcement.text && (
                  <div className="mb-6 p-4 rounded-2xl bg-zinc-950 border border-zinc-800">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 block mb-2">
                      Live Banner Simulation
                    </span>
                    <div
                      className="py-3 px-4 rounded-xl text-xs font-semibold flex items-center justify-between shadow-sm"
                      style={{
                        backgroundColor: contentForm.announcement.bgColor || "#1F2B20",
                        color: contentForm.announcement.textColor || "#FFFFFF",
                      }}
                    >
                      <div className="flex items-center gap-3">
                        <span>{contentForm.announcement.text}</span>
                        {contentForm.announcement.link && (
                          <span className="underline font-bold text-[11px] uppercase">
                            {contentForm.announcement.buttonText || "Learn More"} &rarr;
                          </span>
                        )}
                      </div>
                      <X className="w-4 h-4 opacity-75" />
                    </div>
                  </div>
                )}

                <form onSubmit={handleSaveAnnouncementOnly} className="space-y-5">
                  <div>
                    <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                      Banner State
                    </label>
                    <button
                      type="button"
                      onClick={() =>
                        setContentForm({
                          ...contentForm,
                          announcement: {
                            ...contentForm.announcement,
                            enabled: !contentForm.announcement.enabled,
                          },
                        })
                      }
                      className={`px-5 py-3 rounded-xl border text-xs font-bold flex items-center gap-2 transition-colors ${
                        contentForm.announcement.enabled
                          ? "bg-emerald-500/15 border-emerald-500/30 text-emerald-400"
                          : "bg-zinc-900 border-zinc-800 text-zinc-400"
                      }`}
                    >
                      <Megaphone className="w-4 h-4" />
                      <span>{contentForm.announcement.enabled ? "Banner is ACTIVE & Visible" : "Banner is DISABLED / Hidden"}</span>
                    </button>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                      Announcement Message
                    </label>
                    <input
                      type="text"
                      value={contentForm.announcement.text || ""}
                      onChange={(e) =>
                        setContentForm({
                          ...contentForm,
                          announcement: { ...contentForm.announcement, text: e.target.value },
                        })
                      }
                      placeholder="e.g. Try our new Roast Pork Sandwich & Wood-Fired Pizzas!"
                      className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Button / Link Text
                      </label>
                      <input
                        type="text"
                        value={contentForm.announcement.buttonText || ""}
                        onChange={(e) =>
                          setContentForm({
                            ...contentForm,
                            announcement: { ...contentForm.announcement, buttonText: e.target.value },
                          })
                        }
                        placeholder="e.g. View Menu"
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Destination Link
                      </label>
                      <input
                        type="text"
                        value={contentForm.announcement.link || ""}
                        onChange={(e) =>
                          setContentForm({
                            ...contentForm,
                            announcement: { ...contentForm.announcement, link: e.target.value },
                          })
                        }
                        placeholder="/menu"
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Background Color
                      </label>
                      <div className="flex items-center gap-3">
                        <input
                          type="color"
                          value={contentForm.announcement.bgColor || "#1F2B20"}
                          onChange={(e) =>
                            setContentForm({
                              ...contentForm,
                              announcement: { ...contentForm.announcement, bgColor: e.target.value },
                            })
                          }
                          className="w-10 h-10 rounded-xl bg-transparent border-0 cursor-pointer"
                        />
                        <input
                          type="text"
                          value={contentForm.announcement.bgColor || "#1F2B20"}
                          onChange={(e) =>
                            setContentForm({
                              ...contentForm,
                              announcement: { ...contentForm.announcement, bgColor: e.target.value },
                            })
                          }
                          className="flex-1 px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-xs font-mono"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Text Color
                      </label>
                      <div className="flex items-center gap-3">
                        <input
                          type="color"
                          value={contentForm.announcement.textColor || "#FFFFFF"}
                          onChange={(e) =>
                            setContentForm({
                              ...contentForm,
                              announcement: { ...contentForm.announcement, textColor: e.target.value },
                            })
                          }
                          className="w-10 h-10 rounded-xl bg-transparent border-0 cursor-pointer"
                        />
                        <input
                          type="text"
                          value={contentForm.announcement.textColor || "#FFFFFF"}
                          onChange={(e) =>
                            setContentForm({
                              ...contentForm,
                              announcement: { ...contentForm.announcement, textColor: e.target.value },
                            })
                          }
                          className="flex-1 px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-xs font-mono"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 flex items-center justify-end">
                    <button
                      type="submit"
                      disabled={contentSaving}
                      className="px-6 py-3 rounded-xl bg-[#B18B5B] hover:bg-[#9a784d] text-white font-bold text-xs uppercase tracking-wider transition-all disabled:opacity-50 flex items-center gap-2"
                    >
                      <Save className="w-4 h-4" />
                      <span>{contentSaving ? "Saving..." : "Save Announcement"}</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* TAB 12: SEO & METADATA */}
          {activeTab === "seo" && contentForm && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-[#141413] border border-zinc-800 rounded-3xl p-6 sm:p-8">
                <div className="flex items-center justify-between gap-4 mb-6">
                  <div>
                    <h1 className="text-2xl font-black uppercase tracking-tight text-white">SEO &amp; Metadata</h1>
                    <p className="text-xs text-zinc-400 mt-1">
                      Customise Google search snippet titles, descriptions, and OpenGraph social preview images.
                    </p>
                  </div>
                </div>

                <form onSubmit={handleSaveContent} className="space-y-5">
                  <div>
                    <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                      Homepage Meta Title
                    </label>
                    <input
                      type="text"
                      value={contentForm.seo?.home?.title || ""}
                      onChange={(e) =>
                        setContentForm({
                          ...contentForm,
                          seo: {
                            ...contentForm.seo,
                            home: {
                              ...contentForm.seo?.home,
                              title: e.target.value,
                              description: contentForm.seo?.home?.description || "",
                            },
                          },
                        })
                      }
                      placeholder="BURGER CARTEL | Cafe & Restaurant — 5 Outlets in Darjeeling, Kurseong & Siliguri"
                      className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                      Homepage Meta Description
                    </label>
                    <textarea
                      rows={3}
                      value={contentForm.seo?.home?.description || ""}
                      onChange={(e) =>
                        setContentForm({
                          ...contentForm,
                          seo: {
                            ...contentForm.seo,
                            home: {
                              ...contentForm.seo?.home,
                              title: contentForm.seo?.home?.title || "",
                              description: e.target.value,
                            },
                          },
                        })
                      }
                      placeholder="Burger Cartel is North Bengal's premier American burger restaurant and specialty cafe..."
                      className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B] leading-relaxed"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                      Menu Page Meta Title
                    </label>
                    <input
                      type="text"
                      value={contentForm.seo?.menu?.title || ""}
                      onChange={(e) =>
                        setContentForm({
                          ...contentForm,
                          seo: {
                            ...contentForm.seo,
                            menu: {
                              ...contentForm.seo?.menu,
                              title: e.target.value,
                              description: contentForm.seo?.menu?.description || "",
                            },
                          },
                        })
                      }
                      placeholder="Complete Menu & Prices | Burger Cartel"
                      className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                      Open Graph Social Share Image URL
                    </label>
                    <input
                      type="text"
                      value={contentForm.seo?.home?.ogImage || ""}
                      onChange={(e) =>
                        setContentForm({
                          ...contentForm,
                          seo: {
                            ...contentForm.seo,
                            home: {
                              ...contentForm.seo?.home,
                              title: contentForm.seo?.home?.title || "",
                              description: contentForm.seo?.home?.description || "",
                              ogImage: e.target.value,
                            },
                          },
                        })
                      }
                      placeholder="/images/gallery/05-double-burger-closeup.webp"
                      className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                    />
                  </div>

                  <div className="pt-4 flex items-center justify-end">
                    <button
                      type="submit"
                      disabled={contentSaving}
                      className="px-6 py-3 rounded-xl bg-[#B18B5B] hover:bg-[#9a784d] text-white font-bold text-xs uppercase tracking-wider transition-all disabled:opacity-50 flex items-center gap-2"
                    >
                      <Save className="w-4 h-4" />
                      <span>{contentSaving ? "Saving..." : "Save SEO Settings"}</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* TAB 13: BACKUP & RESTORE */}
          {activeTab === "backup" && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-[#141413] border border-zinc-800 rounded-3xl p-6 sm:p-8">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                  <div>
                    <h1 className="text-2xl font-black uppercase tracking-tight text-white">Backup &amp; Restore</h1>
                    <p className="text-xs text-zinc-400 mt-1">
                      Create point-in-time snapshots of the CMS database and restore anytime with 1-click.
                    </p>
                  </div>
                </div>

                {/* Create Backup Form */}
                <form
                  onSubmit={handleCreateBackup}
                  className="mb-8 p-5 rounded-2xl bg-zinc-900/60 border border-zinc-800 flex flex-col sm:flex-row gap-3"
                >
                  <input
                    type="text"
                    value={backupLabel}
                    onChange={(e) => setBackupLabel(e.target.value)}
                    placeholder="Snapshot note (e.g. Before Menu Price Updates)"
                    className="flex-1 px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-xs focus:outline-none focus:border-[#B18B5B]"
                  />
                  <button
                    type="submit"
                    disabled={backupCreating}
                    className="px-5 py-2.5 rounded-xl bg-[#B18B5B] hover:bg-[#9a784d] text-white text-xs font-bold transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    <Archive className="w-4 h-4" />
                    <span>{backupCreating ? "Creating..." : "Create Snapshot"}</span>
                  </button>
                </form>

                {/* Snapshots List */}
                <h2 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-3">Historical Snapshots</h2>
                <div className="space-y-3">
                  {(cmsData?.backups || []).length === 0 ? (
                    <div className="text-center py-12 text-zinc-500 text-xs">
                      No backups saved yet. Create a snapshot above to safeguard website content.
                    </div>
                  ) : (
                    (cmsData?.backups || []).map((b) => (
                      <div
                        key={b.id}
                        className="p-5 rounded-2xl bg-zinc-900/40 border border-zinc-800 flex flex-col md:flex-row md:items-center justify-between gap-4"
                      >
                        <div>
                          <div className="flex items-center gap-3 mb-1">
                            <span className="font-bold text-sm text-white">{b.label}</span>
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-400 font-mono">
                              {new Date(b.timestamp).toLocaleString()}
                            </span>
                          </div>
                          <span className="text-xs text-zinc-400 font-mono">{b.dataSnippet}</span>
                        </div>

                        <div className="flex items-center gap-2 self-end md:self-center shrink-0">
                          <button
                            type="button"
                            onClick={() => handleDownloadBackup(b)}
                            className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-bold text-zinc-300 transition-colors flex items-center gap-1.5"
                          >
                            <Download className="w-3.5 h-3.5" />
                            <span>Export JSON</span>
                          </button>
                          <button
                            type="button"
                            disabled={restoringId === b.id}
                            onClick={() => handleRestoreBackup(b)}
                            className="px-4 py-1.5 rounded-xl bg-[#B18B5B] hover:bg-[#9a784d] text-white text-xs font-bold transition-colors disabled:opacity-50 flex items-center gap-1.5"
                          >
                            <RefreshCw className={`w-3.5 h-3.5 ${restoringId === b.id ? "animate-spin" : ""}`} />
                            <span>{restoringId === b.id ? "Restoring..." : "Restore"}</span>
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 14: SECURITY & PASSWORDS */}
          {activeTab === "security" && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-[#141413] border border-zinc-800 rounded-3xl p-6 sm:p-8">
                <div className="mb-6">
                  <h1 className="text-2xl font-black uppercase tracking-tight text-white">Security &amp; Credentials</h1>
                  <p className="text-xs text-zinc-400 mt-1">
                    Manage master administrator ID, change password, and inspect security defense layers.
                  </p>
                </div>

                {credMessage && (
                  <div
                    className={`p-3.5 rounded-xl text-xs flex items-center gap-2 mb-6 ${
                      credMessage.type === "success"
                        ? "bg-emerald-500/10 border border-emerald-500/30 text-emerald-300"
                        : "bg-rose-500/10 border border-rose-500/30 text-rose-300"
                    }`}
                  >
                    {credMessage.type === "success" ? <Check className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                    <span>{credMessage.text}</span>
                  </div>
                )}

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Change Credentials Form */}
                  <form onSubmit={handleChangeCredentials} className="space-y-4">
                    <h2 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-2">Change Credentials</h2>

                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Current Master Password
                      </label>
                      <input
                        type="password"
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                        required
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        New Admin ID (Optional)
                      </label>
                      <input
                        type="text"
                        value={newAdminId}
                        onChange={(e) => setNewAdminId(e.target.value)}
                        placeholder={`Keep current (${currentAdminId})`}
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        New Password (Min 8 chars)
                      </label>
                      <input
                        type="password"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="Leave blank to keep unchanged"
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1.5">
                        Confirm New Password
                      </label>
                      <input
                        type="password"
                        value={confirmNewPassword}
                        onChange={(e) => setConfirmNewPassword(e.target.value)}
                        className="w-full px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#B18B5B]"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={credLoading}
                      className="w-full py-3.5 rounded-xl bg-[#B18B5B] hover:bg-[#9a784d] text-white font-bold text-xs uppercase tracking-wider transition-all disabled:opacity-50"
                    >
                      {credLoading ? "Updating..." : "Update Master Credentials"}
                    </button>
                  </form>

                  {/* Security Posture Status */}
                  <div className="space-y-4">
                    <h2 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-2">Active Security Defenses</h2>
                    <div className="p-5 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-3">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-zinc-400">Database Vault:</span>
                        <span className="font-mono text-emerald-400 font-bold">AES-256-GCM Encrypted</span>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-zinc-400">CSRF &amp; Origin Protection:</span>
                        <span className="font-mono text-emerald-400 font-bold">Same-Origin Strict</span>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-zinc-400">Rate Limiting:</span>
                        <span className="font-mono text-emerald-400 font-bold">Token Bucket Active</span>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-zinc-400">Active Admin Sessions:</span>
                        <span className="font-mono text-white font-bold">
                          {dashboardData?.system.activeSessionsCount || 1}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-zinc-400">Public Access Route:</span>
                        <span className="font-mono text-rose-400 font-bold">Blocked (Noindex / Robots Disallowed)</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 15: AUDIT & EVENT LOGS */}
          {activeTab === "logs" && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-[#141413] border border-zinc-800 rounded-3xl p-6 sm:p-8">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                  <div>
                    <h1 className="text-2xl font-black uppercase tracking-tight text-white">Security &amp; Audit Logs</h1>
                    <p className="text-xs text-zinc-400 mt-1">
                      Real-time chronological record of administrative logins, content changes, and security events.
                    </p>
                  </div>
                  <button
                    onClick={fetchDashboardData}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-700 text-xs font-bold text-zinc-300 hover:text-white"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Refresh Logs</span>
                  </button>
                </div>

                <div className="relative mb-6">
                  <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500" />
                  <input
                    type="text"
                    value={logSearch}
                    onChange={(e) => setLogSearch(e.target.value)}
                    placeholder="Search logs by event, admin, or details..."
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-white text-xs focus:outline-none focus:border-[#B18B5B]"
                  />
                </div>

                <div className="space-y-2">
                  {filteredLogs.length === 0 ? (
                    <div className="text-center py-12 text-zinc-500 text-xs">No audit logs found.</div>
                  ) : (
                    filteredLogs.map((log) => (
                      <div
                        key={log.id}
                        className="p-3.5 rounded-xl bg-zinc-900/40 border border-zinc-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                      >
                        <div className="flex items-center gap-3">
                          <History className="w-4 h-4 text-[#B18B5B] shrink-0" />
                          <span className="font-bold text-white">{log.event}</span>
                          {log.details && <span className="text-zinc-400 text-[11px]">— {log.details}</span>}
                        </div>
                        <div className="flex items-center gap-3 text-[11px] text-zinc-500 font-mono shrink-0">
                          {log.adminId && <span className="text-zinc-400">by {log.adminId}</span>}
                          <span>{new Date(log.timestamp).toLocaleString()}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Review Modal (Create / Edit) */}
      {showAddReviewModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#141413] border border-zinc-800 rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative">
            <button
              onClick={() => setShowAddReviewModal(false)}
              className="absolute right-6 top-6 p-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
            <h2 className="text-xl font-black uppercase text-white mb-4">
              {editingReview ? "Edit Review" : "Add New Customer Review"}
            </h2>
            <form onSubmit={handleSaveReviewModal} className="space-y-4">
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1">
                  Customer Name
                </label>
                <input
                  type="text"
                  value={reviewAuthor}
                  onChange={(e) => setReviewAuthor(e.target.value)}
                  required
                  placeholder="e.g. Priya Sharma"
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-xs"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1">
                    Rating (1-5)
                  </label>
                  <select
                    value={reviewRating}
                    onChange={(e) => setReviewRating(Number(e.target.value))}
                    className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-xs"
                  >
                    {[5, 4, 3, 2, 1].map((r) => (
                      <option key={r} value={r}>
                        {r} Stars
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1">
                    Branch Visited
                  </label>
                  <select
                    value={reviewBranchId}
                    onChange={(e) => {
                      setReviewBranchId(e.target.value);
                      const opt = e.target.options[e.target.selectedIndex];
                      setReviewBranchName(opt.text);
                    }}
                    className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-xs"
                  >
                    <option value="all">All Locations</option>
                    <option value="panchanai">Panchanai, Siliguri</option>
                    <option value="darjeeling">Darjeeling</option>
                    <option value="pradhannagar">Pradhan Nagar</option>
                    <option value="kurseong">Kurseong</option>
                    <option value="shivmandir">Shivmandir</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1">
                  Testimonial Quote
                </label>
                <textarea
                  rows={3}
                  value={reviewQuote}
                  onChange={(e) => setReviewQuote(e.target.value)}
                  required
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-xs"
                />
              </div>
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1">
                  Highlight Dish (Optional)
                </label>
                <input
                  type="text"
                  value={reviewHighlightDish}
                  onChange={(e) => setReviewHighlightDish(e.target.value)}
                  placeholder="e.g. Classic Smashed Burger"
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-xs"
                />
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddReviewModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-zinc-800 text-xs font-bold text-zinc-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={reviewSaving}
                  className="px-5 py-2.5 rounded-xl bg-[#B18B5B] text-xs font-bold text-white disabled:opacity-50"
                >
                  {reviewSaving ? "Saving..." : "Save Review"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Custom Page Modal */}
      {showPageModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#141413] border border-zinc-800 rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setShowPageModal(false)}
              className="absolute right-6 top-6 p-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
            <h2 className="text-xl font-black uppercase text-white mb-4">
              {editingPage ? "Edit Custom Page" : "Create New Custom Page"}
            </h2>
            <form onSubmit={handleSavePageModal} className="space-y-4">
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1">
                  Page Title
                </label>
                <input
                  type="text"
                  value={pageTitle}
                  onChange={(e) => handlePageTitleChange(e.target.value)}
                  required
                  placeholder="e.g. Private Catering & Events"
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-xs"
                />
              </div>
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1">
                  URL Slug (/p/...)
                </label>
                <input
                  type="text"
                  value={pageSlug}
                  onChange={(e) => setPageSlug(e.target.value)}
                  required
                  placeholder="e.g. private-catering"
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-xs font-mono"
                />
              </div>
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1">
                  Page Subtitle
                </label>
                <input
                  type="text"
                  value={pageSubtitle}
                  onChange={(e) => setPageSubtitle(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-xs"
                />
              </div>
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1">
                  Hero Image
                </label>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    value={pageHeroImage}
                    onChange={(e) => setPageHeroImage(e.target.value)}
                    placeholder="/images/gallery/01-interior-wide.webp"
                    className="flex-1 px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-xs"
                  />
                  <input
                    type="file"
                    ref={pageFileInputRef}
                    accept="image/png,image/jpeg,image/webp,image/gif"
                    className="hidden"
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (!file) return;
                      setPageUploading(true);
                      const url = await uploadDeviceImage(file);
                      if (url) setPageHeroImage(url);
                      setPageUploading(false);
                      if (pageFileInputRef.current) pageFileInputRef.current.value = "";
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => pageFileInputRef.current?.click()}
                    disabled={pageUploading}
                    className="px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold transition-all border border-zinc-700 flex items-center justify-center gap-1.5 shrink-0 cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5 text-[#B18B5B]" />
                    <span>{pageUploading ? "Uploading..." : "Select from device"}</span>
                  </button>
                </div>
              </div>
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1">
                  Body Content
                </label>
                <textarea
                  rows={6}
                  value={pageContent}
                  onChange={(e) => setPageContent(e.target.value)}
                  required
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-xs leading-relaxed"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1">
                    CTA Button Text
                  </label>
                  <input
                    type="text"
                    value={pageCtaText}
                    onChange={(e) => setPageCtaText(e.target.value)}
                    placeholder="e.g. Contact Us"
                    className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1">
                    CTA Button Link
                  </label>
                  <input
                    type="text"
                    value={pageCtaLink}
                    onChange={(e) => setPageCtaLink(e.target.value)}
                    placeholder="/order-online"
                    className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-xs"
                  />
                </div>
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowPageModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-zinc-800 text-xs font-bold text-zinc-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={pageSaving}
                  className="px-5 py-2.5 rounded-xl bg-[#B18B5B] text-xs font-bold text-white disabled:opacity-50"
                >
                  {pageSaving ? "Saving..." : "Save Page"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Gallery Image Modal */}
      {showImageModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#141413] border border-zinc-800 rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative">
            <button
              onClick={() => setShowImageModal(false)}
              className="absolute right-6 top-6 p-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
            <h2 className="text-xl font-black uppercase text-white mb-4">
              {editingImage ? "Edit Media Asset" : "Add Image Asset"}
            </h2>
            <form onSubmit={handleSaveImageModal} className="space-y-4">
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1">
                  Image Path / URL
                </label>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    value={imageSrc}
                    onChange={(e) => setImageSrc(e.target.value)}
                    required
                    placeholder="/images/gallery/filename.webp"
                    className="flex-1 px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-xs"
                  />
                  <input
                    type="file"
                    ref={galleryFileInputRef}
                    accept="image/png,image/jpeg,image/webp,image/gif"
                    className="hidden"
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (!file) return;
                      setGalleryUploading(true);
                      const url = await uploadDeviceImage(file);
                      if (url) setImageSrc(url);
                      setGalleryUploading(false);
                      if (galleryFileInputRef.current) galleryFileInputRef.current.value = "";
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => galleryFileInputRef.current?.click()}
                    disabled={galleryUploading}
                    className="px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold transition-all border border-zinc-700 flex items-center justify-center gap-1.5 shrink-0 cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5 text-[#B18B5B]" />
                    <span>{galleryUploading ? "Uploading..." : "Select from device"}</span>
                  </button>
                </div>
              </div>
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1">
                  Title
                </label>
                <input
                  type="text"
                  value={imageTitle}
                  onChange={(e) => setImageTitle(e.target.value)}
                  required
                  placeholder="e.g. Smashed Double Patty Burger"
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-xs"
                />
              </div>
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1">
                  Category
                </label>
                <select
                  value={imageCategory}
                  onChange={(e) => setImageCategory(e.target.value as "burgers" | "food" | "interiors" | "outlets")}
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-xs"
                >
                  <option value="burgers">Burgers</option>
                  <option value="food">Food &amp; Drinks</option>
                  <option value="interiors">Cafe Interiors</option>
                  <option value="outlets">Outlets</option>
                </select>
              </div>
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-300 block mb-1">
                  Description
                </label>
                <input
                  type="text"
                  value={imageDescription}
                  onChange={(e) => setImageDescription(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-white text-xs"
                />
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowImageModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-zinc-800 text-xs font-bold text-zinc-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={imageSaving}
                  className="px-5 py-2.5 rounded-xl bg-[#B18B5B] text-xs font-bold text-white disabled:opacity-50"
                >
                  {imageSaving ? "Saving..." : "Save Image"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Live Preview Modal */}
      <LivePreviewModal
        isOpen={isPreviewOpen}
        onClose={() => setIsPreviewOpen(false)}
        initialPath={previewPath}
      />
    </div>
  );
}
