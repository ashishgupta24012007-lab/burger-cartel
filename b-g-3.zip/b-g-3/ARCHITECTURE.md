# Burger Cartel — Technical Architecture & Developer Guide

## 1. System Overview

**Burger Cartel** is a modern, high-performance web platform and Content Management System (CMS) designed for a 5-branch artisan restaurant brand based in North Bengal (Darjeeling, Kurseong, Siliguri). 

The platform is architected with modern full-stack web standards:
- **Framework:** Next.js 16 (App Router, Turbopack, Partial Prerendering & Cache Components)
- **Frontend:** React 19, TypeScript, Tailwind CSS v4, Lucide Icons, GSAP & Lenis smooth scroll
- **Database & Persistence:** Neon PostgreSQL Serverless (`@neondatabase/serverless`)
- **Authentication & Security:** Custom session management using Node.js crypto (`scrypt`, timing-safe comparison, HMAC-SHA256 tokens, HTTP-only SameSite cookies, atomic rate limiting)
- **Asset Optimization:** WebP image format, responsive image sizing, immutable static caching

---

## 2. Directory Structure

The repository is structured logically to separate presentation, business logic, persistence, and static assets:

```text
b-g-3/
├── src/
│   ├── app/                      # Next.js App Router (Pages, Layouts, API Routes)
│   │   ├── (public)/             # Customer-facing routes
│   │   │   ├── page.tsx          # Homepage with CenteredHero, EditorialBar, Reviews, Gallery
│   │   │   ├── about/            # Story, Philosophy, Founder quote
│   │   │   ├── menu/             # Digital interactive menu with category filter & price switch
│   │   │   ├── locations/        # Branch index & individual outlet detail pages (/locations/[slug])
│   │   │   ├── order-online/     # Online ordering partner hubs (Swiggy / Zomato links)
│   │   │   ├── privacy-policy/   # Privacy policy and local storage disclosure
│   │   │   ├── terms/            # Terms of service
│   │   │   └── p/[slug]/         # Dynamic custom marketing & catering pages
│   │   ├── admin-panel/          # Authenticated restaurant back-office portal
│   │   │   └── page.tsx          # Tabbed CMS manager (Hero, Menu, Outlets, Reviews, Pages, SEO)
│   │   ├── api/                  # Server-side REST & Admin APIs
│   │   │   ├── admin/
│   │   │   │   ├── auth/         # Login, logout, status, credential management
│   │   │   │   ├── cms/          # Central CMS action dispatcher (POST /api/admin/cms)
│   │   │   │   ├── dashboard/    # Operational analytics & health check
│   │   │   │   └── media/upload/ # Multi-part device image uploader
│   │   │   ├── cms/content/      # Public cached read API (GET /api/cms/content)
│   │   │   └── media/[filename]/ # Public image serving route
│   │   ├── globals.css           # Tailwind v4 theme, fonts, animation keyframes
│   │   ├── layout.tsx            # Root layout, meta tags, Navbar, Footer, AnnouncementBanner
│   │   ├── icon.png              # Brand favicon (128x128 PNG)
│   │   ├── robots.ts             # SEO robots rules (disallows /admin-panel and /api/)
│   │   └── sitemap.ts            # Dynamic XML sitemap generator
│   │
│   ├── components/               # Modular UI components
│   │   ├── Navbar.tsx            # Sticky header with branch status & mobile navigation
│   │   ├── Footer.tsx            # Brand footer, operational branches, socials, legal links
│   │   ├── CenteredHero.tsx      # Homepage hero section with headline 1 & 2 resolution
│   │   ├── HeroRevealBackground.tsx # High-resolution hero imagery background
│   │   ├── AnnouncementBanner.tsx# Global top alert banner
│   │   ├── LocationModal.tsx     # Branch selector & outlet details modal
│   │   ├── EditorialBar.tsx      # Ticker bar displaying core brand differentiators
│   │   └── admin/
│   │       └── MenuManagerTab.tsx# Menu manager, price display toggle, dish modal, device upload
│   │
│   ├── lib/                      # Core business logic, persistence, and security
│   │   ├── auth/
│   │   │   ├── security.ts       # Cryptographic hashing, token signing, session lifecycle
│   │   │   ├── session.ts        # HTTP cookie extraction, IP and User-Agent verification
│   │   │   ├── rateLimit.ts      # Atomic database rate limiting bucket
│   │   │   └── store.ts          # Admin credential store interface
│   │   ├── client/
│   │   │   └── cmsClient.ts      # Client-side data fetcher with 15s TTL & reactive event bus
│   │   ├── cms/
│   │   │   └── store.ts          # TypeScript schema definitions for site content
│   │   ├── db/
│   │   │   ├── connection.ts     # PostgreSQL connection pool with SSL
│   │   │   └── cmsRepository.ts  # Authoritative database queries for content, menu, outlets
│   │   └── utils/
│   │       └── urlSanitizer.ts   # Safe URL validator preventing XSS / javascript: schemes
│   │
│   ├── data/                     # Clean baseline datasets (used for seed & emergency fallback)
│   │   ├── menuData.ts
│   │   ├── outletsData.ts
│   │   ├── reviewsData.ts
│   │   ├── galleryData.ts
│   │   └── aboutData.ts
│   │
│   └── types/                    # Shared TypeScript interfaces
│       └── index.ts
│
├── public/                       # Static public assets
│   ├── images/                   # Optimized WebP dish photography, logos, hero backgrounds
│   │   ├── menu/                 # Burgers, pizzas, pasta, breakfast, beverages, sides
│   │   ├── gallery/              # High-resolution branch interiors & culinary shots
│   │   ├── logo.png              # Primary brand insignia
│   │   └── burger-sketch-transparent.png
│   └── uploads/                  # Device uploads destination directory (.gitkeep)
│
├── ARCHITECTURE.md               # System architectural documentation (this file)
├── README.md                     # Quickstart, setup, and deployment instructions
├── next.config.ts                # Next.js configuration (CSP, security headers, image optimization)
├── tsconfig.json                 # TypeScript strict compiler configuration
├── package.json                  # Dependencies & npm scripts
└── .env.example                  # Environment variables template
```

---

## 3. Database Architecture (PostgreSQL)

Neon PostgreSQL serves as the **sole authoritative source of truth**. All content edited in the admin panel is saved directly into PostgreSQL tables with version tracking and cryptographic audit logging.

### Key Relational Tables:
1. `site_content`
   - Key-value JSONB store for singleton website sections: `hero`, `about`, `contact`, `navigation`, `footer`, `announcement`, `seo`, and `menuSettings`.
   - Columns: `key` (VARCHAR PK), `value` (JSONB), `version` (INT), `updated_at` (TIMESTAMPTZ).
2. `menu_items`
   - Relational catalog of all dishes across all branches.
   - Columns: `id` (PK), `category_id`, `name`, `description`, `price`, `sale_price`, `is_vegetarian`, `is_spicy`, `is_signature`, `contains_pork`, `is_available`, `is_visible`, `image_url`, `sort_order`, `version`.
3. `menu_categories`
   - Categories grouping dishes (Burgers, Pizzas, Croissants, Pasta, Sides, Beverages, etc.).
   - Columns: `id` (PK), `name`, `slug`, `display_order`, `is_active`.
4. `outlets`
   - Physical branch definitions (Darjeeling, Kurseong, Siliguri Panchanai, Siliguri Pradhan Nagar, etc.).
   - Columns: `id`, `slug` (UNIQUE), `name`, `address`, `phone`, `hours_display`, `daily_hours` (JSONB), `is_open`, `temporary_closure_notice`, `google_maps_url`.
5. `outlet_menu_availability` & `outlet_menu_overrides`
   - Per-branch inventory control allowing individual branches to mark a dish out-of-stock or override price without affecting other branches.
6. `customer_reviews`
   - Testimonials displayed on the homepage with branch association, rating, author, and visibility toggle.
7. `gallery_items`
   - Photo showcase items with high-resolution image URLs, categories (Interior, Food, Vibe), and sort orders.
8. `custom_pages`
   - Dynamic marketing, catering, and event pages created by staff (served at `/p/[slug]`).
9. `admin_users` & `admin_roles`
   - Administrative credentials with scrypt hash + salt, active status, and role-based permissions.
10. `audit_logs`
    - Tamper-evident, cryptographically chained audit log (`entry_hash = HMAC(prev_hash, event, admin, timestamp)`).

---

## 4. CMS Data Flow & Real-Time Synchronisation

```mermaid
flowchart TD
    AdminUser["Restaurant Admin (Browser)"] -->|POST /api/admin/cms| AdminAPI["Next.js CMS API Route"]
    AdminAPI -->|1. Validate Session & Data| Security["Security & Auth Guard"]
    Security -->|2. Atomic SQL Transaction| Postgres[("Neon PostgreSQL")]
    AdminAPI -->|3. On-Demand Revalidation| Cache["Next.js revalidatePath()"]
    AdminAPI -->|4. Broadcast Update| EventBus["cmsClient Event Bus (cms:updated)"]
    
    PublicVisitor["Customer Browser"] -->|GET /api/cms/content| ContentAPI["Public Content API"]
    ContentAPI -->|Fetch Authoritative State| Postgres
    EventBus -->|Live State Sync| ReactComponents["Active React Components"]
```

### Key Principles:
1. **Authoritative Truth:** When an admin clicks "Save", the API persists changes to Neon PostgreSQL immediately.
2. **Anti-Staleness Client Cache:** [cmsClient.ts](file:///Users/hrishitagupta/Desktop/b-g-3/src/lib/client/cmsClient.ts) maintains a short 15-second TTL in-memory cache with automatic re-validation when the user focuses the browser tab (`visibilitychange` listener).
3. **Reactive Broadcast Bus:** Once a save action completes, `broadcastCmsUpdate()` triggers a `cms:updated` CustomEvent. Open tabs and child components update instantaneously without a full page reload.
4. **On-Demand Path Revalidation:** Next.js `revalidatePath()` is invoked for relevant routes (`/`, `/menu`, `/locations`, `/p/[slug]`) during admin saves.

---

## 5. Dynamic Custom Pages (`/p/[slug]`)

Custom pages allow administrators to launch seasonal menus, event notices, or catering promos:
- **Route:** `src/app/p/[slug]/page.tsx`
- **Dynamic Configuration:**
  ```typescript
  export const instant = false;
  import { connection } from "next/server";
  
  export default async function CustomPage({ params }: { params: Promise<{ slug: string }> }) {
    await connection(); // Opts into on-demand server rendering
    const { slug } = await params;
    const pageData = await getCustomPageBySlug(slug);
    if (!pageData) notFound();
    // Render hero, subtitle, rich HTML body, and CTA
  }
  ```
- **Error Handling:** Non-existent or unpublished slugs cleanly render Next.js 404 pages.

---

## 6. Security & Authentication Architecture

1. **Password Hashing:**
   - Employs Node.js standard `crypto.scrypt` with a 32-byte cryptographically secure random salt and memory cost parameters ($N=16384, r=8, p=1$).
   - Verification uses `crypto.timingSafeEqual` to eliminate timing attack vulnerabilities.
2. **Session Cookies:**
   - Cryptographically signed HMAC-SHA256 session token containing the Admin ID, issuance timestamp, and client fingerprint.
   - Stored in an `HTTP-only`, `SameSite=Strict`, `Secure` (in production) cookie named `burger_cartel_admin_session`.
   - Fingerprint binds the session to the client IP and browser User-Agent to prevent session hijacking.
3. **Atomic Rate Limiting:**
   - Protects administrative endpoints (`/api/admin/auth/*`) from brute-force password guessing.
   - Failed attempts consume bucket tokens atomically in PostgreSQL with a temporary lockout after 5 consecutive failures.
4. **XSS & Injection Protection:**
   - All URLs configured in the CMS (links, buttons, social icons) pass through [urlSanitizer.ts](file:///Users/hrishitagupta/Desktop/b-g-3/src/lib/utils/urlSanitizer.ts) which rejects `javascript:`, `data:`, and malformed protocols.
   - Next.js automatically escapes React JSX outputs.
5. **Content Security Policy (CSP):**
   - Configured in [next.config.ts](file:///Users/hrishitagupta/Desktop/b-g-3/next.config.ts) with strict `default-src 'self'`, `frame-ancestors 'none'`, and `object-src 'none'`.

---

## 7. Developer Onboarding & Extension Guide

### Adding a New Dish
1. Log into `/admin-panel` and navigate to **Menu Management**.
2. Click **Add Menu Item**.
3. Fill in Dish Name, Category, Price, and Description.
4. Click **Select from device** to upload a photo directly, or choose a pre-existing asset.
5. Click **Create Dish**. The dish is instantly live across the public menu.

### Adding a New Outlet
1. In `/admin-panel`, navigate to **Branch Outlets**.
2. Choose **Add Outlet**. Enter the town name, physical street address, phone number, operating hours, and Google Maps embed/place link.
3. Save the outlet. Next.js creates the dynamic route `/locations/[slug]` automatically.

### Toggling Menu Prices
1. In `/admin-panel` under **Menu Management**, toggle the **Prices: [ON / OFF]** switch.
2. When toggled OFF, prices are hidden on the public menu while preserving dish cards and typography.

---

## 8. Deployment Recommendations

### Recommended Hosts:
1. **Vercel:**
   - Zero-config deployment with native App Router and Turbopack support.
   - Simply connect the Git repository and configure environment variables (`DATABASE_URL`, `SESSION_SECRET`).
2. **Railway / Render:**
   - Run standard Node.js server using `npm run build && npm run start`.
3. **Self-Hosted VPS (Ubuntu / Docker):**
   - Build using Docker or standard `next start -p 3000` behind Nginx reverse proxy with SSL enabled (Let's Encrypt).
