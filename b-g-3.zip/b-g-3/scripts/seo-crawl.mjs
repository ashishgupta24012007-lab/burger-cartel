import fs from "node:fs";
import path from "node:path";

const BASE_LOCAL = "http://localhost:3001";
const PUBLIC_DOMAIN = "https://burgercartel.in";

const SEED_PATHS = [
  "/",
  "/menu",
  "/locations",
  "/locations/panchanai",
  "/locations/pradhan-nagar",
  "/locations/darjeeling",
  "/locations/kurseong",
  "/locations/shivmandir",
  "/about",
  "/order-online",
  "/p/franchise",
  "/terms",
  "/privacy-policy",
  "/admin-panel",
  "/robots.txt",
  "/sitemap.xml",
  "/this-page-does-not-exist-test-404"
];

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function cleanText(str) {
  if (!str) return "";
  return str.replace(/\s+/g, " ").trim();
}

function escapeCsv(val) {
  if (val === null || val === undefined) return '""';
  const str = String(val).replace(/"/g, '""');
  return `"${str}"`;
}

async function fetchPage(urlPath) {
  const url = `${BASE_LOCAL}${urlPath}`;
  try {
    const res = await fetch(url, {
      redirect: "manual",
      headers: {
        "User-Agent": "BurgerCartelSeoAuditor/2.0 (+https://burgercartel.in)",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
      }
    });

    const statusCode = res.status;
    const location = res.headers.get("location") || "";
    let finalUrl = urlPath;
    if (statusCode >= 300 && statusCode < 400 && location) {
      finalUrl = location;
    }

    const contentType = res.headers.get("content-type") || "";
    const isHtml = contentType.includes("text/html");
    const isTextOrXml = contentType.includes("text/") || contentType.includes("xml");

    let body = "";
    if (isHtml || isTextOrXml) {
      body = await res.text();
    }

    return {
      path: urlPath,
      statusCode,
      finalUrl,
      contentType,
      body,
      isHtml
    };
  } catch (err) {
    return {
      path: urlPath,
      statusCode: 0,
      finalUrl: urlPath,
      contentType: "",
      body: "",
      isHtml: false,
      error: err.message
    };
  }
}

function parseHtmlMetadata(html, urlPath) {
  // Title
  const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const title = titleMatch ? cleanText(titleMatch[1]) : "";

  // Meta description
  let metaDescription = "";
  const descMatch1 = html.match(/<meta[^>]*name=["']description["'][^>]*content=["']([^"']*)["']/i);
  const descMatch2 = html.match(/<meta[^>]*content=["']([^"']*)["'][^>]*name=["']description["']/i);
  if (descMatch1) metaDescription = cleanText(descMatch1[1]);
  else if (descMatch2) metaDescription = cleanText(descMatch2[1]);

  // H1
  const h1Matches = [...html.matchAll(/<h1[^>]*>([\s\S]*?)<\/h1>/gi)];
  const h1List = h1Matches.map(m => cleanText(m[1].replace(/<[^>]+>/g, "")));
  const h1 = h1List.length > 0 ? h1List.join(" | ") : "NONE";

  // Canonical
  let canonical = "";
  const canonMatch = html.match(/<link[^>]*rel=["']canonical["'][^>]*href=["']([^"']*)["']/i);
  if (canonMatch) canonical = canonMatch[1];

  // Robots meta
  let robotsMeta = "";
  const robotsMatch1 = html.match(/<meta[^>]*name=["']robots["'][^>]*content=["']([^"']*)["']/i);
  const robotsMatch2 = html.match(/<meta[^>]*content=["']([^"']*)["'][^>]*name=["']robots["']/i);
  if (robotsMatch1) robotsMeta = cleanText(robotsMatch1[1]);
  else if (robotsMatch2) robotsMeta = cleanText(robotsMatch2[1]);

  // Indexability
  let indexability = "INDEXABLE";
  if (robotsMeta.toLowerCase().includes("noindex")) {
    indexability = "NOINDEX";
  } else if (urlPath.startsWith("/admin") || urlPath.startsWith("/api")) {
    indexability = "DISALLOWED_ADMIN";
  }

  // Internal Links
  const linkMatches = [...html.matchAll(/<a[^>]*href=["']([^"']*)["']/gi)];
  const internalLinks = [];
  for (const m of linkMatches) {
    const rawHref = m[1].trim();
    if (!rawHref || rawHref.startsWith("#") || rawHref.startsWith("javascript:") || rawHref.startsWith("mailto:") || rawHref.startsWith("tel:")) {
      continue;
    }
    if (rawHref.startsWith("/")) {
      internalLinks.push(rawHref.split("#")[0].split("?")[0] || "/");
    } else if (rawHref.startsWith(PUBLIC_DOMAIN)) {
      const p = rawHref.replace(PUBLIC_DOMAIN, "").split("#")[0].split("?")[0] || "/";
      internalLinks.push(p);
    }
  }

  // Images without alt
  const imgMatches = [...html.matchAll(/<img([^>]*)>/gi)];
  let imagesMissingAlt = 0;
  const missingAltSources = [];
  for (const m of imgMatches) {
    const attrs = m[1];
    const altMatch = attrs.match(/alt=["']([^"']*)["']/i);
    const srcMatch = attrs.match(/src=["']([^"']*)["']/i);
    const src = srcMatch ? srcMatch[1] : "unknown";
    if (!altMatch || !altMatch[1].trim()) {
      imagesMissingAlt++;
      missingAltSources.push(src);
    }
  }

  // Structured Data (JSON-LD)
  const jsonLdMatches = [...html.matchAll(/<script[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)];
  const structuredDataTypes = [];
  for (const m of jsonLdMatches) {
    try {
      const parsed = JSON.parse(m[1]);
      function extractTypes(obj) {
        if (!obj) return;
        if (Array.isArray(obj)) {
          obj.forEach(extractTypes);
        } else if (typeof obj === "object") {
          if (obj["@type"]) {
            structuredDataTypes.push(obj["@type"]);
          }
          if (obj["@graph"] && Array.isArray(obj["@graph"])) {
            obj["@graph"].forEach(extractTypes);
          }
        }
      }
      extractTypes(parsed);
    } catch (e) {
      structuredDataTypes.push("INVALID_JSON");
    }
  }

  return {
    title,
    metaDescription,
    h1,
    h1Count: h1List.length,
    canonical,
    robotsMeta: robotsMeta || "default (index, follow)",
    indexability,
    internalLinksOut: internalLinks,
    imagesMissingAltCount: imagesMissingAlt,
    imagesMissingAltSources: missingAltSources,
    structuredDataTypes: [...new Set(structuredDataTypes)].join("; ") || "NONE"
  };
}

async function main() {
  console.log("Starting Phase 0 baseline crawl against local build:", BASE_LOCAL);
  const crawlResults = [];
  const inlinksMap = new Map();

  for (const p of SEED_PATHS) {
    console.log(`Crawling ${p}...`);
    const fetched = await fetchPage(p);
    let parsed = {
      title: "",
      metaDescription: "",
      h1: "N/A",
      h1Count: 0,
      canonical: "",
      robotsMeta: "N/A",
      indexability: "N/A",
      internalLinksOut: [],
      imagesMissingAltCount: 0,
      imagesMissingAltSources: [],
      structuredDataTypes: "NONE"
    };

    if (fetched.isHtml && fetched.body) {
      parsed = parseHtmlMetadata(fetched.body, p);
      for (const target of parsed.internalLinksOut) {
        inlinksMap.set(target, (inlinksMap.get(target) || 0) + 1);
      }
    } else if (p === "/robots.txt") {
      parsed.title = "robots.txt";
      parsed.indexability = "ROBOTS_TXT";
    } else if (p === "/sitemap.xml") {
      parsed.title = "XML Sitemap";
      parsed.indexability = "SITEMAP_XML";
    }

    crawlResults.push({
      ...fetched,
      ...parsed
    });

    await sleep(600); // 600ms throttle
  }

  // Build CSV
  const headers = [
    "url",
    "status_code",
    "final_url",
    "title",
    "meta_description",
    "h1",
    "canonical",
    "robots_meta",
    "indexability",
    "internal_links_in",
    "internal_links_out_count",
    "images_missing_alt_count",
    "structured_data_types",
    "evaluation_status"
  ];

  const rows = crawlResults.map(r => {
    const inlinksCount = inlinksMap.get(r.path) || 0;
    let evalStatus = "PASS";
    if (r.statusCode === 404 && r.path === "/this-page-does-not-exist-test-404") {
      evalStatus = "PASS"; // Expected 404 test
    } else if (r.statusCode >= 400 && r.path !== "/this-page-does-not-exist-test-404") {
      evalStatus = "FAIL";
    } else if (r.isHtml) {
      if (!r.title || r.title.length === 0) evalStatus = "FAIL";
      if (!r.canonical) evalStatus = "FAIL";
      if (r.h1Count !== 1) evalStatus = "REQUIRES HUMAN REVIEW";
    }

    return [
      escapeCsv(`${PUBLIC_DOMAIN}${r.path}`),
      escapeCsv(r.statusCode),
      escapeCsv(r.finalUrl.startsWith("/") ? `${PUBLIC_DOMAIN}${r.finalUrl}` : r.finalUrl),
      escapeCsv(r.title),
      escapeCsv(r.metaDescription),
      escapeCsv(r.h1),
      escapeCsv(r.canonical),
      escapeCsv(r.robotsMeta),
      escapeCsv(r.indexability),
      escapeCsv(inlinksCount),
      escapeCsv(r.internalLinksOut.length),
      escapeCsv(r.imagesMissingAltCount),
      escapeCsv(r.structuredDataTypes),
      escapeCsv(evalStatus)
    ].join(",");
  });

  const csvContent = [headers.join(","), ...rows].join("\n");
  const outputPath = path.join(process.cwd(), "docs/seo/baseline-crawl.csv");
  fs.writeFileSync(outputPath, csvContent, "utf8");
  console.log(`Baseline crawl written to ${outputPath} (${crawlResults.length} URLs crawled).`);

  // Write detailed crawl JSON for audit consumption
  const jsonPath = path.join(process.cwd(), "docs/seo/baseline-crawl.json");
  fs.writeFileSync(jsonPath, JSON.stringify(crawlResults, null, 2), "utf8");
  console.log(`Detailed crawl JSON written to ${jsonPath}.`);
}

main().catch(console.error);
