#!/usr/bin/env bash
# =============================================================================
# BURGER CARTEL — SECURE ARTIFACT PACKAGING SCRIPT
# Creates a clean, distribution-ready ZIP archive free of secret files,
# local environment overrides, node_modules, and OS metadata files.
# =============================================================================
set -euo pipefail

TARGET_DIR="${1:-/Users/hrishitagupta/Desktop/b-g-3}"
OUTPUT_ZIP="${2:-/Users/hrishitagupta/Desktop/b-g-3.zip}"

echo "[Package] Verifying source directory: ${TARGET_DIR}"
if [ ! -d "${TARGET_DIR}" ]; then
  echo "[Package ERROR] Target directory does not exist: ${TARGET_DIR}" >&2
  exit 1
fi

# Ensure no secret files are inside target before packaging
if [ -f "${TARGET_DIR}/.env.local" ]; then
  echo "[Package ALERT] Found .env.local in target directory. Removing to prevent secret leakage..."
  rm -f "${TARGET_DIR}/.env.local"
fi

# Clean up OS metadata and build artifacts
echo "[Package] Cleaning OS metadata and build cache..."
find "${TARGET_DIR}" -name ".DS_Store" -delete || true
rm -rf "${TARGET_DIR}/.next" || true

# Create clean ZIP excluding any secret, node_modules, and cache files
echo "[Package] Creating distribution archive: ${OUTPUT_ZIP}"
cd "$(dirname "${TARGET_DIR}")"
BASE_NAME="$(basename "${TARGET_DIR}")"

rm -f "${OUTPUT_ZIP}"
zip -r "${OUTPUT_ZIP}" "${BASE_NAME}" \
  -x "*.DS_Store" \
  -x "*/**/.DS_Store" \
  -x "${BASE_NAME}/.env.local" \
  -x "${BASE_NAME}/.env*.local" \
  -x "${BASE_NAME}/.next*" \
  -x "${BASE_NAME}/**/.next*" \
  -x "${BASE_NAME}/node_modules*" \
  -x "${BASE_NAME}/**/node_modules*"

echo "[Package SUCCESS] Verified archive created at: ${OUTPUT_ZIP} ($(du -sh "${OUTPUT_ZIP}" | cut -f1))"
