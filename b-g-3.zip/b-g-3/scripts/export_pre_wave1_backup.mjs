import { neon } from "@neondatabase/serverless";
import * as fs from "fs";
import * as crypto from "crypto";

if (fs.existsSync(".env.local")) {
  const envContent = fs.readFileSync(".env.local", "utf8");
  for (const line of envContent.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const eqIdx = trimmed.indexOf("=");
    if (eqIdx > 0) {
      const key = trimmed.slice(0, eqIdx).trim();
      let val = trimmed.slice(eqIdx + 1).trim();
      if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
        val = val.slice(1, -1);
      }
      process.env[key] = val;
    }
  }
}

const dbUrl = process.env.DATABASE_URL;
if (!dbUrl) {
  console.error("DATABASE_URL is not set.");
  process.exit(1);
}

const sql = neon(dbUrl);

const TABLES = [
  "restaurants",
  "admin_roles",
  "admin_users",
  "admin_sessions",
  "audit_logs",
  "outlets",
  "menu_categories",
  "menu_items",
  "outlet_menu_availability",
  "outlet_menu_overrides",
  "customer_reviews",
  "gallery_items",
  "custom_pages",
  "site_content",
  "media_assets",
  "cms_backups",
  "cms_releases"
];

async function runBackup() {
  console.log("Starting Neon PostgreSQL pre-Wave-1 backup...");
  const backupData = {
    timestamp: new Date().toISOString(),
    databaseUrlMasked: dbUrl.replace(/:[^:@]+@/, ":***@"),
    tables: {}
  };

  for (const table of TABLES) {
    try {
      const rows = await sql.query(`SELECT * FROM ${table} ORDER BY 1 ASC`);
      backupData.tables[table] = {
        count: rows.length,
        rows
      };
      console.log(`  ✔ Exported ${table}: ${rows.length} rows`);
    } catch (err) {
      console.warn(`  ⚠ Table ${table} query failed: ${err.message}`);
      backupData.tables[table] = { count: 0, error: err.message, rows: [] };
    }
  }

  const jsonStr = JSON.stringify(backupData, null, 2);
  const backupPath = "backups/burger_cartel_pre_wave1.json";
  fs.writeFileSync(backupPath, jsonStr, "utf8");

  const hash = crypto.createHash("sha256").update(jsonStr).digest("hex");
  const checksumPath = "backups/BACKUP_CHECKSUM.sha256";
  fs.writeFileSync(checksumPath, `${hash}  burger_cartel_pre_wave1.json\n`, "utf8");

  console.log(`\nBackup saved to ${backupPath} (${(Buffer.byteLength(jsonStr) / 1024).toFixed(2)} KB)`);
  console.log(`SHA-256 Checksum: ${hash}`);
}

runBackup().catch((err) => {
  console.error("Backup failed:", err);
  process.exit(1);
});
