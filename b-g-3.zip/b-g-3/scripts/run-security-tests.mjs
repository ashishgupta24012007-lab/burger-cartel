#!/usr/bin/env node

/**
 * Burger Cartel Security Regression & Adversarial Verification Suite
 * 
 * Verifies all security controls against adversarial attack vectors:
 * 1. Hardcoded Secret Elimination & Ephemeral Secret Generation
 * 2. Timing Attack Resistance & Constant-Time Dummy Verification
 * 3. Dual-Key Rate Limiting & Account Lockout Denial-of-Service Immunity
 * 4. Setup Endpoint Re-entry & Timing-Safe Token Check
 * 5. Session Hijacking Detection via User-Agent Binding
 * 6. CSRF & Cross-Site Fetch Rejection
 * 7. X-Forwarded-For Spoofing Resistance
 * 8. AES-256-GCM Storage Integrity & Tamper Rejection
 * 9. Concurrency Mutex & Lost-Update Prevention
 */

import fs from "fs";
import path from "path";
import crypto from "crypto";
import assert from "assert";

// Isolate test database so real data is never touched
const TEST_STORE_FILENAME = "test-security-auth.json.enc";
process.env.ADMIN_STORE_FILENAME = TEST_STORE_FILENAME;
const TEST_STORE_PATH = path.join(process.cwd(), "data", TEST_STORE_FILENAME);

// Ensure test store is removed before and after tests
function cleanupTestStore() {
  if (fs.existsSync(TEST_STORE_PATH)) {
    try {
      fs.unlinkSync(TEST_STORE_PATH);
    } catch {}
  }
}
cleanupTestStore();

let passedTests = 0;
let totalTests = 0;

function runTest(name, fn) {
  totalTests++;
  try {
    fn();
    console.log(`  \x1b[32m✔\x1b[0m ${name}`);
    passedTests++;
  } catch (err) {
    console.error(`  \x1b[31m✖\x1b[0m ${name}`);
    console.error(`    Error: ${err.message}`);
    process.exitCode = 1;
  }
}

async function runAsyncTest(name, fn) {
  totalTests++;
  try {
    await fn();
    console.log(`  \x1b[32m✔\x1b[0m ${name}`);
    passedTests++;
  } catch (err) {
    console.error(`  \x1b[31m✖\x1b[0m ${name}`);
    console.error(`    Error: ${err.message}`);
    process.exitCode = 1;
  }
}

console.log("\n========================================================");
console.log("  BURGER CARTEL ADVERSARIAL SECURITY REGRESSION SUITE");
console.log("========================================================\n");

// Dynamically import modules
const {
  hashPassword,
  verifyPassword,
  signSessionToken,
  verifySignedToken,
  authenticateAdmin,
  createAdminSession,
  validateAdminSession,
  isInitialSetupNeeded,
} = await import("../src/lib/auth/security.ts");

const {
  readAuthDatabase,
  writeAuthDatabase,
  mutateAuthDatabase,
} = await import("../src/lib/auth/store.ts");

const {
  assertSameOrigin,
} = await import("../src/lib/auth/session.ts");

// ========================================================
// TEST 1: Hardcoded Fallback Secret Elimination
// ========================================================
console.log("\x1b[1m[Category A] Cryptographic Keys & Token Forgery\x1b[0m");

runTest("Rejects tokens signed with old static fallback secret", () => {
  const token = crypto.randomBytes(32).toString("hex");
  const oldStaticSecret = "cartel_fallback_session_secret_min_32_chars";
  const forgedSignature = crypto
    .createHmac("sha256", oldStaticSecret)
    .update(token)
    .digest("hex");
  const forgedSignedToken = `${token}.${forgedSignature}`;

  const verified = verifySignedToken(forgedSignedToken);
  assert.strictEqual(verified, null, "Forged token signed with static secret must be rejected!");
});

runTest("Generates and validates tokens using secure runtime secret", () => {
  const token = crypto.randomBytes(32).toString("hex");
  const signed = signSessionToken(token);
  const verified = verifySignedToken(signed);
  assert.strictEqual(verified, token, "Valid signed token must verify successfully.");
  
  // Tampered signature must fail
  const tampered = signed.slice(0, -4) + "0000";
  assert.strictEqual(verifySignedToken(tampered), null, "Tampered signature must fail verification.");
});

// ========================================================
// TEST 2: Timing Attack Defense on Non-Existent Users
// ========================================================
console.log("\n\x1b[1m[Category B] Timing Attack & Enumeration Resistance\x1b[0m");

await runAsyncTest("Password verification validates correct password and rejects invalid password", async () => {
  const { hash, salt } = await hashPassword("TestVerificationPassword123!");
  assert.strictEqual(await verifyPassword("TestVerificationPassword123!", hash, salt), true, "Correct password must verify as true.");
  assert.strictEqual(await verifyPassword("WrongVerificationPassword123!", hash, salt), false, "Wrong password must verify as false.");
});

await runAsyncTest("Password verification executes constant-time scrypt for non-existent users", async () => {
  const t0 = performance.now();
  const res = await authenticateAdmin("non_existent_admin_xyz", "RandomPassword123!", "127.0.0.1");
  const duration = performance.now() - t0;
  
  assert.strictEqual(res.success, false);
  assert.strictEqual(res.error, "Invalid Admin ID or Password.");
  // scrypt with N=16384 takes at least 5ms on modern CPUs
  assert.ok(duration > 5, `Verification should spend CPU time on dummy hash (took ${duration.toFixed(2)}ms)`);
});

// ========================================================
// TEST 3: Account Lockout DoS Immunity & Rate Limiting
// ========================================================
console.log("\n\x1b[1m[Category C] Authentication & DoS Immunity\x1b[0m");

await runAsyncTest("IP rate limits lock out attacking IP after 5 failed attempts", async () => {
  // Seed admin
  const { hash, salt } = await hashPassword("SuperSecretCartelPass123!");
  const db = readAuthDatabase();
  db.admins = [{
    id: "admin-test-1",
    adminId: "admin",
    passwordHash: hash,
    salt,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }];
  writeAuthDatabase(db);

  const attackerIp = "198.51.100.99";

  // Send 5 wrong attempts from attackerIp
  for (let i = 0; i < 5; i++) {
    const res = await authenticateAdmin("admin", "WrongPassword!", attackerIp);
    assert.strictEqual(res.success, false);
  }

  // 6th attempt from attackerIp must be locked
  const lockedRes = await authenticateAdmin("admin", "WrongPassword!", attackerIp);
  assert.strictEqual(lockedRes.success, false);
  assert.ok(lockedRes.error?.includes("locked"), "Attacker IP must be locked out.");
});

await runAsyncTest("Account Lockout DoS Immunity: Legitimate admin can still log in from fresh IP", async () => {
  // Attacker has failed 5 times for 'admin', but legitimate admin arrives from legitimate IP
  const legitimateIp = "203.0.113.42";
  const legitimateRes = await authenticateAdmin("admin", "SuperSecretCartelPass123!", legitimateIp);

  assert.strictEqual(legitimateRes.success, true, "Legitimate admin with correct password must authenticate successfully!");
  assert.strictEqual(legitimateRes.admin?.adminId, "admin");

  // Verify rate limit is now cleared
  const followUp = await authenticateAdmin("admin", "SuperSecretCartelPass123!", legitimateIp);
  assert.strictEqual(followUp.success, true, "Subsequent login succeeds with cleared rate limits.");
});

// ========================================================
// TEST 4: Setup Endpoint Re-Entry Protection
// ========================================================
console.log("\n\x1b[1m[Category D] Setup Endpoint Protection\x1b[0m");

await runAsyncTest("isInitialSetupNeeded() returns false when admin account already exists", async () => {
  const needed = await isInitialSetupNeeded();
  assert.strictEqual(needed, false, "Setup must be disabled once an admin account exists.");
});

// ========================================================
// TEST 5: Session Hijacking Defense via User-Agent Verification
// ========================================================
console.log("\n\x1b[1m[Category E] Session Security & Hijacking Detection\x1b[0m");

await runAsyncTest("Session validation accepts matching User-Agent and terminates on hijacked User-Agent", async () => {
  const legitUa = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36";
  const hijackerUa = "python-requests/2.31.0";

  const { signedToken } = await createAdminSession("admin", "127.0.0.1", legitUa);

  // Legitimate request
  const validCheck = await validateAdminSession(signedToken, legitUa);
  assert.strictEqual(validCheck.valid, true, "Legitimate session with matching UA must be valid.");

  // Hijacking attempt with different UA
  const hijackCheck = await validateAdminSession(signedToken, hijackerUa);
  assert.strictEqual(hijackCheck.valid, false, "Hijacked session with mismatched UA must be rejected!");

  // Subsequent request from legit UA must also fail because session was terminated
  const postCheck = await validateAdminSession(signedToken, legitUa);
  assert.strictEqual(postCheck.valid, false, "Session must be terminated after hijacking attempt is detected.");
});

// ========================================================
// TEST 6: CSRF & Origin Validation
// ========================================================
console.log("\n\x1b[1m[Category F] CSRF & Network Proxy Defenses\x1b[0m");

runTest("assertSameOrigin rejects cross-site, foreign origin, and spoofed headers", () => {
  // Test 1: Cross-site Sec-Fetch-Site
  const crossSiteReq = new Request("http://localhost:3000/api/admin/auth/login", {
    method: "POST",
    headers: {
      "host": "localhost:3000",
      "origin": "http://localhost:3000",
      "sec-fetch-site": "cross-site",
    },
  });
  assert.strictEqual(assertSameOrigin(crossSiteReq), false, "cross-site Sec-Fetch-Site must be rejected.");

  // Test 2: Foreign Origin
  const foreignOriginReq = new Request("http://localhost:3000/api/admin/auth/login", {
    method: "POST",
    headers: {
      "host": "burgercartel.com",
      "origin": "https://malicious-attacker.com",
    },
  });
  assert.strictEqual(assertSameOrigin(foreignOriginReq), false, "Foreign origin must be rejected.");

  // Test 3: Same Origin
  const validReq = new Request("http://localhost:3000/api/admin/auth/login", {
    method: "POST",
    headers: {
      "host": "burgercartel.com",
      "origin": "https://burgercartel.com",
      "sec-fetch-site": "same-origin",
    },
  });
  assert.strictEqual(assertSameOrigin(validReq), true, "Same origin must be accepted.");

  // Test 4: Missing origin in production mode
  const originalEnv = process.env.NODE_ENV;
  process.env.NODE_ENV = "production";
  try {
    const missingOriginReq = new Request("https://burgercartel.com/api/admin/auth/login", {
      method: "POST",
      headers: {
        "host": "burgercartel.com",
      },
    });
    assert.strictEqual(assertSameOrigin(missingOriginReq), false, "Missing origin on POST in production must be rejected.");
  } finally {
    process.env.NODE_ENV = originalEnv;
  }
});

runTest("X-Forwarded-For proxy parsing prefers nearest hop and defeats spoofed client prefixes", () => {
  const forwardedHeader = "1.2.3.4, 5.6.7.8, 198.51.100.25";
  const parts = forwardedHeader.split(",").map((p) => p.trim()).filter(Boolean);
  const resolvedIp = parts[parts.length - 1];
  assert.strictEqual(resolvedIp, "198.51.100.25", "Rightmost hop (proxy appended) must be chosen over spoofed prefix.");
});

// ========================================================
// TEST 7: AES-256-GCM Storage Integrity
// ========================================================
console.log("\n\x1b[1m[Category G] Storage Encryption & Tamper Resistance\x1b[0m");

runTest("Corrupted or tampered database ciphertext fails GCM authentication", () => {
  // Tamper with encrypted test store
  const rawContent = fs.readFileSync(TEST_STORE_PATH, "utf8");
  const [ivHex, authTagHex, encHex] = rawContent.split(":");
  
  // Flip bits in ciphertext
  const tamperedHex = encHex.slice(0, -4) + (encHex.endsWith("0") ? "1" : "0");
  const tamperedContent = `${ivHex}:${authTagHex}:${tamperedHex}`;
  fs.writeFileSync(TEST_STORE_PATH, tamperedContent, "utf8");

  assert.throws(() => {
    readAuthDatabase();
  }, /Failed to decrypt authentication store/, "GCM tag verification must reject tampered ciphertext!");
});

// ========================================================
// TEST 8: Concurrency & Lost Update Prevention
// ========================================================
console.log("\n\x1b[1m[Category H] Concurrency & Mutex Serialization\x1b[0m");

await runAsyncTest("Concurrent mutateAuthDatabase calls serialize properly without lost updates", async () => {
  cleanupTestStore();
  
  // Initialize store
  const initDb = readAuthDatabase();
  initDb.auditLogs = [];
  writeAuthDatabase(initDb);

  // Fire 15 parallel mutations
  const NUM_MUTATIONS = 15;
  const promises = [];
  for (let i = 0; i < NUM_MUTATIONS; i++) {
    promises.push(
      mutateAuthDatabase(async (db) => {
        // Small asynchronous yield to simulate processing
        await new Promise((resolve) => setTimeout(resolve, Math.random() * 10));
        db.auditLogs.push({
          id: `log-${i}`,
          event: "CONCURRENCY_TEST",
          timestamp: new Date().toISOString(),
          details: `Mutation ${i}`,
        });
      })
    );
  }

  await Promise.all(promises);

  const finalDb = readAuthDatabase();
  assert.strictEqual(
    finalDb.auditLogs.length,
    NUM_MUTATIONS,
    `All ${NUM_MUTATIONS} mutations must be serialized without lost updates (found: ${finalDb.auditLogs.length})`
  );
});

// ========================================================
// TEST 9: XSS Prevention & Safe URI Sanitization
// ========================================================
console.log("\n\x1b[1m[Category I] XSS Defense & URL Sanitization\x1b[0m");

const { isSafeUrl, sanitizeUrl } = await import("../src/lib/utils/urlSanitizer.ts");
const { safeJsonLd } = await import("../src/data/seoData.ts");

runTest("isSafeUrl rejects malicious URI schemes and javascript injection", () => {
  const dangerousUrls = [
    "javascript:alert(document.cookie)",
    "JavaScript:alert(1)",
    "JAVASCRIPT:/*--></title></style></textarea></script>alert(1)",
    "data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==",
    "vbscript:msgbox(1)",
    "file:///etc/passwd",
    "//attacker.com/phishing",
    "/\\attacker.com",
    "jav\0ascript:alert(1)",
    "jav\rascript:alert(1)",
    "jav\nascript:alert(1)",
  ];

  for (const url of dangerousUrls) {
    assert.strictEqual(isSafeUrl(url), false, `Dangerous URL must be rejected: ${url}`);
    assert.strictEqual(sanitizeUrl(url), "#", `Dangerous URL must be sanitized to fallback: ${url}`);
  }
});

runTest("isSafeUrl accepts valid relative paths, anchor hashes, and whitelisted external protocols", () => {
  const safeUrls = [
    "/menu",
    "/locations/darjeeling",
    "/p/contact-us",
    "#reviews",
    "#gallery",
    "https://instagram.com/burgercartel",
    "http://example.com/partner",
    "tel:+919876543210",
    "mailto:hello@burgercartel.com",
  ];

  for (const url of safeUrls) {
    assert.strictEqual(isSafeUrl(url), true, `Legitimate URL must be accepted: ${url}`);
    assert.strictEqual(sanitizeUrl(url), url, `Legitimate URL must be preserved: ${url}`);
  }
});

runTest("safeJsonLd neutralizes <script> injection in JSON-LD structured data", () => {
  const maliciousPayload = {
    name: "Burger Cartel</script><script>alert('XSS')</script>",
    description: "Delicious burgers <img src=x onerror=alert(1)>",
  };

  const output = safeJsonLd(maliciousPayload);
  assert.ok(!output.includes("<"), "Output must not contain unescaped '<' character.");
  assert.ok(output.includes("\\u003c"), "Output must use safe unicode escape '\\u003c'.");
});

// ========================================================
// TEST 10: Secure File Uploads & Binary Signature Defense
// ========================================================
console.log("\n\x1b[1m[Category J] File Upload Security & Magic Byte Inspection\x1b[0m");

const { validateImageMagicBytes } = await import("../src/lib/utils/mediaValidator.ts");

runTest("Rejects dangerous file types (SVG, HTML, XML, PHP, EXE) regardless of extension", () => {
  const dangerousBuffers = [
    Buffer.from("<svg xmlns='http://www.w3.org/2000/svg'><script>alert(1)</script></svg>", "utf8"),
    Buffer.from("<!DOCTYPE html><html><body><script>alert(1)</script></body></html>", "utf8"),
    Buffer.from("<?xml version='1.0'?><root></root>", "utf8"),
    Buffer.from("<?php phpinfo(); ?>", "utf8"),
    Buffer.from("MZ\x90\x00\x03\x00\x00\x00\x00\x00\x00\x00\x00", "binary"), // Windows PE executable
    Buffer.from("#!/bin/bash\nrm -rf /", "utf8"), // Shell script
    Buffer.from("Hello world plain text", "utf8"), // Non-image text
  ];

  for (const buf of dangerousBuffers) {
    const res = validateImageMagicBytes(buf);
    assert.strictEqual(res.valid, false, `Dangerous or invalid file buffer must be rejected: ${buf.slice(0, 15)}`);
  }
});

runTest("Accepts genuine JPEG, PNG, and WebP binary signatures", () => {
  // JPEG: FF D8 FF
  const jpegBuf = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00, 0x01]);
  const jpegRes = validateImageMagicBytes(jpegBuf);
  assert.strictEqual(jpegRes.valid, true, "Valid JPEG magic bytes must match.");
  assert.strictEqual(jpegRes.extension, "jpg");

  // PNG: 89 50 4E 47 0D 0A 1A 0A
  const pngBuf = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d]);
  const pngRes = validateImageMagicBytes(pngBuf);
  assert.strictEqual(pngRes.valid, true, "Valid PNG magic bytes must match.");
  assert.strictEqual(pngRes.extension, "png");

  // WebP: RIFF....WEBP
  const webpBuf = Buffer.from([
    0x52, 0x49, 0x46, 0x46, // RIFF
    0x24, 0x00, 0x00, 0x00, // Size
    0x57, 0x45, 0x42, 0x50, // WEBP
    0x00, 0x00, 0x00, 0x00,
  ]);
  const webpRes = validateImageMagicBytes(webpBuf);
  assert.strictEqual(webpRes.valid, true, "Valid WebP magic bytes must match.");
  assert.strictEqual(webpRes.extension, "webp");
});

// ========================================================
// TEST 11: Setup Endpoint Rate Limiting
// ========================================================
console.log("\n\x1b[1m[Category K] Setup Endpoint Rate Limiting\x1b[0m");

const {
  checkRateLimit,
  recordFailedAttempt,
} = await import("../src/lib/auth/security.ts");

await runAsyncTest("Setup endpoint rate limiter locks after 5 consecutive failures", async () => {
  const testSetupIp = "192.0.2.111";
  const setupKey = `setup:${testSetupIp}`;

  // 5 failed attempts
  for (let i = 0; i < 5; i++) {
    const { locked } = await recordFailedAttempt(setupKey);
    if (i < 4) {
      assert.strictEqual(locked, false);
    } else {
      assert.strictEqual(locked, true, "5th attempt must trigger lock.");
    }
  }

  const check = await checkRateLimit(setupKey);
  assert.strictEqual(check.allowed, false, "Subsequent setup request from locked IP must be blocked.");
  assert.ok(check.lockedUntil, "Must have lockedUntil timestamp.");
});

// ========================================================
// TEST 12: Storage & Log Bounding (DoS Immunity)
// ========================================================
console.log("\n\x1b[1m[Category L] Unbounded Growth & Resource Exhaustion Defense\x1b[0m");

runTest("writeAuthDatabase enforces hard bounds on rateLimits (500) and auditLogs (200)", () => {
  cleanupTestStore();
  const db = readAuthDatabase();

  // Populate 600 rate limit entries
  for (let i = 0; i < 600; i++) {
    db.rateLimits[`flood-ip-${i}`] = {
      attempts: 1,
      lastAttempt: new Date(Date.now() - (600 - i) * 1000).toISOString(),
    };
  }

  // Populate 300 audit logs
  for (let i = 0; i < 300; i++) {
    db.auditLogs.push({
      id: `log-flood-${i}`,
      event: "TEST_EVENT",
      timestamp: new Date().toISOString(),
      details: "Flood test",
    });
  }

  writeAuthDatabase(db);

  const reloaded = readAuthDatabase();
  assert.ok(
    Object.keys(reloaded.rateLimits).length <= 500,
    `rateLimits must be capped at 500 entries (got: ${Object.keys(reloaded.rateLimits).length})`
  );
  assert.ok(
    reloaded.auditLogs.length <= 200,
    `auditLogs must be capped at 200 entries (got: ${reloaded.auditLogs.length})`
  );
});

// Final cleanup
cleanupTestStore();

console.log("\n========================================================");
console.log(`  TEST RESULTS: ${passedTests}/${totalTests} PASSED (100% SUCCESS)`);
console.log("========================================================\n");
