-- ============================================================================
-- BURGER CARTEL MIGRATION 002: REFINED RELATIONAL SCHEMA (Phase 2.1)
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 1. ADMIN ROLES TABLE
CREATE TABLE IF NOT EXISTS admin_roles (
    id VARCHAR(32) PRIMARY KEY,
    name VARCHAR(64) NOT NULL,
    description TEXT,
    permissions JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO admin_roles (id, name, description, permissions)
VALUES 
    ('superadmin', 'Super Administrator', 'Unrestricted administrative access to all branches and CMS modules', '["*"]'::jsonb),
    ('branch_manager', 'Branch Manager', 'Limited to outlet hours and branch menu inventory overrides', '["outlets:update", "inventory:override"]'::jsonb),
    ('editor', 'Content Editor', 'Can draft and edit content, reviews, and media but cannot publish without approval', '["cms:draft", "media:upload"]'::jsonb)
ON CONFLICT (id) DO NOTHING;

-- Update admin_users to reference admin_roles and add security fields
ALTER TABLE admin_users 
    ADD COLUMN IF NOT EXISTS role_id VARCHAR(32) DEFAULT 'superadmin' REFERENCES admin_roles(id),
    ADD COLUMN IF NOT EXISTS email VARCHAR(128),
    ADD COLUMN IF NOT EXISTS assigned_outlet_id VARCHAR(64),
    ADD COLUMN IF NOT EXISTS failed_login_attempts INT NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS locked_until TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS last_login_at TIMESTAMPTZ;

-- 2. RESTAURANTS (PARENT BRAND ENTITY)
CREATE TABLE IF NOT EXISTS restaurants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(128) NOT NULL,
    tagline VARCHAR(256),
    support_phone VARCHAR(32) NOT NULL,
    support_email VARCHAR(128) NOT NULL,
    instagram_url VARCHAR(256),
    facebook_url VARCHAR(256),
    whatsapp_number VARCHAR(32),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Seed default brand entity if none exists
INSERT INTO restaurants (id, name, tagline, support_phone, support_email, instagram_url, facebook_url, whatsapp_number)
VALUES (
    'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11',
    'Burger Cartel',
    'The Best Smash Burgers & Gourmet Cafe in Darjeeling & Siliguri',
    '+91 89100 24100',
    'contact@burgercartel.in',
    'https://instagram.com/burgercartel.in',
    'https://facebook.com/burgercartel',
    '+91 89100 24100'
)
ON CONFLICT (id) DO NOTHING;

-- 3. ENHANCE OUTLETS
ALTER TABLE outlets
    ADD COLUMN IF NOT EXISTS restaurant_id UUID REFERENCES restaurants(id) ON DELETE SET NULL,
    ALTER COLUMN short_name SET DEFAULT '';

UPDATE outlets SET restaurant_id = 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11' WHERE restaurant_id IS NULL;

-- 4. ENHANCE MENU CATEGORIES
ALTER TABLE menu_categories
    ADD COLUMN IF NOT EXISTS is_active BOOLEAN NOT NULL DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS publication_status VARCHAR(20) NOT NULL DEFAULT 'published';

-- 5. ENHANCE MENU ITEMS WITH NUMERIC PRICING
-- Add numeric columns
ALTER TABLE menu_items
    ADD COLUMN IF NOT EXISTS base_price NUMERIC(10, 2) DEFAULT 180.00 CHECK (base_price >= 0),
    ADD COLUMN IF NOT EXISTS sale_price_numeric NUMERIC(10, 2) CHECK (sale_price_numeric IS NULL OR sale_price_numeric >= 0),
    ADD COLUMN IF NOT EXISTS currency VARCHAR(3) NOT NULL DEFAULT 'INR',
    ADD COLUMN IF NOT EXISTS is_vegetarian BOOLEAN DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS is_active BOOLEAN NOT NULL DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS publication_status VARCHAR(20) NOT NULL DEFAULT 'published',
    ADD COLUMN IF NOT EXISTS version INT NOT NULL DEFAULT 1;

-- Backfill base_price from string price (stripping currency symbol '₹' and whitespace)
UPDATE menu_items 
SET base_price = COALESCE(
    NULLIF(regexp_replace(price, '[^0-9.]', '', 'g'), '')::numeric, 
    180.00
)
WHERE base_price IS NULL OR base_price = 180.00;

-- Sync is_vegetarian from is_veg
UPDATE menu_items SET is_vegetarian = is_veg WHERE is_veg IS NOT NULL;

-- 6. OUTLET MENU OVERRIDES (Availability + Branch-Specific Pricing)
CREATE TABLE IF NOT EXISTS outlet_menu_overrides (
    outlet_id VARCHAR(64) NOT NULL REFERENCES outlets(id) ON DELETE CASCADE,
    menu_item_id VARCHAR(64) NOT NULL REFERENCES menu_items(id) ON DELETE CASCADE,
    is_available BOOLEAN NOT NULL DEFAULT TRUE,
    price_override NUMERIC(10, 2) CHECK (price_override IS NULL OR price_override >= 0),
    sale_price_override NUMERIC(10, 2) CHECK (sale_price_override IS NULL OR sale_price_override >= 0),
    reason TEXT,
    updated_by UUID REFERENCES admin_users(id),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (outlet_id, menu_item_id)
);

-- Backfill outlet_menu_overrides from existing outlet_menu_availability
INSERT INTO outlet_menu_overrides (outlet_id, menu_item_id, is_available, updated_at)
SELECT outlet_id, menu_item_id, is_available, NOW()
FROM outlet_menu_availability
ON CONFLICT (outlet_id, menu_item_id) 
DO UPDATE SET is_available = EXCLUDED.is_available, updated_at = NOW();

-- 7. ENHANCE MEDIA ASSETS
ALTER TABLE media_assets
    ADD COLUMN IF NOT EXISTS storage_key VARCHAR(512),
    ADD COLUMN IF NOT EXISTS public_url TEXT,
    ADD COLUMN IF NOT EXISTS original_filename VARCHAR(255),
    ADD COLUMN IF NOT EXISTS width INT CHECK (width IS NULL OR (width >= 200 AND width <= 3840)),
    ADD COLUMN IF NOT EXISTS height INT CHECK (height IS NULL OR (height >= 200 AND height <= 2160)),
    ADD COLUMN IF NOT EXISTS blur_hash VARCHAR(128),
    ADD COLUMN IF NOT EXISTS alt_text VARCHAR(255),
    ADD COLUMN IF NOT EXISTS status VARCHAR(32) NOT NULL DEFAULT 'active';

UPDATE media_assets 
SET storage_key = 'uploads/' || filename,
    public_url = '/api/media/' || filename,
    original_filename = filename
WHERE storage_key IS NULL;

-- 8. CUSTOMER REVIEWS
ALTER TABLE customer_reviews
    ADD COLUMN IF NOT EXISTS is_published BOOLEAN NOT NULL DEFAULT TRUE;

UPDATE customer_reviews SET is_published = NOT hidden WHERE hidden IS NOT NULL;

-- 9. CUSTOM EDITORIAL PAGES
ALTER TABLE custom_pages
    ADD COLUMN IF NOT EXISTS version INT NOT NULL DEFAULT 1;

-- 10. RELEASES & PUBLISHING AUDIT
CREATE TABLE IF NOT EXISTS cms_releases (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    release_number SERIAL UNIQUE,
    label VARCHAR(256) NOT NULL,
    description TEXT,
    published_by VARCHAR(64) NOT NULL DEFAULT 'system',
    published_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    snapshot_manifest JSONB NOT NULL DEFAULT '{}'::jsonb,
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);

-- Performance & Query Indexes
CREATE INDEX IF NOT EXISTS idx_menu_items_cat_active ON menu_items(category_id, is_active, publication_status);
CREATE INDEX IF NOT EXISTS idx_menu_overrides_outlet_item ON outlet_menu_overrides(outlet_id, menu_item_id);
CREATE INDEX IF NOT EXISTS idx_reviews_branch_published ON customer_reviews(branch_id, is_published);
CREATE INDEX IF NOT EXISTS idx_releases_active_num ON cms_releases(is_active, release_number DESC);
