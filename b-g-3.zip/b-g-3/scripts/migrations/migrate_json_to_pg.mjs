#!/usr/bin/env node

/**
 * BURGER CARTEL ZERO-DATA-LOSS CMS MIGRATION SCRIPT
 * Migrates local JSON database (data/cms-content.json) into Managed PostgreSQL (Neon)
 */

import fs from "fs";
import path from "path";
import { neon } from "@neondatabase/serverless";

const DATABASE_URL = process.env.DATABASE_URL || "postgresql://neondb_owner:npg_4UIVYA0HozRc@ep-wispy-sunset-bdc2aled-pooler.c-8.us-east-2.aws.neon.tech/neondb?channel_binding=require&sslmode=require";

if (!DATABASE_URL) {
  console.error("❌ DATABASE_URL is not configured.");
  process.exit(1);
}

const sql = neon(DATABASE_URL);
const jsonPath = path.resolve("data/cms-content.json");

if (!fs.existsSync(jsonPath)) {
  console.error(`❌ Source JSON not found at ${jsonPath}`);
  process.exit(1);
}

const rawData = fs.readFileSync(jsonPath, "utf8");
const cms = JSON.parse(rawData);

console.log("=================================================");
console.log("BURGER CARTEL: JSON -> POSTGRESQL DATA MIGRATION");
console.log("=================================================");
console.log(`Source File: ${jsonPath} (${(rawData.length / 1024).toFixed(1)} KB)`);

async function migrate() {
  // 1. MENU CATEGORIES
  console.log("\n[1/8] Migrating Menu Categories...");
  let catCount = 0;
  for (const cat of cms.menuCategories || []) {
    await sql`
      INSERT INTO menu_categories (id, slug, name, description, is_visible, sort_order)
      VALUES (${cat.id}, ${cat.slug || cat.id}, ${cat.name}, ${cat.description || null}, ${cat.isVisible ?? true}, ${cat.sortOrder || 0})
      ON CONFLICT (id) DO UPDATE SET
        name = EXCLUDED.name,
        slug = EXCLUDED.slug,
        description = EXCLUDED.description,
        is_visible = EXCLUDED.is_visible,
        sort_order = EXCLUDED.sort_order,
        updated_at = NOW();
    `;
    catCount++;
  }
  console.log(`  ✔ Migrated ${catCount} categories.`);

  // 2. MENU ITEMS
  console.log("\n[2/8] Migrating Menu Items...");
  let itemCount = 0;
  for (const item of cms.menuItems || []) {
    await sql`
      INSERT INTO menu_items (
        id, category_id, name, description, price, sale_price,
        is_veg, is_spicy, is_signature, contains_pork, is_available, is_visible,
        image_url, sort_order
      )
      VALUES (
        ${item.id}, ${item.category}, ${item.name}, ${item.description || null},
        ${item.price || "₹180"}, ${item.salePrice || null},
        ${Boolean(item.isVeg)}, ${Boolean(item.isSpicy)}, ${Boolean(item.isSignature)},
        ${Boolean(item.containsPork)}, ${item.isAvailable ?? true}, ${item.isVisible ?? true},
        ${item.image || null}, ${item.sortOrder || 0}
      )
      ON CONFLICT (id) DO UPDATE SET
        category_id = EXCLUDED.category_id,
        name = EXCLUDED.name,
        description = EXCLUDED.description,
        price = EXCLUDED.price,
        sale_price = EXCLUDED.sale_price,
        is_veg = EXCLUDED.is_veg,
        is_spicy = EXCLUDED.is_spicy,
        is_signature = EXCLUDED.is_signature,
        contains_pork = EXCLUDED.contains_pork,
        is_available = EXCLUDED.is_available,
        is_visible = EXCLUDED.is_visible,
        image_url = EXCLUDED.image_url,
        sort_order = EXCLUDED.sort_order,
        updated_at = NOW();
    `;
    itemCount++;
  }
  console.log(`  ✔ Migrated ${itemCount} menu items.`);

  // 3. OUTLETS (BRANCHES)
  console.log("\n[3/8] Migrating Outlets...");
  let outletCount = 0;
  for (const o of cms.outlets || []) {
    await sql`
      INSERT INTO outlets (
        id, slug, name, short_name, address, phone, hours_display,
        daily_hours, is_open, is_featured, temporary_closure_notice,
        google_maps_url, latitude, longitude, swiggy_url, zomato_url,
        image_url, seo_title, meta_description
      )
      VALUES (
        ${o.id}, ${o.slug}, ${o.name}, ${o.shortName || null}, ${o.address},
        ${o.phone}, ${o.hoursDisplay}, ${JSON.stringify(o.dailyHours || [])}::jsonb,
        ${o.isOpen ?? true}, ${o.isFeatured ?? true}, ${o.temporaryClosureNotice || null},
        ${o.googleMapsUrl || null}, ${o.latitude || null}, ${o.longitude || null},
        ${o.swiggyUrl || null}, ${o.zomatoUrl || null}, ${o.image || null},
        ${o.seoTitle || null}, ${o.metaDescription || null}
      )
      ON CONFLICT (id) DO UPDATE SET
        slug = EXCLUDED.slug,
        name = EXCLUDED.name,
        short_name = EXCLUDED.short_name,
        address = EXCLUDED.address,
        phone = EXCLUDED.phone,
        hours_display = EXCLUDED.hours_display,
        daily_hours = EXCLUDED.daily_hours,
        is_open = EXCLUDED.is_open,
        is_featured = EXCLUDED.is_featured,
        temporary_closure_notice = EXCLUDED.temporary_closure_notice,
        google_maps_url = EXCLUDED.google_maps_url,
        latitude = EXCLUDED.latitude,
        longitude = EXCLUDED.longitude,
        swiggy_url = EXCLUDED.swiggy_url,
        zomato_url = EXCLUDED.zomato_url,
        image_url = EXCLUDED.image_url,
        seo_title = EXCLUDED.seo_title,
        meta_description = EXCLUDED.meta_description,
        updated_at = NOW();
    `;
    outletCount++;
  }
  console.log(`  ✔ Migrated ${outletCount} branch outlets.`);

  // 4. OUTLET MENU AVAILABILITY JUNCTION
  console.log("\n[4/8] Initializing Branch-Specific Menu Availability...");
  let availCount = 0;
  for (const o of cms.outlets || []) {
    for (const item of cms.menuItems || []) {
      await sql`
        INSERT INTO outlet_menu_availability (outlet_id, menu_item_id, is_available)
        VALUES (${o.id}, ${item.id}, ${item.isAvailable ?? true})
        ON CONFLICT (outlet_id, menu_item_id) DO NOTHING;
      `;
      availCount++;
    }
  }
  console.log(`  ✔ Initialized ${availCount} branch-menu availability mappings.`);

  // 5. CUSTOMER REVIEWS
  console.log("\n[5/8] Migrating Customer Reviews...");
  let revCount = 0;
  for (const rev of cms.reviews || []) {
    await sql`
      INSERT INTO customer_reviews (
        id, author, avatar_text, rating, date_text, branch_id, branch_name,
        quote, highlight_dish, is_featured, hidden, source
      )
      VALUES (
        ${rev.id}, ${rev.author}, ${rev.avatarText || null}, ${rev.rating || 5},
        ${rev.dateText || "Verified Customer"}, ${rev.branchId || "all"}, ${rev.branchName || "All Locations"},
        ${rev.quote}, ${rev.highlightDish || null}, ${Boolean(rev.isFeatured)},
        ${Boolean(rev.hidden)}, ${rev.source || "google"}
      )
      ON CONFLICT (id) DO UPDATE SET
        author = EXCLUDED.author,
        rating = EXCLUDED.rating,
        quote = EXCLUDED.quote,
        highlight_dish = EXCLUDED.highlight_dish,
        is_featured = EXCLUDED.is_featured,
        hidden = EXCLUDED.hidden,
        updated_at = NOW();
    `;
    revCount++;
  }
  console.log(`  ✔ Migrated ${revCount} customer reviews.`);

  // 6. GALLERY ITEMS
  console.log("\n[6/8] Migrating Gallery Photography...");
  let galCount = 0;
  for (const g of cms.gallery || []) {
    await sql`
      INSERT INTO gallery_items (id, title, category, category_label, src, alt, description, featured, sort_order)
      VALUES (${g.id}, ${g.title}, ${g.category}, ${g.categoryLabel}, ${g.src}, ${g.alt}, ${g.description || null}, ${Boolean(g.featured)}, ${g.sortOrder || 0})
      ON CONFLICT (id) DO UPDATE SET
        title = EXCLUDED.title,
        src = EXCLUDED.src,
        alt = EXCLUDED.alt,
        description = EXCLUDED.description,
        featured = EXCLUDED.featured,
        sort_order = EXCLUDED.sort_order,
        updated_at = NOW();
    `;
    galCount++;
  }
  console.log(`  ✔ Migrated ${galCount} gallery items.`);

  // 7. CUSTOM PAGES
  console.log("\n[7/8] Migrating Custom Pages...");
  let pageCount = 0;
  for (const p of cms.customPages || []) {
    await sql`
      INSERT INTO custom_pages (id, title, slug, subtitle, hero_image, content, blocks, cta_text, cta_link, seo_title, meta_description, is_published)
      VALUES (${p.id}, ${p.title}, ${p.slug}, ${p.subtitle || null}, ${p.heroImage || null}, ${p.content}, ${JSON.stringify(p.blocks || [])}::jsonb, ${p.ctaText || null}, ${p.ctaLink || null}, ${p.seoTitle || null}, ${p.metaDescription || null}, ${p.isPublished ?? true})
      ON CONFLICT (id) DO UPDATE SET
        title = EXCLUDED.title,
        slug = EXCLUDED.slug,
        content = EXCLUDED.content,
        blocks = EXCLUDED.blocks,
        is_published = EXCLUDED.is_published,
        updated_at = NOW();
    `;
    pageCount++;
  }
  console.log(`  ✔ Migrated ${pageCount} custom pages.`);

  // 8. SITE CONTENT MODULAR KEYS
  console.log("\n[8/8] Migrating Modular Site Content Sections...");
  const sections = ["hero", "announcement", "about", "contact", "navigation", "footer", "seo"];
  let secCount = 0;
  for (const sec of sections) {
    if (cms.siteContent && cms.siteContent[sec]) {
      await sql`
        INSERT INTO site_content (key, value, version, updated_at)
        VALUES (${sec}, ${JSON.stringify(cms.siteContent[sec])}::jsonb, 1, NOW())
        ON CONFLICT (key) DO UPDATE SET
          value = EXCLUDED.value,
          version = site_content.version + 1,
          updated_at = NOW();
      `;
      secCount++;
    }
  }
  console.log(`  ✔ Migrated ${secCount} site content modules.`);

  console.log("\n=================================================");
  console.log("✅ DATA MIGRATION COMPLETED WITH 0 ERRORS!");
  console.log("=================================================");
}

migrate().catch(err => {
  console.error("❌ Migration failed:", err);
  process.exit(1);
});
