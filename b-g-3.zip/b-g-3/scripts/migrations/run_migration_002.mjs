#!/usr/bin/env node
import fs from "fs";
import path from "path";
import { neon } from "@neondatabase/serverless";

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("FATAL: DATABASE_URL is not set.");
  process.exit(1);
}

const sql = neon(DATABASE_URL);

async function run() {
  console.log("Applying Migration 002: Refined Relational Schema (Phase 2.1)...");
  const sqlFile = path.join(process.cwd(), "scripts/migrations/002_refined_schema.sql");
  const sqlContent = fs.readFileSync(sqlFile, "utf8");

  // Split statements by semicolon while ignoring dollar-quoted strings
  const statements = sqlContent
    .split(/;\s*$/m)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);

  for (let i = 0; i < statements.length; i++) {
    const stmt = statements[i];
    try {
      await sql.query(stmt);
      console.log(`  [${i + 1}/${statements.length}] Applied statement successfully.`);
    } catch (err) {
      console.error(`  [${i + 1}/${statements.length}] ERROR on statement:`, stmt.slice(0, 80));
      console.error("  ", err.message);
      throw err;
    }
  }

  console.log("Migration 002 applied successfully!");
}

run().catch((err) => {
  console.error("Migration failed:", err);
  process.exit(1);
});
