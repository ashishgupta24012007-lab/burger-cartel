import { neon } from "@neondatabase/serverless";
import * as fs from "fs";
import * as path from "path";

// Load .env.local
if (fs.existsSync(".env.local")) {
  const envContent = fs.readFileSync(".env.local", "utf8");
  for (const line of envContent.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const eqIdx = trimmed.indexOf("=");
    if (eqIdx > 0) {
      const key = trimmed.slice(0, eqIdx).trim();
      let val = trimmed.slice(eqIdx + 1).trim();
      if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
        val = val.slice(1, -1);
      }
      process.env[key] = val;
    }
  }
}

const dbUrl = process.env.DATABASE_URL;
if (!dbUrl) {
  console.error("DATABASE_URL is not set.");
  process.exit(1);
}

const sql = neon(dbUrl);

function slugify(text) {
  return text.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}

async function runMigration() {
  console.log("========================================================");
  console.log("  RUNNING MIGRATION 003: RELATIONAL HARDENING & REVISIONS");
  console.log("========================================================\n");

  const migrationSqlPath = path.join(process.cwd(), "scripts/migrations/003_relational_hardening.sql");
  const rawSql = fs.readFileSync(migrationSqlPath, "utf8");

  // Neon serverless driver accepts queries; we execute the DDL
  console.log("[Stage 1] Executing DDL Schema Updates...");
  
  // Neon execute individual statements
  const statements = rawSql
    .split(/;\s*$/m)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);

  for (let i = 0; i < statements.length; i++) {
    const stmt = statements[i];
    try {
      await sql.query(stmt);
      console.log(`  [${i + 1}/${statements.length}] Applied DDL statement successfully.`);
    } catch (err) {
      console.error(`  [${i + 1}/${statements.length}] ERROR on statement:`, stmt.slice(0, 80));
      console.error("  ", err.message);
      throw err;
    }
  }
  console.log("  ✔ All Migration 003 DDL statements applied successfully.\n");

  // Stage 2: Backfill Relational Variants from data/cms-content.json
  console.log("[Stage 2] Backfilling Menu Item Variants...");
  const rawCms = JSON.parse(fs.readFileSync("data/cms-content.json", "utf8"));
  let variantGroupCount = 0;
  let variantOptionCount = 0;

  for (const item of rawCms.menuItems) {
    if (item.variants && Array.isArray(item.variants) && item.variants.length > 0) {
      const groupId = `${item.id}-variants`;
      const groupName = "Choice of Patty / Style";

      await sql`
        INSERT INTO menu_item_variant_groups (id, menu_item_id, name, min_selections, max_selections, sort_order)
        VALUES (${groupId}, ${item.id}, ${groupName}, 1, 1, 0)
        ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, updated_at = NOW();
      `;
      variantGroupCount++;

      for (let i = 0; i < item.variants.length; i++) {
        const variantName = item.variants[i];
        const variantId = `${item.id}-${slugify(variantName)}`;
        const isDefault = i === 0;

        await sql`
          INSERT INTO menu_item_variants (id, group_id, name, price_delta, is_default, is_available, sort_order)
          VALUES (${variantId}, ${groupId}, ${variantName}, 0.00, ${isDefault}, TRUE, ${i})
          ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, updated_at = NOW();
        `;
        variantOptionCount++;
      }
    }
  }
  console.log(`  ✔ Seeded ${variantGroupCount} variant groups and ${variantOptionCount} relational variants.\n`);

  // Stage 3: Backfill Initial Revisions for all Menu Items
  console.log("[Stage 3] Seeding Initial Revisions for Menu Items...");
  const menuItems = await sql`SELECT * FROM menu_items`;
  let itemRevCount = 0;

  for (const item of menuItems) {
    const version = item.version || 1;
    await sql`
      INSERT INTO menu_item_revisions (
        item_id, version, name, category_id, price, base_price, description, 
        image_url, is_veg, is_popular, is_active, snapshot, committed_by
      ) VALUES (
        ${item.id}, ${version}, ${item.name}, ${item.category_id}, ${item.price}, 
        ${item.base_price}, ${item.description}, ${item.image_url}, ${item.is_veg}, 
        ${item.is_signature}, ${item.is_active}, ${JSON.stringify(item)}, 'system_migration_003'
      )
      ON CONFLICT (item_id, version) DO NOTHING;
    `;
    itemRevCount++;
  }
  console.log(`  ✔ Seeded ${itemRevCount} baseline menu item revisions (v1).\n`);

  // Stage 4: Backfill Initial Revisions for Site Content
  console.log("[Stage 4] Seeding Initial Revisions for Site Content...");
  const contentRows = await sql`SELECT * FROM site_content`;
  let contentRevCount = 0;

  for (const row of contentRows) {
    const version = row.version || 1;
    const content = row.value || row.content_json || {};
    await sql`
      INSERT INTO site_content_revisions (
        key, version, content_json, committed_by
      ) VALUES (
        ${row.key}, ${version}, ${JSON.stringify(content)}, 'system_migration_003'
      )
      ON CONFLICT (key, version) DO NOTHING;
    `;
    contentRevCount++;
  }
  console.log(`  ✔ Seeded ${contentRevCount} baseline site content revisions.\n`);

  console.log("========================================================");
  console.log("  MIGRATION 003 COMPLETED SUCCESSFULLY");
  console.log("========================================================\n");
}

runMigration().catch((err) => {
  console.error("Migration 003 failed:", err);
  process.exit(1);
});
