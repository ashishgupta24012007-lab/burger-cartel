-- ============================================================================
-- BURGER CARTEL MIGRATION 003: RELATIONAL HARDENING & REVISION ENGINE (Wave 1)
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 1. RELATIONAL MENU VARIANTS (3NF Normalization)
CREATE TABLE IF NOT EXISTS menu_item_variant_groups (
    id VARCHAR(64) PRIMARY KEY,
    menu_item_id VARCHAR(64) NOT NULL REFERENCES menu_items(id) ON DELETE CASCADE,
    name VARCHAR(128) NOT NULL,
    min_selections INT NOT NULL DEFAULT 0,
    max_selections INT NOT NULL DEFAULT 1,
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS menu_item_variants (
    id VARCHAR(64) PRIMARY KEY,
    group_id VARCHAR(64) NOT NULL REFERENCES menu_item_variant_groups(id) ON DELETE CASCADE,
    name VARCHAR(128) NOT NULL,
    price_delta NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
    is_default BOOLEAN NOT NULL DEFAULT FALSE,
    is_available BOOLEAN NOT NULL DEFAULT TRUE,
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. IMMUTABLE REVISION TABLES (Domain 4 Publishing Architecture)
CREATE TABLE IF NOT EXISTS menu_item_revisions (
    revision_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    item_id VARCHAR(64) NOT NULL REFERENCES menu_items(id) ON DELETE CASCADE,
    version INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    category_id VARCHAR(64) NOT NULL REFERENCES menu_categories(id) ON DELETE RESTRICT,
    price VARCHAR(32) NOT NULL,
    base_price NUMERIC(10, 2) NOT NULL,
    description TEXT,
    image_url TEXT,
    is_veg BOOLEAN,
    is_popular BOOLEAN,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    snapshot JSONB NOT NULL DEFAULT '{}'::jsonb,
    committed_by VARCHAR(64) NOT NULL DEFAULT 'admin',
    committed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(item_id, version)
);

CREATE TABLE IF NOT EXISTS site_content_revisions (
    revision_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    key VARCHAR(64) NOT NULL REFERENCES site_content(key) ON DELETE CASCADE,
    version INT NOT NULL,
    content_json JSONB NOT NULL,
    committed_by VARCHAR(64) NOT NULL DEFAULT 'admin',
    committed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(key, version)
);

-- 3. RELEASE ITEMS MANIFEST (Selective Staging & Atomic Rollback)
CREATE TABLE IF NOT EXISTS cms_release_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    release_id UUID NOT NULL REFERENCES cms_releases(id) ON DELETE CASCADE,
    entity_type VARCHAR(32) NOT NULL,
    entity_id VARCHAR(64) NOT NULL,
    revision_id UUID,
    version INT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. MULTI-TENANT & BRANCH SCOPING AUTHORIZATION (Domain 3 Security)
CREATE TABLE IF NOT EXISTS admin_user_outlets (
    admin_id UUID NOT NULL REFERENCES admin_users(id) ON DELETE CASCADE,
    outlet_id VARCHAR(64) NOT NULL REFERENCES outlets(id) ON DELETE CASCADE,
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (admin_id, outlet_id)
);

-- 5. DISTRIBUTED RATE LIMITING TABLE (Domain 3 Security)
CREATE TABLE IF NOT EXISTS rate_limit_buckets (
    key VARCHAR(256) PRIMARY KEY,
    tokens INT NOT NULL,
    last_refill TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL
);

-- 6. FOREIGN KEYS AND SECURITY INTEGRITY COLUMNS
ALTER TABLE customer_reviews DROP CONSTRAINT IF EXISTS fk_customer_reviews_outlet;
ALTER TABLE customer_reviews ADD CONSTRAINT fk_customer_reviews_outlet FOREIGN KEY (branch_id) REFERENCES outlets(id) ON DELETE SET NULL;

ALTER TABLE audit_logs 
    ADD COLUMN IF NOT EXISTS admin_user_id UUID REFERENCES admin_users(id) ON DELETE SET NULL,
    ADD COLUMN IF NOT EXISTS prev_hash VARCHAR(64),
    ADD COLUMN IF NOT EXISTS entry_hash VARCHAR(64);

ALTER TABLE cms_backups
    ADD COLUMN IF NOT EXISTS checksum_sha256 VARCHAR(64);

-- 7. B-TREE PERFORMANCE INDEXES
CREATE INDEX IF NOT EXISTS idx_variants_group_id ON menu_item_variants(group_id);
CREATE INDEX IF NOT EXISTS idx_variant_groups_item_id ON menu_item_variant_groups(menu_item_id);
CREATE INDEX IF NOT EXISTS idx_revisions_item_version ON menu_item_revisions(item_id, version DESC);
CREATE INDEX IF NOT EXISTS idx_content_revisions_key_version ON site_content_revisions(key, version DESC);
CREATE INDEX IF NOT EXISTS idx_release_items_release ON cms_release_items(release_id);
CREATE INDEX IF NOT EXISTS idx_admin_user_outlets_admin ON admin_user_outlets(admin_id);
CREATE INDEX IF NOT EXISTS idx_admin_user_outlets_outlet ON admin_user_outlets(outlet_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_timestamp ON audit_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_admin_id ON audit_logs(admin_id);
CREATE INDEX IF NOT EXISTS idx_rate_limit_expires ON rate_limit_buckets(expires_at);
