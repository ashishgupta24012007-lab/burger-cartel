-- ====================================================================
-- BURGER CARTEL PRODUCTION RELATIONAL SCHEMA MIGRATION 001
-- Target: Managed PostgreSQL (Neon / Standard PostgreSQL)
-- Standard: ACID Compliant, Foreign Keys, JSONB Document Stores, RBAC
-- ====================================================================

-- 1. MENU CATEGORIES
CREATE TABLE IF NOT EXISTS menu_categories (
  id VARCHAR(64) PRIMARY KEY,
  slug VARCHAR(64) UNIQUE NOT NULL,
  name VARCHAR(128) NOT NULL,
  description TEXT,
  is_visible BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. MENU ITEMS
CREATE TABLE IF NOT EXISTS menu_items (
  id VARCHAR(64) PRIMARY KEY,
  category_id VARCHAR(64) NOT NULL REFERENCES menu_categories(id) ON DELETE CASCADE,
  name VARCHAR(128) NOT NULL,
  description TEXT,
  price VARCHAR(32) NOT NULL,
  sale_price VARCHAR(32),
  is_veg BOOLEAN NOT NULL DEFAULT FALSE,
  is_spicy BOOLEAN NOT NULL DEFAULT FALSE,
  is_signature BOOLEAN NOT NULL DEFAULT FALSE,
  contains_pork BOOLEAN NOT NULL DEFAULT FALSE,
  is_available BOOLEAN NOT NULL DEFAULT TRUE,
  is_visible BOOLEAN NOT NULL DEFAULT TRUE,
  image_url TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. OUTLETS (BRANCHES)
CREATE TABLE IF NOT EXISTS outlets (
  id VARCHAR(64) PRIMARY KEY,
  slug VARCHAR(64) UNIQUE NOT NULL,
  name VARCHAR(128) NOT NULL,
  short_name VARCHAR(64),
  address TEXT NOT NULL,
  phone VARCHAR(64) NOT NULL,
  hours_display VARCHAR(128) NOT NULL,
  daily_hours JSONB NOT NULL DEFAULT '[]'::jsonb,
  is_open BOOLEAN NOT NULL DEFAULT TRUE,
  is_featured BOOLEAN NOT NULL DEFAULT TRUE,
  temporary_closure_notice TEXT,
  google_maps_url TEXT,
  latitude NUMERIC(10, 7),
  longitude NUMERIC(10, 7),
  swiggy_url TEXT,
  zomato_url TEXT,
  image_url TEXT,
  seo_title TEXT,
  meta_description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. OUTLET-SPECIFIC MENU AVAILABILITY (Solves H-02: Branch-level inventory)
CREATE TABLE IF NOT EXISTS outlet_menu_availability (
  outlet_id VARCHAR(64) NOT NULL REFERENCES outlets(id) ON DELETE CASCADE,
  menu_item_id VARCHAR(64) NOT NULL REFERENCES menu_items(id) ON DELETE CASCADE,
  is_available BOOLEAN NOT NULL DEFAULT TRUE,
  PRIMARY KEY (outlet_id, menu_item_id)
);

-- 5. CUSTOMER REVIEWS
CREATE TABLE IF NOT EXISTS customer_reviews (
  id VARCHAR(64) PRIMARY KEY,
  author VARCHAR(128) NOT NULL,
  avatar_text VARCHAR(16),
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  date_text VARCHAR(64) NOT NULL,
  branch_id VARCHAR(64) NOT NULL,
  branch_name VARCHAR(128) NOT NULL,
  quote TEXT NOT NULL,
  highlight_dish VARCHAR(128),
  is_featured BOOLEAN NOT NULL DEFAULT FALSE,
  hidden BOOLEAN NOT NULL DEFAULT FALSE,
  source VARCHAR(32) NOT NULL DEFAULT 'google',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. GALLERY ITEMS
CREATE TABLE IF NOT EXISTS gallery_items (
  id VARCHAR(64) PRIMARY KEY,
  title VARCHAR(128) NOT NULL,
  category VARCHAR(32) NOT NULL,
  category_label VARCHAR(64) NOT NULL,
  src TEXT NOT NULL,
  alt TEXT NOT NULL,
  description TEXT,
  featured BOOLEAN NOT NULL DEFAULT FALSE,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 7. CUSTOM PAGES (No-Code Page Builder)
CREATE TABLE IF NOT EXISTS custom_pages (
  id VARCHAR(64) PRIMARY KEY,
  title VARCHAR(256) NOT NULL,
  slug VARCHAR(128) UNIQUE NOT NULL,
  subtitle TEXT,
  hero_image TEXT,
  content TEXT NOT NULL,
  blocks JSONB NOT NULL DEFAULT '[]'::jsonb,
  cta_text VARCHAR(128),
  cta_link TEXT,
  seo_title TEXT,
  meta_description TEXT,
  is_published BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 8. SITE CONTENT (Modular Key-Value JSONB store with optimistic locking)
CREATE TABLE IF NOT EXISTS site_content (
  key VARCHAR(64) PRIMARY KEY,
  value JSONB NOT NULL,
  version INTEGER NOT NULL DEFAULT 1,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 9. ADMINISTRATORS (RBAC)
CREATE TABLE IF NOT EXISTS admin_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id VARCHAR(64) UNIQUE NOT NULL,
  password_hash VARCHAR(256) NOT NULL,
  salt VARCHAR(64) NOT NULL,
  role VARCHAR(32) NOT NULL DEFAULT 'superadmin',
  must_change_password BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 10. ADMIN SESSIONS (Distributed serverless session store)
CREATE TABLE IF NOT EXISTS admin_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  token_hash VARCHAR(128) UNIQUE NOT NULL,
  admin_id VARCHAR(64) NOT NULL REFERENCES admin_users(admin_id) ON DELETE CASCADE,
  ip VARCHAR(45) NOT NULL,
  user_agent VARCHAR(255) NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 11. AUDIT LOGS
CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event VARCHAR(64) NOT NULL,
  admin_id VARCHAR(64),
  ip VARCHAR(45),
  details TEXT,
  timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 12. CMS SNAPSHOT BACKUPS
CREATE TABLE IF NOT EXISTS cms_backups (
  id VARCHAR(64) PRIMARY KEY,
  label VARCHAR(128) NOT NULL,
  data_snippet TEXT,
  data JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- INDEXES FOR FAST QUERYING
CREATE INDEX IF NOT EXISTS idx_menu_items_category ON menu_items(category_id);
CREATE INDEX IF NOT EXISTS idx_menu_items_visible ON menu_items(is_visible, sort_order);
CREATE INDEX IF NOT EXISTS idx_reviews_branch ON customer_reviews(branch_id, hidden);
CREATE INDEX IF NOT EXISTS idx_sessions_token ON admin_sessions(token_hash);
CREATE INDEX IF NOT EXISTS idx_sessions_expires ON admin_sessions(expires_at);
CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_logs(timestamp DESC);
