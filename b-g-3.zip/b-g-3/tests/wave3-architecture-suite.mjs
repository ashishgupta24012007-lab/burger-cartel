/**
 * BURGER CARTEL — WAVE 3 COMPREHENSIVE ARCHITECTURAL & SECURITY TEST SUITE
 * 
 * Verifies all Wave 3 P0, P1, and P2 implementations:
 * 1. PostgreSQL Authentication & Session Persistence
 * 2. Central Server-Side RBAC & 403 Matrix Verification
 * 3. Branch Isolation across all 5 Outlets
 * 4. PostgreSQL Backup, Checksum Integrity & Atomic Restore
 * 5. Immutable Content Publishing, Release Manifests & Rollback
 * 6. Authoritative Branch Availability & Price Override Consolidation
 * 7. Sharp Media Pipeline, Magic Bytes & 16MP Bomb Defense
 * 8. Base Price Numeric Authority, ₹0 Handling & Optimistic Concurrency Locking
 * 9. Public API Draft Filtering Verification
 * 10. Dynamic Branch Routing & Dynamic Sitemap via Live HTTP Server
 */

import { neon } from "@neondatabase/serverless";
import fs from "fs";
import path from "path";
import sharp from "sharp";

// Load environment variables
const envPath = path.resolve(process.cwd(), ".env.local");
if (fs.existsSync(envPath)) {
  const envContent = fs.readFileSync(envPath, "utf-8");
  for (const line of envContent.split("\n")) {
    const trimmed = line.trim();
    if (trimmed && !trimmed.startsWith("#")) {
      const [key, ...rest] = trimmed.split("=");
      if (key && rest.length > 0 && !process.env[key]) {
        process.env[key] = rest.join("=").replace(/^["']|["']$/g, "");
      }
    }
  }
}

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("❌ DATABASE_URL is not set.");
  process.exit(1);
}

const sql = neon(DATABASE_URL);

let passedTests = 0;
let failedTests = 0;

function assert(condition, testName, details = "") {
  if (condition) {
    console.log(`  ✅ [PASS] ${testName}`);
    passedTests++;
  } else {
    console.error(`  ❌ [FAIL] ${testName} ${details ? `(${details})` : ""}`);
    failedTests++;
  }
}

async function runSuite() {
  console.log("\n=======================================================");
  console.log("   BURGER CARTEL — WAVE 3 ARCHITECTURE & SECURITY SUITE");
  console.log("=======================================================\n");

  let superadminUser = null;

  // ---------------------------------------------------------
  // TEST 1: PostgreSQL Authentication & Session Persistence
  // ---------------------------------------------------------
  console.log("--- 1. PostgreSQL Auth & Session Persistence ---");
  try {
    const adminRows = await sql`
      SELECT u.id, u.admin_id, u.role_id, r.permissions
      FROM admin_users u
      LEFT JOIN admin_roles r ON u.role_id = r.id;
    `;
    assert(adminRows.length > 0, "Active admin users persist in PostgreSQL admin_users", `Found ${adminRows.length} users`);
    superadminUser = adminRows.find((a) => a.role_id === "superadmin") || adminRows[0];
    assert(Boolean(superadminUser), "Authoritative superadmin role exists in database", `Superadmin ID: ${superadminUser?.admin_id}`);

    // Verify session table schema
    const sessionCols = await sql`
      SELECT column_name FROM information_schema.columns WHERE table_name = 'admin_sessions';
    `;
    const colNames = sessionCols.map((c) => c.column_name);
    assert(
      colNames.includes("token_hash") && colNames.includes("admin_id") && colNames.includes("revoked"),
      "admin_sessions table has token_hash, admin_id, and revoked columns"
    );
  } catch (err) {
    assert(false, "PostgreSQL Auth persistence check", err.message);
  }

  // ---------------------------------------------------------
  // TEST 2: Central Server-Side RBAC Matrix Enforcement
  // ---------------------------------------------------------
  console.log("\n--- 2. Central Server-Side RBAC Enforcement ---");
  try {
    const { verifyRbacPermission, ACTION_PERMISSION_MATRIX } = await import("../src/lib/auth/rbac.ts");
    assert(Boolean(ACTION_PERMISSION_MATRIX), "Server-side action permission matrix is defined");
    assert(ACTION_PERMISSION_MATRIX["PUBLISH_ALL"] === "cms:publish", "PUBLISH_ALL requires 'cms:publish'");
    assert(ACTION_PERMISSION_MATRIX["CREATE_BACKUP"] === "system:admin", "CREATE_BACKUP requires 'system:admin'");
    assert(ACTION_PERMISSION_MATRIX["UPDATE_OUTLET"] === "outlets:update", "UPDATE_OUTLET requires 'outlets:update'");

    // Test editor session denying publish
    const editorSession = {
      id: "test-editor-id",
      adminId: "editor-user",
      roleId: "editor",
      permissions: ["cms:draft"],
    };
    const rbacPublishDenied = await verifyRbacPermission(editorSession, "PUBLISH_ALL");
    assert(!rbacPublishDenied.authorized && rbacPublishDenied.status === 403, "Editor without cms:publish is rejected with HTTP 403");

    // Test superadmin session allowing publish
    const superadminSession = {
      id: superadminUser?.id || "superadmin-uuid",
      adminId: superadminUser?.admin_id || "admin",
      roleId: "superadmin",
      permissions: ["*"],
    };
    const rbacPublishAllowed = await verifyRbacPermission(superadminSession, "PUBLISH_ALL");
    assert(rbacPublishAllowed.authorized === true, "Superadmin wildcard (*) authorizes PUBLISH_ALL");
  } catch (err) {
    assert(false, "RBAC test execution", err.message);
  }

  // ---------------------------------------------------------
  // TEST 3: Branch Isolation Across All 5 Outlets
  // ---------------------------------------------------------
  console.log("\n--- 3. Branch Isolation Across All 5 Outlets ---");
  try {
    const { assertAuthorizedForOutlet } = await import("../src/lib/auth/branchAuth.ts");
    const outlets = ["darjeeling", "kurseong", "panchanai", "pradhan-nagar", "shivmandir"];

    // Verify all 5 outlets exist in database
    const dbOutlets = await sql`SELECT slug FROM outlets WHERE slug = ANY(${outlets});`;
    assert(dbOutlets.length === 5, "All 5 restaurant branches exist in PostgreSQL outlets table", `Found ${dbOutlets.length}/5`);

    // Superadmin has access to all 5
    let superadminAllFive = true;
    for (const slug of outlets) {
      const auth = await assertAuthorizedForOutlet(superadminUser.id, slug);
      if (!auth) superadminAllFive = false;
    }
    assert(superadminAllFive, "Superadmin is authorized across all 5 physical outlets");

    // Mock branch manager for darjeeling
    const { verifyRbacPermission } = await import("../src/lib/auth/rbac.ts");
    const darjeelingManager = {
      id: "00000000-0000-0000-0000-000000000002",
      adminId: "mgr-darjeeling",
      roleId: "branch_manager",
      assignedOutletId: "darjeeling",
      permissions: ["outlets:update", "inventory:override"],
    };

    // Attempt unauthorized access to kurseong
    const crossBranchDenied = await verifyRbacPermission(darjeelingManager, "UPDATE_OUTLET", { outletId: "kurseong" });
    assert(!crossBranchDenied.authorized && crossBranchDenied.status === 403, "Darjeeling branch manager modifying Kurseong returns HTTP 403 Forbidden");
  } catch (err) {
    assert(false, "Branch isolation test", err.message);
  }

  // ---------------------------------------------------------
  // TEST 4: PostgreSQL Backup, SHA-256 Checksum & Restore
  // ---------------------------------------------------------
  console.log("\n--- 4. PostgreSQL Backup, SHA-256 Checksum & Restore ---");
  try {
    const { createDatabaseSnapshot, listDatabaseSnapshots, restoreDatabaseSnapshot } = await import("../src/lib/db/cmsBackupRepository.ts");
    
    // Create snapshot
    const testLabel = `Automated Wave 3 Test Snapshot ${Date.now()}`;
    const snapshot = await createDatabaseSnapshot(testLabel, "test-suite");
    assert(Boolean(snapshot.id), "Database snapshot created in PostgreSQL cms_backups", `ID: ${snapshot.id}`);
    assert(typeof snapshot.checksumSha256 === "string" && snapshot.checksumSha256.length === 64, "Snapshot has cryptographically verified SHA-256 checksum", snapshot.checksumSha256);

    // List snapshots
    const snapshots = await listDatabaseSnapshots();
    const found = snapshots.find((s) => s.id === snapshot.id);
    assert(Boolean(found), "Snapshot appears in listDatabaseSnapshots()", `Total snapshots: ${snapshots.length}`);

    // Restore snapshot
    const restoreResult = await restoreDatabaseSnapshot(snapshot.id, "test-suite");
    assert(restoreResult.success === true, "Atomic snapshot restoration completed with cryptographic integrity check", `Restored ${restoreResult.verifiedItemsCount} items`);
  } catch (err) {
    assert(false, "Backup and restore test", err.message);
  }

  // ---------------------------------------------------------
  // TEST 5: Immutable Content Publishing & Releases
  // ---------------------------------------------------------
  console.log("\n--- 5. Immutable Content Publishing & Releases ---");
  try {
    const { recordMenuItemRevision, publishReleaseManifest } = await import("../src/lib/db/cmsPublishing.ts");

    // 1. Record immutable revision for a test menu item
    const testItemId = "the-classic";
    const testItem = {
      id: testItemId,
      category: "burgers",
      name: "The Classic Smash Burger",
      price: "₹180",
      basePrice: 180,
      description: "Tested revision burger",
      isVegetarian: false,
      isHouseFavourite: true,
      isAvailable: true,
      isVisible: true,
      sortOrder: 1,
    };

    const revId = await recordMenuItemRevision(testItem, "test-suite", 2);
    assert(Boolean(revId) && revId.length === 36, "Immutable revision created in menu_item_revisions", `Revision UUID: ${revId}`);

    // 2. Publish explicit release manifest containing approved revision
    const release = await publishReleaseManifest({
      label: `Wave 3 Verified Release ${Date.now()}`,
      description: "Automated test release",
      publishedBy: "test-suite",
      approvedItemIds: [testItemId],
    });
    assert(release.isActive === true, "Release published and activated in cms_releases", `Release v${release.releaseNumber}`);
    assert(release.snapshotManifest.menuItems.some((m) => m.id === testItemId), "Release manifest includes approved menu item");

    // 3. Verify item in menu_items is published
    const itemInDb = await sql`SELECT publication_status, is_active FROM menu_items WHERE id = ${testItemId} LIMIT 1;`;
    assert(itemInDb[0]?.publication_status === "published", "Menu item publication_status is marked 'published' in PostgreSQL");
  } catch (err) {
    assert(false, "Publishing test", err.message);
  }

  // ---------------------------------------------------------
  // TEST 6: Branch Availability & Price Override Consolidation
  // ---------------------------------------------------------
  console.log("\n--- 6. Branch Availability & Price Override Consolidation ---");
  try {
    const { setOutletMenuAvailability, setOutletMenuPriceOverride, getOutletMenuAvailability } = await import("../src/lib/db/cmsRepository.ts");

    const testOutlet = "panchanai";
    const testItem = "the-classic";

    // Step A: Mark item UNAVAILABLE at panchanai
    await setOutletMenuAvailability(testOutlet, testItem, false);
    const availMap = await getOutletMenuAvailability(testOutlet);
    assert(availMap[testItem] === false, "Item marked unavailable at Panchanai branch");

    // Step B: Set price override for this item at panchanai
    // CRITICAL: Changing price override MUST NOT reset availability to true!
    await setOutletMenuPriceOverride(testOutlet, testItem, 220);

    const checkRow = await sql`
      SELECT is_available, price_override FROM outlet_menu_overrides
      WHERE outlet_id = ${testOutlet} AND menu_item_id = ${testItem}
      LIMIT 1;
    `;
    assert(Number(checkRow[0]?.price_override) === 220, "Price override persisted at ₹220");
    assert(checkRow[0]?.is_available === false, "CRITICAL: Price override preserved item's UNAVAILABLE state (did NOT reset to true)");

    // Restore item to available
    await setOutletMenuAvailability(testOutlet, testItem, true);
    await setOutletMenuPriceOverride(testOutlet, testItem, null);
  } catch (err) {
    assert(false, "Branch availability consolidation test", err.message);
  }

  // ---------------------------------------------------------
  // TEST 7: Sharp Media Processing & 16MP Bomb Defense
  // ---------------------------------------------------------
  console.log("\n--- 7. Sharp Media Processing & 16MP Bomb Defense ---");
  try {
    const { processAndStoreMedia } = await import("../src/lib/storage/mediaStorage.ts");

    // 1. Valid test image creation (800x600 PNG)
    const validPng = await sharp({
      create: {
        width: 800,
        height: 600,
        channels: 3,
        background: { r: 180, g: 60, b: 30 },
      },
    }).png().toBuffer();

    const processed = await processAndStoreMedia(validPng, "burger-test.png");
    assert(processed.mimeType === "image/webp", "Processed image output converted to WebP format");
    assert(processed.variants.length === 2, "Generated 2 responsive WebP variants (md: 800w, sm: 400w)");
    assert(processed.variants.every((v) => v.format === "webp" && v.width <= 800), "Variants conform to maximum responsive dimensions");

    // 2. Decompression Bomb Defense: 25MP (> 16MP limit)
    let bombRejected = false;
    try {
      const hugeImage = await sharp({
        create: {
          width: 5000,
          height: 5000, // 25MP > 16MP
          channels: 3,
          background: { r: 0, g: 0, b: 0 },
        },
      }).png().toBuffer();
      await processAndStoreMedia(hugeImage, "bomb.png");
    } catch (bombErr) {
      if (bombErr.message.includes("16 Megapixels") || bombErr.message.includes("limit") || bombErr.message.includes("boundary")) {
        bombRejected = true;
      }
    }
    assert(bombRejected, "Decompression bomb (>16MP) was rejected before processing");
  } catch (err) {
    assert(false, "Media processing test", err.message);
  }

  // ---------------------------------------------------------
  // TEST 8: Base Price Numeric Authority, ₹0 Handling & Optimistic Locking
  // ---------------------------------------------------------
  console.log("\n--- 8. Base Price Authority, ₹0 & Optimistic Concurrency ---");
  try {
    const { saveMenuItem, ConcurrencyConflictError } = await import("../src/lib/db/cmsRepository.ts");

    // 1. ₹0 price test: Condiment/Free add-on must stay 0 and NOT default to 180!
    const zeroPriceItem = {
      id: "test-condiment-zero",
      category: "sides",
      name: "Free Secret House Sauce",
      price: "₹0",
      basePrice: 0,
      description: "Complimentary signature dip",
      isVegetarian: true,
      isAvailable: true,
      isVisible: true,
      sortOrder: 99,
    };

    await saveMenuItem(zeroPriceItem, undefined, "published", "test-suite");
    const zeroDbRow = await sql`
      SELECT price, base_price, is_veg, is_vegetarian, version
      FROM menu_items WHERE id = 'test-condiment-zero' LIMIT 1;
    `;
    assert(Number(zeroDbRow[0]?.base_price) === 0, "Base price 0 correctly stored as numeric 0 (not replaced by 180)");
    assert(zeroDbRow[0]?.is_veg === true && zeroDbRow[0]?.is_vegetarian === true, "Dual vegetarian flags (is_veg and is_vegetarian) synchronized");

    // 2. Optimistic Concurrency Conflict Test
    const currentVersion = Number(zeroDbRow[0]?.version) || 1;
    const staleVersion = currentVersion - 1; // Stale version simulates concurrent administrator modification

    let conflictCaught = false;
    try {
      await saveMenuItem(
        { ...zeroPriceItem, name: "Conflicting Update" },
        staleVersion,
        "draft",
        "concurrent-admin"
      );
    } catch (conflictErr) {
      if (conflictErr instanceof ConcurrencyConflictError) {
        conflictCaught = true;
      }
    }
    assert(conflictCaught, "Conditional database update detected version mismatch and threw ConcurrencyConflictError");

    // Cleanup test item
    await sql`DELETE FROM menu_items WHERE id = 'test-condiment-zero';`;
    await sql`DELETE FROM menu_item_revisions WHERE item_id = 'test-condiment-zero';`;
  } catch (err) {
    assert(false, "Price authority & concurrency test", err.message);
  }

  // ---------------------------------------------------------
  // TEST 9: Public API Draft Filtering Verification
  // ---------------------------------------------------------
  console.log("\n--- 9. Public API Draft Filtering Verification ---");
  try {
    const { getCmsData, saveMenuItem } = await import("../src/lib/db/cmsRepository.ts");

    // Create an explicit draft item
    const draftItem = {
      id: "unreleased-secret-burger",
      category: "burgers",
      name: "Top Secret Unreleased Wagyu Burger",
      price: "₹999",
      basePrice: 999,
      isVegetarian: false,
      isAvailable: true,
      isVisible: true,
      sortOrder: 1,
    };
    await saveMenuItem(draftItem, undefined, "draft", "test-suite");

    // Test getCmsData({ publishedOnly: true }) which powers public site
    const publicData = await getCmsData({ publishedOnly: true });
    const draftFound = publicData.menuItems.some((m) => m.id === "unreleased-secret-burger");
    assert(!draftFound, "CRITICAL: Draft unreleased menu item is strictly EXCLUDED from public getCmsData({ publishedOnly: true })");

    // Test getCmsData({ publishedOnly: false }) which powers admin CMS
    const adminData = await getCmsData({ publishedOnly: false });
    const draftInAdmin = adminData.menuItems.some((m) => m.id === "unreleased-secret-burger");
    assert(draftInAdmin, "Draft menu item is present in Admin CMS view for review & approval");

    // Cleanup draft item
    await sql`DELETE FROM menu_items WHERE id = 'unreleased-secret-burger';`;
    await sql`DELETE FROM menu_item_revisions WHERE item_id = 'unreleased-secret-burger';`;
  } catch (err) {
    assert(false, "Public API draft filtering test", err.message);
  }

  // ---------------------------------------------------------
  // TEST 10: Dynamic Branch Routing & Dynamic Sitemap via HTTP
  // ---------------------------------------------------------
  console.log("\n--- 10. Dynamic Branch Routing & Dynamic Sitemap via HTTP ---");
  try {
    // Test public CMS content endpoint
    const resContent = await fetch("http://localhost:3000/api/cms/content");
    assert(resContent.ok, "HTTP GET /api/cms/content returned status 200 OK");
    const jsonContent = await resContent.json();
    assert(Array.isArray(jsonContent.menuItems) && jsonContent.menuItems.length > 0, "Public CMS API returns menu items", `Found ${jsonContent.menuItems.length} items`);
    assert(Array.isArray(jsonContent.outlets) && jsonContent.outlets.length >= 5, "Public CMS API returns all 5 outlets", `Found ${jsonContent.outlets.length} outlets`);

    // Test dynamic locations page
    const resLocation = await fetch("http://localhost:3000/locations/panchanai");
    assert(resLocation.ok, "HTTP GET /locations/panchanai returned 200 OK");

    // Test non-existent outlet returns 404 / notFound (no resurrection from static fallback)
    const resInvalid = await fetch("http://localhost:3000/locations/non-existent-ghost-outlet");
    const htmlInvalid = await resInvalid.text();
    const isNotFoundTriggered = resInvalid.status === 404 || htmlInvalid.includes("__next_error__") || htmlInvalid.includes("OFF THE MENU");
    assert(isNotFoundTriggered, "HTTP GET /locations/non-existent-ghost-outlet strictly triggers notFound() (no static fallback resurrection)");

    // Test sitemap
    const resSitemap = await fetch("http://localhost:3000/sitemap.xml");
    assert(resSitemap.ok, "HTTP GET /sitemap.xml returned 200 OK");
    const xml = await resSitemap.text();
    assert(xml.includes("/locations/panchanai") && xml.includes("/locations/darjeeling"), "Sitemap dynamically contains physical outlet landing pages");
  } catch (err) {
    assert(false, "Dynamic HTTP routes test", err.message);
  }

  // ---------------------------------------------------------
  // SUMMARY
  // ---------------------------------------------------------
  console.log("\n=======================================================");
  console.log(`   TOTAL TESTS: ${passedTests + failedTests}`);
  console.log(`   PASSED:      ${passedTests}`);
  console.log(`   FAILED:      ${failedTests}`);
  console.log("=======================================================\n");

  if (failedTests > 0) {
    process.exit(1);
  }
}

runSuite().catch((err) => {
  console.error("Test suite crashed:", err);
  process.exit(1);
});
