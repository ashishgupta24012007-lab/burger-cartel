#!/usr/bin/env node

/**
 * Burger Cartel Controlled Bot & Abuse-Resilience Runner
 * 
 * Safely executes staged abuse simulations against localhost in accordance with
 * Phase 3 Rules of Engagement.
 */

import http from "node:http";
import { performance } from "node:perf_hooks";

const TARGET_HOST = process.env.TARGET_URL || "http://localhost:3001";
const parsedTarget = new URL(TARGET_HOST);

const ALLOWED_HOSTS = ["localhost", "127.0.0.1", "::1"];
if (!ALLOWED_HOSTS.includes(parsedTarget.hostname)) {
  console.error(`\x1b[31m[SCOPE GUARD] Target ${parsedTarget.hostname} is outside the allowed hosts!\x1b[0m`);
  process.exit(1);
}

const STAGES = [
  { name: "Stage 0: Smoke Verification", concurrency: 2, totalRequests: 20 },
  { name: "Stage 1: Low Concurrency", concurrency: 10, totalRequests: 200 },
  { name: "Stage 2: Moderate Concurrency", concurrency: 30, totalRequests: 600 },
  { name: "Stage 3: High Concurrency", concurrency: 50, totalRequests: 1200 },
];

const SCENARIOS = [
  // Scenario 1: Cache-busting public flood
  {
    name: "Cache-Busting Query Flooding",
    makeRequest: (i) => ({
      path: `/?cb=${Date.now()}_${i}&rand=${Math.random()}`,
      method: "GET",
      headers: { "User-Agent": "BotStressTester/1.0" },
    }),
  },
  // Scenario 2: High-frequency protected API probing
  {
    name: "Unauthenticated API Probing",
    makeRequest: (i) => ({
      path: i % 2 === 0 ? "/api/admin/dashboard" : "/api/admin/cms",
      method: "GET",
      headers: { "User-Agent": "BotScanner/2.1" },
    }),
  },
  // Scenario 3: Login brute-force with spoofed X-Forwarded-For prefixes
  {
    name: "Login Brute Force with Spoofed Forwarded Headers",
    makeRequest: (i) => ({
      path: "/api/admin/auth/login",
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Forwarded-For": `192.168.1.${i % 250}, 10.0.0.${i % 100}, 127.0.0.1`,
        "User-Agent": "CredentialStuffer/3.0",
      },
      body: JSON.stringify({
        adminId: `admin_target_${i % 3}`,
        password: `PasswordAttempt_${i}!`,
      }),
    }),
  },
  // Scenario 4: Malformed input injection
  {
    name: "Malformed & Oversized Payloads",
    makeRequest: (i) => ({
      path: "/api/admin/auth/login",
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        adminId: "X".repeat(500),
        password: "Y".repeat(1000),
      }),
    }),
  },
];

function sendHttp({ path, method, headers, body }) {
  return new Promise((resolve) => {
    const t0 = performance.now();
    const req = http.request(
      {
        hostname: parsedTarget.hostname,
        port: parsedTarget.port,
        path,
        method,
        headers,
        timeout: 5000,
      },
      (res) => {
        let respData = "";
        res.on("data", (chunk) => {
          respData += chunk;
        });
        res.on("end", () => {
          const duration = performance.now() - t0;
          resolve({
            statusCode: res.statusCode,
            duration,
            success: true,
          });
        });
      }
    );

    req.on("error", (err) => {
      const duration = performance.now() - t0;
      resolve({
        statusCode: 0,
        duration,
        success: false,
        error: err.message,
      });
    });

    req.on("timeout", () => {
      req.destroy();
      const duration = performance.now() - t0;
      resolve({
        statusCode: 408,
        duration,
        success: false,
        error: "Timeout",
      });
    });

    if (body) {
      req.write(body);
    }
    req.end();
  });
}

function calculatePercentiles(latencies) {
  if (latencies.length === 0) return { p50: 0, p90: 0, p95: 0, p99: 0 };
  const sorted = [...latencies].sort((a, b) => a - b);
  const p = (pct) => sorted[Math.floor((pct / 100) * sorted.length)] || sorted[sorted.length - 1];
  return {
    p50: p(50).toFixed(1),
    p90: p(90).toFixed(1),
    p95: p(95).toFixed(1),
    p99: p(99).toFixed(1),
  };
}

async function runStage(stageConfig) {
  console.log(`\n--- Starting ${stageConfig.name} (${stageConfig.totalRequests} reqs, concurrency: ${stageConfig.concurrency}) ---`);
  const statusCodes = {};
  const latencies = [];
  let completed = 0;
  let errors5xx = 0;

  const tStart = performance.now();

  async function worker(workerId) {
    let reqIdx = workerId;
    while (reqIdx < stageConfig.totalRequests) {
      const scenario = SCENARIOS[reqIdx % SCENARIOS.length];
      const reqConfig = scenario.makeRequest(reqIdx);
      const res = await sendHttp(reqConfig);

      statusCodes[res.statusCode] = (statusCodes[res.statusCode] || 0) + 1;
      latencies.push(res.duration);
      if (res.statusCode >= 500) errors5xx++;

      reqIdx += stageConfig.concurrency;
      completed++;
    }
  }

  const workers = [];
  for (let w = 0; w < stageConfig.concurrency; w++) {
    workers.push(worker(w));
  }
  await Promise.all(workers);

  const totalTimeSec = (performance.now() - tStart) / 1000;
  const throughput = (completed / totalTimeSec).toFixed(1);
  const percentiles = calculatePercentiles(latencies);

  console.log(`  Completed: ${completed} requests in ${totalTimeSec.toFixed(2)}s (${throughput} req/s)`);
  console.log(`  Latencies: p50=${percentiles.p50}ms, p90=${percentiles.p90}ms, p95=${percentiles.p95}ms, p99=${percentiles.p99}ms`);
  console.log(`  Status Distribution:`, statusCodes);
  console.log(`  5xx Server Errors: ${errors5xx} (Rate: ${((errors5xx / completed) * 100).toFixed(2)}%)`);

  // Stop Condition Checks
  const errRate = (errors5xx / completed) * 100;
  if (errRate > 2) {
    throw new Error(`Stop condition triggered! 5xx error rate ${errRate.toFixed(2)}% exceeds 2% ceiling.`);
  }
  if (parseFloat(percentiles.p95) > 2000) {
    console.warn(`  [WARNING] p95 latency (${percentiles.p95}ms) exceeded 2000ms threshold.`);
  }

  return {
    stage: stageConfig.name,
    requests: completed,
    durationSec: totalTimeSec.toFixed(2),
    throughputReqSec: throughput,
    percentiles,
    statusCodes,
    errors5xx,
  };
}

async function main() {
  console.log("========================================================");
  console.log("  BURGER CARTEL BOT & ABUSE-RESILIENCE TEST CAMPAIGN");
  console.log(`  Target: ${TARGET_HOST} (Scope Guard: ACTIVE)`);
  console.log("========================================================");

  const stageResults = [];

  for (const stage of STAGES) {
    const res = await runStage(stage);
    stageResults.push(res);
  }

  console.log("\n========================================================");
  console.log("  ALL LOAD STAGES COMPLETED SUCCESSFULLY");
  console.log("========================================================\n");

  // Output JSON report for audit documentation
  console.log(JSON.stringify(stageResults, null, 2));
}

main().catch((err) => {
  console.error("\n[CAMPAIGN ABORTED]:", err.message);
  process.exit(1);
});
