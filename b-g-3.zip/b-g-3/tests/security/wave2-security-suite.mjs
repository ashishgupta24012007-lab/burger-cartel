/**
 * Wave 2 Security & Scoping Automated Verification Suite
 * 
 * Verifies:
 *   [Test Group 1] Asynchronous Scrypt Cryptographic Integrity & Throttling
 *   [Test Group 2] Distributed Database Rate Limiting (rate_limit_buckets)
 *   [Test Group 3] Branch-Level Authorization & RBAC (admin_user_outlets)
 *   [Test Group 4] Session Cookie RFC 6265bis __Host- Hardening & CSRF
 */

import { neon } from "@neondatabase/serverless";
import crypto from "crypto";

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("FATAL: DATABASE_URL environment variable is required.");
  process.exit(1);
}

const sql = neon(DATABASE_URL);

let passed = 0;
let failed = 0;

function assert(condition, message) {
  if (condition) {
    console.log(`  ✔ ${message}`);
    passed++;
  } else {
    console.error(`  ✖ FAIL: ${message}`);
    failed++;
  }
}

async function runSuite() {
  console.log("========================================================");
  console.log("  BURGER CARTEL WAVE 2 SECURITY VERIFICATION SUITE");
  console.log("========================================================\n");

  // ---------------------------------------------------------------------------
  // [Test Group 1] Asynchronous Scrypt Cryptographic Integrity & Throttling
  // ---------------------------------------------------------------------------
  console.log("[Test Group 1] Asynchronous Scrypt Cryptographic Integrity & Throttling");

  // Dynamically import compiled security module
  // Using direct node execution of the lib files
  const {
    hashPassword,
    verifyPassword,
  } = await import("../../src/lib/auth/security.ts");

  // 1.1 Hash generation
  const testPassword = "BurgerCartel@Test2026!";
  const hashResult = await hashPassword(testPassword);
  assert(
    hashResult.hash && hashResult.hash.length === 128 && hashResult.salt && hashResult.salt.length === 32,
    "Async hashPassword produces 64-byte (128 hex chars) Scrypt hash and 16-byte salt"
  );

  // 1.2 Hash verification
  const isValid = await verifyPassword(testPassword, hashResult.hash, hashResult.salt);
  assert(isValid === true, "Async verifyPassword successfully validates matching password and hash");

  // 1.3 Incorrect password rejection
  const isInvalid = await verifyPassword("WrongPassword123!", hashResult.hash, hashResult.salt);
  assert(isInvalid === false, "Async verifyPassword correctly rejects non-matching password");

  // 1.4 Input boundary validation (minimum 8 characters)
  let shortRejected = false;
  try {
    await hashPassword("short");
  } catch {
    shortRejected = true;
  }
  assert(shortRejected, "hashPassword rejects passwords under 8 characters with validation error");

  // 1.5 Input boundary validation (maximum 128 characters)
  let longRejected = false;
  try {
    await hashPassword("a".repeat(129));
  } catch {
    longRejected = true;
  }
  assert(longRejected, "hashPassword rejects passwords exceeding 128 characters (DoS prevention)");

  // 1.6 Concurrency & Throttling: burst test of 10 concurrent hashing operations
  const burstStart = Date.now();
  const burstPromises = Array.from({ length: 10 }, (_, i) =>
    hashPassword(`ConcurrentPassword#${i + 1}Val!`)
  );
  const burstResults = await Promise.all(burstPromises);
  const burstDuration = Date.now() - burstStart;
  assert(
    burstResults.length === 10 && burstResults.every(r => r.hash.length === 128),
    `Burst concurrency: 10 parallel scrypt operations resolved cleanly in ${burstDuration}ms without event-loop starvation`
  );

  // ---------------------------------------------------------------------------
  // [Test Group 2] Distributed Database Rate Limiting (rate_limit_buckets)
  // ---------------------------------------------------------------------------
  console.log("\n[Test Group 2] Distributed Database Rate Limiting (rate_limit_buckets)");

  const {
    checkRateLimitDb,
    recordFailedAttemptDb,
    resetRateLimitDb,
    cleanupExpiredBuckets,
  } = await import("../../src/lib/auth/rateLimit.ts");

  const testIpKey = `test_ip_${Date.now()}`;

  // 2.1 Initial state: key has not failed
  const initialCheck = await checkRateLimitDb(testIpKey);
  assert(
    initialCheck.allowed === true && initialCheck.remainingAttempts === 5,
    "Initial rate limit check returns allowed=true with 5 remaining attempts"
  );

  // 2.2 Record 1st failed attempt
  const fail1 = await recordFailedAttemptDb(testIpKey);
  assert(fail1.locked === false, "1st failed attempt does not lock the account/IP");

  const checkAfter1 = await checkRateLimitDb(testIpKey);
  assert(
    checkAfter1.allowed === true && checkAfter1.remainingAttempts === 4,
    "Bucket tokens decremented to 4 after first failed attempt"
  );

  // 2.3 Record 4 more failed attempts to reach threshold (total 5)
  await recordFailedAttemptDb(testIpKey); // tokens -> 3
  await recordFailedAttemptDb(testIpKey); // tokens -> 2
  await recordFailedAttemptDb(testIpKey); // tokens -> 1
  const fail5 = await recordFailedAttemptDb(testIpKey); // tokens -> 0

  assert(
    fail5.locked === true && Boolean(fail5.lockedUntil),
    "5th failed attempt triggers account lockout with lockedUntil timestamp"
  );

  const checkLocked = await checkRateLimitDb(testIpKey);
  assert(
    checkLocked.allowed === false && checkLocked.remainingAttempts === 0,
    "Locked bucket correctly returns allowed=false with 0 remaining attempts"
  );

  // 2.4 Verify database persistence in rate_limit_buckets table
  const dbBucketRows = await sql`SELECT * FROM rate_limit_buckets WHERE key = ${testIpKey}`;
  assert(
    dbBucketRows.length === 1 && dbBucketRows[0].tokens === 0,
    "Lockout state persisted in PostgreSQL rate_limit_buckets table"
  );

  // 2.5 Reset rate limit on successful authentication
  await resetRateLimitDb(testIpKey);
  const checkAfterReset = await checkRateLimitDb(testIpKey);
  assert(
    checkAfterReset.allowed === true && checkAfterReset.remainingAttempts === 5,
    "resetRateLimitDb deletes database bucket and restores full 5-attempt quota"
  );

  // 2.6 Cleanup expired buckets
  await cleanupExpiredBuckets();
  assert(true, "cleanupExpiredBuckets executes without error");

  // ---------------------------------------------------------------------------
  // [Test Group 3] Branch-Level Authorization & RBAC (admin_user_outlets)
  // ---------------------------------------------------------------------------
  console.log("\n[Test Group 3] Branch-Level Authorization & RBAC (admin_user_outlets)");

  const {
    assertAuthorizedForOutlet,
    getAuthorizedOutlets,
  } = await import("../../src/lib/auth/branchAuth.ts");

  // Retrieve existing superadmin
  const adminUsers = await sql`
    SELECT id, admin_id, role, role_id
    FROM admin_users
    WHERE role_id = 'superadmin' OR role = 'superadmin'
    LIMIT 1
  `;

  if (adminUsers.length > 0) {
    const superadminId = adminUsers[0].id;

    // 3.1 Superadmin has unrestricted access to ANY outlet
    const canManageKurseong = await assertAuthorizedForOutlet(superadminId, "kurseong");
    const canManageDarjeeling = await assertAuthorizedForOutlet(superadminId, "darjeeling");
    assert(
      canManageKurseong === true && canManageDarjeeling === true,
      "Superadmin role grants unrestricted access across all outlets (Kurseong, Darjeeling)"
    );

    // 3.2 Superadmin gets wildcard in getAuthorizedOutlets
    const authorizedOutlets = await getAuthorizedOutlets(superadminId);
    assert(
      authorizedOutlets.includes("*"),
      "getAuthorizedOutlets returns wildcard ['*'] for superadmin"
    );
  } else {
    console.warn("  ⚠ Warning: No superadmin user found in admin_users for testing.");
  }

  // 3.3 Test scoped branch manager (non-superadmin)
  // Create a temporary branch manager admin user and test IDOR isolation
  const testManagerId = crypto.randomUUID();
  try {
    await sql`
      INSERT INTO admin_users (id, admin_id, password_hash, salt, role, role_id)
      VALUES (${testManagerId}, 'TEST-BM-KURSEONG', 'dummy_hash', 'dummy_salt', 'branch_manager', 'branch_manager')
    `;

    // Without assignment: denied for all outlets
    const deniedBefore = await assertAuthorizedForOutlet(testManagerId, "kurseong");
    assert(deniedBefore === false, "Branch manager without outlet assignment is denied by default (Default Deny)");

    // Assign Kurseong only
    await sql`
      INSERT INTO admin_user_outlets (admin_id, outlet_id)
      VALUES (${testManagerId}, 'kurseong')
    `;

    // Check Kurseong (should allow)
    const allowedKurseong = await assertAuthorizedForOutlet(testManagerId, "kurseong");
    assert(allowedKurseong === true, "Branch manager with Kurseong assignment is authorized for 'kurseong'");

    // Check Darjeeling (IDOR attempt: should deny)
    const deniedDarjeeling = await assertAuthorizedForOutlet(testManagerId, "darjeeling");
    assert(deniedDarjeeling === false, "Branch manager assigned to Kurseong is strictly DENIED access to 'darjeeling' (IDOR mitigation)");

    // Scoped list verification
    const managerOutlets = await getAuthorizedOutlets(testManagerId);
    assert(
      managerOutlets.length === 1 && managerOutlets[0] === "kurseong",
      "getAuthorizedOutlets for branch manager returns strictly assigned outlet ['kurseong']"
    );
  } finally {
    // Clean up temporary test data
    await sql`DELETE FROM admin_user_outlets WHERE admin_id = ${testManagerId}`;
    await sql`DELETE FROM admin_users WHERE id = ${testManagerId}`;
  }

  // ---------------------------------------------------------------------------
  // [Test Group 4] Session Cookie RFC 6265bis __Host- Hardening & Configuration
  // ---------------------------------------------------------------------------
  console.log("\n[Test Group 4] Session Cookie RFC 6265bis __Host- Hardening & Configuration");

  const {
    BASE_COOKIE_NAME,
    HOST_COOKIE_NAME,
    NO_CACHE_HEADERS,
  } = await import("../../src/lib/auth/session.ts");

  // 4.1 Cookie naming specifications
  assert(
    BASE_COOKIE_NAME === "burger_cartel_admin_session",
    "Base cookie name is 'burger_cartel_admin_session'"
  );
  assert(
    HOST_COOKIE_NAME === "__Host-burger_cartel_admin_session",
    "Hardened production cookie name uses RFC 6265bis '__Host-' prefix"
  );

  // 4.2 Security cache-control headers
  assert(
    NO_CACHE_HEADERS["Cache-Control"].includes("no-store") &&
    NO_CACHE_HEADERS["Cache-Control"].includes("no-cache") &&
    NO_CACHE_HEADERS["Cache-Control"].includes("private"),
    "NO_CACHE_HEADERS strictly enforces 'no-store, no-cache, must-revalidate, private' on sensitive auth endpoints"
  );

  // ---------------------------------------------------------------------------
  // Summary
  // ---------------------------------------------------------------------------
  console.log("\n========================================================");
  console.log(`  WAVE 2 SECURITY RESULTS: ${passed}/${passed + failed} PASSED`);
  if (failed > 0) {
    console.error(`  ${failed} TESTS FAILED`);
    console.log("========================================================");
    process.exit(1);
  }
  console.log("========================================================\n");
}

runSuite().catch((err) => {
  console.error("FATAL SUITE ERROR:", err);
  process.exit(1);
});
