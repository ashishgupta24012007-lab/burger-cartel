#!/usr/bin/env node

/**
 * Burger Cartel HTTP Security & Authorization Matrix Suite
 * 
 * Verifies live HTTP endpoints against unauthorized access, CSRF,
 * content-type bypasses, and security header enforcement on localhost.
 */

import assert from "assert";

const TARGET_HOST = process.env.TARGET_URL || "http://localhost:3005";
const ALLOWED_HOSTS = ["localhost", "127.0.0.1", "::1"];

// Target Allowlist Guard (Operating Contract Part 3 Rule 1)
const parsedTarget = new URL(TARGET_HOST);
if (!ALLOWED_HOSTS.includes(parsedTarget.hostname)) {
  console.error(`\x1b[31m[SCOPE GUARD] Target ${parsedTarget.hostname} is outside the allowed hosts!\x1b[0m`);
  process.exit(1);
}

let passed = 0;
let total = 0;

async function test(name, fn) {
  total++;
  try {
    await fn();
    console.log(`  \x1b[32m✔\x1b[0m ${name}`);
    passed++;
  } catch (err) {
    console.error(`  \x1b[31m✖\x1b[0m ${name}`);
    console.error(`    Error: ${err.message}`);
    process.exitCode = 1;
  }
}

async function runSuite() {
  console.log("\n========================================================");
  console.log("  BURGER CARTEL HTTP SECURITY MATRIX SUITE");
  console.log(`  Target: ${TARGET_HOST} (Scope Guard: ACTIVE)`);
  console.log("========================================================\n");

  // Category 1: Authorization on Protected API Handlers
  console.log("\x1b[1m[Matrix A] Unauthenticated Access Prevention\x1b[0m");

  await test("GET /api/admin/dashboard rejects anonymous caller with 401", async () => {
    const res = await fetch(`${TARGET_HOST}/api/admin/dashboard`);
    assert.strictEqual(res.status, 401, "Anonymous dashboard access must be 401 Unauthorized.");
  });

  await test("GET /api/admin/cms rejects anonymous caller with 401", async () => {
    const res = await fetch(`${TARGET_HOST}/api/admin/cms`);
    assert.strictEqual(res.status, 401, "Anonymous CMS read access must be 401 Unauthorized.");
  });

  await test("POST /api/admin/cms rejects anonymous caller with 401", async () => {
    const res = await fetch(`${TARGET_HOST}/api/admin/cms`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "UPDATE_SITE_CONTENT", payload: {} }),
    });
    assert.strictEqual(res.status, 401, "Anonymous CMS write access must be 401 Unauthorized.");
  });

  await test("POST /api/admin/media/upload rejects anonymous caller with 401", async () => {
    const form = new FormData();
    form.append("file", new Blob(["fake"], { type: "image/jpeg" }));
    const res = await fetch(`${TARGET_HOST}/api/admin/media/upload`, {
      method: "POST",
      body: form,
    });
    assert.strictEqual(res.status, 401, "Anonymous upload access must be 401 Unauthorized.");
  });

  await test("POST /api/admin/auth/change-credentials rejects anonymous caller with 401", async () => {
    const res = await fetch(`${TARGET_HOST}/api/admin/auth/change-credentials`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ currentPassword: "foo" }),
    });
    assert.strictEqual(res.status, 401, "Anonymous credential change must be 401 Unauthorized.");
  });

  // Category 2: CSRF & Origin Defense
  console.log("\n\x1b[1m[Matrix B] CSRF & Cross-Origin Enforcement\x1b[0m");

  await test("POST /api/admin/auth/login rejects foreign Origin header with 403", async () => {
    const res = await fetch(`${TARGET_HOST}/api/admin/auth/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Origin": "https://malicious-attacker-site.com",
      },
      body: JSON.stringify({ adminId: "admin", password: "Password123!" }),
    });
    assert.strictEqual(res.status, 403, "Foreign origin POST must be 403 Forbidden.");
  });

  await test("POST /api/admin/auth/login rejects sec-fetch-site: cross-site with 403", async () => {
    const res = await fetch(`${TARGET_HOST}/api/admin/auth/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Sec-Fetch-Site": "cross-site",
      },
      body: JSON.stringify({ adminId: "admin", password: "Password123!" }),
    });
    assert.strictEqual(res.status, 403, "Cross-site tagged fetch must be 403 Forbidden.");
  });

  // Category 3: Content-Type & Payload Boundary Enforcement
  console.log("\n\x1b[1m[Matrix C] Content-Type & Input Boundary Enforcement\x1b[0m");

  await test("POST /api/admin/auth/login rejects text/plain with 415", async () => {
    const res = await fetch(`${TARGET_HOST}/api/admin/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "text/plain" },
      body: "adminId=admin&password=Password123!",
    });
    assert.strictEqual(res.status, 415, "Non-JSON POST must be 415 Unsupported Media Type.");
  });

  await test("POST /api/admin/auth/login rejects oversized credentials with 400", async () => {
    const res = await fetch(`${TARGET_HOST}/api/admin/auth/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Origin": TARGET_HOST,
      },
      body: JSON.stringify({ adminId: "a".repeat(100), password: "b".repeat(200) }),
    });
    assert.strictEqual(res.status, 400, "Oversized inputs must return 400 Bad Request.");
  });

  // Category 4: Security Headers on Live Responses
  console.log("\n\x1b[1m[Matrix D] Security Headers Verification\x1b[0m");

  await test("GET / returns all required security headers", async () => {
    const res = await fetch(`${TARGET_HOST}/`);
    assert.strictEqual(res.status, 200);

    const csp = res.headers.get("content-security-policy");
    assert.ok(csp && csp.includes("default-src 'self'"), "CSP must include default-src 'self'");
    assert.ok(csp && csp.includes("frame-ancestors 'none'"), "CSP must include frame-ancestors 'none'");

    const xcto = res.headers.get("x-content-type-options");
    assert.strictEqual(xcto, "nosniff", "X-Content-Type-Options must be nosniff.");

    const xfo = res.headers.get("x-frame-options");
    assert.strictEqual(xfo, "DENY", "X-Frame-Options must be DENY.");

    const rp = res.headers.get("referrer-policy");
    assert.strictEqual(rp, "strict-origin-when-cross-origin", "Referrer-Policy must be strict-origin-when-cross-origin.");

    const hsts = res.headers.get("strict-transport-security");
    assert.ok(hsts && hsts.includes("max-age="), "HSTS must be present.");
  });

  console.log("\n========================================================");
  console.log(`  MATRIX RESULTS: ${passed}/${total} PASSED`);
  console.log("========================================================\n");
}

runSuite().catch((err) => {
  console.error("Suite execution failure:", err);
  process.exit(1);
});
