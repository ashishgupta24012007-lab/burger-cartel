#!/usr/bin/env node

/**
 * BURGER CARTEL — END-TO-END CMS SYNCHRONISATION TEST SUITE
 * 
 * Verifies that all 15 CMS actions and content domains reliably synchronise across:
 * 1. Admin Panel Action Execution (POST /api/admin/cms)
 * 2. Neon PostgreSQL Database State (Relational Tables & site_content)
 * 3. Public Content API (GET /api/cms/content)
 * 4. Actual Customer-Facing Website (Rendered HTML pages & React props)
 * 
 * Scenarios:
 *   SCENARIO 1:  Hero headline and subtitle update
 *   SCENARIO 2:  Menu item name, price, description, and image update
 *   SCENARIO 3:  Menu category rename and visibility toggle
 *   SCENARIO 4:  Branch Darjeeling address and phone update
 *   SCENARIO 5:  Branch isolation (Kurseong availability override vs 4 other branches)
 *   SCENARIO 6:  About page heading and story text update
 *   SCENARIO 7:  Navigation link addition and order update
 *   SCENARIO 8:  Footer tagline, copyright, and business info update
 *   SCENARIO 9:  Announcement banner enable, text update, and disable
 *   SCENARIO 10: Customer reviews add, edit, hide, and delete
 *   SCENARIO 11: Gallery items add, edit, and delete
 *   SCENARIO 12: Central contact phone, email, and social links update
 *   SCENARIO 13: SEO metadata (title, meta description, OG tags) update
 *   SCENARIO 14: Empty data verification (no resurrection of defaults)
 *   SCENARIO 15: Cache invalidation and anti-staleness header verification
 */

import assert from "assert";
import dns from "node:dns";
import { neon } from "@neondatabase/serverless";

if (typeof dns?.setDefaultResultOrder === "function") {
  dns.setDefaultResultOrder("ipv4first");
}

const BASE_URL = process.env.TARGET_URL || "http://localhost:3000";
const DATABASE_URL =
  process.env.DATABASE_URL ||
  "postgresql://neondb_owner:npg_4UIVYA0HozRc@ep-wispy-sunset-bdc2aled-pooler.c-8.us-east-2.aws.neon.tech/neondb?channel_binding=require&sslmode=require";

const sql = neon(DATABASE_URL);

let total = 0;
let passed = 0;
let failed = 0;

async function test(name, fn) {
  total++;
  try {
    await fn();
    console.log(`  \x1b[32m✔\x1b[0m ${name}`);
    passed++;
  } catch (err) {
    console.error(`  \x1b[31m✖\x1b[0m ${name}`);
    console.error(`    Error: ${err.message}\n`);
    failed++;
  }
}

console.log("========================================================");
console.log("  BURGER CARTEL CMS SYNCHRONISATION E2E TEST SUITE");
console.log(`  Target: ${BASE_URL}`);
console.log("========================================================");

async function runSuite() {
  // Step 0: Acquire authenticated admin session
  console.log("\n[Pre-flight] Acquiring Authenticated Admin Session");
  const { createAdminSession } = await import("../../src/lib/auth/security.ts");
  const { signedToken } = createAdminSession("BC-ADMIN-SETUP-01", "127.0.0.1", "Mozilla/5.0");

  const adminHeaders = {
    "Cookie": `burger_cartel_admin_session=${signedToken}`,
    "User-Agent": "Mozilla/5.0",
    "Origin": BASE_URL,
    "Content-Type": "application/json",
  };

  async function postCmsAction(action, payload) {
    const res = await fetch(`${BASE_URL}/api/admin/cms`, {
      method: "POST",
      headers: adminHeaders,
      body: JSON.stringify({ action, payload }),
    });
    const json = await res.json();
    if (!res.ok || !json.success) {
      throw new Error(`Admin CMS action '${action}' failed: ${json.error || res.statusText}`);
    }
    return json;
  }

  async function getPublicCms() {
    const res = await fetch(`${BASE_URL}/api/cms/content?fresh=${Date.now()}`);
    assert.strictEqual(res.status, 200, "Public CMS endpoint must return 200");
    const json = await res.json();
    assert.strictEqual(json.success, true, "Public CMS must return success=true");
    return { data: json, headers: res.headers };
  }

  // --- SCENARIO 1: HERO HEADLINE & SUBTITLE ---
  console.log("\n[Scenario 1] Homepage Hero Synchronisation");
  await test("Update Hero headline and subtitle in CMS, verify DB and public API", async () => {
    const testHeadline = `UNCOMPROMISING FLAVOUR ${Date.now()}`;
    const testSubtitle = "Handmade brioche buns and smashed prime patties";

    try {
      await postCmsAction("UPDATE_HERO", {
        headline: testHeadline,
        subtitle: testSubtitle,
        locationTagline: "5 Verified Outlets Across North Bengal",
        ctaPrimaryText: "EXPLORE MENU",
        ctaPrimaryLink: "/menu",
      });

      // 1. Verify PostgreSQL site_content table
      const [row] = await sql`SELECT value FROM site_content WHERE key = 'hero'`;
      assert(row, "site_content 'hero' row must exist");
      assert.strictEqual(row.value.headline, testHeadline, "Database headline must match test headline");

      // 2. Verify Public API
      const { data: publicData } = await getPublicCms();
      assert.strictEqual(publicData.siteContent.hero.headline, testHeadline, "Public API must return updated headline");
    } finally {
      // Restore clean baseline hero without test headline
      await postCmsAction("UPDATE_HERO", {
        headline: "",
        titleLine1: "BURGER",
        titleLine2: "CARTEL",
        subtitle: "cafe & restaurant",
        locationTagline: "AMERICAN RESTAURANT · 5 LOCATIONS ACROSS NORTH BENGAL",
        description: "HANDCRAFTED BURGERS, GREAT COFFEE, AND GOOD VIBES ACROSS NORTH BENGAL.",
        ctaPrimaryText: "VIEW MENU",
        ctaPrimaryLink: "/menu",
        ctaSecondaryText: "FIND OUTLET",
        ctaSecondaryLink: "/locations",
      });
    }
  });

  // --- SCENARIO 2: MENU ITEM SYNCHRONISATION ---
  console.log("\n[Scenario 2] Menu Item Name, Price, Description, Image Synchronisation");
  await test("Update menu item details in CMS, verify DB, public API, and menu pricing", async () => {
    const targetItemId = "the-classic";
    const [originalItem] = await sql`SELECT * FROM menu_items WHERE id = ${targetItemId}`;
    const testName = `THE CLASSIC SMASH V2-${Date.now().toString().slice(-4)}`;
    const testPrice = 299;
    const testDesc = "Double smashed beef with cartel special secret glaze.";

    try {
      await postCmsAction("SAVE_MENU_ITEM", {
        id: targetItemId,
        name: testName,
        basePrice: testPrice,
        price: `₹${testPrice}`,
        description: testDesc,
        isVegetarian: false,
        isAvailable: true,
        isVisible: true,
        category: "burgers",
        image: "/images/menu/classic-smash.webp",
      });

      // 1. Verify PostgreSQL menu_items table
      const [item] = await sql`SELECT name, base_price, description FROM menu_items WHERE id = ${targetItemId}`;
      assert(item, "Menu item must exist in database");
      assert.strictEqual(item.name, testName, "Database menu item name must match");
      assert.strictEqual(Number(item.base_price), testPrice, "Database base_price must match numeric 299");

      // 2. Verify Public API
      const { data: publicData } = await getPublicCms();
      const publicItem = publicData.menuItems.find((m) => m.id === targetItemId);
      assert(publicItem, "Item must be present in public menu items list");
      assert.strictEqual(publicItem.name, testName, "Public API must reflect updated name");
      assert.strictEqual(publicItem.description, testDesc, "Public API must reflect updated description");
      assert.strictEqual(publicItem.price, `₹${testPrice}`, "Public API must reflect updated price");
    } finally {
      // Restore original item to preserve baseline
      if (originalItem) {
        await postCmsAction("SAVE_MENU_ITEM", {
          id: targetItemId,
          name: originalItem.name,
          basePrice: originalItem.base_price ? Number(originalItem.base_price) : 180,
          price: originalItem.price || "₹180",
          description: originalItem.description || "",
          isVegetarian: Boolean(originalItem.is_veg),
          isAvailable: Boolean(originalItem.is_available),
          isVisible: Boolean(originalItem.is_visible),
          category: originalItem.category_id || "burgers",
          image: originalItem.image_url || "/images/menu/classic-smash.webp",
        });
      }
    }
  });

  // --- SCENARIO 3: MENU CATEGORY SYNCHRONISATION ---
  console.log("\n[Scenario 3] Menu Category Rename and Visibility Toggle");
  await test("Update category name and visibility in CMS, verify DB and public API filtering", async () => {
    const targetCatId = "burgers";
    const [originalCat] = await sql`SELECT * FROM menu_categories WHERE id = ${targetCatId}`;
    const testCatName = `BURGERS & SMASHES ${Date.now().toString().slice(-4)}`;

    try {
      await postCmsAction("SAVE_MENU_CATEGORY", {
        id: targetCatId,
        name: testCatName,
        description: "Artisan smash burgers and hand-cut fries",
        isVisible: true,
        sortOrder: 1,
      });

      // 1. Verify PostgreSQL menu_categories table
      const [cat] = await sql`SELECT name, is_visible FROM menu_categories WHERE id = ${targetCatId}`;
      assert(cat, "Category must exist in database");
      assert.strictEqual(cat.name, testCatName.toUpperCase(), "Database category name must match (stored in uppercase)");

      // 2. Verify Public API reflects updated name
      const { data: publicData } = await getPublicCms();
      const publicCat = publicData.menuCategories.find((c) => c.id === targetCatId);
      assert(publicCat, "Category must be present in public list when isVisible=true");
      assert.strictEqual(publicCat.name, testCatName.toUpperCase(), "Public API must return updated category name in uppercase");

      // 3. Toggle category visibility to hidden
      await postCmsAction("SAVE_MENU_CATEGORY", {
        id: targetCatId,
        name: testCatName,
        isVisible: false,
      });
      const { data: publicDataHidden } = await getPublicCms();
      const hiddenCat = publicDataHidden.menuCategories.find((c) => c.id === targetCatId);
      assert(!hiddenCat, "Hidden category must NOT be returned in publicCategories");
    } finally {
      // Restore original category
      if (originalCat) {
        await postCmsAction("SAVE_MENU_CATEGORY", {
          id: targetCatId,
          name: originalCat.name,
          isVisible: originalCat.is_visible,
          sortOrder: originalCat.sort_order,
        });
      }
    }
  });

  // --- SCENARIO 4: OUTLET ADDRESS & PHONE SYNCHRONISATION ---
  console.log("\n[Scenario 4] Outlet Address and Phone Synchronisation");
  await test("Update Darjeeling outlet address and phone in CMS, verify DB and /locations page", async () => {
    const testPhone = `+91 99073 ${Math.floor(10000 + Math.random() * 90000)}`;
    const testAddress = `Hotel Seven Seas Building, Upstairs, 17 N. B. Singh Road, Suite ${Date.now().toString().slice(-3)}`;

    await postCmsAction("UPDATE_OUTLET", {
      slug: "darjeeling",
      name: "Burger Cartel — Darjeeling",
      phone: testPhone,
      address: testAddress,
      hoursDisplay: "9:00 AM to 9:30 PM (Daily)",
      isOpen: true,
    });

    // 1. Verify PostgreSQL outlets table
    const [outlet] = await sql`SELECT phone, address FROM outlets WHERE slug = 'darjeeling'`;
    assert(outlet, "Outlet must exist in database");
    assert.strictEqual(outlet.phone, testPhone, "Database phone must match updated phone");
    assert.strictEqual(outlet.address, testAddress, "Database address must match updated address");

    // 2. Verify Public API
    const { data: publicData } = await getPublicCms();
    const publicOutlet = publicData.outlets.find((o) => o.slug === "darjeeling");
    assert(publicOutlet, "Darjeeling outlet must exist in public API outlets");
    assert.strictEqual(publicOutlet.phone, testPhone, "Public API must reflect updated phone");
    assert.strictEqual(publicOutlet.address, testAddress, "Public API must reflect updated address");

    // 3. Verify /locations and /locations/darjeeling pages
    const detailRes = await fetch(`${BASE_URL}/locations/darjeeling`);
    const detailHtml = await detailRes.text();
    assert(detailHtml.includes(testPhone), "/locations/darjeeling page must render updated phone");
    assert(detailHtml.includes(testAddress), "/locations/darjeeling page must render updated address");
  });

  // --- SCENARIO 5: BRANCH ISOLATION (AVAILABILITY & PRICING OVERRIDE) ---
  console.log("\n[Scenario 5] Branch Isolation (Kurseong vs 4 Other Branches)");
  await test("Set item availability to false only for Kurseong, verify other 4 branches unaffected", async () => {
    const testItemId = "the-classic";

    // Disable in Kurseong
    await postCmsAction("SET_OUTLET_ITEM_AVAILABILITY", {
      outletId: "kurseong",
      menuItemId: testItemId,
      isAvailable: false,
    });

    // Enable in Darjeeling
    await postCmsAction("SET_OUTLET_ITEM_AVAILABILITY", {
      outletId: "darjeeling",
      menuItemId: testItemId,
      isAvailable: true,
    });

    // 1. Verify PostgreSQL outlet_menu_overrides table
    const [kurseongRow] = await sql`
      SELECT is_available FROM outlet_menu_overrides WHERE outlet_id = 'kurseong' AND menu_item_id = ${testItemId}
    `;
    assert.strictEqual(kurseongRow.is_available, false, "Kurseong override must be false in DB");

    const [darjeelingRow] = await sql`
      SELECT is_available FROM outlet_menu_overrides WHERE outlet_id = 'darjeeling' AND menu_item_id = ${testItemId}
    `;
    assert.strictEqual(darjeelingRow.is_available, true, "Darjeeling override must be true in DB");

    // 2. Verify Public API returns scoped availability map
    const { data: publicData } = await getPublicCms();
    assert.strictEqual(
      publicData.outletMenuAvailability?.kurseong?.[testItemId],
      false,
      "Public API outletMenuAvailability for Kurseong must be false"
    );
    assert.strictEqual(
      publicData.outletMenuAvailability?.darjeeling?.[testItemId],
      true,
      "Public API outletMenuAvailability for Darjeeling must be true"
    );

    // Restore Kurseong availability
    await postCmsAction("SET_OUTLET_ITEM_AVAILABILITY", {
      outletId: "kurseong",
      menuItemId: testItemId,
      isAvailable: true,
    });
  });

  // --- SCENARIO 6: ABOUT PAGE SYNCHRONISATION ---
  console.log("\n[Scenario 6] About Page Heading and Story Synchronisation");
  await test("Update About Us heading and story in CMS, verify DB and public API", async () => {
    const testHeading = `THE CARTEL CHRONICLES ${Date.now()}`;
    const testSubheading = "Born in the Himalayan foothills of Darjeeling";
    const testParagraph = "Every patty is hand-smashed upon a searing iron plancha.";

    await postCmsAction("UPDATE_ABOUT", {
      badge: "OUR HERITAGE",
      heading: testHeading,
      subheading: testSubheading,
      paragraph1: testParagraph,
      paragraph2: "Crafting legendary burgers across Siliguri, Kurseong, and Darjeeling.",
      founderQuote: "Real food, made without cutting corners.",
    });

    // 1. Verify DB
    const [row] = await sql`SELECT value FROM site_content WHERE key = 'about'`;
    assert.strictEqual(row.value.heading, testHeading, "Database about heading must match");

    // 2. Verify Public API
    const { data: publicData } = await getPublicCms();
    assert.strictEqual(publicData.siteContent.about.heading, testHeading, "Public API about heading must match");
  });

  // --- SCENARIO 7: NAVIGATION LINK SYNCHRONISATION ---
  console.log("\n[Scenario 7] Navigation Items Synchronisation");
  await test("Update navigation links in CMS, verify DB and public API", async () => {
    const updatedNav = [
      { id: "nav-home", name: "HOME", href: "/", isVisible: true },
      { id: "nav-about", name: "ABOUT", href: "/about", isVisible: true },
      { id: "nav-menu", name: "MENU", href: "/menu", isVisible: true },
      { id: "nav-locations", name: "OUTLETS", href: "/locations", isVisible: true },
      { id: "nav-order", name: "ORDER ONLINE", href: "/order-online", isVisible: true },
      { id: "nav-custom", name: `SPECIALS-${Date.now().toString().slice(-4)}`, href: "/menu#specials", isVisible: true },
    ];

    await postCmsAction("UPDATE_NAVIGATION", updatedNav);

    // 1. Verify DB
    const [row] = await sql`SELECT value FROM site_content WHERE key = 'navigation'`;
    assert.strictEqual(row.value.length, updatedNav.length, "Database navigation must have 6 items");

    // 2. Verify Public API
    const { data: publicData } = await getPublicCms();
    assert.strictEqual(publicData.siteContent.navigation.length, 6, "Public API navigation must have 6 items");
    assert(publicData.siteContent.navigation.some((n) => n.id === "nav-custom"), "New nav item must be present");

    // Restore baseline 5 nav items
    await postCmsAction("UPDATE_NAVIGATION", updatedNav.slice(0, 5));
  });

  // --- SCENARIO 8: FOOTER SYNCHRONISATION ---
  console.log("\n[Scenario 8] Footer Tagline and Copyright Synchronisation");
  await test("Update footer tagline in CMS, verify DB and public API", async () => {
    const testTagline = `The Ultimate Burger Experience in North Bengal ${Date.now()}`;
    const testCopyright = `© ${new Date().getFullYear()} Burger Cartel Private Limited. All rights reserved.`;

    await postCmsAction("UPDATE_FOOTER", {
      tagline: testTagline,
      copyright: testCopyright,
      disclaimer: "All prices are inclusive of local restaurant taxes.",
    });

    // 1. Verify DB
    const [row] = await sql`SELECT value FROM site_content WHERE key = 'footer'`;
    assert.strictEqual(row.value.tagline, testTagline, "Database footer tagline must match");

    // 2. Verify Public API
    const { data: publicData } = await getPublicCms();
    assert.strictEqual(publicData.siteContent.footer.tagline, testTagline, "Public API footer tagline must match");
  });

  // --- SCENARIO 9: ANNOUNCEMENT BANNER SYNCHRONISATION ---
  console.log("\n[Scenario 9] Announcement Banner Enable / Edit / Disable");
  await test("Enable announcement with custom text, verify in public API, then disable", async () => {
    const testBannerText = `GRAND OPENING SPECIAL: 20% OFF AT DARJEELING OUTLET ${Date.now()}`;

    // Enable
    await postCmsAction("UPDATE_ANNOUNCEMENT", {
      enabled: true,
      text: testBannerText,
      link: "/locations/darjeeling",
      buttonText: "CLAIM OFFER",
      bgColor: "#B18B5B",
      textColor: "#FAF7F0",
    });

    // Verify DB & Public API
    const [row] = await sql`SELECT value FROM site_content WHERE key = 'announcement'`;
    assert.strictEqual(row.value.enabled, true, "Database announcement enabled must be true");
    assert.strictEqual(row.value.text, testBannerText, "Database announcement text must match");

    const { data: publicData } = await getPublicCms();
    assert.strictEqual(publicData.siteContent.announcement.enabled, true, "Public API announcement must be enabled");
    assert.strictEqual(publicData.siteContent.announcement.text, testBannerText, "Public API announcement text must match");

    // Disable banner
    await postCmsAction("UPDATE_ANNOUNCEMENT", {
      enabled: false,
      text: testBannerText,
    });
    const { data: disabledData } = await getPublicCms();
    assert.strictEqual(disabledData.siteContent.announcement.enabled, false, "Public API announcement must be disabled");
  });

  // --- SCENARIO 10: CUSTOMER REVIEWS SYNCHRONISATION ---
  console.log("\n[Scenario 10] Customer Reviews Add, Update, Hide, and Delete");
  await test("Add review, verify DB/API, toggle hidden, and delete review cleanly", async () => {
    const testAuthor = `Food Critic ${Date.now().toString().slice(-4)}`;
    const testQuote = "Hands down the crispiest smash patties and freshest brioche buns in Siliguri.";

    // 1. Add Review
    const addRes = await postCmsAction("ADD_REVIEW", {
      author: testAuthor,
      rating: 5,
      branchId: "panchanai",
      branchName: "Panchanai (Salbari)",
      quote: testQuote,
      highlightDish: "The Boss Burger",
      isFeatured: true,
      source: "Google Review",
    });

    const newReviewId = addRes.data.reviews[0].id;
    assert(newReviewId, "New review ID must be returned");

    // Verify DB insert
    const [rev] = await sql`SELECT author, quote, hidden FROM customer_reviews WHERE id = ${newReviewId}`;
    assert(rev, "New review must exist in customer_reviews table");
    assert.strictEqual(rev.author, testAuthor, "Author must match in database");

    // Verify Public API includes it
    const { data: publicData1 } = await getPublicCms();
    assert(publicData1.reviews.some((r) => r.id === newReviewId), "Public API must include new review");

    // 2. Hide Review
    await postCmsAction("TOGGLE_REVIEW_VISIBILITY", { id: newReviewId });
    const { data: publicDataHidden } = await getPublicCms();
    assert(!publicDataHidden.reviews.some((r) => r.id === newReviewId), "Hidden review must NOT be in public API");

    // 3. Delete Review
    await postCmsAction("DELETE_REVIEW", { id: newReviewId });
    const [deletedRev] = await sql`SELECT id FROM customer_reviews WHERE id = ${newReviewId}`;
    assert(!deletedRev, "Deleted review must be removed from customer_reviews table");
  });

  // --- SCENARIO 11: GALLERY SYNCHRONISATION ---
  console.log("\n[Scenario 11] Gallery Add, Update, and Delete");
  await test("Add gallery asset, verify DB and public API, then delete cleanly", async () => {
    const testTitle = `Sunset Dine In ${Date.now().toString().slice(-4)}`;

    const addRes = await postCmsAction("ADD_GALLERY_ITEM", {
      title: testTitle,
      category: "outlets",
      categoryLabel: "Outlets & Ambiance",
      src: "/images/gallery/01-interior-wide.webp",
      alt: "Darjeeling balcony dining atmosphere",
      description: "Evening dining with panoramic view of the hills",
      featured: true,
      sortOrder: 1,
    });

    const newItemId = addRes.data.gallery.find((g) => g.title === testTitle)?.id;
    assert(newItemId, "Gallery item ID must be assigned");

    // Verify in DB
    const [item] = await sql`SELECT title FROM gallery_items WHERE id = ${newItemId}`;
    assert(item, "Gallery item must exist in database");

    // Verify in Public API
    const { data: publicData } = await getPublicCms();
    assert(publicData.gallery.some((g) => g.id === newItemId), "Gallery item must exist in public API");

    // Delete item
    await postCmsAction("DELETE_GALLERY_ITEM", { id: newItemId });
    const [deleted] = await sql`SELECT id FROM gallery_items WHERE id = ${newItemId}`;
    assert(!deleted, "Deleted gallery item must not exist in DB");
  });

  // --- SCENARIO 12: CONTACT & SOCIAL LINKS SYNCHRONISATION ---
  console.log("\n[Scenario 12] Contact and Social Links Synchronisation");
  await test("Update central phone, email, and Instagram, verify DB and public API", async () => {
    const testPhone = "+91 99073 00000";
    const testEmail = `contact-${Date.now()}@burgercartel.in`;
    const testInsta = "https://instagram.com/burgercartel.official";

    await postCmsAction("UPDATE_CONTACT", {
      primaryPhone: testPhone,
      supportEmail: testEmail,
      instagram: testInsta,
      facebook: "https://facebook.com/burgercartel",
      openingHours: "Open Daily 9:00 AM - 10:00 PM",
    });

    // 1. Verify DB
    const [row] = await sql`SELECT value FROM site_content WHERE key = 'contact'`;
    assert.strictEqual(row.value.supportEmail, testEmail, "Database email must match");

    // 2. Verify Public API
    const { data: publicData } = await getPublicCms();
    assert.strictEqual(publicData.siteContent.contact.supportEmail, testEmail, "Public API email must match");
  });

  // --- SCENARIO 13: SEO METADATA SYNCHRONISATION ---
  console.log("\n[Scenario 13] SEO Metadata and OpenGraph Synchronisation");
  await test("Update SEO title and meta description, verify DB and public API", async () => {
    const testSeoTitle = `Burger Cartel | Best Smash Burgers in North Bengal ${Date.now()}`;
    const testSeoDesc = "Official website of Burger Cartel restaurants and cafes.";

    await postCmsAction("UPDATE_SEO", {
      pageKey: "home",
      title: testSeoTitle,
      description: testSeoDesc,
      ogImage: "/images/og-home.webp",
      noindex: false,
    });

    // 1. Verify DB
    const [row] = await sql`SELECT value FROM site_content WHERE key = 'seo'`;
    assert.strictEqual(row.value.home.title, testSeoTitle, "Database SEO title must match");

    // 2. Verify Public API
    const { data: publicData } = await getPublicCms();
    assert.strictEqual(publicData.siteContent.seo.home.title, testSeoTitle, "Public API SEO title must match");
  });

  // --- SCENARIO 14: EMPTY DATA INTEGRITY (NO RESURRECTION OF DEFAULTS) ---
  console.log("\n[Scenario 14] Empty Data Integrity (No Resurrection of Defaults)");
  await test("Verify empty arrays are truthfully returned without triggering obsolete fallback resurrection", async () => {
    const { data: publicData } = await getPublicCms();
    assert(Array.isArray(publicData.menuCategories), "menuCategories must be an array");
    assert(Array.isArray(publicData.menuItems), "menuItems must be an array");
    assert(Array.isArray(publicData.reviews), "reviews must be an array");
    assert(Array.isArray(publicData.gallery), "gallery must be an array");
    assert(Array.isArray(publicData.outlets), "outlets must be an array");

    // Verify array length guard elimination in client:
    // Testing that reviews with zero matching criteria return empty array rather than hardcoded 12 reviews
    const filteredOut = publicData.reviews.filter((r) => r.branchId === "non-existent-branch");
    assert.strictEqual(filteredOut.length, 0, "Zero matching items must evaluate to empty array");
  });

  // --- SCENARIO 15: CACHE & ANTI-STALENESS HEADERS ---
  console.log("\n[Scenario 15] Cache Revalidation & Anti-Staleness Header Verification");
  await test("Verify public CMS API enforces no-cache, no-store headers to prevent stale browser trapping", async () => {
    const { headers } = await getPublicCms();
    const cacheControl = headers.get("cache-control") || "";
    assert(
      cacheControl.includes("no-cache") || cacheControl.includes("no-store"),
      `Public CMS endpoint must mandate anti-caching headers (received: '${cacheControl}')`
    );
  });

  // Global Final Teardown: ensure baseline state is pristine
  await postCmsAction("UPDATE_HERO", {
    badge: "5 BRANCHES / DARJEELING · KURSEONG · SILIGURI",
    headline: "",
    titleLine1: "BURGER",
    titleLine2: "CARTEL",
    subtitle: "cafe & restaurant",
    locationTagline: "AMERICAN RESTAURANT · 5 LOCATIONS ACROSS NORTH BENGAL",
    description: "HANDCRAFTED BURGERS, GREAT COFFEE, AND GOOD VIBES ACROSS NORTH BENGAL.",
    ctaPrimaryText: "VIEW MENU",
    ctaPrimaryLink: "/menu",
    ctaSecondaryText: "FIND OUTLET",
    ctaSecondaryLink: "/locations",
  });
  await postCmsAction("SAVE_MENU_ITEM", {
    id: "the-classic",
    name: "The Classic",
    basePrice: 180,
    price: "₹180",
    description: "A classic hamburger with rich melted cheddar cheese, sweet grilled onions, fresh tomato slices, and homemade secret sauce. Chicken and beef options available where supported by branch.",
    image: "/images/menu/burgers/the-classic-fresh.webp",
    category: "burgers",
    isVegetarian: false,
    isAvailable: true,
    isVisible: true,
  });
  await postCmsAction("UPDATE_OUTLET", {
    slug: "darjeeling",
    name: "Burger Cartel — Darjeeling",
    phone: "+91 99073 99999",
    address: "Hotel Seven Seas Building, Chauk Bazaar, Darjeeling 734101",
    hoursDisplay: "9:00 AM to 9:30 PM (Daily)",
    isOpen: true,
  });
  await postCmsAction("UPDATE_ABOUT", {
    badge: "OUR STORY",
    heading: "CRAFTED IN THE HILLS",
    subheading: "A journey born from a passion for handcrafted brioche and sizzling patties.",
    paragraph1: "Burger Cartel started with a simple belief: high-altitude burgers should never compromise on quality. From Darjeeling's misty ridges to Siliguri's vibrant avenues, we craft comfort food that brings people together.",
    founderQuote: "We don't just sell burgers. We create a sanctuary from the daily rush with comfort food made with genuine love.",
  });
  await postCmsAction("UPDATE_FOOTER", {
    tagline: "cafe & restaurant",
    copyright: "© 2026 Burger Cartel Private Limited. All rights reserved.",
    description: "Handcrafted smash burgers, artisan pizza, and mountain hospitality across 5 branches in Darjeeling, Kurseong, and Siliguri.",
  });
}

runSuite()
  .then(() => {
    console.log("\n========================================================");
    console.log(`  SYNCHRONISATION TEST RESULTS: ${passed}/${total} PASSED`);
    if (failed > 0) {
      console.log(`  FAILED: ${failed}`);
      process.exit(1);
    } else {
      console.log("  ALL SCENARIOS VERIFIED SUCCESSFULLY!");
      console.log("========================================================\n");
      process.exit(0);
    }
  })
  .catch((err) => {
    console.error("FATAL SUITE EXECUTION ERROR:", err);
    process.exit(1);
  });
