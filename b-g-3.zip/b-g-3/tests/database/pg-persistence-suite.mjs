#!/usr/bin/env node

/**
 * BURGER CARTEL DATABASE & STORAGE INTEGRATION TEST SUITE
 * Verifies Neon Managed PostgreSQL architecture, relational constraints,
 * branch availability, media persistence, and concurrency.
 */

import assert from "assert";
import { neon } from "@neondatabase/serverless";

const DATABASE_URL = process.env.DATABASE_URL || "postgresql://neondb_owner:npg_4UIVYA0HozRc@ep-wispy-sunset-bdc2aled-pooler.c-8.us-east-2.aws.neon.tech/neondb?channel_binding=require&sslmode=require";

const sql = neon(DATABASE_URL);

let total = 0;
let passed = 0;

async function test(name, fn) {
  total++;
  try {
    await fn();
    console.log(`  \x1b[32m✔\x1b[0m ${name}`);
    passed++;
  } catch (err) {
    console.error(`  \x1b[31m✖\x1b[0m ${name}`);
    console.error(`    Error: ${err.message}\n`);
  }
}

console.log("========================================================");
console.log("  BURGER CARTEL POSTGRESQL ARCHITECTURE TEST SUITE");
console.log("========================================================");

async function runSuite() {
  console.log("\n[Test Group 1] Relational Schema & Table Presence");

  await test("All 12 required production tables exist in PostgreSQL", async () => {
    const rows = await sql`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public'
    `;
    const tableNames = rows.map((r) => r.table_name);
    const required = [
      "menu_categories",
      "menu_items",
      "outlets",
      "outlet_menu_availability",
      "customer_reviews",
      "gallery_items",
      "custom_pages",
      "site_content",
      "admin_users",
      "admin_sessions",
      "audit_logs",
      "media_assets"
    ];

    for (const req of required) {
      assert(tableNames.includes(req), `Missing required table: ${req}`);
    }
  });

  console.log("\n[Test Group 2] Zero Data Loss Verification");

  await test("All 14 menu categories migrated with zero loss", async () => {
    const res = await sql`SELECT COUNT(*)::int AS count FROM menu_categories`;
    assert.strictEqual(res[0].count, 14, `Expected 14 categories, found ${res[0].count}`);
  });

  await test("All 86 menu items migrated with category relations intact", async () => {
    const res = await sql`
      SELECT COUNT(*)::int AS count 
      FROM menu_items m
      JOIN menu_categories c ON m.category_id = c.id
    `;
    assert.strictEqual(res[0].count, 86, `Expected 86 linked menu items, found ${res[0].count}`);
  });

  await test("All 5 outlets exist with verified location data", async () => {
    const res = await sql`SELECT slug, name, phone FROM outlets ORDER BY slug`;
    assert.strictEqual(res.length, 5, `Expected 5 outlets, found ${res.length}`);
    const slugs = res.map((o) => o.slug);
    assert(slugs.includes("panchanai"));
    assert(slugs.includes("pradhan-nagar"));
    assert(slugs.includes("darjeeling"));
    assert(slugs.includes("kurseong"));
    assert(slugs.includes("shivmandir"));
  });

  console.log("\n[Test Group 3] Advanced Features (Branch Availability & Media)");

  await test("Branch-specific menu availability mapping operates correctly", async () => {
    // Test toggling Bacon & Cheese unavailable at Kurseong outlet only
    const kurseongId = "kurseong";
    const testItemId = "bacon-and-cheese";

    // Set unavailable in Kurseong
    await sql`
      UPDATE outlet_menu_availability
      SET is_available = FALSE
      WHERE outlet_id = ${kurseongId} AND menu_item_id = ${testItemId}
    `;

    // Verify Kurseong is FALSE
    const kurseongStatus = await sql`
      SELECT is_available FROM outlet_menu_availability
      WHERE outlet_id = ${kurseongId} AND menu_item_id = ${testItemId}
    `;
    assert.strictEqual(kurseongStatus[0].is_available, false);

    // Verify Panchanai remains TRUE (isolated per outlet)
    const panchanaiStatus = await sql`
      SELECT is_available FROM outlet_menu_availability
      WHERE outlet_id = 'panchanai' AND menu_item_id = ${testItemId}
    `;
    assert.strictEqual(panchanaiStatus[0].is_available, true);

    // Revert back
    await sql`
      UPDATE outlet_menu_availability
      SET is_available = TRUE
      WHERE outlet_id = ${kurseongId} AND menu_item_id = ${testItemId}
    `;
  });

  await test("Persistent media storage inserts and retrieves binary base64 cleanly", async () => {
    const testFilename = "test-dish-photo-spec.webp";
    const testBase64 = Buffer.from("RIFFtestWEBPVP8Xfakeimagebytes").toString("base64");

    await sql`
      INSERT INTO media_assets (id, filename, mime_type, size_bytes, data_base64)
      VALUES ('test-id-1', ${testFilename}, 'image/webp', 28, ${testBase64})
      ON CONFLICT (filename) DO UPDATE SET data_base64 = EXCLUDED.data_base64
    `;

    const fetched = await sql`
      SELECT filename, mime_type, data_base64 
      FROM media_assets 
      WHERE filename = ${testFilename}
    `;

    assert.strictEqual(fetched.length, 1);
    assert.strictEqual(fetched[0].mime_type, "image/webp");
    assert.strictEqual(fetched[0].data_base64, testBase64);

    // Cleanup
    await sql`DELETE FROM media_assets WHERE filename = ${testFilename}`;
  });

  console.log("\n[Test Group 4] Concurrency & Optimistic Locking");

  await test("Site content updates increment version and avoid lost updates", async () => {
    const vBefore = await sql`SELECT version FROM site_content WHERE key = 'hero'`;
    const initialVersion = vBefore[0]?.version || 1;

    // Concurrently trigger 3 updates
    await Promise.all([
      sql`UPDATE site_content SET version = version + 1 WHERE key = 'hero'`,
      sql`UPDATE site_content SET version = version + 1 WHERE key = 'hero'`,
      sql`UPDATE site_content SET version = version + 1 WHERE key = 'hero'`,
    ]);

    const vAfter = await sql`SELECT version FROM site_content WHERE key = 'hero'`;
    assert.strictEqual(vAfter[0].version, initialVersion + 3);
  });

  console.log("\n[Test Group 5] Phase 2.1 Refinements (Numeric Pricing & Releases)");

  await test("All 86 menu items have numeric base prices >= 0", async () => {
    const items = await sql`SELECT id, base_price FROM menu_items`;
    assert.strictEqual(items.length, 86);
    for (const item of items) {
      assert.ok(typeof Number(item.base_price) === "number" && !isNaN(Number(item.base_price)));
      assert.ok(Number(item.base_price) >= 0, `Item ${item.id} has invalid base_price`);
    }
  });

  await test("Branch-specific pricing overrides operate independently", async () => {
    const outletId = "kurseong";
    const itemId = "the-classic";
    const overridePrice = 195.00;

    // Apply Kurseong outlet pricing override
    await sql`
      UPDATE outlet_menu_overrides
      SET price_override = ${overridePrice}
      WHERE outlet_id = ${outletId} AND menu_item_id = ${itemId}
    `;

    const kurseongOverride = await sql`
      SELECT price_override FROM outlet_menu_overrides
      WHERE outlet_id = ${outletId} AND menu_item_id = ${itemId}
    `;
    assert.strictEqual(Number(kurseongOverride[0].price_override), overridePrice);

    // Panchanai remains unaffected (NULL or base price)
    const panchanaiOverride = await sql`
      SELECT price_override FROM outlet_menu_overrides
      WHERE outlet_id = 'panchanai' AND menu_item_id = ${itemId}
    `;
    assert.strictEqual(panchanaiOverride[0].price_override, null);

    // Revert
    await sql`
      UPDATE outlet_menu_overrides
      SET price_override = NULL
      WHERE outlet_id = ${outletId} AND menu_item_id = ${itemId}
    `;
  });

  await test("CMS releases table creates and records publication snapshots", async () => {
    const res = await sql`
      INSERT INTO cms_releases (label, description, snapshot_manifest)
      VALUES ('Automated Test Release', 'Test release snapshot', '{"version": 1}'::jsonb)
      RETURNING id, release_number
    `;
    assert.ok(res.length > 0);
    assert.ok(res[0].release_number > 0);

    // Cleanup test release
    await sql`DELETE FROM cms_releases WHERE id = ${res[0].id}`;
  });

  console.log("\n[Test Group 6] Wave 1 Relational Hardening & Revision Verification");

  await test("All 26 variant groups and 90 relational variants exist in 3NF schema", async () => {
    const groups = await sql`SELECT COUNT(*)::int AS count FROM menu_item_variant_groups`;
    const variants = await sql`SELECT COUNT(*)::int AS count FROM menu_item_variants`;
    assert.strictEqual(groups[0].count, 26, `Expected 26 variant groups, found ${groups[0].count}`);
    assert.strictEqual(variants[0].count, 90, `Expected 90 variants, found ${variants[0].count}`);
  });

  await test("menu_item_revisions contains 86 baseline v1 records and enforces uniqueness", async () => {
    const revs = await sql`SELECT COUNT(*)::int AS count FROM menu_item_revisions WHERE version = 1`;
    assert.strictEqual(revs[0].count, 86, `Expected 86 baseline revisions, found ${revs[0].count}`);
    
    // Test unique constraint violation on duplicate (item_id, version)
    let threw = false;
    try {
      await sql`
        INSERT INTO menu_item_revisions (item_id, version, name, category_id, price, base_price)
        VALUES ('the-classic', 1, 'The Classic Duplicate', 'burgers', '₹190', 190.00)
      `;
    } catch {
      threw = true;
    }
    assert.ok(threw, "Expected duplicate revision insert to fail UNIQUE constraint");
  });

  await test("site_content_revisions contains 7 baseline content revisions", async () => {
    const revs = await sql`SELECT COUNT(*)::int AS count FROM site_content_revisions`;
    assert.strictEqual(revs[0].count, 7, `Expected 7 site content revisions, found ${revs[0].count}`);
  });

  await test("customer_reviews enforces foreign key constraint to outlets table", async () => {
    let threw = false;
    try {
      await sql`
        INSERT INTO customer_reviews (id, author, rating, branch_id, quote)
        VALUES ('invalid-rev-test', 'Tester', 5, 'nonexistent-outlet-id-999', 'Fake review')
      `;
    } catch {
      threw = true;
    }
    assert.ok(threw, "Expected invalid branch_id to violate fk_customer_reviews_outlet");
  });

  await test("Cryptographically chained audit logs insert and chain hashes cleanly", async () => {
    const testAdminId = "BC-ADMIN-SETUP-01";
    const testEvent = "SECURITY_TEST_CHAIN";
    const timestamp = new Date().toISOString();
    
    // Fetch last hash
    const latest = await sql`SELECT entry_hash FROM audit_logs ORDER BY timestamp DESC LIMIT 1`;
    const prevHash = latest[0]?.entry_hash || "GENESIS_BLOCK_BURGER_CARTEL_00000000000000000000000000000000";
    
    const crypto = await import("crypto");
    const entryHash = crypto.createHash("sha256").update(`${prevHash}|${testEvent}|${testAdminId}|127.0.0.1|Test details|${timestamp}`).digest("hex");

    const inserted = await sql`
      INSERT INTO audit_logs (id, event, admin_id, ip, details, timestamp, prev_hash, entry_hash)
      VALUES (gen_random_uuid(), ${testEvent}, ${testAdminId}, '127.0.0.1', 'Test details', ${timestamp}::timestamptz, ${prevHash}, ${entryHash})
      RETURNING id, entry_hash
    `;
    assert.strictEqual(inserted.length, 1);
    assert.strictEqual(inserted[0].entry_hash, entryHash);

    // Cleanup
    await sql`DELETE FROM audit_logs WHERE id = ${inserted[0].id}`;
  });

  console.log("\n========================================================");
  console.log(`  DATABASE TEST RESULTS: ${passed}/${total} PASSED`);
  console.log("========================================================");

  if (passed !== total) {
    process.exit(1);
  }
}

runSuite().catch(err => {
  console.error("Fatal suite failure:", err);
  process.exit(1);
});
