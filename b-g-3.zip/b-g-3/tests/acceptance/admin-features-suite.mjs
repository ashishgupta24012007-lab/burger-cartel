import assert from "node:assert/strict";
import dns from "node:dns";
import sharp from "sharp";
import { createAdminSession } from "../../src/lib/auth/security.ts";

if (typeof dns?.setDefaultResultOrder === "function") {
  dns.setDefaultResultOrder("ipv4first");
}

const BASE_URL = "http://localhost:3000";

async function getAdminHeaders() {
  const { signedToken } = await createAdminSession("BC-ADMIN-SETUP-01", "127.0.0.1", "Mozilla/5.0");
  return {
    "Cookie": `burger_cartel_admin_session=${signedToken}`,
    "User-Agent": "Mozilla/5.0",
    "Origin": BASE_URL,
    "Content-Type": "application/json",
  };
}

async function run() {
  console.log("=== STARTING COMPREHENSIVE ADMIN PANEL AUDIT & VERIFICATION ===");
  const adminHeaders = await getAdminHeaders();
  console.log("✓ Step 1: Admin session token generated and validated.");

  // 1. Custom Page Creation & Viewing
  console.log("\n--- Testing Custom Page Creation & Public View ---");
  const testSlug = `vip-catering-${Date.now()}`;
  const savePageRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "SAVE_CUSTOM_PAGE",
      payload: {
        title: "Exclusive Mountain Catering",
        slug: testSlug,
        subtitle: "Luxury burger pop-ups for Himalayan summits",
        content: "We provide high-altitude artisanal burger catering for private gatherings across North Bengal.",
        isPublished: true,
      },
    }),
  });
  const savePageJson = await savePageRes.json();
  assert.equal(savePageJson.success, true, `Failed to save custom page: ${JSON.stringify(savePageJson)}`);
  console.log(`✓ Custom page created successfully: /p/${testSlug}`);

  // Fetch the public custom page via HTTP
  const publicPageRes = await fetch(`${BASE_URL}/p/${testSlug}`);
  assert.equal(publicPageRes.status, 200, `Public custom page returned ${publicPageRes.status}`);
  const publicPageHtml = await publicPageRes.text();
  assert.match(publicPageHtml, /Exclusive Mountain Catering/, "Public page must contain page title");
  assert.match(publicPageHtml, /Luxury burger pop-ups/, "Public page must contain subtitle");
  console.log(`✓ Public custom page /p/${testSlug} rendered with HTTP 200 and verified content`);

  // Verify non-existent slug returns 404 cleanly
  const notFoundRes = await fetch(`${BASE_URL}/p/non-existent-page-slug-9999`);
  const notFoundHtml = await notFoundRes.text();
  assert.ok(
    notFoundRes.status === 404 || notFoundHtml.includes("404 - Page Not Found"),
    "Non-existent page must render 404 not found page"
  );
  console.log("✓ Non-existent custom page returns clean 404 not found page");

  // Clean up test page
  await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "DELETE_CUSTOM_PAGE",
      payload: { id: testSlug },
    }),
  });
  console.log(`✓ Cleaned up test page /p/${testSlug}`);

  // 2. Menu Price Switch (ON / OFF)
  console.log("\n--- Testing Menu Price Switch (ON / OFF) ---");
  // Toggle OFF
  const priceOffRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "UPDATE_MENU_SETTINGS",
      payload: { showPrices: false },
    }),
  });
  const priceOffJson = await priceOffRes.json();
  assert.equal(priceOffJson.success, true, "Toggle prices OFF must succeed");
  
  // Verify public content API reflects showPrices: false
  const contentOffRes = await fetch(`${BASE_URL}/api/cms/content`);
  const contentOffJson = await contentOffRes.json();
  assert.equal(contentOffJson.siteContent?.menuSettings?.showPrices, false, "showPrices must be false in CMS content");
  console.log("✓ Price switch turned OFF and verified in public CMS content API");

  // Toggle back ON
  const priceOnRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "UPDATE_MENU_SETTINGS",
      payload: { showPrices: true },
    }),
  });
  const priceOnJson = await priceOnRes.json();
  assert.equal(priceOnJson.success, true, "Toggle prices ON must succeed");
  
  const contentOnRes = await fetch(`${BASE_URL}/api/cms/content`);
  const contentOnJson = await contentOnRes.json();
  assert.equal(contentOnJson.siteContent?.menuSettings?.showPrices, true, "showPrices must be true in CMS content");
  console.log("✓ Price switch restored ON and verified in public CMS content API");

  // 3. Media Upload from Device (Multipart/form-data)
  console.log("\n--- Testing Select Image From Device / Media Upload ---");
  // Valid 400x300 PNG image
  const pngBuffer = await sharp({
    create: { width: 400, height: 300, channels: 3, background: { r: 255, g: 100, b: 50 } },
  })
    .png()
    .toBuffer();
  const formData = new FormData();
  formData.append("file", new Blob([pngBuffer], { type: "image/png" }), "test-upload.png");

  const uploadRes = await fetch(`${BASE_URL}/api/admin/media/upload`, {
    method: "POST",
    headers: {
      Cookie: adminHeaders.Cookie,
      Origin: BASE_URL,
      "User-Agent": "Mozilla/5.0",
    },
    body: formData,
  });
  const uploadJson = await uploadRes.json();
  assert.equal(uploadJson.success, true, `Image upload failed: ${JSON.stringify(uploadJson)}`);
  assert.ok(uploadJson.url.startsWith("/api/media/"), `Unexpected upload URL: ${uploadJson.url}`);
  console.log(`✓ Device image uploaded successfully: ${uploadJson.url}`);

  // Verify the uploaded image can be served publicly
  const mediaServeRes = await fetch(`${BASE_URL}${uploadJson.url}`);
  assert.equal(mediaServeRes.status, 200, `Media serve endpoint returned ${mediaServeRes.status}`);
  const mediaContentType = mediaServeRes.headers.get("content-type");
  assert.equal(mediaContentType, "image/webp", `Unexpected content-type: ${mediaContentType}`);
  console.log("✓ Uploaded image served publicly with HTTP 200 and image/webp Content-Type");

  // 4. Update Announcement Banner
  console.log("\n--- Testing Announcement Banner Update ---");
  const testBannerText = "🔥 Special Offer: Order Online Across Siliguri, Kurseong & Darjeeling!";
  const bannerRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "UPDATE_ANNOUNCEMENT",
      payload: {
        enabled: true,
        text: testBannerText,
        link: "/order-online",
        buttonText: "Order Now",
        bgColor: "#1F2B20",
        textColor: "#FFFFFF",
      },
    }),
  });
  const bannerJson = await bannerRes.json();
  assert.equal(bannerJson.success, true, "Banner update must succeed");
  
  const contentBannerRes = await fetch(`${BASE_URL}/api/cms/content`);
  const contentBannerJson = await contentBannerRes.json();
  assert.equal(contentBannerJson.siteContent.announcement.text, testBannerText, "Banner text must match");
  console.log("✓ Announcement banner updated and verified in public CMS content");

  // Restore clean disabled banner state
  await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "UPDATE_ANNOUNCEMENT",
      payload: {
        enabled: false,
        text: "",
        link: "/order-online",
        buttonText: "Order Now",
        bgColor: "#1F2B20",
        textColor: "#FFFFFF",
      },
    }),
  });
  console.log("✓ Announcement banner disabled and restored clean");

  // 5. Update Navigation Links
  console.log("\n--- Testing Navigation Links Update ---");
  const navRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "UPDATE_NAVIGATION",
      payload: [
        { id: "nav-home", name: "HOME", href: "/", isVisible: true },
        { id: "nav-menu", name: "MENU", href: "/menu", isVisible: true },
        { id: "nav-outlets", name: "OUTLETS", href: "/locations", isVisible: true },
        { id: "nav-about", name: "ABOUT", href: "/about", isVisible: true },
        { id: "nav-order", name: "ORDER ONLINE", href: "/order-online", isVisible: true },
      ],
    }),
  });
  const navJson = await navRes.json();
  assert.equal(navJson.success, true, "Navigation links update must succeed");
  console.log("✓ Navigation links updated and verified");

  // 6. Outlet Editing Verification
  console.log("\n--- Testing Outlet Editing ---");
  const outletRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "UPDATE_OUTLET",
      payload: {
        slug: "panchanai",
        name: "Panchanai (Flagship)",
        phone: "+91 99073 32580",
        hoursDisplay: "Open Daily: 9:00 AM - 10:00 PM",
        isOpen: true,
        address: "Panchanai, Near Sukna Army Camp, Siliguri, WB 734009",
        googleMapsUrl: "https://maps.google.com/?q=Burger+Cartel+Panchanai",
      },
    }),
  });
  const outletJson = await outletRes.json();
  assert.equal(outletJson.success, true, "Outlet update must succeed");
  console.log("✓ Panchanai outlet verified and saved");

  // 7. Verify Menu Items (The Classic description intact)
  console.log("\n--- Testing Menu Items Integrity ---");
  const contentItemsRes = await fetch(`${BASE_URL}/api/cms/content`);
  const contentItemsJson = await contentItemsRes.json();
  const theClassic = contentItemsJson.menuItems.find((m) => m.id === "the-classic");
  assert.ok(theClassic, "The Classic burger must exist in menuItems");
  assert.ok(theClassic.description && theClassic.description.length > 20, "The Classic description must be non-empty and detailed");
  console.log(`✓ The Classic burger description verified: "${theClassic.description.slice(0, 50)}..."`);

  console.log("\n=======================================================");
  console.log("✅ ALL ADMIN PANEL CAPABILITIES AUDITED & PASSED 100%!");
  console.log("=======================================================");
}

run().catch((err) => {
  console.error("TEST FAILED:", err);
  process.exit(1);
});
