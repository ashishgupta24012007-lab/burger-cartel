import assert from "node:assert/strict";
import dns from "node:dns";
import sharp from "sharp";
import { createAdminSession } from "../../src/lib/auth/security.ts";

if (typeof dns?.setDefaultResultOrder === "function") {
  dns.setDefaultResultOrder("ipv4first");
}

const BASE_URL = "http://localhost:3000";

async function getAdminHeaders(role = "superadmin") {
  const { signedToken } = await createAdminSession("BC-ADMIN-SETUP-01", "127.0.0.1", "Mozilla/5.0 (AdminTest)");
  return {
    "Cookie": `burger_cartel_admin_session=${signedToken}`,
    "User-Agent": "Mozilla/5.0 (AdminTest)",
    "Origin": BASE_URL,
    "Content-Type": "application/json",
  };
}

async function runCompleteAdminTest() {
  console.log("===============================================================================");
  console.log("🚀 STARTING EXHAUSTIVE BURGER CARTEL ADMIN PANEL VERIFICATION SUITE");
  console.log("===============================================================================\n");

  const adminHeaders = await getAdminHeaders();
  console.log("🔑 [AUTH] 1. Superadmin Session Token Successfully Generated & Signed.");

  // 1. AUTH STATUS
  console.log("\n🔒 [AUTH] 2. Checking /api/admin/auth/status...");
  const authStatusRes = await fetch(`${BASE_URL}/api/admin/auth/status`, {
    headers: {
      Cookie: adminHeaders.Cookie,
      "User-Agent": adminHeaders["User-Agent"],
    },
  });
  assert.equal(authStatusRes.status, 200, "Auth status returned non-200");
  const authStatusJson = await authStatusRes.json();
  assert.equal(authStatusJson.authenticated, true, "User must be authenticated");
  assert.equal(authStatusJson.role, "superadmin", "Role must be superadmin");
  console.log(`   ✓ Authenticated as: ${authStatusJson.adminId} (Role: ${authStatusJson.role})`);

  // 2. DASHBOARD ANALYTICS & OVERVIEW
  console.log("\n📊 [DASHBOARD] 3. Testing /api/admin/dashboard metrics...");
  const dashRes = await fetch(`${BASE_URL}/api/admin/dashboard`, {
    headers: {
      Cookie: adminHeaders.Cookie,
      "User-Agent": adminHeaders["User-Agent"],
    },
  });
  assert.equal(dashRes.status, 200, "Dashboard returned non-200");
  const dashJson = await dashRes.json();
  assert.equal(dashJson.success, true, "Dashboard failed");
  console.log(`   ✓ Persistence Layer: ${dashJson.system?.storageType}`);
  console.log(`   ✓ Active Sessions: ${dashJson.system?.activeSessionsCount}`);
  console.log(`   ✓ Active Outlets: ${dashJson.outlets?.length}`);
  console.log(`   ✓ Audit Logs Tracked: ${dashJson.recentLogs?.length}`);

  // 3. MENU CATEGORY CRUD
  console.log("\n🍔 [MENU] 4. Testing Menu Category Creation & Deletion...");
  const testCatId = `test-cat-${Date.now()}`;
  const saveCatRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "SAVE_MENU_CATEGORY",
      payload: {
        id: testCatId,
        name: "Artisan Truffle Burgers",
        description: "Seasonal limited edition truffle-infused smash burgers",
        isVisible: true,
        sortOrder: 99,
      },
    }),
  });
  const saveCatJson = await saveCatRes.json();
  assert.equal(saveCatJson.success, true, `Save category failed: ${JSON.stringify(saveCatJson)}`);
  console.log(`   ✓ Menu Category '${testCatId}' created.`);

  // Delete Category
  const delCatRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "DELETE_MENU_CATEGORY",
      payload: { id: testCatId },
    }),
  });
  const delCatJson = await delCatRes.json();
  assert.equal(delCatJson.success, true, "Delete category failed");
  console.log(`   ✓ Menu Category '${testCatId}' deleted and cleaned up.`);

  // 4. MENU ITEM CRUD & IMMEDIATE PUBLICATION
  console.log("\n🍟 [MENU] 5. Testing Menu Item Creation, Pricing & Deletion...");
  const testItemId = `item-test-${Date.now()}`;
  const saveItemRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "SAVE_MENU_ITEM",
      payload: {
        id: testItemId,
        category: "burgers",
        name: "The Royal Himalayan Smash",
        description: "Double chicken patty with smoked cheese, caramelized onions and spicy mayo.",
        price: "₹299",
        basePrice: 299,
        isVeg: false,
        isVegetarian: false,
        isAvailable: true,
        isVisible: true,
      },
    }),
  });
  const saveItemJson = await saveItemRes.json();
  assert.equal(saveItemJson.success, true, `Save item failed: ${JSON.stringify(saveItemJson)}`);
  console.log(`   ✓ Menu item created with basePrice 299: '${testItemId}'`);

  // Verify item is present in public content
  const contentAfterItemRes = await fetch(`${BASE_URL}/api/cms/content`);
  const contentAfterItemJson = await contentAfterItemRes.json();
  const createdItem = contentAfterItemJson.menuItems.find((m) => m.id === testItemId);
  assert.ok(createdItem, "Item must immediately appear in public menu items list");
  assert.equal(createdItem.name, "The Royal Himalayan Smash");
  console.log(`   ✓ Menu item verified in live public website content API.`);

  // Clean up item
  const delItemRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "DELETE_MENU_ITEM",
      payload: { id: testItemId },
    }),
  });
  const delItemJson = await delItemRes.json();
  assert.equal(delItemJson.success, true, "Delete item failed");
  console.log(`   ✓ Test menu item deleted and cleaned up.`);

  // 5. BRANCH AVAILABILITY & PRICE OVERRIDES
  console.log("\n📍 [BRANCH CONTROLS] 6. Testing Branch Availability & Price Overrides...");
  const branchAvailRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "SET_OUTLET_ITEM_AVAILABILITY",
      payload: {
        outletId: "panchanai",
        menuItemId: "the-classic",
        isAvailable: true,
      },
    }),
  });
  const branchAvailJson = await branchAvailRes.json();
  assert.equal(branchAvailJson.success, true, "Set outlet availability failed");
  console.log("   ✓ Panchanai availability for 'the-classic' updated.");

  const branchPriceRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "SET_OUTLET_MENU_PRICE_OVERRIDE",
      payload: {
        outletId: "darjeeling",
        menuItemId: "the-classic",
        priceOverride: 220,
      },
    }),
  });
  const branchPriceJson = await branchPriceRes.json();
  assert.equal(branchPriceJson.success, true, "Set price override failed");
  console.log("   ✓ Darjeeling branch price override (₹220) applied atomically without resetting availability.");

  // 6. OUTLET MANAGEMENT
  console.log("\n🏢 [OUTLETS] 7. Testing Outlet Management Updates...");
  const outletUpdateRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "UPDATE_OUTLET",
      payload: {
        slug: "panchanai",
        name: "Panchanai (Flagship)",
        phone: "+91 99073 32580",
        hoursDisplay: "Open Daily: 9:00 AM - 10:00 PM",
        isOpen: true,
        address: "Panchanai, Near Sukna Army Camp, Siliguri, WB 734009",
        googleMapsUrl: "https://maps.google.com/?q=Burger+Cartel+Panchanai",
      },
    }),
  });
  const outletUpdateJson = await outletUpdateRes.json();
  assert.equal(outletUpdateJson.success, true, "Outlet update failed");
  console.log("   ✓ Panchanai outlet details updated.");

  // 7. SITE CONTENT (Hero, Announcement, Navigation, Footer, SEO)
  console.log("\n📝 [CONTENT] 8. Testing Site Content Section Updates...");
  const updateHeroRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "UPDATE_HERO",
      payload: {
        badgeText: "HIMALAYAN SMASH BURGER CULTURE",
        titleLine1: "RAW SMASH.",
        titleLine2: "PURE CARTEL.",
        subtitle: "Five legendary destinations across Siliguri, Darjeeling & Kurseong serving handcrafted smashed patties and single-origin coffee.",
        ctaPrimaryText: "ORDER ONLINE NOW",
        ctaPrimaryLink: "/order-online",
        ctaSecondaryText: "EXPLORE MENU",
        ctaSecondaryLink: "/menu",
      },
    }),
  });
  const updateHeroJson = await updateHeroRes.json();
  assert.equal(updateHeroJson.success, true, "Hero update failed");
  console.log("   ✓ Hero section updated.");

  const updateAnnounceRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "UPDATE_ANNOUNCEMENT",
      payload: {
        enabled: false,
        text: "",
        link: "/order-online",
        buttonText: "Order Now",
        bgColor: "#1F2B20",
        textColor: "#FFFFFF",
      },
    }),
  });
  const updateAnnounceJson = await updateAnnounceRes.json();
  assert.equal(updateAnnounceJson.success, true, "Announcement update failed");
  console.log("   ✓ Announcement banner updated.");

  // 8. CUSTOMER REVIEWS CRUD
  console.log("\n⭐ [REVIEWS] 9. Testing Customer Reviews Management...");
  const testRevId = `rev-${Date.now()}`;
  const saveRevRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "ADD_REVIEW",
      payload: {
        id: testRevId,
        author: "Pooja Sharma",
        rating: 5,
        branchId: "panchanai",
        branchName: "Panchanai",
        quote: "Best smash burger in North Bengal! The brioche buns are buttery and so soft.",
        highlightDish: "The Classic",
        source: "google",
      },
    }),
  });
  const saveRevJson = await saveRevRes.json();
  assert.equal(saveRevJson.success, true, "Add review failed");
  console.log("   ✓ Review added.");

  // Clean up review
  const delRevRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "DELETE_REVIEW",
      payload: { id: testRevId },
    }),
  });
  const delRevJson = await delRevRes.json();
  assert.equal(delRevJson.success, true, "Delete review failed");
  console.log("   ✓ Test review deleted.");

  // 9. GALLERY CRUD
  console.log("\n🖼️ [GALLERY] 10. Testing Gallery Item Management...");
  const testGalId = `gal-${Date.now()}`;
  const saveGalRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "ADD_GALLERY_ITEM",
      payload: {
        id: testGalId,
        title: "Evening Cartel Vibe",
        category: "vibes",
        categoryLabel: "Atmosphere",
        src: "/images/gallery/01-interior-wide.webp",
        alt: "Warm interior lighting at Burger Cartel",
        description: "Cozy community vibes in Siliguri",
        featured: true,
        sortOrder: 1,
      },
    }),
  });
  const saveGalJson = await saveGalRes.json();
  assert.equal(saveGalJson.success, true, "Add gallery item failed");
  console.log("   ✓ Gallery item added.");

  const delGalRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "DELETE_GALLERY_ITEM",
      payload: { id: testGalId, force: true },
    }),
  });
  const delGalJson = await delGalRes.json();
  assert.equal(delGalJson.success, true, "Delete gallery item failed");
  console.log("   ✓ Test gallery item deleted.");

  // 10. MEDIA ASSET UPLOAD WITH SHARP PROCESSING
  console.log("\n📸 [MEDIA STORAGE] 11. Testing Device Media Upload with Sharp & Magic Bytes...");
  const testImageBuffer = await sharp({
    create: { width: 400, height: 300, channels: 3, background: { r: 240, g: 120, b: 60 } },
  })
    .png()
    .toBuffer();

  const formData = new FormData();
  formData.append("file", new Blob([testImageBuffer], { type: "image/png" }), "dish-special.png");

  const uploadRes = await fetch(`${BASE_URL}/api/admin/media/upload`, {
    method: "POST",
    headers: {
      Cookie: adminHeaders.Cookie,
      Origin: BASE_URL,
      "User-Agent": adminHeaders["User-Agent"],
    },
    body: formData,
  });
  const uploadJson = await uploadRes.json();
  assert.equal(uploadJson.success, true, `Upload failed: ${JSON.stringify(uploadJson)}`);
  assert.ok(uploadJson.url.startsWith("/api/media/"), "Upload URL must start with /api/media/");
  console.log(`   ✓ Image processed with Sharp and stored in PostgreSQL: ${uploadJson.url}`);

  // Fetch served media
  const serveMediaRes = await fetch(`${BASE_URL}${uploadJson.url}`);
  assert.equal(serveMediaRes.status, 200, "Media endpoint returned non-200");
  assert.equal(serveMediaRes.headers.get("content-type"), "image/webp", "Media served as WebP");
  console.log("   ✓ Media asset served publicly with HTTP 200 and image/webp Content-Type.");

  // 11. POSTGRESQL BACKUP & SNAPSHOTS
  console.log("\n💾 [BACKUPS] 12. Testing PostgreSQL Database Snapshot Creation & Listing...");
  const backupRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "CREATE_BACKUP",
      payload: { label: "Automated Suite Snapshot" },
    }),
  });
  const backupJson = await backupRes.json();
  assert.equal(backupJson.success, true, `Backup creation failed: ${JSON.stringify(backupJson)}`);
  console.log(`   ✓ PostgreSQL backup created: '${backupJson.backup?.id || "snapshot"}'`);

  const listBackupsRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({ action: "LIST_BACKUPS" }),
  });
  const listBackupsJson = await listBackupsRes.json();
  assert.equal(listBackupsJson.success, true, "List backups failed");
  assert.ok(Array.isArray(listBackupsJson.backups), "Backups must be an array");
  console.log(`   ✓ Verified ${listBackupsJson.backups.length} database snapshots in PostgreSQL.`);

  // 12. CONTENT PUBLISHING & RELEASES
  console.log("\n🚀 [PUBLISHING] 13. Testing Content Publishing & Release Manifests...");
  const publishRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({
      action: "PUBLISH_ALL",
      payload: { label: "Automated Verification Release" },
    }),
  });
  const publishJson = await publishRes.json();
  assert.equal(publishJson.success, true, `Publish release failed: ${JSON.stringify(publishJson)}`);
  console.log("   ✓ Release published successfully.");

  const releasesRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: adminHeaders,
    body: JSON.stringify({ action: "LIST_RELEASES" }),
  });
  const releasesJson = await releasesRes.json();
  assert.equal(releasesJson.success, true, "List releases failed");
  assert.ok(Array.isArray(releasesJson.releases), "Releases must be an array");
  console.log(`   ✓ Total tracked releases in PostgreSQL: ${releasesJson.releases.length}`);

  // 13. SECURITY GATES & RBAC DEFENSES
  console.log("\n🛡️ [SECURITY] 14. Testing Security Gates (CSRF, Unauth, Role-Check)...");
  
  // Cross-Origin Request -> Must return 403
  const csrfRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: {
      ...adminHeaders,
      Origin: "https://evil-attacker-site.com",
    },
    body: JSON.stringify({ action: "LIST_BACKUPS" }),
  });
  assert.equal(csrfRes.status, 403, "Cross-origin request must be rejected with 403");
  console.log("   ✓ CSRF Defense: Cross-origin request rejected with HTTP 403.");

  // Unauthenticated Request -> Must return 401
  const unauthRes = await fetch(`${BASE_URL}/api/admin/cms`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Origin: BASE_URL,
      "User-Agent": "Mozilla/5.0",
    },
    body: JSON.stringify({ action: "LIST_BACKUPS" }),
  });
  assert.equal(unauthRes.status, 401, "Unauthenticated request must be rejected with 401");
  console.log("   ✓ Auth Defense: Unauthenticated request rejected with HTTP 401.");

  // 14. ADMIN PANEL FRONTEND ROUTE
  console.log("\n🖥️ [UI] 15. Testing /admin-panel page load...");
  const adminPageRes = await fetch(`${BASE_URL}/admin-panel`);
  assert.equal(adminPageRes.status, 200, "/admin-panel page returned non-200");
  const adminPageHtml = await adminPageRes.text();
  assert.ok(adminPageHtml.includes("BURGER CARTEL") || adminPageHtml.includes("Admin"), "/admin-panel HTML rendered");
  console.log("   ✓ Admin panel UI loads with HTTP 200 OK.");

  console.log("\n===============================================================================");
  console.log("🎉 ALL 15 CRITICAL ADMIN PANEL SUBSYSTEMS & APIs PASSED 100%!");
  console.log("===============================================================================\n");
}

runCompleteAdminTest().catch((err) => {
  console.error("\n❌ SUITE EXECUTION FAILED:", err);
  process.exit(1);
});
